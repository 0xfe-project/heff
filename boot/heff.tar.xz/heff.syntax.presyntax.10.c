// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_EndValue 24675
#define TAG_IInvalid 29207
#define TAG_MkAlt 55173
#define TAG_MkBinding 51651
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SetPath 11095
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_bound 295286168
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_giving 701566649
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth__giving__bound[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving, LBL_bound};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1350453750x1419818528_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1350453750x1419818528_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s381243888x312298213_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s564340418x743780676_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s605646493x1315728604_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s605646493x1315728604_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtBy_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2easAction(V, V, V);
V g_heff_2esyntax_2epresyntax_2easAction_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2easAction_clo;
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ecoNames_get(void);
V g_heff_2esyntax_2epresyntax_2eendOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_clo;
V g_heff_2esyntax_2epresyntax_2eguardE(V, V);
V g_heff_2esyntax_2epresyntax_2eguardE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eguardE_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2eliftE(V, V, V);
V g_heff_2esyntax_2epresyntax_2eliftE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eliftE_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ementions(V, V);
V g_heff_2esyntax_2epresyntax_2ementions_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ementions_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo;
V g_heff_2esyntax_2epresyntax_2erightTuple(V, V);
V g_heff_2esyntax_2epresyntax_2erightTuple_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2erightTuple_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V, V);
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1538488470x1742347707_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eutf8Of(V);
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewithBoundOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_clo;
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_clo;
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_get(void);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s717144537x1885076661(V);
V g_list_2eany_24s717144537x1885076661_entry(V self, V *a);
extern Clo g_list_2eany_24s717144537x1885076661_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s57109758x1528051153(V, V);
V g_list_2efoldl_24s57109758x1528051153_entry(V self, V *a);
extern Clo g_list_2efoldl_24s57109758x1528051153_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1238159332x1367432882(V);
V g_list_2emap_24s1238159332x1367432882_entry(V self, V *a);
extern Clo g_list_2emap_24s1238159332x1367432882_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esegmentOdd_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2esegmentOdd(V v_ty_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(v_ty_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2esegmentOdd(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str3, 0, "");
Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eutf8Of_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eutf8Of(V v_c_240) {
top: ;
  if (heff_intLt_c_lent(v_c_240, MK_INT(128LL), 2)) {
    return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(1LL), v_c_240, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str0)));
  } else {
    if (heff_intLt_c_lent(v_c_240, MK_INT(2048LL), 2)) {
      int64_t v_t_241 = (((int64_t)192ULL) + (heff_peek_word(v_c_240) / ((int64_t)64ULL)));
      int64_t v_t_242 = ((v_t_241 * ((int64_t)256ULL)) + ((int64_t)128ULL));
      int64_t v_t_243 = (v_t_242 + (heff_unbox_word(v_c_240) % ((int64_t)64ULL)));
      return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(2LL), heff_box_word(v_t_243), ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str1)));
    } else {
      if (heff_intLt_c_lent(v_c_240, MK_INT(65536LL), 2)) {
        int64_t v_t_244 = (((int64_t)224ULL) + (heff_peek_word(v_c_240) / ((int64_t)4096ULL)));
        int64_t v_t_245 = ((v_t_244 * ((int64_t)256ULL)) + ((int64_t)128ULL));
        int64_t v_t_246 = ((heff_peek_word(v_c_240) / ((int64_t)64ULL)) % ((int64_t)64ULL));
        int64_t v_t_247 = ((v_t_245 + v_t_246) * ((int64_t)256ULL));
        int64_t v_t_248 = ((v_t_247 + ((int64_t)128ULL)) + (heff_unbox_word(v_c_240) % ((int64_t)64ULL)));
        return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(3LL), heff_box_word(v_t_248), ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str2)));
      } else {
        V v_t_249 = heff_intAdd(MK_INT(240LL), heff_intDiv_lent(v_c_240, MK_INT(262144LL), 2));
        V v_t_2410 = heff_intAdd(heff_intMul(v_t_249, MK_INT(256LL)), MK_INT(128LL));
        V v_t_2411 = heff_intMod(heff_intDiv_lent(v_c_240, MK_INT(4096LL), 2), MK_INT(64LL));
        V v_t_2412 = heff_intMul(heff_intAdd(v_t_2410, v_t_2411), MK_INT(256LL));
        V v_t_2413 = heff_intMod(heff_intDiv_lent(v_c_240, MK_INT(64LL), 2), MK_INT(64LL));
        V v_t_2414 = heff_intAdd(heff_intAdd(v_t_2412, MK_INT(128LL)), v_t_2413);
        V v_t_2415 = heff_intAdd(heff_intMul(v_t_2414, MK_INT(256LL)), MK_INT(128LL));
        V v_t_2416 = heff_intAdd(v_t_2415, heff_intMod(v_c_240, MK_INT(64LL)));
        return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(4LL), v_t_2416, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str3)));
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eutf8Of(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str1, 4, "Unit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str2, 14, "prelude.typeOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str3, 14, "prelude.typeOf");
V g_heff_2esyntax_2epresyntax_2evarParams_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2evarParams_lam1(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2evarParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evarParams_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2evarParams(V v_sp_240, V v_unit_241, V v_vars_242) {
top: ;
  if ((heff_dup(v_unit_241) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_vars_242)) {
    case TAG_Nil: {
      V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str0)}), heff_dup(v_sp_240)});
      V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str1)}), v_sp_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_t_244}), NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      return (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evarParams_lam0, 1, 1, (V[]){v_sp_240}), v_vars_242));
    }
    default: return heff_nomatch(v_vars_242);
    }
  } else {
    return (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evarParams_lam1, 1, 1, (V[]){v_sp_240}), v_vars_242));
  }
}
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2evarParams(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2epresyntax_2evarParams_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str2)}), heff_dup(v_sp_240)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_247)}), heff_dup(v_sp_240)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_248, v_t_2410));
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_247}), v_sp_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_t_2411});
}
V g_heff_2esyntax_2epresyntax_2evarParams_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str3)}), heff_dup(v_sp_240)});
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2413)}), heff_dup(v_sp_240)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  V v_t_2417 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2414, v_t_2416));
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_2413}), v_sp_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_t_2417});
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ejumpCall_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpCall_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ejumpCall(V v_cx_240, V v_sp_241, V v_j_242) {
top: ;
  V v_vars_243 = heff_take_field(v_j_242, 1);
  V v_unit_244 = heff_take_field(v_j_242, 2);
  V v_head_245 = heff_take_field(v_j_242, 0);
  V v_depth_246 = heff_get_n(v_j_242, 3, 4);
  V v_vars_247 = v_vars_243;
  V v_t_248 = v_unit_244;
  V v_t_2412;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    switch (heff_tag_of(v_vars_247)) {
    case TAG_Nil: {
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ejumpCall_str0)}), heff_dup(v_sp_241)});
      v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      v_t_2412 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_247));
      break;
    }
    default: heff_nomatch(v_vars_247);
    }
  } else {
    heff_drop(v_t_248);
    v_t_2412 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_247));
  }
  V v_t_2413 = (g_heff_2esyntax_2epresyntax_2eapp(v_head_245, v_t_2412));
  V v_t_2414 = heff_intSub(heff_dup(heff_rfield(v_cx_240, 4)), v_depth_246);
  return (g_heff_2esyntax_2epresyntax_2eleaving(v_cx_240, v_sp_241, v_t_2414, v_t_2413));
}
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpCall(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epatNames_24dps_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2esyntax_2epresyntax_2epatNames_24dps_str0), 2)) {
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        heff_drop(v_x_244);
        return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
      } else {
        V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
        return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_245);
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_249); r_; });
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2410);
    }
    case TAG_PatOp: {
      V v_ps_2413 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2413));
      V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2414); r_; });
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2415);
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2421 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2421));
      V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2422); r_; });
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2423);
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2425 = heff_field(v_x11_242, 0);
      V v_q_2427 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 5ULL, 3);
      V v_cell_2428 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2425, heff_hole()});
      V v_u_2429 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2428);
      V t_0 = v_q_2427;
      V t_1 = v_u_2429;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2epatNames_24dps(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_a_2410 = heff_field(v_a_244, 4);
        V v_ru_24a_244_24MkSegment = heff_take_reuse_n(v_a_244, 31ULL, 5);
        V v_a_2440;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2440 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_246)) {
          case TAG_At: {
            V v_a_2411 = heff_dup(heff_field(v_a_246, 0));
            switch (heff_tag_of(v_a_2411)) {
            case TAG_ELam: {
              heff_take_n(v_a_2411, 0ULL, 2);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_a_2411, 0ULL, 4);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            default: {
              heff_drop(v_a_2411);
              HeffT2 v_t_2435 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_246)));
              {
                V v_field_2436 = v_t_2435.f[0];
                V v_field_2437 = v_t_2435.f[1];
                V v_a_2438 = v_field_2436;
                V v_a_2439 = v_field_2437;
                heff_drop(v_a_2439);
                v_a_2440 = v_a_2438;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_246);
          }
        }
        V v_t_2441 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkSegment, TAG_MkSegment, 5, 31ULL, (V[]){v_a_246, v_a_247, v_a_248, v_a_249, v_a_2410}), v_a_245});
        V v_cell_2442 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2441, heff_hole()});
        HeffT2 v_t_2443 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24dps_24cpr(v_a_2440, v_xs_243, v_cell_2442));
        {
          V v_field_2444 = v_t_2443.f[0];
          V v_field_2445 = v_t_2443.f[1];
          V v_x_2446 = v_field_2444;
          V v__5f_2447 = v_field_2445;
          heff_drop(v__5f_2447);
          return ((HeffT2){{v_x_2446, v_cell_2442}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str0, 2, "v#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str1, 2, "v#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str2, 2, "v#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str3, 2, "v#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str4, 2, "v#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str5, 2, "v#");
V g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V v_l_240, V v_acc_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_At: {
    V v_e1_243 = heff_dup(heff_field(v_e_242, 0));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_ELam: {
      V v_b_245 = heff_field(v_e1_243, 0);
      V v_body_246 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24ELam = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_248 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_249 = heff_get_n(heff_get_n(v_l_240, 1, 2), 0, 2);
        V v_t_2410 = heff_rec_n(2, shape_muts__inLam, (V[]){v_t_249, NTAG(TAG_True)});
        V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eguardE(v_t_2410, v_body_246));
        V v_t_2412 = heff_tag_re_n(v_ru_24e_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24e1_243_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_b_245, v_t_2411}), v_sp_248});
        return ((HeffT2){{v_acc_241, v_t_2412}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_EMatch: {
      V v_s_2413 = heff_field(v_e1_243, 0);
      V v_alts_2414 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24EMatch = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_2416 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        HeffT2 v_t_2417 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_dup(v_l_240), v_acc_241, v_s_2413));
        {
          V v_field_2418 = v_t_2417.f[0];
          V v_field_2419 = v_t_2417.f[1];
          V v_x_2420 = v_field_2418;
          V v_y_2421 = v_field_2419;
          V v_t_2422 = (g_list_2eany_24s717144537x1885076661(v_alts_2414));
          if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
            heff_drop(v_t_2422);
            V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){heff_dup(v_l_240)}));
            V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2easAction_clo), 2, (V[]){v_t_2423, heff_get_n(v_l_240, 0, 2)}));
            V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ealtBy_clo), 1, (V[]){v_t_2424}));
            V v_t_2426 = (g_list_2emap(v_t_2425, v_alts_2414));
            V v_t_2427 = heff_intShow(heff_dup(heff_rfield(v_sp_2416, 0)));
            V v_t_2428 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_2421, v_t_2426}), heff_dup(v_sp_2416)});
            V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str0), v_t_2427), v_t_2428});
            V v_f_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_x_2420});
            V v_t_2431 = heff_intShow(heff_dup(heff_rfield(v_sp_2416, 0)));
            V v_t_2432 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str1), v_t_2431)});
            V v_f_2433 = heff_tag_n(TAG_At, 2, (V[]){v_t_2432, v_sp_2416});
            return ((HeffT2){{v_f_2430, v_f_2433}});
          } else {
            heff_drop(v_t_2422);
            V v_f_2434 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
            HeffT2 v_t_2445 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0, 2, 1, (V[]){v_f_2434}), v_x_2420, v_alts_2414));
            {
              V v_field_2446 = v_t_2445.f[0];
              V v_field_2447 = v_t_2445.f[1];
              V v_x_2448 = v_field_2446;
              V v_y_2449 = v_field_2447;
              V v_t_2450 = heff_tag_re_n(v_ru_24e_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24e1_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_2421, v_y_2449}), v_sp_2416});
              return ((HeffT2){{v_x_2448, v_t_2450}});
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2451 = heff_field(v_e1_243, 0);
      V v_e12_2452 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24ELetIn = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_2454 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        switch (heff_tag_of(v_e12_2452)) {
        case TAG_At: {
          V v_e121_2455 = heff_field(v_e12_2452, 0);
          V v_asp_2456 = heff_field(v_e12_2452, 1);
          V v_ru_24e12_2452_24At = heff_take_reuse_n(v_e12_2452, 3ULL, 2);
          switch (heff_tag_of(v_e121_2455)) {
          case TAG_MkAlt: {
            V v_p_2457 = heff_field(v_e121_2455, 0);
            V v_body_2458 = heff_field(v_e121_2455, 1);
            V v_ru_24e121_2455_24MkAlt = heff_take_reuse_n(v_e121_2455, 3ULL, 2);
            HeffT2 v_t_2459 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_dup(v_l_240), v_acc_241, v_rhs_2451));
            {
              V v_field_2460 = v_t_2459.f[0];
              V v_field_2461 = v_t_2459.f[1];
              V v_x_2462 = v_field_2460;
              V v_y_2463 = v_field_2461;
              V v_t_2493;
              switch (heff_tag_of(v_body_2458)) {
              case TAG_At: {
                V v_e1_2464 = heff_dup(heff_field(v_body_2458, 0));
                switch (heff_tag_of(v_e1_2464)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_2464, 0ULL, 2);
                  switch (heff_tag_of(v_body_2458)) {
                  case TAG_At: {
                    v_t_2493 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_body_2458);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_2464, 0ULL, 1);
                  switch (heff_tag_of(v_body_2458)) {
                  case TAG_At: {
                    v_t_2493 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_body_2458);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_2464, 0ULL, 1);
                  switch (heff_tag_of(v_body_2458)) {
                  case TAG_At: {
                    v_t_2493 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_body_2458);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_2464, 0ULL, 1);
                  switch (heff_tag_of(v_body_2458)) {
                  case TAG_At: {
                    v_t_2493 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_body_2458);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_2464, 0ULL, 1);
                  switch (heff_tag_of(v_body_2458)) {
                  case TAG_At: {
                    v_t_2493 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_body_2458);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_2464, 0ULL, 4);
                  switch (heff_tag_of(v_body_2458)) {
                  case TAG_At: {
                    v_t_2493 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_body_2458);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_2464);
                  HeffT2 v_t_2488 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_body_2458)));
                  {
                    V v_field_2489 = v_t_2488.f[0];
                    V v_field_2490 = v_t_2488.f[1];
                    V v_x_2491 = v_field_2489;
                    V v_y_2492 = v_field_2490;
                    heff_drop(v_y_2492);
                    v_t_2493 = v_x_2491;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_body_2458);
              }
              if ((heff_dup(v_t_2493) == NTAG(TAG_True))) {
                heff_drop(v_t_2493);
                V v_cx_2494 = heff_dup(heff_rfield(v_l_240, 0));
                HeffT2 v_t_2495 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, NTAG(TAG_Nil), v_body_2458));
                {
                  V v_field_2496 = v_t_2495.f[0];
                  V v_field_2497 = v_t_2495.f[1];
                  V v_x_2498 = v_field_2496;
                  V v_y_2499 = v_field_2497;
                  V v_t_24102;
                  switch (heff_tag_of(v_y_2499)) {
                  case TAG_At: {
                    V v_s_24101 = heff_dup(heff_field(v_y_2499, 1));
                    v_t_24102 = v_s_24101;
                    break;
                  }
                  default: heff_nomatch(v_y_2499);
                  }
                  V v_t_24103 = heff_get_n(heff_dup(heff_rfield(v_cx_2494, 0)), 1, 3);
                  V v_t_24104 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24103}), v_t_24102});
                  V v_t_24105 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_2499, NTAG(TAG_Nil)});
                  V v_t_24106 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24104, v_t_24105));
                  V v_t_24107 = ({ V a_0 = v_cx_2494; V a_1 = v_x_2498; V a_2 = v_t_24106; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2498); r_; });
                  V v_t_24108 = heff_intShow(heff_dup(heff_rfield(v_sp_2454, 0)));
                  V v_t_24109 = heff_tag_re_n(v_ru_24e12_2452_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24e121_2455_24MkAlt, TAG_MkAlt, 2, 1ULL, (V[]){v_p_2457, v_t_24107}), v_asp_2456});
                  V v_t_24110 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_2463, v_t_24109}), heff_dup(v_sp_2454)});
                  V v_t_24111 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str2), v_t_24108), v_t_24110});
                  V v_f_24112 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24111, v_x_2462});
                  V v_t_24113 = heff_intShow(heff_dup(heff_rfield(v_sp_2454, 0)));
                  V v_t_24114 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str3), v_t_24113)});
                  V v_f_24115 = heff_tag_n(TAG_At, 2, (V[]){v_t_24114, v_sp_2454});
                  return ((HeffT2){{v_f_24112, v_f_24115}});
                }
              } else {
                heff_drop(v_t_2493);
                HeffT2 v_t_24116 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_x_2462, v_body_2458));
                {
                  V v_field_24117 = v_t_24116.f[0];
                  V v_field_24118 = v_t_24116.f[1];
                  V v_x_24119 = v_field_24117;
                  V v_y_24120 = v_field_24118;
                  V v_t_24121 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24e121_2455_24MkAlt, TAG_MkAlt, 2, 1ULL, (V[]){v_p_2457, v_y_24120}), v_asp_2456});
                  V v_t_24122 = heff_tag_at_n(v_ru_24e12_2452_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_2463, v_t_24121}), v_sp_2454});
                  return ((HeffT2){{v_x_24119, v_t_24122}});
                }
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_e121_2455)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_e12_2452)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24123 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24EDo = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24125 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_24126 = heff_tag_re_n(v_ru_24e_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24e1_243_24EDo, TAG_EDo, 1, 1ULL, (V[]){v_ss_24123}), v_sp_24125});
        V v_t_24127 = (g_heff_2esyntax_2epresyntax_2eguardE(heff_get_n(v_l_240, 1, 2), v_t_24126));
        return ((HeffT2){{v_acc_241, v_t_24127}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_ENest: {
      V v_c_24128 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ENest = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24130 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        HeffT2 v_t_24131 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_acc_241, v_c_24128));
        {
          V v_field_24132 = v_t_24131.f[0];
          V v_field_24133 = v_t_24131.f[1];
          V v_x_24134 = v_field_24132;
          V v_y_24135 = v_field_24133;
          V v_t_24136 = heff_intShow(heff_dup(heff_rfield(v_sp_24130, 0)));
          V v_t_24137 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str4), v_t_24136), v_y_24135});
          V v_f_24138 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24137, v_x_24134});
          V v_t_24139 = heff_intShow(heff_dup(heff_rfield(v_sp_24130, 0)));
          V v_t_24140 = heff_tag_at_n(v_ru_24e1_243_24ENest, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str5), v_t_24139)});
          V v_f_24141 = heff_tag_re_n(v_ru_24e_242_24At, TAG_At, 2, 2ULL, (V[]){v_t_24140, v_sp_24130});
          return ((HeffT2){{v_f_24138, v_f_24141}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_ELazy: {
      V v_body_24142 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ELazy = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24144 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_24145 = heff_get_n(heff_get_n(v_l_240, 1, 2), 0, 2);
        V v_t_24146 = heff_rec_n(2, shape_muts__inLam, (V[]){v_t_24145, NTAG(TAG_True)});
        V v_t_24147 = (g_heff_2esyntax_2epresyntax_2eguardE(v_t_24146, v_body_24142));
        V v_t_24148 = heff_tag_re_n(v_ru_24e_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELazy, TAG_ELazy, 1, (V[]){v_t_24147}), v_sp_24144});
        return ((HeffT2){{v_acc_241, v_t_24148}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24149 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ETry = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      heff_drop_rec(v_l_240, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24151 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_24152 = heff_tag_re_n(v_ru_24e_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24e1_243_24ETry, TAG_ETry, 1, 1ULL, (V[]){v_tr_24149}), v_sp_24151});
        return ((HeffT2){{v_acc_241, v_t_24152}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_EWith: {
      V v_w_24153 = heff_field(v_e1_243, 0);
      V v_x_24154 = heff_field(v_e1_243, 1);
      V v_xsp_24155 = heff_field(v_e1_243, 2);
      V v_body_24156 = heff_field(v_e1_243, 3);
      V v_ru_24e1_243_24EWith = heff_take_reuse_n(v_e1_243, 15ULL, 4);
      heff_drop_rec(v_l_240, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24158 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_24159 = heff_tag_re_n(v_ru_24e_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24e1_243_24EWith, TAG_EWith, 4, 15ULL, (V[]){v_w_24153, v_x_24154, v_xsp_24155, v_body_24156}), v_sp_24158});
        return ((HeffT2){{v_acc_241, v_t_24159}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_EWithBound: {
      V v_bs_24160 = heff_field(v_e1_243, 0);
      V v_w_24161 = heff_field(v_e1_243, 1);
      V v_body_24162 = heff_field(v_e1_243, 2);
      V v_ru_24e1_243_24EWithBound = heff_take_reuse_n(v_e1_243, 7ULL, 3);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24164 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_f_24165 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){heff_dup(v_l_240)}));
        HeffT2 v_t_24177 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam1, 2, 1, (V[]){v_f_24165}), v_acc_241, v_bs_24160));
        {
          V v_field_24178 = v_t_24177.f[0];
          V v_field_24179 = v_t_24177.f[1];
          V v_x_24180 = v_field_24178;
          V v_y_24181 = v_field_24179;
          V v_t_24182 = heff_tag_re_n(v_ru_24e_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24e1_243_24EWithBound, TAG_EWithBound, 3, 6ULL, (V[]){v_y_24181, v_w_24161, v_body_24162}), v_sp_24164});
          V v_t_24183 = (g_heff_2esyntax_2epresyntax_2eguardE(heff_get_n(v_l_240, 1, 2), v_t_24182));
          return ((HeffT2){{v_x_24180, v_t_24183}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    default: {
      heff_drop(v_e1_243);
      V v_t_24184 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24184, v_acc_241, v_e_242);
    }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0(V self, V *args) {
  V v_st_2435 = args[0];
  V v_x3_2436 = args[1];
  V v_f_2434 = heff_env(self)[0];
  switch (heff_tag_of(v_x3_2436)) {
  case TAG_At: {
    V v_x31_2437 = heff_field(v_x3_2436, 0);
    V v_sp_2438 = heff_field(v_x3_2436, 1);
    V v_ru_24x3_2436_24At = heff_take_reuse_n(v_x3_2436, 3ULL, 2);
    switch (heff_tag_of(v_x31_2437)) {
    case TAG_MkAlt: {
      V v_p_2439 = heff_field(v_x31_2437, 0);
      V v_e_2440 = heff_field(v_x31_2437, 1);
      V v_ru_24x31_2437_24MkAlt = heff_take_reuse_n(v_x31_2437, 3ULL, 2);
      heff_clo_take(self, 1);
      V v_x1_2441 = heff_tr(heff_call(v_f_2434, 2, (V[]){v_st_2435, v_e_2440}));
      switch (heff_tag_of(v_x1_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x1_2441, 0);
        V v_y_2443 = heff_field(v_x1_2441, 1);
        V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
        V v_t_2444 = heff_tag_re_n(v_ru_24x3_2436_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_2437_24MkAlt, TAG_MkAlt, 2, 1ULL, (V[]){v_p_2439, v_y_2443}), v_sp_2438});
        return heff_tag_re_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_2442, v_t_2444});
      }
      default: return heff_nomatch(v_x1_2441);
      }
    }
    default: return heff_nomatch(v_x31_2437);
    }
  }
  default: return heff_nomatch(v_x3_2436);
  }
}
V g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam1(V self, V *args) {
  V v_st_24166 = args[0];
  V v_x3_24167 = args[1];
  V v_f_24165 = heff_env(self)[0];
  switch (heff_tag_of(v_x3_24167)) {
  case TAG_At: {
    V v_x31_24168 = heff_field(v_x3_24167, 0);
    V v_sp_24169 = heff_field(v_x3_24167, 1);
    V v_ru_24x3_24167_24At = heff_take_reuse_n(v_x3_24167, 3ULL, 2);
    switch (heff_tag_of(v_x31_24168)) {
    case TAG_MkBinding: {
      V v_x_24170 = heff_field(v_x31_24168, 0);
      V v_xsp_24171 = heff_field(v_x31_24168, 1);
      V v_e_24172 = heff_field(v_x31_24168, 2);
      V v_ru_24x31_24168_24MkBinding = heff_take_reuse_n(v_x31_24168, 7ULL, 3);
      heff_clo_take(self, 1);
      V v_x1_24173 = heff_tr(heff_call(v_f_24165, 2, (V[]){v_st_24166, v_e_24172}));
      switch (heff_tag_of(v_x1_24173)) {
      case TAG_MkPair: {
        V v_x_24174 = heff_field(v_x1_24173, 0);
        V v_y_24175 = heff_field(v_x1_24173, 1);
        V v_ru_24x1_24173_24MkPair = heff_take_reuse_n(v_x1_24173, 3ULL, 2);
        V v_t_24176 = heff_tag_re_n(v_ru_24x3_24167_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_24168_24MkBinding, TAG_MkBinding, 3, 3ULL, (V[]){v_x_24170, v_xsp_24171, v_y_24175}), v_sp_24169});
        return heff_tag_re_n(v_ru_24x1_24173_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_24174, v_t_24176});
      }
      default: return heff_nomatch(v_x1_24173);
      }
    }
    default: return heff_nomatch(v_x31_24168);
    }
  }
  default: return heff_nomatch(v_x3_24167);
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s605646493x1315728604_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24SetPath = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_2422;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2422 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_247)) {
          case TAG_At: {
            V v_a_248 = heff_dup(heff_field(v_a_247, 0));
            switch (heff_tag_of(v_a_248)) {
            case TAG_ELam: {
              heff_take_n(v_a_248, 0ULL, 2);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2422 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2422 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            default: {
              heff_drop(v_a_248);
              HeffT2 v_t_2417 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_247)));
              {
                V v_field_2418 = v_t_2417.f[0];
                V v_field_2419 = v_t_2417.f[1];
                V v_a_2420 = v_field_2418;
                V v_a_2421 = v_field_2419;
                heff_drop(v_a_2421);
                v_a_2422 = v_a_2420;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_247);
          }
        }
        V v_t_2423 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24SetPath, TAG_SetPath, 2, 3ULL, (V[]){v_a_246, v_a_247}), v_a_245});
        V v_cell_2424 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
        HeffT2 v_t_2425 = (g_heff_2esyntax_2epresyntax_2eaccList_24s605646493x1315728604_24dps_24cpr(v_a_2422, v_xs_243, v_cell_2424));
        {
          V v_field_2426 = v_t_2425.f[0];
          V v_field_2427 = v_t_2425.f[1];
          V v_x_2428 = v_field_2426;
          V v__5f_2429 = v_field_2427;
          heff_drop(v__5f_2429);
          return ((HeffT2){{v_x_2428, v_cell_2424}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s605646493x1315728604_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_SetPath: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_ru_24a_247_24SetPath = heff_take_reuse_n(v_a_247, 3ULL, 2);
        V v_a_2425;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2425 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_2410)) {
          case TAG_At: {
            V v_a_2411 = heff_dup(heff_field(v_a_2410, 0));
            switch (heff_tag_of(v_a_2411)) {
            case TAG_ELam: {
              heff_take_n(v_a_2411, 0ULL, 2);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2425 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2425 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            default: {
              heff_drop(v_a_2411);
              HeffT2 v_t_2420 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_2410)));
              {
                V v_field_2421 = v_t_2420.f[0];
                V v_field_2422 = v_t_2420.f[1];
                V v_a_2423 = v_field_2421;
                V v_a_2424 = v_field_2422;
                heff_drop(v_a_2424);
                v_a_2425 = v_a_2423;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_2410);
          }
        }
        V v_t_2426 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24SetPath, TAG_SetPath, 2, 3ULL, (V[]){v_a_249, v_a_2410}), v_a_248});
        V v_cell_2427 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
        V v_u_2428 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2427);
        V t_0 = v_a_2425;
        V t_1 = v_xs_246;
        V t_2 = v_u_2428;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1350453750x1419818528_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkBinding: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24MkBinding = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_a_2423;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2423 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_248)) {
          case TAG_At: {
            V v_a_249 = heff_dup(heff_field(v_a_248, 0));
            switch (heff_tag_of(v_a_249)) {
            case TAG_ELam: {
              heff_take_n(v_a_249, 0ULL, 2);
              switch (heff_tag_of(v_a_248)) {
              case TAG_At: {
                v_a_2423 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_248);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_249, 0ULL, 1);
              switch (heff_tag_of(v_a_248)) {
              case TAG_At: {
                v_a_2423 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_248);
              }
              break;
            }
            default: {
              heff_drop(v_a_249);
              HeffT2 v_t_2418 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_248)));
              {
                V v_field_2419 = v_t_2418.f[0];
                V v_field_2420 = v_t_2418.f[1];
                V v_a_2421 = v_field_2419;
                V v_a_2422 = v_field_2420;
                heff_drop(v_a_2422);
                v_a_2423 = v_a_2421;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_248);
          }
        }
        V v_t_2424 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkBinding, TAG_MkBinding, 3, 7ULL, (V[]){v_a_246, v_a_247, v_a_248}), v_a_245});
        V v_cell_2425 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
        HeffT2 v_t_2426 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1350453750x1419818528_24dps_24cpr(v_a_2423, v_xs_243, v_cell_2425));
        {
          V v_field_2427 = v_t_2426.f[0];
          V v_field_2428 = v_t_2426.f[1];
          V v_x_2429 = v_field_2427;
          V v__5f_2430 = v_field_2428;
          heff_drop(v__5f_2430);
          return ((HeffT2){{v_x_2429, v_cell_2425}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_247;
    if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
      heff_drop(v_st_240);
      v_st_247 = NTAG(TAG_True);
    } else {
      heff_drop(v_st_240);
      v_st_247 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_x_245)));
    }
    V v_cell_248 = heff_tag_re_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_245, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
    V t_0 = v_st_247;
    V t_1 = v_xs_246;
    V t_2 = v_u_249;
    v_st_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_dup(heff_field(v_x3_241, 0));
    switch (heff_tag_of(v_x31_242)) {
    case TAG_EVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENotationVar: {
      heff_take_n(v_x31_242, 0ULL, 3);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EBinary: {
      V v_segs_2413 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EBinary = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2415 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2416 = (g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(v_st_240, v_segs_2413));
        {
          V v_field_2417 = v_t_2416.f[0];
          V v_field_2418 = v_t_2416.f[1];
          V v_x_2419 = v_field_2417;
          V v_y_2420 = v_field_2418;
          V v_t_2421 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24EBinary, TAG_EBinary, 1, (V[]){v_y_2420}), v_sp_2415});
          return ((HeffT2){{v_x_2419, v_t_2421}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EApp: {
      V v_h_2424 = heff_field(v_x31_242, 0);
      V v_args_2425 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EApp = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2427 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2428;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2428 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2428 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_h_2424)));
        }
        HeffT2 v_t_2429 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24cpr(v_x_2428, v_args_2425));
        {
          V v_field_2430 = v_t_2429.f[0];
          V v_field_2431 = v_t_2429.f[1];
          V v_x_2432 = v_field_2430;
          V v_y_2433 = v_field_2431;
          V v_t_2434 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EApp, TAG_EApp, 2, 1ULL, (V[]){v_h_2424, v_y_2433}), v_sp_2427});
          return ((HeffT2){{v_x_2432, v_t_2434}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENamed: {
      V v_x_2436 = heff_field(v_x31_242, 0);
      V v_e_2437 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ENamed = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2439 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2440;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2440 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2440 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2437)));
        }
        V v_t_2441 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ENamed, TAG_ENamed, 2, 3ULL, (V[]){v_x_2436, v_e_2437}), v_sp_2439});
        return ((HeffT2){{v_x_2440, v_t_2441}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ELam: {
      V v_b_2444 = heff_field(v_x31_242, 0);
      V v_body_2445 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELam = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2447 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2448;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2448 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2448 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_body_2445)));
        }
        V v_t_2449 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELam, TAG_ELam, 2, 3ULL, (V[]){v_b_2444, v_body_2445}), v_sp_2447});
        return ((HeffT2){{v_x_2448, v_t_2449}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2450 = heff_field(v_x31_242, 0);
      V v_t_2451 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EAnn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2453 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2454;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2454 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2454 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2450)));
        }
        V v_t_2455 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EAnn, TAG_EAnn, 2, 3ULL, (V[]){v_e_2450, v_t_2451}), v_sp_2453});
        return ((HeffT2){{v_x_2454, v_t_2455}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESpec: {
      V v_a_2456 = heff_field(v_x31_242, 0);
      V v_x_2457 = heff_field(v_x31_242, 1);
      V v_xsp_2458 = heff_field(v_x31_242, 2);
      V v_v_2459 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24ESpec = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2461 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_2462 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_2456, v_x_2457, v_xsp_2458, v_v_2459}), v_sp_2461});
          return ((HeffT2){{NTAG(TAG_True), v_t_2462}});
        } else {
          heff_drop(v_st_240);
          V v_x_2463 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_2456)));
          V v_x_2464;
          if ((heff_dup(v_x_2463) == NTAG(TAG_True))) {
            heff_drop(v_x_2463);
            v_x_2464 = NTAG(TAG_True);
          } else {
            heff_drop(v_x_2463);
            v_x_2464 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_v_2459)));
          }
          V v_t_2465 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_2456, v_x_2457, v_xsp_2458, v_v_2459}), v_sp_2461});
          return ((HeffT2){{v_x_2464, v_t_2465}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EStruct: {
      V v_fs_2468 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EStruct = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2470 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2471 = (g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24cpr(v_st_240, v_fs_2468));
        {
          V v_field_2472 = v_t_2471.f[0];
          V v_field_2473 = v_t_2471.f[1];
          V v_x_2474 = v_field_2472;
          V v_y_2475 = v_field_2473;
          V v_t_2476 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24EStruct, TAG_EStruct, 1, (V[]){v_y_2475}), v_sp_2470});
          return ((HeffT2){{v_x_2474, v_t_2476}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_2477 = heff_field(v_x31_242, 0);
      V v_fs_2478 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EUpdate = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2480 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2481;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2481 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2481 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_2477)));
        }
        HeffT2 v_t_2482 = (g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24cpr(v_x_2481, v_fs_2478));
        {
          V v_field_2483 = v_t_2482.f[0];
          V v_field_2484 = v_t_2482.f[1];
          V v_x_2485 = v_field_2483;
          V v_y_2486 = v_field_2484;
          V v_t_2487 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EUpdate, TAG_EUpdate, 2, 1ULL, (V[]){v_a_2477, v_y_2486}), v_sp_2480});
          return ((HeffT2){{v_x_2485, v_t_2487}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EMatch: {
      V v_s_2488 = heff_field(v_x31_242, 0);
      V v_alts_2489 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EMatch = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2491 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2492;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2492 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2492 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_s_2488)));
        }
        HeffT2 v_t_2493 = (g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24cpr(v_x_2492, v_alts_2489));
        {
          V v_field_2494 = v_t_2493.f[0];
          V v_field_2495 = v_t_2493.f[1];
          V v_x_2496 = v_field_2494;
          V v_y_2497 = v_field_2495;
          V v_t_2498 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EMatch, TAG_EMatch, 2, 1ULL, (V[]){v_s_2488, v_y_2497}), v_sp_2491});
          return ((HeffT2){{v_x_2496, v_t_2498}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2499 = heff_field(v_x31_242, 0);
      V v_a_24100 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELetIn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24102 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_24100)) {
          case TAG_At: {
            V v_x31_24103 = heff_field(v_a_24100, 0);
            V v_sp_24104 = heff_field(v_a_24100, 1);
            V v_ru_24a_24100_24At = heff_take_reuse_n(v_a_24100, 3ULL, 2);
            switch (heff_tag_of(v_x31_24103)) {
            case TAG_MkAlt: {
              V v_p_24105 = heff_field(v_x31_24103, 0);
              V v_e_24106 = heff_field(v_x31_24103, 1);
              V v_ru_24x31_24103_24MkAlt = heff_take_reuse_n(v_x31_24103, 3ULL, 2);
              V v_t_24107 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_24103_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_p_24105, v_e_24106}), v_sp_24104});
              V v_t_24108 = heff_tag_at_n(v_ru_24a_24100_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, 1ULL, (V[]){v_rhs_2499, v_t_24107}), v_sp_24102});
              return ((HeffT2){{NTAG(TAG_True), v_t_24108}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24103)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24100)}});
          }
        } else {
          heff_drop(v_st_240);
          V v_x_24109 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_rhs_2499)));
          switch (heff_tag_of(v_a_24100)) {
          case TAG_At: {
            V v_x31_24110 = heff_field(v_a_24100, 0);
            V v_sp_24111 = heff_field(v_a_24100, 1);
            V v_ru_24a_24100_24At = heff_take_reuse_n(v_a_24100, 3ULL, 2);
            switch (heff_tag_of(v_x31_24110)) {
            case TAG_MkAlt: {
              V v_p_24112 = heff_field(v_x31_24110, 0);
              V v_e_24113 = heff_field(v_x31_24110, 1);
              V v_ru_24x31_24110_24MkAlt = heff_take_reuse_n(v_x31_24110, 3ULL, 2);
              V v_x_24114;
              if ((heff_dup(v_x_24109) == NTAG(TAG_True))) {
                heff_drop(v_x_24109);
                v_x_24114 = NTAG(TAG_True);
              } else {
                heff_drop(v_x_24109);
                v_x_24114 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24113)));
              }
              V v_t_24115 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_24110_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_p_24112, v_e_24113}), v_sp_24111});
              V v_t_24116 = heff_tag_at_n(v_ru_24a_24100_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, 1ULL, (V[]){v_rhs_2499, v_t_24115}), v_sp_24102});
              return ((HeffT2){{v_x_24114, v_t_24116}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24110)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24100)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24117 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EDo = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24119 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24120 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_st_240, v_ss_24117));
        {
          V v_field_24121 = v_t_24120.f[0];
          V v_field_24122 = v_t_24120.f[1];
          V v_x_24123 = v_field_24121;
          V v_y_24124 = v_field_24122;
          V v_t_24125 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24EDo, TAG_EDo, 1, (V[]){v_y_24124}), v_sp_24119});
          return ((HeffT2){{v_x_24123, v_t_24125}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EAssign: {
      V v_x_24129 = heff_field(v_x31_242, 0);
      V v_xsp_24130 = heff_field(v_x31_242, 1);
      V v_e_24131 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EAssign = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24133 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24134;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24134 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24134 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24131)));
        }
        V v_t_24135 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EAssign, TAG_EAssign, 3, 7ULL, (V[]){v_x_24129, v_xsp_24130, v_e_24131}), v_sp_24133});
        return ((HeffT2){{v_x_24134, v_t_24135}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24136 = heff_field(v_x31_242, 0);
      V v_body_24137 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EWhile = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24139 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24140;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24140 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24140 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_c_24136)));
        }
        HeffT2 v_t_24141 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_24140, v_body_24137));
        {
          V v_field_24142 = v_t_24141.f[0];
          V v_field_24143 = v_t_24141.f[1];
          V v_x_24144 = v_field_24142;
          V v_y_24145 = v_field_24143;
          V v_t_24146 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EWhile, TAG_EWhile, 2, 1ULL, (V[]){v_c_24136, v_y_24145}), v_sp_24139});
          return ((HeffT2){{v_x_24144, v_t_24146}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EFor: {
      V v_p_24147 = heff_field(v_x31_242, 0);
      V v_c_24148 = heff_field(v_x31_242, 1);
      V v_body_24149 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EFor = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24151 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24152;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24152 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24152 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_c_24148)));
        }
        HeffT2 v_t_24153 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_24152, v_body_24149));
        {
          V v_field_24154 = v_t_24153.f[0];
          V v_field_24155 = v_t_24153.f[1];
          V v_x_24156 = v_field_24154;
          V v_y_24157 = v_field_24155;
          V v_t_24158 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EFor, TAG_EFor, 3, 3ULL, (V[]){v_p_24147, v_c_24148, v_y_24157}), v_sp_24151});
          return ((HeffT2){{v_x_24156, v_t_24158}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24159 = heff_field(v_x31_242, 0);
      V v_a_24160 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EIfThen = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24162 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_24163 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24159, v_a_24160}), v_sp_24162});
          return ((HeffT2){{NTAG(TAG_True), v_t_24163}});
        } else {
          heff_drop(v_st_240);
          V v_x_24164 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_c_24159)));
          V v_x_24165;
          if ((heff_dup(v_x_24164) == NTAG(TAG_True))) {
            heff_drop(v_x_24164);
            v_x_24165 = NTAG(TAG_True);
          } else {
            heff_drop(v_x_24164);
            v_x_24165 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_24160)));
          }
          V v_t_24166 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24159, v_a_24160}), v_sp_24162});
          return ((HeffT2){{v_x_24165, v_t_24166}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EBreak: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EReturn: {
      V v_e_24167 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EReturn = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24169 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24170;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24170 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24170 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24167)));
        }
        V v_t_24171 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EReturn, TAG_EReturn, 1, 1ULL, (V[]){v_e_24167}), v_sp_24169});
        return ((HeffT2){{v_x_24170, v_t_24171}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ENest: {
      V v_e_24172 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ENest = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24174 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24175;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24175 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24175 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24172)));
        }
        V v_t_24176 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ENest, TAG_ENest, 1, 1ULL, (V[]){v_e_24172}), v_sp_24174});
        return ((HeffT2){{v_x_24175, v_t_24176}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24177 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ELazy = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24179 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24180;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24180 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24180 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24177)));
        }
        V v_t_24181 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELazy, TAG_ELazy, 1, 1ULL, (V[]){v_e_24177}), v_sp_24179});
        return ((HeffT2){{v_x_24180, v_t_24181}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24182 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETuple = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24184 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24185 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24cpr(v_st_240, v_es_24182));
        {
          V v_field_24186 = v_t_24185.f[0];
          V v_field_24187 = v_t_24185.f[1];
          V v_x_24188 = v_field_24186;
          V v_y_24189 = v_field_24187;
          V v_t_24190 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETuple, TAG_ETuple, 1, (V[]){v_y_24189}), v_sp_24184});
          return ((HeffT2){{v_x_24188, v_t_24190}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24191 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETry = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24193 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        switch (heff_tag_of(v_tr_24191)) {
        case TAG_MkTry: {
          V v_err_24194 = heff_field(v_tr_24191, 0);
          V v_body_24195 = heff_field(v_tr_24191, 1);
          V v_c_24196 = heff_field(v_tr_24191, 2);
          V v_ru_24tr_24191_24MkTry = heff_take_reuse_n(v_tr_24191, 7ULL, 3);
          HeffT2 v_t_24197 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_st_240, v_body_24195));
          {
            V v_field_24198 = v_t_24197.f[0];
            V v_field_24199 = v_t_24197.f[1];
            V v_x_24200 = v_field_24198;
            V v_y_24201 = v_field_24199;
            switch (heff_tag_of(v_c_24196)) {
            case TAG_MkCatchArm: {
              V v_b_24202 = heff_field(v_c_24196, 0);
              V v_ss_24203 = heff_field(v_c_24196, 1);
              V v_ru_24c_24196_24MkCatchArm = heff_take_reuse_n(v_c_24196, 3ULL, 2);
              HeffT2 v_t_24204 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_24200, v_ss_24203));
              {
                V v_field_24205 = v_t_24204.f[0];
                V v_field_24206 = v_t_24204.f[1];
                V v_x_24207 = v_field_24205;
                V v_y_24208 = v_field_24206;
                V v_t_24209 = heff_tag_re_n(v_ru_24tr_24191_24MkTry, TAG_MkTry, 3, 1ULL, (V[]){v_err_24194, v_y_24201, heff_tag_re_n(v_ru_24c_24196_24MkCatchArm, TAG_MkCatchArm, 2, 1ULL, (V[]){v_b_24202, v_y_24208})});
                V v_t_24210 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETry, TAG_ETry, 1, (V[]){v_t_24209}), v_sp_24193});
                return ((HeffT2){{v_x_24207, v_t_24210}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_c_24196)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_tr_24191)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWith: {
      V v_w_24211 = heff_field(v_x31_242, 0);
      V v_x_24212 = heff_field(v_x31_242, 1);
      V v_xsp_24213 = heff_field(v_x31_242, 2);
      V v_body_24214 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24EWith = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24216 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24217;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24217 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24217 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_w_24211)));
        }
        HeffT2 v_t_24218 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_24217, v_body_24214));
        {
          V v_field_24219 = v_t_24218.f[0];
          V v_field_24220 = v_t_24218.f[1];
          V v_x_24221 = v_field_24219;
          V v_y_24222 = v_field_24220;
          V v_t_24223 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EWith, TAG_EWith, 4, 7ULL, (V[]){v_w_24211, v_x_24212, v_xsp_24213, v_y_24222}), v_sp_24216});
          return ((HeffT2){{v_x_24221, v_t_24223}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWithBound: {
      V v_bs_24224 = heff_field(v_x31_242, 0);
      V v_w_24225 = heff_field(v_x31_242, 1);
      V v_body_24226 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EWithBound = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24228 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24229 = (g_heff_2esyntax_2epresyntax_2eaccList_24s381243888x312298213_24cpr(v_st_240, v_bs_24224));
        {
          V v_field_24230 = v_t_24229.f[0];
          V v_field_24231 = v_t_24229.f[1];
          V v_x_24232 = v_field_24230;
          V v_y_24233 = v_field_24231;
          switch (heff_tag_of(v_w_24225)) {
          case TAG_Nothing: {
            V v_t_24234 = heff_tag_re_n(v_ru_24x31_242_24EWithBound, TAG_EWithBound, 3, 4ULL, (V[]){v_y_24233, NTAG(TAG_Nothing), v_body_24226});
            return ((HeffT2){{v_x_24232, heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24234, v_sp_24228})}});
          }
          case TAG_Just: {
            V v_e_24235 = heff_field(v_w_24225, 0);
            V v_ru_24w_24225_24Just = heff_take_reuse_n(v_w_24225, 1ULL, 1);
            V v_x_24236;
            if ((heff_dup(v_x_24232) == NTAG(TAG_True))) {
              heff_drop(v_x_24232);
              v_x_24236 = NTAG(TAG_True);
            } else {
              heff_drop(v_x_24232);
              v_x_24236 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24235)));
            }
            V v_t_24237 = heff_tag_re_n(v_ru_24x31_242_24EWithBound, TAG_EWithBound, 3, 4ULL, (V[]){v_y_24233, heff_tag_re_n(v_ru_24w_24225_24Just, TAG_Just, 1, 1ULL, (V[]){v_e_24235}), v_body_24226});
            return ((HeffT2){{v_x_24236, heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24237, v_sp_24228})}});
          }
          default: return ((HeffT2){{heff_nomatch(v_w_24225)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s564340418x743780676_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    HeffT3 v_t_247 = (g_heff_2esyntax_2epresyntax_2estmtAcc_24s1538488470x1742347707_24cpr(v_st_240, v_x_245));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_field_2410 = v_t_247.f[2];
      V v_st_2411 = v_field_248;
      V v_y_2412 = heff_tag_n(TAG_At, 2, (V[]){v_field_249, v_field_2410});
      V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_2412, heff_hole()});
      V v_u_2414 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2413);
      V t_0 = v_st_2411;
      V t_1 = v_xs_246;
      V t_2 = v_u_2414;
      v_st_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_str0, 7, "holding");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_str1, 12, "holdingWhere");
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_lam1(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithBoundOf_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ewithBoundOf(V v_sp_240, V v_bs_241, V v_w_242, V v_body_243) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_w_242)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_str0);
    break;
  }
  case TAG_Just: {
    v_t_245 = ((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_str1);
    break;
  }
  default: heff_nomatch(v_w_242);
  }
  V v_t_246 = (g_list_2emap_24s1238159332x1367432882(heff_dup(v_bs_241)));
  V v_t_247 = (g_heff_2esyntax_2epresyntax_2erightTuple(heff_dup(v_sp_240), v_t_246));
  V v_t_2410 = (g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242(heff_dup(v_sp_240), heff_dup(v_bs_241), heff_clo_n(g_heff_2esyntax_2epresyntax_2ewithBoundOf_lam0, 1, 1, (V[]){heff_dup(v_body_243)})));
  V v_t_2416;
  switch (heff_tag_of(v_w_242)) {
  case TAG_Nothing: {
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_p_2411 = heff_field(v_w_242, 0);
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242(heff_dup(v_sp_240), heff_dup(v_bs_241), heff_clo_n(g_heff_2esyntax_2epresyntax_2ewithBoundOf_lam1, 1, 1, (V[]){heff_dup(v_p_2411)})));
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244(heff_dup(v_sp_240), heff_dup(v_bs_241), heff_dup(v_p_2411)));
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
    v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2415});
    break;
  }
  default: heff_nomatch(v_w_242);
  }
  V v_t_2417 = heff_tr(heff_call(heff_dup(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_get()), 1, (V[]){heff_dup(v_bs_241)}));
  V v_t_2418 = heff_tr(heff_call(heff_dup(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_get()), 1, (V[]){heff_dup(v_bs_241)}));
  V v_t_2419 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_240), v_t_2418));
  V v_t_2420 = (g_heff_2esyntax_2epresyntax_2erightTuple(heff_dup(v_sp_240), v_t_2419));
  V v_cx_2421 = heff_rec_n(7, shape_names__muts__loop__sp__depth__giving__bound, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2ecoNames_get()), v_t_2417, NTAG(TAG_Nothing), heff_dup(v_sp_240), MK_INT(0LL), NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_2420})});
  V v_t_2426;
  switch (heff_tag_of(v_body_243)) {
  case TAG_Nil: {
    v_t_2426 = (g_heff_2esyntax_2epresyntax_2eendOf(heff_dup(v_cx_2421), heff_get_n(v_cx_2421, 3, 7), NTAG(TAG_EndValue)));
    break;
  }
  case TAG_Cons: {
    V v_s_2422 = heff_field(v_body_243, 0);
    V v_x32_2423 = heff_field(v_body_243, 1);
    heff_take_n(v_body_243, 3ULL, 2);
    switch (heff_tag_of(v_x32_2423)) {
    case TAG_Nil: {
      v_t_2426 = heff_tr(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(v_cx_2421, v_s_2422));
      break;
    }
    case TAG_Cons: {
      v_t_2426 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_2421, v_s_2422, v_x32_2423, NTAG(TAG_EndValue)));
      break;
    }
    default: heff_nomatch(v_x32_2423);
    }
    break;
  }
  default: heff_nomatch(v_body_243);
  }
  V v_t_2427 = (g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244(heff_dup(v_sp_240), v_bs_241, v_t_2426));
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
  V v_ys_2429 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2428));
  V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_245}), v_sp_240});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_ys_2429})});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2430, v_t_2431));
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epresyntax_2ewithBoundOf(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_body_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_249 = (g_list_2efoldl_24s57109758x1528051153(NTAG(TAG_Nil), v_body_243));
  return ({ V a_0 = v_x_248; V a_1 = v_xs_249; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_x_248); heff_drop(v_xs_249); r_; });
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2412; V a_1 = v_p_2411; V r_ = (g_heff_2esyntax_2epresyntax_2ementions(a_0, a_1)); heff_drop(v_x_2412); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2echeckedWays_str0, 235, "any of these: give the type where it is bound, `let x : T = ...`; give it in place, `(e : T)`; or write it where a type is expected of it, as an argument of a function whose type is known or as the body of a definition with a signature");

static V g_heff_2esyntax_2epresyntax_2echeckedWays_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2echeckedWays_st;
static V g_heff_2esyntax_2epresyntax_2echeckedWays_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2echeckedWays_str0);
}
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2echeckedWays_st)) return g_heff_2esyntax_2epresyntax_2echeckedWays_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2echeckedWays_val, &g_heff_2esyntax_2epresyntax_2echeckedWays_st, g_heff_2esyntax_2epresyntax_2echeckedWays_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_str0, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_str1, 49, "cannot use descriptive syntax in nominal position");
Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V v_tok_240, V v_sp_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_TPi: {
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_245, v_sp_241});
  }
  case TAG_TSig: {
    V v_ru_24n_242_24TSig = heff_take_reuse_n(v_n_242, 0ULL, 1);
    V v_t_247 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_str0), NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_at_n(v_ru_24n_242_24TSig, TAG_TInf, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_247, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_241});
  }
  case TAG_TSum: {
    V v_ru_24n_242_24TSum = heff_take_reuse_n(v_n_242, 0ULL, 1);
    V v_t_2410 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_str1), NTAG(TAG_Nothing)});
    V v_t_2411 = heff_tag_at_n(v_ru_24n_242_24TSum, TAG_TInf, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_241});
  }
  case TAG_TType: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2412, v_sp_241});
  }
  case TAG_TInt: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2413, v_sp_241});
  }
  case TAG_TFloat: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2414, v_sp_241});
  }
  case TAG_TString: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2415, v_sp_241});
  }
  case TAG_TRune: {
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2416, v_sp_241});
  }
  case TAG_TArray: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2418, v_sp_241});
  }
  case TAG_TFixed: {
    V v_t_2420 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2420, v_sp_241});
  }
  case TAG_TInf: {
    V v_t_2422 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2422, v_sp_241});
  }
  case TAG_TChk: {
    V v_t_2424 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2424, v_sp_241});
  }
  case TAG_TNominal: {
    V v_t_2426 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2426, v_sp_241});
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(a[0], a[1], a[2]);
}