// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndJump 17665
#define TAG_IInvalid 29207
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SetPath 11095
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_start 311115900
#define LBL_stmts 311127493
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1806941268x1247563264_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtBy_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2easAction(V, V, V);
V g_heff_2esyntax_2epresyntax_2easAction_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2easAction_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eguardE(V, V);
V g_heff_2esyntax_2epresyntax_2eguardE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eguardE_clo;
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2ehasReturn(V);
V g_heff_2esyntax_2epresyntax_2ehasReturn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasReturn_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2eliftE(V, V, V);
V g_heff_2esyntax_2epresyntax_2eliftE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eliftE_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo;
V g_heff_2esyntax_2epresyntax_2escopeJoin(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2estmtAcc_24s153905797x297886855_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eutf8Of(V);
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewholeBinary(V, V);
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eall_24s1414119352x995333365(V, V);
V g_list_2eall_24s1414119352x995333365_entry(V self, V *a);
extern Clo g_list_2eall_24s1414119352x995333365_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2eany_24s717144537x1885076661(V);
V g_list_2eany_24s717144537x1885076661_entry(V self, V *a);
extern Clo g_list_2eany_24s717144537x1885076661_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esegmentOdd_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2esegmentOdd(V v_ty_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(v_ty_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2esegmentOdd(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str3, 0, "");
Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eutf8Of_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eutf8Of(V v_c_240) {
top: ;
  if (heff_intLt_c_lent(v_c_240, MK_INT(128LL), 2)) {
    return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(1LL), v_c_240, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str0)));
  } else {
    if (heff_intLt_c_lent(v_c_240, MK_INT(2048LL), 2)) {
      int64_t v_t_241 = (((int64_t)192ULL) + (heff_peek_word(v_c_240) / ((int64_t)64ULL)));
      int64_t v_t_242 = ((v_t_241 * ((int64_t)256ULL)) + ((int64_t)128ULL));
      int64_t v_t_243 = (v_t_242 + (heff_unbox_word(v_c_240) % ((int64_t)64ULL)));
      return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(2LL), heff_box_word(v_t_243), ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str1)));
    } else {
      if (heff_intLt_c_lent(v_c_240, MK_INT(65536LL), 2)) {
        int64_t v_t_244 = (((int64_t)224ULL) + (heff_peek_word(v_c_240) / ((int64_t)4096ULL)));
        int64_t v_t_245 = ((v_t_244 * ((int64_t)256ULL)) + ((int64_t)128ULL));
        int64_t v_t_246 = ((heff_peek_word(v_c_240) / ((int64_t)64ULL)) % ((int64_t)64ULL));
        int64_t v_t_247 = ((v_t_245 + v_t_246) * ((int64_t)256ULL));
        int64_t v_t_248 = ((v_t_247 + ((int64_t)128ULL)) + (heff_unbox_word(v_c_240) % ((int64_t)64ULL)));
        return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(3LL), heff_box_word(v_t_248), ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str2)));
      } else {
        V v_t_249 = heff_intAdd(MK_INT(240LL), heff_intDiv(heff_dup(v_c_240), MK_INT(262144LL)));
        V v_t_2410 = heff_intAdd(heff_intMul(v_t_249, MK_INT(256LL)), MK_INT(128LL));
        V v_t_2411 = heff_intMod(heff_intDiv(heff_dup(v_c_240), MK_INT(4096LL)), MK_INT(64LL));
        V v_t_2412 = heff_intMul(heff_intAdd(v_t_2410, v_t_2411), MK_INT(256LL));
        V v_t_2413 = heff_intMod(heff_intDiv(heff_dup(v_c_240), MK_INT(64LL)), MK_INT(64LL));
        V v_t_2414 = heff_intAdd(heff_intAdd(v_t_2412, MK_INT(128LL)), v_t_2413);
        V v_t_2415 = heff_intAdd(heff_intMul(v_t_2414, MK_INT(256LL)), MK_INT(128LL));
        V v_t_2416 = heff_intAdd(v_t_2415, heff_intMod(v_c_240, MK_INT(64LL)));
        return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(4LL), v_t_2416, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str3)));
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eutf8Of(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str1, 4, "Unit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str2, 14, "prelude.typeOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str3, 14, "prelude.typeOf");
V g_heff_2esyntax_2epresyntax_2evarParams_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2evarParams_lam1(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2evarParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evarParams_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2evarParams(V v_sp_240, V v_unit_241, V v_vars_242) {
top: ;
  if ((heff_dup(v_unit_241) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_vars_242)) {
    case TAG_Nil: {
      V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str0)}), heff_dup(v_sp_240)});
      V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str1)}), v_sp_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_t_244}), NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      return (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evarParams_lam0, 1, 1, (V[]){v_sp_240}), v_vars_242));
    }
    default: return heff_nomatch(v_vars_242);
    }
  } else {
    return (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evarParams_lam1, 1, 1, (V[]){v_sp_240}), v_vars_242));
  }
}
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2evarParams(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2epresyntax_2evarParams_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_x_247)}), heff_dup(v_sp_240)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str2)}), heff_dup(v_sp_240)});
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_247}), v_sp_240});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_249, v_t_2411));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_t_2412});
}
V g_heff_2esyntax_2epresyntax_2evarParams_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_x_2413)}), heff_dup(v_sp_240)});
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str3)}), heff_dup(v_sp_240)});
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_2413}), v_sp_240});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2415, v_t_2417));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_t_2418});
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ejumpCall_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpCall_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ejumpCall(V v_cx_240, V v_sp_241, V v_j_242) {
top: ;
  V v_depth_243 = heff_take_field(v_j_242, 3);
  V v_head_244 = heff_take_field(v_j_242, 0);
  V v_vars_245 = heff_take_field(v_j_242, 1);
  V v_unit_246 = heff_get_n(v_j_242, 2, 4);
  V v_t_247 = heff_intSub(heff_dup(heff_rfield(v_cx_240, 4)), v_depth_243);
  V v_vars_248 = v_vars_245;
  V v_t_2412;
  if ((heff_dup(v_unit_246) == NTAG(TAG_True))) {
    heff_drop(v_unit_246);
    switch (heff_tag_of(v_vars_248)) {
    case TAG_Nil: {
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ejumpCall_str0)}), heff_dup(v_sp_241)});
      v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      v_t_2412 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_248));
      break;
    }
    default: heff_nomatch(v_vars_248);
    }
  } else {
    heff_drop(v_unit_246);
    v_t_2412 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_248));
  }
  V v_t_2413 = (g_heff_2esyntax_2epresyntax_2eapp(v_head_244, v_t_2412));
  return (g_heff_2esyntax_2epresyntax_2eleaving(v_cx_240, v_sp_241, v_t_247, v_t_2413));
}
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpCall(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epatNames_24dps_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2esyntax_2epresyntax_2epatNames_24dps_str0), 2)) {
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        heff_drop(v_x_244);
        return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
      } else {
        V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
        return heff_setField(v_d_241, MK_INT(1LL), v_t_245);
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_249); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2410);
    }
    case TAG_PatOp: {
      V v_ps_2413 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2413));
      V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2414); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2415);
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2421 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2421));
      V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2422); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2423);
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2425 = heff_field(v_x11_242, 0);
      V v_q_2427 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 5ULL, 3);
      V v_cell_2428 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2425, heff_hole()});
      V v_u_2429 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2428));
      heff_drop(v_u_2429);
      V t_0 = v_q_2427;
      V t_1 = v_cell_2428;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatNames_24dps(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    HeffT2 v_t_244 = ({ V a_0 = v_st_240; V a_1 = v_x_242; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2estmtAcc_24s153905797x297886855_24cpr(a_0, a_1)); heff_drop(v_st_240); r_; });
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_st_247 = v_field_245;
      V v_y_248 = v_field_246;
      HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_st_247, v_xs_243));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v_y_2413 = v_field_2411;
        return ((HeffT2){{v_x_2412, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_248, v_y_2413})}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str0, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str2, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str3, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str4, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str5, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str6, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str7, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str8, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str9, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str10, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str11, 1, "#");
V g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V v_l_240, V v_acc_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_At: {
    V v_e1_243 = heff_dup(heff_field(v_e_242, 0));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_EVar: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_246 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_246, v_acc_241, v_e_242);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_248 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_248, v_acc_241, v_e_242);
    }
    case TAG_ETag: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2410, v_acc_241, v_e_242);
    }
    case TAG_EInt: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2412, v_acc_241, v_e_242);
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_243, 0ULL, 1);
      V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2414, v_acc_241, v_e_242);
    }
    case TAG_EString: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_2416 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2416, v_acc_241, v_e_242);
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_2418 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2418, v_acc_241, v_e_242);
    }
    case TAG_ERune: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2420, v_acc_241, v_e_242);
    }
    case TAG_EWord: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2422, v_acc_241, v_e_242);
    }
    case TAG_EApp: {
      heff_take_n(v_e1_243, 0ULL, 2);
      V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2425, v_acc_241, v_e_242);
    }
    case TAG_EProject: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2427, v_acc_241, v_e_242);
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_243, 0ULL, 2);
      V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2430, v_acc_241, v_e_242);
    }
    case TAG_EPi: {
      heff_take_n(v_e1_243, 0ULL, 2);
      V v_t_2433 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2433, v_acc_241, v_e_242);
    }
    case TAG_ELam: {
      V v_b_2434 = heff_field(v_e1_243, 0);
      V v_body_2435 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24ELam = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_2437 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_2438 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELam, TAG_ELam, 2, (V[]){v_b_2434, v_body_2435}), v_sp_2437});
        V v_f_2439 = (g_heff_2esyntax_2epresyntax_2eguardE(heff_get_n(v_l_240, 1, 2), v_t_2438));
        return ((HeffT2){{v_acc_241, v_f_2439}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_243, 0ULL, 2);
      V v_t_2442 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2442, v_acc_241, v_e_242);
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_243, 0ULL, 4);
      V v_t_2447 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2447, v_acc_241, v_e_242);
    }
    case TAG_ESig: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_2449 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2449, v_acc_241, v_e_242);
    }
    case TAG_ESum: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_2451 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2451, v_acc_241, v_e_242);
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2453, v_acc_241, v_e_242);
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_243, 0ULL, 2);
      V v_t_2456 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2456, v_acc_241, v_e_242);
    }
    case TAG_EMatch: {
      V v_s_2457 = heff_field(v_e1_243, 0);
      V v_alts_2458 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24EMatch = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_2460 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        HeffT2 v_t_2461 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_dup(v_l_240), v_acc_241, v_s_2457));
        {
          V v_field_2462 = v_t_2461.f[0];
          V v_field_2463 = v_t_2461.f[1];
          V v_x_2464 = v_field_2462;
          V v_y_2465 = v_field_2463;
          V v_t_2466 = (g_list_2eany_24s717144537x1885076661(v_alts_2458));
          if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
            heff_drop(v_t_2466);
            V v_t_2467 = heff_intShow(heff_dup(heff_rfield(v_sp_2460, 0)));
            V v_t_2468 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str1), v_t_2467));
            V v_t_2469 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){heff_dup(v_l_240)}));
            V v_t_2470 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2easAction_clo), 2, (V[]){v_t_2469, heff_get_n(v_l_240, 0, 2)}));
            V v_t_2471 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ealtBy_clo), 1, (V[]){v_t_2470}));
            V v_t_2472 = (g_list_2emap(v_t_2471, v_alts_2458));
            V v_t_2473 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_2465, v_t_2472}), heff_dup(v_sp_2460)});
            V v_f_2474 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2468, v_t_2473}), v_x_2464});
            V v_t_2475 = heff_intShow(heff_dup(heff_rfield(v_sp_2460, 0)));
            V v_t_2476 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str3), v_t_2475));
            V v_f_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2476}), v_sp_2460});
            return ((HeffT2){{v_f_2474, v_f_2477}});
          } else {
            heff_drop(v_t_2466);
            V v_f_2478 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
            HeffT2 v_t_2489 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0, 2, 1, (V[]){v_f_2478}), v_x_2464, v_alts_2458));
            {
              V v_field_2490 = v_t_2489.f[0];
              V v_field_2491 = v_t_2489.f[1];
              V v_x_2492 = v_field_2490;
              V v_y_2493 = v_field_2491;
              V v_t_2494 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_2465, v_y_2493}), v_sp_2460});
              return ((HeffT2){{v_x_2492, v_t_2494}});
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2495 = heff_field(v_e1_243, 0);
      V v_e12_2496 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24ELetIn = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_2498 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        switch (heff_tag_of(v_e12_2496)) {
        case TAG_At: {
          V v_e121_2499 = heff_field(v_e12_2496, 0);
          V v_asp_24100 = heff_field(v_e12_2496, 1);
          V v_ru_24e12_2496_24At = heff_take_reuse_n(v_e12_2496, 3ULL, 2);
          switch (heff_tag_of(v_e121_2499)) {
          case TAG_MkAlt: {
            V v_p_24101 = heff_field(v_e121_2499, 0);
            V v_body_24102 = heff_field(v_e121_2499, 1);
            V v_ru_24e121_2499_24MkAlt = heff_take_reuse_n(v_e121_2499, 3ULL, 2);
            HeffT2 v_t_24103 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_dup(v_l_240), v_acc_241, v_rhs_2495));
            {
              V v_field_24104 = v_t_24103.f[0];
              V v_field_24105 = v_t_24103.f[1];
              V v_x_24106 = v_field_24104;
              V v_y_24107 = v_field_24105;
              V v_t_24108 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_body_24102)));
              if ((heff_dup(v_t_24108) == NTAG(TAG_True))) {
                heff_drop(v_t_24108);
                V v_t_24109 = heff_intShow(heff_dup(heff_rfield(v_sp_2498, 0)));
                V v_t_24110 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str4), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str5), v_t_24109));
                V v_lift_24111 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){heff_dup(v_l_240)}));
                V v_cx_24112 = heff_get_n(v_l_240, 0, 2);
                V v_x1_24113 = heff_tr(heff_call(v_lift_24111, 2, (V[]){NTAG(TAG_Nil), v_body_24102}));
                V v_t_24123;
                switch (heff_tag_of(v_x1_24113)) {
                case TAG_MkPair: {
                  V v_x_24114 = heff_field(v_x1_24113, 0);
                  V v_y_24115 = heff_field(v_x1_24113, 1);
                  heff_take_n(v_x1_24113, 3ULL, 2);
                  V v_t_24116 = heff_get_n(heff_dup(heff_rfield(v_cx_24112, 0)), 1, 3);
                  V v_t_24119;
                  switch (heff_tag_of(v_y_24115)) {
                  case TAG_At: {
                    V v_s_24118 = heff_dup(heff_field(v_y_24115, 1));
                    v_t_24119 = v_s_24118;
                    break;
                  }
                  default: heff_nomatch(v_y_24115);
                  }
                  V v_t_24120 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24116}), v_t_24119});
                  V v_t_24121 = heff_tag_at_n(v_ru_24e121_2499_24MkAlt, TAG_Cons, 2, (V[]){v_y_24115, NTAG(TAG_Nil)});
                  V v_t_24122 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24120, v_t_24121));
                  v_t_24123 = ({ V a_0 = v_cx_24112; V a_1 = v_x_24114; V a_2 = v_t_24122; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24114); r_; });
                  break;
                }
                default: heff_nomatch(v_x1_24113);
                }
                V v_t_24124 = heff_tag_at_n(v_ru_24e12_2496_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24101, v_t_24123}), v_asp_24100});
                V v_t_24125 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_24107, v_t_24124}), heff_dup(v_sp_2498)});
                V v_f_24126 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24110, v_t_24125}), v_x_24106});
                V v_t_24127 = heff_intShow(heff_dup(heff_rfield(v_sp_2498, 0)));
                V v_t_24128 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str6), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str7), v_t_24127));
                V v_f_24129 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24128}), v_sp_2498});
                return ((HeffT2){{v_f_24126, v_f_24129}});
              } else {
                heff_drop_cell(v_ru_24e121_2499_24MkAlt, 2);
                heff_drop(v_t_24108);
                HeffT2 v_t_24130 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_x_24106, v_body_24102));
                {
                  V v_field_24131 = v_t_24130.f[0];
                  V v_field_24132 = v_t_24130.f[1];
                  V v_x_24133 = v_field_24131;
                  V v_y_24134 = v_field_24132;
                  V v_t_24135 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24101, v_y_24134}), v_asp_24100});
                  V v_t_24136 = heff_tag_at_n(v_ru_24e12_2496_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_24107, v_t_24135}), v_sp_2498});
                  return ((HeffT2){{v_x_24133, v_t_24136}});
                }
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_e121_2499)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_e12_2496)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24137 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24EDo = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24139 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_24140 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EDo, TAG_EDo, 1, (V[]){v_ss_24137}), v_sp_24139});
        V v_f_24141 = (g_heff_2esyntax_2epresyntax_2eguardE(heff_get_n(v_l_240, 1, 2), v_t_24140));
        return ((HeffT2){{v_acc_241, v_f_24141}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_243, 0ULL, 2);
      V v_t_24144 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24144, v_acc_241, v_e_242);
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_24146 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24146, v_acc_241, v_e_242);
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_243, 0ULL, 3);
      V v_t_24150 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24150, v_acc_241, v_e_242);
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_243, 0ULL, 2);
      V v_t_24153 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24153, v_acc_241, v_e_242);
    }
    case TAG_EFor: {
      heff_take_n(v_e1_243, 0ULL, 3);
      V v_t_24157 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24157, v_acc_241, v_e_242);
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_243, 0ULL, 2);
      V v_t_24160 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24160, v_acc_241, v_e_242);
    }
    case TAG_EBreak: {
      V v_t_24161 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24161, v_acc_241, v_e_242);
    }
    case TAG_EContinue: {
      V v_t_24162 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24162, v_acc_241, v_e_242);
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_24164 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24164, v_acc_241, v_e_242);
    }
    case TAG_ENest: {
      V v_c_24165 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ENest = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24167 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        HeffT2 v_t_24168 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_acc_241, v_c_24165));
        {
          V v_field_24169 = v_t_24168.f[0];
          V v_field_24170 = v_t_24168.f[1];
          V v_x_24171 = v_field_24169;
          V v_y_24172 = v_field_24170;
          V v_t_24173 = heff_intShow(heff_dup(heff_rfield(v_sp_24167, 0)));
          V v_t_24174 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str8), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str9), v_t_24173));
          V v_f_24175 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24174, v_y_24172}), v_x_24171});
          V v_t_24176 = heff_intShow(heff_dup(heff_rfield(v_sp_24167, 0)));
          V v_t_24177 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str10), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str11), v_t_24176));
          V v_f_24178 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ENest, TAG_EVar, 1, (V[]){v_t_24177}), v_sp_24167});
          return ((HeffT2){{v_f_24175, v_f_24178}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_ELazy: {
      V v_body_24179 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ELazy = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24181 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_24182 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELazy, TAG_ELazy, 1, (V[]){v_body_24179}), v_sp_24181});
        V v_f_24183 = (g_heff_2esyntax_2epresyntax_2eguardE(heff_get_n(v_l_240, 1, 2), v_t_24182));
        return ((HeffT2){{v_acc_241, v_f_24183}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_ETuple: {
      heff_take_n(v_e1_243, 0ULL, 1);
      V v_t_24185 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24185, v_acc_241, v_e_242);
    }
    case TAG_ETry: {
      V v_tr_24186 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ETry = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      heff_drop_rec(v_l_240, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24188 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_24189 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ETry, TAG_ETry, 1, (V[]){v_tr_24186}), v_sp_24188});
        return ((HeffT2){{v_acc_241, v_t_24189}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_EWith: {
      V v_w_24190 = heff_field(v_e1_243, 0);
      V v_x_24191 = heff_field(v_e1_243, 1);
      V v_xsp_24192 = heff_field(v_e1_243, 2);
      V v_body_24193 = heff_field(v_e1_243, 3);
      V v_ru_24e1_243_24EWith = heff_take_reuse_n(v_e1_243, 15ULL, 4);
      heff_drop_rec(v_l_240, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24195 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_24196 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EWith, TAG_EWith, 4, (V[]){v_w_24190, v_x_24191, v_xsp_24192, v_body_24193}), v_sp_24195});
        return ((HeffT2){{v_acc_241, v_t_24196}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_e1_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0(V self, V *args) {
  V v_st_2479 = args[0];
  V v_x3_2480 = args[1];
  V v_f_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2480)) {
  case TAG_At: {
    V v_x31_2481 = heff_field(v_x3_2480, 0);
    V v_sp_2482 = heff_field(v_x3_2480, 1);
    V v_ru_24x3_2480_24At = heff_take_reuse_n(v_x3_2480, 3ULL, 2);
    switch (heff_tag_of(v_x31_2481)) {
    case TAG_MkAlt: {
      V v_p_2483 = heff_field(v_x31_2481, 0);
      V v_e_2484 = heff_field(v_x31_2481, 1);
      V v_ru_24x31_2481_24MkAlt = heff_take_reuse_n(v_x31_2481, 3ULL, 2);
      V v_x1_2485 = heff_tr(heff_call(v_f_2478, 2, (V[]){v_st_2479, v_e_2484}));
      switch (heff_tag_of(v_x1_2485)) {
      case TAG_MkPair: {
        V v_x_2486 = heff_field(v_x1_2485, 0);
        V v_y_2487 = heff_field(v_x1_2485, 1);
        heff_take_n(v_x1_2485, 3ULL, 2);
        V v_t_2488 = heff_tag_at_n(v_ru_24x3_2480_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2483, v_y_2487}), v_sp_2482});
        return heff_tag_at_n(v_ru_24x31_2481_24MkAlt, TAG_MkPair, 2, (V[]){v_x_2486, v_t_2488});
      }
      default: return heff_nomatch(v_x1_2485);
      }
    }
    default: return heff_nomatch(v_x31_2481);
    }
  }
  default: return heff_nomatch(v_x3_2480);
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1806941268x1247563264_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 3ULL, 2);
        V v_a_248;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_248 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_248 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_a_247)));
        }
        HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1806941268x1247563264_24cpr(v_a_248, v_xs_243));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_y_2413 = v_field_2411;
          V v_t_2414 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2412, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_y_2413})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_dup(heff_field(v_x3_241, 0));
    switch (heff_tag_of(v_x31_242)) {
    case TAG_EVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EBinary: {
      V v_segs_2410 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EBinary = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2412 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(v_st_240, v_segs_2410));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_x_2416 = v_field_2414;
          V v_y_2417 = v_field_2415;
          V v_t_2418 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EBinary, TAG_EBinary, 1, (V[]){v_y_2417}), v_sp_2412});
          return ((HeffT2){{v_x_2416, v_t_2418}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EApp: {
      V v_h_2421 = heff_field(v_x31_242, 0);
      V v_args_2422 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EApp = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2424 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2425;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2425 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2425 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_h_2421)));
        }
        HeffT2 v_t_2426 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24cpr(v_x_2425, v_args_2422));
        {
          V v_field_2427 = v_t_2426.f[0];
          V v_field_2428 = v_t_2426.f[1];
          V v_x_2429 = v_field_2427;
          V v_y_2430 = v_field_2428;
          V v_t_2431 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EApp, TAG_EApp, 2, (V[]){v_h_2421, v_y_2430}), v_sp_2424});
          return ((HeffT2){{v_x_2429, v_t_2431}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENamed: {
      V v_x_2433 = heff_field(v_x31_242, 0);
      V v_e_2434 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ENamed = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2436 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2437;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2437 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2437 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2434)));
        }
        V v_t_2438 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENamed, TAG_ENamed, 2, (V[]){v_x_2433, v_e_2434}), v_sp_2436});
        return ((HeffT2){{v_x_2437, v_t_2438}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ELam: {
      V v_b_2441 = heff_field(v_x31_242, 0);
      V v_body_2442 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELam = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2444 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2445;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2445 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2445 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_body_2442)));
        }
        V v_t_2446 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELam, TAG_ELam, 2, (V[]){v_b_2441, v_body_2442}), v_sp_2444});
        return ((HeffT2){{v_x_2445, v_t_2446}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2447 = heff_field(v_x31_242, 0);
      V v_t_2448 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EAnn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2450 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2451;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2451 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2451 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2447)));
        }
        V v_t_2452 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAnn, TAG_EAnn, 2, (V[]){v_e_2447, v_t_2448}), v_sp_2450});
        return ((HeffT2){{v_x_2451, v_t_2452}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESpec: {
      V v_a_2453 = heff_field(v_x31_242, 0);
      V v_x_2454 = heff_field(v_x31_242, 1);
      V v_xsp_2455 = heff_field(v_x31_242, 2);
      V v_v_2456 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24ESpec = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2458 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_2459 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_2453, v_x_2454, v_xsp_2455, v_v_2456}), v_sp_2458});
          return ((HeffT2){{NTAG(TAG_True), v_t_2459}});
        } else {
          heff_drop(v_st_240);
          V v_x_2460 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_2453)));
          V v_x_2461;
          if ((heff_dup(v_x_2460) == NTAG(TAG_True))) {
            heff_drop(v_x_2460);
            v_x_2461 = NTAG(TAG_True);
          } else {
            heff_drop(v_x_2460);
            v_x_2461 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_v_2456)));
          }
          V v_t_2462 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_2453, v_x_2454, v_xsp_2455, v_v_2456}), v_sp_2458});
          return ((HeffT2){{v_x_2461, v_t_2462}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EStruct: {
      V v_fs_2465 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EStruct = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2467 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2468 = (g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24cpr(v_st_240, v_fs_2465));
        {
          V v_field_2469 = v_t_2468.f[0];
          V v_field_2470 = v_t_2468.f[1];
          V v_x_2471 = v_field_2469;
          V v_y_2472 = v_field_2470;
          V v_t_2473 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EStruct, TAG_EStruct, 1, (V[]){v_y_2472}), v_sp_2467});
          return ((HeffT2){{v_x_2471, v_t_2473}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_2474 = heff_field(v_x31_242, 0);
      V v_fs_2475 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EUpdate = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2477 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2478;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2478 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2478 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_2474)));
        }
        HeffT2 v_t_2479 = (g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24cpr(v_x_2478, v_fs_2475));
        {
          V v_field_2480 = v_t_2479.f[0];
          V v_field_2481 = v_t_2479.f[1];
          V v_x_2482 = v_field_2480;
          V v_y_2483 = v_field_2481;
          V v_t_2484 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EUpdate, TAG_EUpdate, 2, (V[]){v_a_2474, v_y_2483}), v_sp_2477});
          return ((HeffT2){{v_x_2482, v_t_2484}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EMatch: {
      V v_s_2485 = heff_field(v_x31_242, 0);
      V v_alts_2486 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EMatch = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2488 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2489;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2489 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2489 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_s_2485)));
        }
        HeffT2 v_t_2490 = (g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24cpr(v_x_2489, v_alts_2486));
        {
          V v_field_2491 = v_t_2490.f[0];
          V v_field_2492 = v_t_2490.f[1];
          V v_x_2493 = v_field_2491;
          V v_y_2494 = v_field_2492;
          V v_t_2495 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2485, v_y_2494}), v_sp_2488});
          return ((HeffT2){{v_x_2493, v_t_2495}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2496 = heff_field(v_x31_242, 0);
      V v_a_2497 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELetIn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2499 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_2497)) {
          case TAG_At: {
            V v_x31_24100 = heff_field(v_a_2497, 0);
            V v_sp_24101 = heff_field(v_a_2497, 1);
            V v_ru_24a_2497_24At = heff_take_reuse_n(v_a_2497, 3ULL, 2);
            switch (heff_tag_of(v_x31_24100)) {
            case TAG_MkAlt: {
              V v_p_24102 = heff_field(v_x31_24100, 0);
              V v_e_24103 = heff_field(v_x31_24100, 1);
              heff_take_n(v_x31_24100, 3ULL, 2);
              V v_t_24104 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24102, v_e_24103}), v_sp_24101});
              V v_t_24105 = heff_tag_at_n(v_ru_24a_2497_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_2496, v_t_24104}), v_sp_2499});
              return ((HeffT2){{NTAG(TAG_True), v_t_24105}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24100)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_2497)}});
          }
        } else {
          heff_drop(v_st_240);
          V v_x_24106 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_rhs_2496)));
          switch (heff_tag_of(v_a_2497)) {
          case TAG_At: {
            V v_x31_24107 = heff_field(v_a_2497, 0);
            V v_sp_24108 = heff_field(v_a_2497, 1);
            V v_ru_24a_2497_24At = heff_take_reuse_n(v_a_2497, 3ULL, 2);
            switch (heff_tag_of(v_x31_24107)) {
            case TAG_MkAlt: {
              V v_p_24109 = heff_field(v_x31_24107, 0);
              V v_e_24110 = heff_field(v_x31_24107, 1);
              heff_take_n(v_x31_24107, 3ULL, 2);
              V v_x_24111;
              if ((heff_dup(v_x_24106) == NTAG(TAG_True))) {
                heff_drop(v_x_24106);
                v_x_24111 = NTAG(TAG_True);
              } else {
                heff_drop(v_x_24106);
                v_x_24111 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24110)));
              }
              V v_t_24112 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24109, v_e_24110}), v_sp_24108});
              V v_t_24113 = heff_tag_at_n(v_ru_24a_2497_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_2496, v_t_24112}), v_sp_2499});
              return ((HeffT2){{v_x_24111, v_t_24113}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24107)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_2497)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24114 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EDo = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24116 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24117 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_st_240, v_ss_24114));
        {
          V v_field_24118 = v_t_24117.f[0];
          V v_field_24119 = v_t_24117.f[1];
          V v_x_24120 = v_field_24118;
          V v_y_24121 = v_field_24119;
          V v_t_24122 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EDo, TAG_EDo, 1, (V[]){v_y_24121}), v_sp_24116});
          return ((HeffT2){{v_x_24120, v_t_24122}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EAssign: {
      V v_x_24126 = heff_field(v_x31_242, 0);
      V v_xsp_24127 = heff_field(v_x31_242, 1);
      V v_e_24128 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EAssign = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24130 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24131;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24131 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24131 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24128)));
        }
        V v_t_24132 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAssign, TAG_EAssign, 3, (V[]){v_x_24126, v_xsp_24127, v_e_24128}), v_sp_24130});
        return ((HeffT2){{v_x_24131, v_t_24132}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24133 = heff_field(v_x31_242, 0);
      V v_body_24134 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EWhile = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24136 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24137;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24137 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24137 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_c_24133)));
        }
        HeffT2 v_t_24138 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_24137, v_body_24134));
        {
          V v_field_24139 = v_t_24138.f[0];
          V v_field_24140 = v_t_24138.f[1];
          V v_x_24141 = v_field_24139;
          V v_y_24142 = v_field_24140;
          V v_t_24143 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWhile, TAG_EWhile, 2, (V[]){v_c_24133, v_y_24142}), v_sp_24136});
          return ((HeffT2){{v_x_24141, v_t_24143}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EFor: {
      V v_p_24144 = heff_field(v_x31_242, 0);
      V v_c_24145 = heff_field(v_x31_242, 1);
      V v_body_24146 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EFor = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24148 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24149;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24149 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24149 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_c_24145)));
        }
        HeffT2 v_t_24150 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_24149, v_body_24146));
        {
          V v_field_24151 = v_t_24150.f[0];
          V v_field_24152 = v_t_24150.f[1];
          V v_x_24153 = v_field_24151;
          V v_y_24154 = v_field_24152;
          V v_t_24155 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EFor, TAG_EFor, 3, (V[]){v_p_24144, v_c_24145, v_y_24154}), v_sp_24148});
          return ((HeffT2){{v_x_24153, v_t_24155}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24156 = heff_field(v_x31_242, 0);
      V v_a_24157 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EIfThen = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24159 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_24160 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24156, v_a_24157}), v_sp_24159});
          return ((HeffT2){{NTAG(TAG_True), v_t_24160}});
        } else {
          heff_drop(v_st_240);
          V v_x_24161 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_c_24156)));
          V v_x_24162;
          if ((heff_dup(v_x_24161) == NTAG(TAG_True))) {
            heff_drop(v_x_24161);
            v_x_24162 = NTAG(TAG_True);
          } else {
            heff_drop(v_x_24161);
            v_x_24162 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_24157)));
          }
          V v_t_24163 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24156, v_a_24157}), v_sp_24159});
          return ((HeffT2){{v_x_24162, v_t_24163}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EBreak: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EReturn: {
      V v_e_24164 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EReturn = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24166 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24167;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24167 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24167 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24164)));
        }
        V v_t_24168 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EReturn, TAG_EReturn, 1, (V[]){v_e_24164}), v_sp_24166});
        return ((HeffT2){{v_x_24167, v_t_24168}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ENest: {
      V v_e_24169 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ENest = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24171 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24172;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24172 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24172 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24169)));
        }
        V v_t_24173 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENest, TAG_ENest, 1, (V[]){v_e_24169}), v_sp_24171});
        return ((HeffT2){{v_x_24172, v_t_24173}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24174 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ELazy = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24176 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24177;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24177 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24177 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24174)));
        }
        V v_t_24178 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELazy, TAG_ELazy, 1, (V[]){v_e_24174}), v_sp_24176});
        return ((HeffT2){{v_x_24177, v_t_24178}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24179 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETuple = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24181 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24182 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24cpr(v_st_240, v_es_24179));
        {
          V v_field_24183 = v_t_24182.f[0];
          V v_field_24184 = v_t_24182.f[1];
          V v_x_24185 = v_field_24183;
          V v_y_24186 = v_field_24184;
          V v_t_24187 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETuple, TAG_ETuple, 1, (V[]){v_y_24186}), v_sp_24181});
          return ((HeffT2){{v_x_24185, v_t_24187}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24188 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETry = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24190 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        switch (heff_tag_of(v_tr_24188)) {
        case TAG_MkTry: {
          V v_err_24191 = heff_field(v_tr_24188, 0);
          V v_body_24192 = heff_field(v_tr_24188, 1);
          V v_c_24193 = heff_field(v_tr_24188, 2);
          V v_ru_24tr_24188_24MkTry = heff_take_reuse_n(v_tr_24188, 7ULL, 3);
          HeffT2 v_t_24194 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_st_240, v_body_24192));
          {
            V v_field_24195 = v_t_24194.f[0];
            V v_field_24196 = v_t_24194.f[1];
            V v_x_24197 = v_field_24195;
            V v_y_24198 = v_field_24196;
            switch (heff_tag_of(v_c_24193)) {
            case TAG_MkCatchArm: {
              V v_b_24199 = heff_field(v_c_24193, 0);
              V v_ss_24200 = heff_field(v_c_24193, 1);
              heff_take_n(v_c_24193, 3ULL, 2);
              HeffT2 v_t_24201 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_24197, v_ss_24200));
              {
                V v_field_24202 = v_t_24201.f[0];
                V v_field_24203 = v_t_24201.f[1];
                V v_x_24204 = v_field_24202;
                V v_y_24205 = v_field_24203;
                V v_t_24206 = heff_tag_at_n(v_ru_24tr_24188_24MkTry, TAG_MkTry, 3, (V[]){v_err_24191, v_y_24198, heff_tag_n(TAG_MkCatchArm, 2, (V[]){v_b_24199, v_y_24205})});
                V v_t_24207 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETry, TAG_ETry, 1, (V[]){v_t_24206}), v_sp_24190});
                return ((HeffT2){{v_x_24204, v_t_24207}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_c_24193)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_tr_24188)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWith: {
      V v_w_24208 = heff_field(v_x31_242, 0);
      V v_x_24209 = heff_field(v_x31_242, 1);
      V v_xsp_24210 = heff_field(v_x31_242, 2);
      V v_body_24211 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24EWith = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24213 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24214;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24214 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24214 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_w_24208)));
        }
        HeffT2 v_t_24215 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_24214, v_body_24211));
        {
          V v_field_24216 = v_t_24215.f[0];
          V v_field_24217 = v_t_24215.f[1];
          V v_x_24218 = v_field_24216;
          V v_y_24219 = v_field_24217;
          V v_t_24220 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWith, TAG_EWith, 4, (V[]){v_w_24208, v_x_24209, v_xsp_24210, v_y_24219}), v_sp_24213});
          return ((HeffT2){{v_x_24218, v_t_24220}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_str0, 4, "join");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_str2, 4, "join");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_str3, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2escopeJoin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2escopeJoin_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2escopeJoin(V v_t_240, V v_cx_241, V v_sp_242, V v_scope_243, V v_rest_244, V v_end_245) {
top: ;
  V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_str1), v_t_246));
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), heff_dup(v_sp_242)});
  V v_t_249 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){v_t_248, heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_241, 4))});
  V v_t_2410 = heff_tr(heff_call(v_scope_243, 1, (V[]){heff_tag_n(TAG_EndJump, 1, (V[]){v_t_249})}));
  V v_t_2411 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_str3), v_t_2411));
  V v_t_2413 = ({ V a_0 = heff_dup(v_sp_242); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_241, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2414 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_cx_241, v_rest_244, v_end_245}));
  V v_t_2415 = (g_heff_2esyntax_2epresyntax_2elocalFun(v_t_2412, heff_dup(v_sp_242), v_t_2413, v_t_2414));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2410, v_t_2416}), v_sp_242});
}
V g_heff_2esyntax_2epresyntax_2escopeJoin_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2escopeJoin(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2echeckedWays_str0, 235, "any of these: give the type where it is bound, `let x : T = ...`; give it in place, `(e : T)`; or write it where a type is expected of it, as an argument of a function whose type is known or as the body of a definition with a signature");

static V g_heff_2esyntax_2epresyntax_2echeckedWays_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2echeckedWays_st;
static V g_heff_2esyntax_2epresyntax_2echeckedWays_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2echeckedWays_str0);
}
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2echeckedWays_st)) return g_heff_2esyntax_2epresyntax_2echeckedWays_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2echeckedWays_val, &g_heff_2esyntax_2epresyntax_2echeckedWays_st, g_heff_2esyntax_2epresyntax_2echeckedWays_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr_str0, 0, "");

HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(V v_asBits_240, V v_segs_241, V v_sp_242) {
top: ;
  if ((heff_dup(v_asBits_240) == NTAG(TAG_True))) {
    return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  } else {
    V v_t_243 = (g_list_2eany_24s689038521x519269801(v_segs_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    } else {
      heff_drop(v_t_243);
      V v_t_244 = (g_list_2emap_24s34825065x1144190520(heff_dup(v_segs_241)));
      HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(v_t_244, MK_INT(0LL)));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_n_248 = v_field_247;
          if (!heff_intEq_c_lent(v_n_248, MK_INT(0LL), 2)) {
            heff_drop(v_n_248);
            return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
          } else {
            heff_drop(v_n_248);
            V v_x1_249 = (g_list_2eany_24s689038521x519269801(v_segs_241));
            if (!(heff_dup(v_x1_249) == NTAG(TAG_True))) {
              heff_drop(v_x1_249);
              V v_t_2410 = (g_list_2eall_24s1414119352x995333365(MK_INT(0LL), v_segs_241));
              if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
                heff_drop(v_t_2410);
                V v_t_2411 = (g_heff_2esyntax_2epresyntax_2ewholeBinary(v_segs_241, ((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr_str0)));
                HEFF_LAST return g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr(v_segs_241, v_sp_242, v_t_2411);
              } else {
                heff_drop(v_t_2410);
                return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_True); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
              }
            } else {
              heff_drop(v_x1_249);
              return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_True); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
            }
          }
        } else {
          heff_drop(v_field_247);
          return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_str0, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_str1, 49, "cannot use descriptive syntax in nominal position");
Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V v_tok_240, V v_sp_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_TPi: {
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_245, v_sp_241});
  }
  case TAG_TSig: {
    V v_ru_24n_242_24TSig = heff_take_reuse_n(v_n_242, 0ULL, 1);
    V v_t_247 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_str0), NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_at_n(v_ru_24n_242_24TSig, TAG_TInf, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_247, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_241});
  }
  case TAG_TSum: {
    V v_ru_24n_242_24TSum = heff_take_reuse_n(v_n_242, 0ULL, 1);
    V v_t_2410 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_str1), NTAG(TAG_Nothing)});
    V v_t_2411 = heff_tag_at_n(v_ru_24n_242_24TSum, TAG_TInf, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_241});
  }
  case TAG_TType: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2412, v_sp_241});
  }
  case TAG_TInt: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2413, v_sp_241});
  }
  case TAG_TFloat: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2414, v_sp_241});
  }
  case TAG_TString: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2415, v_sp_241});
  }
  case TAG_TRune: {
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2416, v_sp_241});
  }
  case TAG_TArray: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2418, v_sp_241});
  }
  case TAG_TFixed: {
    V v_t_2420 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2420, v_sp_241});
  }
  case TAG_TInf: {
    V v_t_2422 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2422, v_sp_241});
  }
  case TAG_TChk: {
    V v_t_2424 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2424, v_sp_241});
  }
  case TAG_TNominal: {
    V v_t_2426 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2426, v_sp_241});
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(a[0], a[1], a[2]);
}