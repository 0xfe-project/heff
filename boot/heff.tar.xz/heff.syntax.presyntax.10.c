// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndJump 17665
#define TAG_MkAlt 55173
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_start 311115900
#define LBL_stmts 311127493
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtBy_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2easAction(V, V, V);
V g_heff_2esyntax_2epresyntax_2easAction_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2easAction_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eguardE(V, V);
V g_heff_2esyntax_2epresyntax_2eguardE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eguardE_clo;
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2eisMadeName(V);
V g_heff_2esyntax_2epresyntax_2eisMadeName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisMadeName_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2eliftE(V, V, V);
V g_heff_2esyntax_2epresyntax_2eliftE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eliftE_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo;
V g_heff_2esyntax_2epresyntax_2escopeJoin(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2estmtAcc_24s153905797x297886855_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eutf8Of(V);
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewholeBinary(V, V);
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eall_24s1687051711x1677682329(V, V);
V g_list_2eall_24s1687051711x1677682329_entry(V self, V *a);
extern Clo g_list_2eall_24s1687051711x1677682329_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2eany_24s717144537x1885076661(V);
V g_list_2eany_24s717144537x1885076661_entry(V self, V *a);
extern Clo g_list_2eany_24s717144537x1885076661_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esegmentOdd_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2esegmentOdd(V v_ty_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(v_ty_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2esegmentOdd(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str3, 0, "");
Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eutf8Of_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eutf8Of(V v_c_240) {
top: ;
  if (heff_intLt_c_lent(v_c_240, MK_INT(128LL), 2)) {
    return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(1LL), v_c_240, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str0)));
  } else {
    if (heff_intLt_c_lent(v_c_240, MK_INT(2048LL), 2)) {
      int64_t v_t_243 = (((int64_t)192ULL) + (heff_peek_word(v_c_240) / ((int64_t)64ULL)));
      int64_t v_t_244 = ((v_t_243 * ((int64_t)256ULL)) + ((int64_t)128ULL));
      int64_t v_t_245 = (v_t_244 + (heff_unbox_word(v_c_240) % ((int64_t)64ULL)));
      return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(2LL), heff_box_word(v_t_245), ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str1)));
    } else {
      if (heff_intLt_c_lent(v_c_240, MK_INT(65536LL), 2)) {
        int64_t v_t_247 = (((int64_t)224ULL) + (heff_peek_word(v_c_240) / ((int64_t)4096ULL)));
        int64_t v_t_248 = ((v_t_247 * ((int64_t)256ULL)) + ((int64_t)128ULL));
        int64_t v_t_249 = ((heff_peek_word(v_c_240) / ((int64_t)64ULL)) % ((int64_t)64ULL));
        int64_t v_t_2410 = ((v_t_248 + v_t_249) * ((int64_t)256ULL));
        int64_t v_t_2411 = ((v_t_2410 + ((int64_t)128ULL)) + (heff_unbox_word(v_c_240) % ((int64_t)64ULL)));
        return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(3LL), heff_box_word(v_t_2411), ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str2)));
      } else {
        V v_t_2412 = heff_intAdd(MK_INT(240LL), heff_intDiv(heff_dup(v_c_240), MK_INT(262144LL)));
        V v_t_2413 = heff_intAdd(heff_intMul(v_t_2412, MK_INT(256LL)), MK_INT(128LL));
        V v_t_2414 = heff_intMod(heff_intDiv(heff_dup(v_c_240), MK_INT(4096LL)), MK_INT(64LL));
        V v_t_2415 = heff_intMul(heff_intAdd(v_t_2413, v_t_2414), MK_INT(256LL));
        V v_t_2416 = heff_intMod(heff_intDiv(heff_dup(v_c_240), MK_INT(64LL)), MK_INT(64LL));
        V v_t_2417 = heff_intAdd(heff_intAdd(v_t_2415, MK_INT(128LL)), v_t_2416);
        V v_t_2418 = heff_intAdd(heff_intMul(v_t_2417, MK_INT(256LL)), MK_INT(128LL));
        V v_t_2419 = heff_intAdd(v_t_2418, heff_intMod(v_c_240, MK_INT(64LL)));
        return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(4LL), v_t_2419, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str3)));
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eutf8Of(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str1, 4, "Unit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str2, 14, "prelude.typeOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str3, 14, "prelude.typeOf");
V g_heff_2esyntax_2epresyntax_2evarParams_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2evarParams_lam1(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2evarParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evarParams_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2evarParams(V v_sp_240, V v_unit_241, V v_vars_242) {
top: ;
  if ((heff_dup(v_unit_241) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_vars_242)) {
    case TAG_Nil: {
      V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str0)}), heff_dup(v_sp_240)});
      V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str1)}), v_sp_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_t_244}), NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      return (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evarParams_lam0, 1, 1, (V[]){v_sp_240}), v_vars_242));
    }
    default: return heff_nomatch(v_vars_242);
    }
  } else {
    return (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evarParams_lam1, 1, 1, (V[]){v_sp_240}), v_vars_242));
  }
}
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2evarParams(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2epresyntax_2evarParams_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_x_247)}), heff_dup(v_sp_240)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str2)}), heff_dup(v_sp_240)});
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_247}), v_sp_240});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_249, v_t_2411));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_t_2412});
}
V g_heff_2esyntax_2epresyntax_2evarParams_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_x_2413)}), heff_dup(v_sp_240)});
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str3)}), heff_dup(v_sp_240)});
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_2413}), v_sp_240});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2415, v_t_2417));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_t_2418});
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ejumpCall_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpCall_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ejumpCall(V v_cx_240, V v_sp_241, V v_j_242) {
top: ;
  V v_t_243 = heff_intSub(heff_dup(heff_rfield(v_cx_240, 4)), heff_take_field(v_j_242, 3));
  V v_vars_244 = heff_take_field(v_j_242, 1);
  V v_t_245 = heff_take_field(v_j_242, 2);
  V v_t_249;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    switch (heff_tag_of(v_vars_244)) {
    case TAG_Nil: {
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ejumpCall_str0)}), heff_dup(v_sp_241)});
      v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      v_t_249 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_244));
      break;
    }
    default: heff_nomatch(v_vars_244);
    }
  } else {
    heff_drop(v_t_245);
    v_t_249 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_244));
  }
  V v_t_2410 = (g_heff_2esyntax_2epresyntax_2eapp(heff_get_n(v_j_242, 0, 4), v_t_249));
  return (g_heff_2esyntax_2epresyntax_2eleaving(v_cx_240, v_sp_241, v_t_243, v_t_2410));
}
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpCall(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epatNames_24dps_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2esyntax_2epresyntax_2epatNames_24dps_str0), 2)) {
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        heff_drop(v_x_244);
        return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
      } else {
        V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
        return heff_setField(v_d_241, MK_INT(1LL), v_t_246);
      }
    }
    case TAG_PatTag: {
      V v_ps_249 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_249));
      V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2411);
    }
    case TAG_PatOp: {
      V v_ps_2414 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2414));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2415); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2416);
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2422 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2422));
      V v_t_2424 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2423; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2423); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2424);
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2426 = heff_field(v_x11_242, 0);
      V v_q_2428 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 5ULL, 3);
      V v_cell_2429 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2426, heff_hole()});
      V v_u_2430 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2429));
      heff_drop(v_u_2430);
      V t_0 = v_q_2428;
      V t_1 = v_cell_2429;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatNames_24dps(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    HeffT2 v_t_244 = ({ V a_0 = v_st_240; V a_1 = v_x_242; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2estmtAcc_24s153905797x297886855_24cpr(a_0, a_1)); heff_drop(v_st_240); r_; });
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_st_247 = v_field_245;
      V v_y_248 = v_field_246;
      HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_st_247, v_xs_243));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v_y_2413 = v_field_2411;
        return ((HeffT2){{v_x_2412, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_248, v_y_2413})}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str0, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str2, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str3, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str4, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str5, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str6, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str7, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str8, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str9, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str10, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str11, 1, "#");
V g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V v_l_240, V v_acc_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_At: {
    V v_e1_243 = heff_dup(heff_field(v_e_242, 0));
    V v_sp_244 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_EVar: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_246 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_246, v_acc_241, v_e_242);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_248 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_248, v_acc_241, v_e_242);
    }
    case TAG_ETag: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2410, v_acc_241, v_e_242);
    }
    case TAG_EInt: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2412, v_acc_241, v_e_242);
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2414, v_acc_241, v_e_242);
    }
    case TAG_EString: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2416 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2416, v_acc_241, v_e_242);
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2418 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2418, v_acc_241, v_e_242);
    }
    case TAG_ERune: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2420, v_acc_241, v_e_242);
    }
    case TAG_EWord: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2422, v_acc_241, v_e_242);
    }
    case TAG_EApp: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2425, v_acc_241, v_e_242);
    }
    case TAG_EProject: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2427, v_acc_241, v_e_242);
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2430, v_acc_241, v_e_242);
    }
    case TAG_EPi: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2433 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2433, v_acc_241, v_e_242);
    }
    case TAG_ELam: {
      V v_b_2434 = heff_field(v_e1_243, 0);
      V v_body_2435 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24ELam = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      heff_drop_tag(v_e_242, 2);
      V v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELam, TAG_ELam, 2, (V[]){v_b_2434, v_body_2435}), v_sp_244});
      V v_f_2437 = (g_heff_2esyntax_2epresyntax_2eguardE(heff_get_n(v_l_240, 1, 2), v_t_2436));
      return ((HeffT2){{v_acc_241, v_f_2437}});
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2440, v_acc_241, v_e_242);
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_243, 0ULL, 4);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2445 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2445, v_acc_241, v_e_242);
    }
    case TAG_ESig: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2447 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2447, v_acc_241, v_e_242);
    }
    case TAG_ESum: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2449 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2449, v_acc_241, v_e_242);
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2451 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2451, v_acc_241, v_e_242);
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2454 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2454, v_acc_241, v_e_242);
    }
    case TAG_EMatch: {
      V v_s_2455 = heff_field(v_e1_243, 0);
      V v_alts_2456 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24EMatch = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      heff_drop_tag(v_e_242, 2);
      HeffT2 v_t_2457 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_dup(v_l_240), v_acc_241, v_s_2455));
      {
        V v_field_2458 = v_t_2457.f[0];
        V v_field_2459 = v_t_2457.f[1];
        V v_x_2460 = v_field_2458;
        V v_y_2461 = v_field_2459;
        V v_t_2462 = (g_list_2eany_24s717144537x1885076661(v_alts_2456));
        if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
          heff_drop(v_t_2462);
          V v_t_2463 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
          V v_t_2464 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str1), v_t_2463));
          V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){heff_dup(v_l_240)}));
          V v_t_2466 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2easAction_clo), 2, (V[]){v_t_2465, heff_get_n(v_l_240, 0, 2)}));
          V v_t_2467 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ealtBy_clo), 1, (V[]){v_t_2466}));
          V v_t_2468 = (g_list_2emap(v_t_2467, v_alts_2456));
          V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_2461, v_t_2468}), heff_dup(v_sp_244)});
          V v_f_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2464, v_t_2469}), v_x_2460});
          V v_t_2471 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
          V v_t_2472 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str3), v_t_2471));
          V v_f_2473 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2472}), v_sp_244});
          return ((HeffT2){{v_f_2470, v_f_2473}});
        } else {
          heff_drop(v_t_2462);
          V v_f_2474 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
          HeffT2 v_t_2485 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0, 2, 1, (V[]){v_f_2474}), v_x_2460, v_alts_2456));
          {
            V v_field_2486 = v_t_2485.f[0];
            V v_field_2487 = v_t_2485.f[1];
            V v_x_2488 = v_field_2486;
            V v_y_2489 = v_field_2487;
            V v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_2461, v_y_2489}), v_sp_244});
            return ((HeffT2){{v_x_2488, v_t_2490}});
          }
        }
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2491 = heff_field(v_e1_243, 0);
      V v_e12_2492 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24ELetIn = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      heff_drop_tag(v_e_242, 2);
      switch (heff_tag_of(v_e12_2492)) {
      case TAG_At: {
        V v_e121_2493 = heff_field(v_e12_2492, 0);
        V v_asp_2494 = heff_field(v_e12_2492, 1);
        V v_ru_24e12_2492_24At = heff_take_reuse_n(v_e12_2492, 3ULL, 2);
        switch (heff_tag_of(v_e121_2493)) {
        case TAG_MkAlt: {
          V v_p_2495 = heff_field(v_e121_2493, 0);
          V v_body_2496 = heff_field(v_e121_2493, 1);
          V v_ru_24e121_2493_24MkAlt = heff_take_reuse_n(v_e121_2493, 3ULL, 2);
          HeffT2 v_t_2497 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_dup(v_l_240), v_acc_241, v_rhs_2491));
          {
            V v_field_2498 = v_t_2497.f[0];
            V v_field_2499 = v_t_2497.f[1];
            V v_x_24100 = v_field_2498;
            V v_y_24101 = v_field_2499;
            V v_t_24102 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_body_2496)));
            if ((heff_dup(v_t_24102) == NTAG(TAG_True))) {
              heff_drop(v_t_24102);
              V v_t_24103 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
              V v_t_24104 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str4), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str5), v_t_24103));
              V v_lift_24105 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){heff_dup(v_l_240)}));
              V v_cx_24106 = heff_get_n(v_l_240, 0, 2);
              V v_x1_24107 = heff_tr(heff_call(v_lift_24105, 2, (V[]){NTAG(TAG_Nil), v_body_2496}));
              V v_t_24117;
              switch (heff_tag_of(v_x1_24107)) {
              case TAG_MkPair: {
                V v_x_24108 = heff_field(v_x1_24107, 0);
                V v_y_24109 = heff_field(v_x1_24107, 1);
                V v_ru_24x1_24107_24MkPair = heff_take_reuse_n(v_x1_24107, 3ULL, 2);
                V v_t_24110 = heff_get_n(heff_dup(heff_rfield(v_cx_24106, 0)), 1, 2);
                V v_t_24113;
                switch (heff_tag_of(v_y_24109)) {
                case TAG_At: {
                  V v_s_24112 = heff_dup(heff_field(v_y_24109, 1));
                  v_t_24113 = v_s_24112;
                  break;
                }
                default: heff_nomatch(v_y_24109);
                }
                V v_t_24114 = heff_tag_at_n(v_ru_24e12_2492_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24110}), v_t_24113});
                V v_t_24115 = heff_tag_at_n(v_ru_24x1_24107_24MkPair, TAG_Cons, 2, (V[]){v_y_24109, NTAG(TAG_Nil)});
                V v_t_24116 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24114, v_t_24115));
                v_t_24117 = ({ V a_0 = v_cx_24106; V a_1 = v_x_24108; V a_2 = v_t_24116; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24108); r_; });
                break;
              }
              default: heff_nomatch(v_x1_24107);
              }
              V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e121_2493_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2495, v_t_24117}), v_asp_2494});
              V v_t_24119 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_24101, v_t_24118}), heff_dup(v_sp_244)});
              V v_f_24120 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24104, v_t_24119}), v_x_24100});
              V v_t_24121 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
              V v_t_24122 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str6), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str7), v_t_24121));
              V v_f_24123 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24122}), v_sp_244});
              return ((HeffT2){{v_f_24120, v_f_24123}});
            } else {
              heff_drop_cell(v_ru_24e121_2493_24MkAlt, 2);
              heff_drop(v_t_24102);
              HeffT2 v_t_24124 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_x_24100, v_body_2496));
              {
                V v_field_24125 = v_t_24124.f[0];
                V v_field_24126 = v_t_24124.f[1];
                V v_x_24127 = v_field_24125;
                V v_y_24128 = v_field_24126;
                V v_t_24129 = heff_tag_at_n(v_ru_24e12_2492_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2495, v_y_24128}), v_asp_2494});
                V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_24101, v_t_24129}), v_sp_244});
                return ((HeffT2){{v_x_24127, v_t_24130}});
              }
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_e121_2493)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e12_2492)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24131 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24EDo = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      heff_drop_tag(v_e_242, 2);
      V v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EDo, TAG_EDo, 1, (V[]){v_ss_24131}), v_sp_244});
      V v_f_24133 = (g_heff_2esyntax_2epresyntax_2eguardE(heff_get_n(v_l_240, 1, 2), v_t_24132));
      return ((HeffT2){{v_acc_241, v_f_24133}});
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24136 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24136, v_acc_241, v_e_242);
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24138 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24138, v_acc_241, v_e_242);
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_243, 0ULL, 3);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24142 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24142, v_acc_241, v_e_242);
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24145 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24145, v_acc_241, v_e_242);
    }
    case TAG_EFor: {
      heff_take_n(v_e1_243, 0ULL, 3);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24149 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24149, v_acc_241, v_e_242);
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24152 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24152, v_acc_241, v_e_242);
    }
    case TAG_EBreak: {
      heff_drop_rec(v_sp_244, 2);
      V v_t_24153 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24153, v_acc_241, v_e_242);
    }
    case TAG_EContinue: {
      heff_drop_rec(v_sp_244, 2);
      V v_t_24154 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24154, v_acc_241, v_e_242);
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24156 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24156, v_acc_241, v_e_242);
    }
    case TAG_ENest: {
      V v_c_24157 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ENest = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      heff_drop_tag(v_e_242, 2);
      HeffT2 v_t_24158 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_acc_241, v_c_24157));
      {
        V v_field_24159 = v_t_24158.f[0];
        V v_field_24160 = v_t_24158.f[1];
        V v_x_24161 = v_field_24159;
        V v_y_24162 = v_field_24160;
        V v_t_24163 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
        V v_t_24164 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str8), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str9), v_t_24163));
        V v_f_24165 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24164, v_y_24162}), v_x_24161});
        V v_t_24166 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
        V v_t_24167 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str10), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str11), v_t_24166));
        V v_f_24168 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ENest, TAG_EVar, 1, (V[]){v_t_24167}), v_sp_244});
        return ((HeffT2){{v_f_24165, v_f_24168}});
      }
    }
    case TAG_ELazy: {
      V v_body_24169 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ELazy = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      heff_drop_tag(v_e_242, 2);
      V v_t_24170 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELazy, TAG_ELazy, 1, (V[]){v_body_24169}), v_sp_244});
      V v_f_24171 = (g_heff_2esyntax_2epresyntax_2eguardE(heff_get_n(v_l_240, 1, 2), v_t_24170));
      return ((HeffT2){{v_acc_241, v_f_24171}});
    }
    case TAG_ETuple: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24173 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24173, v_acc_241, v_e_242);
    }
    case TAG_ETry: {
      V v_tr_24174 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ETry = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      heff_drop_rec(v_l_240, 2);
      heff_drop_tag(v_e_242, 2);
      V v_t_24175 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ETry, TAG_ETry, 1, (V[]){v_tr_24174}), v_sp_244});
      return ((HeffT2){{v_acc_241, v_t_24175}});
    }
    case TAG_EWith: {
      V v_w_24176 = heff_field(v_e1_243, 0);
      V v_x_24177 = heff_field(v_e1_243, 1);
      V v_xsp_24178 = heff_field(v_e1_243, 2);
      V v_body_24179 = heff_field(v_e1_243, 3);
      V v_ru_24e1_243_24EWith = heff_take_reuse_n(v_e1_243, 15ULL, 4);
      heff_drop_rec(v_l_240, 2);
      heff_drop_tag(v_e_242, 2);
      V v_t_24180 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EWith, TAG_EWith, 4, (V[]){v_w_24176, v_x_24177, v_xsp_24178, v_body_24179}), v_sp_244});
      return ((HeffT2){{v_acc_241, v_t_24180}});
    }
    default: return ((HeffT2){{heff_nomatch(v_e1_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0(V self, V *args) {
  V v_st_2475 = args[0];
  V v_x3_2476 = args[1];
  V v_f_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2476)) {
  case TAG_At: {
    V v_x31_2477 = heff_field(v_x3_2476, 0);
    V v_sp_2478 = heff_field(v_x3_2476, 1);
    V v_ru_24x3_2476_24At = heff_take_reuse_n(v_x3_2476, 3ULL, 2);
    switch (heff_tag_of(v_x31_2477)) {
    case TAG_MkAlt: {
      V v_p_2479 = heff_field(v_x31_2477, 0);
      V v_e_2480 = heff_field(v_x31_2477, 1);
      V v_ru_24x31_2477_24MkAlt = heff_take_reuse_n(v_x31_2477, 3ULL, 2);
      V v_x1_2481 = heff_tr(heff_call(v_f_2474, 2, (V[]){v_st_2475, v_e_2480}));
      switch (heff_tag_of(v_x1_2481)) {
      case TAG_MkPair: {
        V v_x_2482 = heff_field(v_x1_2481, 0);
        V v_y_2483 = heff_field(v_x1_2481, 1);
        heff_take_n(v_x1_2481, 3ULL, 2);
        V v_t_2484 = heff_tag_at_n(v_ru_24x3_2476_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2479, v_y_2483}), v_sp_2478});
        return heff_tag_at_n(v_ru_24x31_2477_24MkAlt, TAG_MkPair, 2, (V[]){v_x_2482, v_t_2484});
      }
      default: return heff_nomatch(v_x1_2481);
      }
    }
    default: return heff_nomatch(v_x31_2477);
    }
  }
  default: return heff_nomatch(v_x3_2476);
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_str0, 4, "join");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_str2, 4, "join");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_str3, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2escopeJoin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2escopeJoin_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2escopeJoin(V v_t_240, V v_cx_241, V v_sp_242, V v_scope_243, V v_rest_244, V v_end_245) {
top: ;
  V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_str1), v_t_246));
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), heff_dup(v_sp_242)});
  V v_t_249 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){v_t_248, heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_241, 4))});
  V v_t_2410 = heff_tr(heff_call(v_scope_243, 1, (V[]){heff_tag_n(TAG_EndJump, 1, (V[]){v_t_249})}));
  V v_t_2411 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_str3), v_t_2411));
  V v_t_2413 = ({ V a_0 = heff_dup(v_sp_242); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_241, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2414 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_cx_241, v_rest_244, v_end_245}));
  V v_t_2415 = (g_heff_2esyntax_2epresyntax_2elocalFun(v_t_2412, heff_dup(v_sp_242), v_t_2413, v_t_2414));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2410, v_t_2416}), v_sp_242});
}
V g_heff_2esyntax_2epresyntax_2escopeJoin_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2escopeJoin(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2echeckedWays_str0, 235, "any of these: give the type where it is bound, `let x : T = ...`; give it in place, `(e : T)`; or write it where a type is expected of it, as an argument of a function whose type is known or as the body of a definition with a signature");

static V g_heff_2esyntax_2epresyntax_2echeckedWays_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2echeckedWays_st;
static V g_heff_2esyntax_2epresyntax_2echeckedWays_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2echeckedWays_str0);
}
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2echeckedWays_st)) return g_heff_2esyntax_2epresyntax_2echeckedWays_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2echeckedWays_val, &g_heff_2esyntax_2epresyntax_2echeckedWays_st, g_heff_2esyntax_2epresyntax_2echeckedWays_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr_str0, 0, "");

HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(V v_asBits_240, V v_segs_241, V v_sp_242) {
top: ;
  if ((heff_dup(v_asBits_240) == NTAG(TAG_True))) {
    return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  } else {
    V v_t_243 = (g_list_2eany_24s689038521x519269801(v_segs_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    } else {
      heff_drop(v_t_243);
      V v_t_244 = (g_list_2emap_24s34825065x1144190520(heff_dup(v_segs_241)));
      HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(v_t_244, MK_INT(0LL)));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_n_249 = v_field_247;
          if (heff_intEq_c(v_n_249, MK_INT(0LL))) {
            V v_x1_2411 = (g_list_2eany_24s689038521x519269801(v_segs_241));
            if ((heff_dup(v_x1_2411) == NTAG(TAG_True))) {
              heff_drop(v_x1_2411);
              return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_True); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
            } else {
              heff_drop(v_x1_2411);
              V v_t_2412 = (g_list_2eall_24s1687051711x1677682329(MK_INT(0LL), v_segs_241));
              if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
                heff_drop(v_t_2412);
                V v_t_2413 = (g_heff_2esyntax_2epresyntax_2ewholeBinary(v_segs_241, ((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr_str0)));
                HEFF_LAST return g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr(v_segs_241, v_sp_242, v_t_2413);
              } else {
                heff_drop(v_t_2412);
                return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_True); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
              }
            }
          } else {
            return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
          }
        } else {
          heff_drop(v_field_247);
          return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eisMadeName_str0, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2eisMadeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eisMadeName_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eisMadeName(V v_x_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2esyntax_2epresyntax_2eisMadeName_str0), v_x_240, MK_INT(0LL), 5)) && ((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) ? ((heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL)) || ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)90ULL)))) : ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)90ULL))))));
  return v_ret_24bool;
}
V g_heff_2esyntax_2epresyntax_2eisMadeName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2eisMadeName(a0); heff_drop(a0); return r;
}