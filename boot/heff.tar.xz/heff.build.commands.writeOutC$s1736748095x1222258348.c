// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_str1, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_str2, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0(V v_outPath_240, V v_hd_241, V v_k_242, V v_done_243, V v_x_244) {
top: ;
  switch (heff_tag_of(v_x_244)) {
  case TAG_Left: {
    V v_ru_24x_244_24Left = heff_take_reuse_n(v_x_244, 0ULL, 1);
    heff_drop(v_done_243);
    int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    V v_t_247 = heff_strSlice_lent(v_outPath_240, heff_box_word(v_t_246), heff_strLength_lent(v_outPath_240, 0), 6);
    V v_t_249;
    if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_str0))) {
      int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
      v_t_249 = heff_strSlice(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_248));
    } else {
      v_t_249 = v_outPath_240;
    }
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_str1), heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_str2)));
    V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_str3)), NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_at_n(v_ru_24x_244_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_lam0, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Right: {
    heff_take_n(v_x_244, 0ULL, 1);
    heff_drop(v_outPath_240);
    return heff_tail(v_done_243, 2, (V[]){v_hd_241, v_k_242});
  }
  default: return heff_nomatch(v_x_244);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_drop(v_x_2417);
  V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_hd_241, v_k_242));
}