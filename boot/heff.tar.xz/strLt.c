// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_strLt_val;
static int g_strLt_st;
static V g_strLt_init(void) {
  return ((V)&prim_strLt_clo);
}
V g_strLt_get(void) {
  if (g_strLt_st == 2) return g_strLt_val;
  if (g_strLt_st == 1) heff_fail("defined by itself");
  g_strLt_st = 1;
  g_strLt_val = heff_tr(g_strLt_init());
  g_strLt_st = 2;
  return g_strLt_val;
}