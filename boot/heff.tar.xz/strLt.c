// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static V prim_strLt_entry(V self, V *a) { (void)self; return heff_strLt(a[0], a[1]); }
static Clo prim_strLt_clo = {{0x80000000u, K_CLO, 0}, prim_strLt_entry, 2, 0};
V g_strLt_get(void);

static V g_strLt_val;
static HEFF_ONCE g_strLt_st;
static V g_strLt_init(void) {
  return ((V)&prim_strLt_clo);
}
V g_strLt_get(void) {
  if (HEFF_DONE(g_strLt_st)) return g_strLt_val;
  return heff_global(&g_strLt_val, &g_strLt_st, g_strLt_init);
}