// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2eload_2eunder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eunder_entry, 3, 0};

V g_heff_2eload_2eunder(V v_ps_240, V v_d_241, V v_p_242) {
top: ;
  V v_st_243 = heff_get(v_ps_240, LBL_style);
  V v_t_244 = (g_std_2epath_2eparse(v_st_243, v_d_241));
  V v_t_245 = (g_std_2epath_2eparse(v_st_243, v_p_242));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = ({ V a_0 = heff_get(heff_dup(v_p_246), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_246), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_248 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_246), LBL_drive), heff_get(v_p_246, LBL_absolute), v_t_247});
  return ({ V a_0 = v_st_243; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); r_; });
}
V g_heff_2eload_2eunder_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2eunder(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eload_2emoduleOf_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2emoduleOf_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eload_2emoduleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2emoduleOf_entry, 2, 0};

V g_heff_2eload_2emoduleOf(V v_ps_240, V v_path_241) {
top: ;
  V v_d_242 = heff_get(heff_dup(v_ps_240), LBL_lib);
  V v_t_243 = ({ V b_0 = heff_get(heff_dup(v_ps_240), LBL_style); V a_1 = heff_dup(v_d_242); V a_2 = heff_dup(v_path_241); V r_ = (g_std_2epath_2eisUnder(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_244 = ({ V b_0 = heff_get(heff_dup(v_ps_240), LBL_style); V a_1 = v_d_242; V a_2 = heff_dup(v_path_241); V r_ = (g_std_2epath_2erelative(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    break;
  }
  case TAG_False: {
    heff_drop(v_d_242);
    v_t_244 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_p_2418;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_d_245 = heff_get(heff_dup(v_ps_240), LBL_src);
    V v_t_246 = ({ V b_0 = heff_get(heff_dup(v_ps_240), LBL_style); V a_1 = heff_dup(v_d_245); V a_2 = heff_dup(v_path_241); V r_ = (g_std_2epath_2eisUnder(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = ({ V b_0 = heff_get(heff_dup(v_ps_240), LBL_style); V a_1 = v_d_245; V a_2 = heff_dup(v_path_241); V r_ = (g_std_2epath_2erelative(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        V v_d_248 = heff_get(heff_dup(v_ps_240), LBL_root);
        V v_t_249 = ({ V b_0 = heff_get(heff_dup(v_ps_240), LBL_style); V a_1 = heff_dup(v_d_248); V a_2 = heff_dup(v_path_241); V r_ = (g_std_2epath_2eisUnder(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          V v_t_2410 = ({ V b_0 = heff_get(heff_dup(v_ps_240), LBL_style); V a_1 = v_d_248; V a_2 = heff_dup(v_path_241); V r_ = (g_std_2epath_2erelative(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          switch (heff_tag_of(v_t_2410)) {
          case TAG_Nothing: {
            v_p_2418 = v_path_241;
            break;
          }
          case TAG_Just: {
            V v_rel_2411 = heff_field(v_t_2410, 0);
            heff_take_n(v_t_2410, 1ULL, 1);
            heff_drop(v_path_241);
            v_p_2418 = v_rel_2411;
            break;
          }
          default: heff_nomatch(v_t_2410);
          }
          break;
        }
        case TAG_False: {
          heff_drop(v_d_248);
          v_p_2418 = v_path_241;
          break;
        }
        default: heff_nomatch(v_t_249);
        }
        break;
      }
      case TAG_Just: {
        V v_rel_2412 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        heff_drop(v_path_241);
        v_p_2418 = v_rel_2412;
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_d_245);
      V v_d_2413 = heff_get(heff_dup(v_ps_240), LBL_root);
      V v_t_2414 = ({ V b_0 = heff_get(heff_dup(v_ps_240), LBL_style); V a_1 = heff_dup(v_d_2413); V a_2 = heff_dup(v_path_241); V r_ = (g_std_2epath_2eisUnder(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        V v_t_2415 = ({ V b_0 = heff_get(heff_dup(v_ps_240), LBL_style); V a_1 = v_d_2413; V a_2 = heff_dup(v_path_241); V r_ = (g_std_2epath_2erelative(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        switch (heff_tag_of(v_t_2415)) {
        case TAG_Nothing: {
          v_p_2418 = v_path_241;
          break;
        }
        case TAG_Just: {
          V v_rel_2416 = heff_field(v_t_2415, 0);
          heff_take_n(v_t_2415, 1ULL, 1);
          heff_drop(v_path_241);
          v_p_2418 = v_rel_2416;
          break;
        }
        default: heff_nomatch(v_t_2415);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_d_2413);
        v_p_2418 = v_path_241;
        break;
      }
      default: heff_nomatch(v_t_2414);
      }
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    break;
  }
  case TAG_Just: {
    V v_rel_2417 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_path_241);
    v_p_2418 = v_rel_2417;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_2419 = heff_intSub(heff_strLength(heff_dup(v_p_2418)), MK_INT(3LL));
  V v_t_2420 = heff_strSlice(heff_dup(v_p_2418), v_t_2419, heff_strLength(heff_dup(v_p_2418)));
  V v_t_2421 = heff_strEq(v_t_2420, ((V)&g_heff_2eload_2emoduleOf_str0));
  V v_s_2423;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_True: {
    V v_t_2422 = heff_intSub(heff_strLength(heff_dup(v_p_2418)), MK_INT(3LL));
    v_s_2423 = heff_strSlice(v_p_2418, MK_INT(0LL), v_t_2422);
    break;
  }
  case TAG_False: {
    v_s_2423 = v_p_2418;
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V v_p_2424 = ({ V b_0 = heff_get(v_ps_240, LBL_style); V a_1 = v_s_2423; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2425 = ({ V a_0 = heff_get(heff_dup(v_p_2424), LBL_absolute); V b_1 = heff_get(v_p_2424, LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eload_2emoduleOf_str1);
  }
  case TAG_Cons: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_xs_2427 = heff_field(v_x2_2425, 1);
    heff_take_n(v_x2_2425, 3ULL, 2);
    return ({ V a_0 = v_x_2426; V a_1 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s13(a_0, a_1)); heff_drop(v_xs_2427); r_; });
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2eload_2emoduleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2emoduleOf(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eproblemMsg_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eproblemMsg_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eload_2eproblemMsg_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
Clo g_heff_2eload_2eproblemMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eproblemMsg_entry, 3, 0};

V g_heff_2eload_2eproblemMsg(V v_path_240, V v_src_241, V v_p_242) {
top: ;
  V v_t_243 = (g_heff_2erender_2elineColGo(heff_dup(v_src_241), heff_get(heff_dup(v_p_242), LBL_at), MK_INT(0LL), MK_INT(0LL)));
  V v_t_244 = heff_intAdd(heff_get(v_t_243, LBL_line), MK_INT(1LL));
  V v_t_245 = (g_heff_2erender_2elineColGo(v_src_241, heff_get(heff_dup(v_p_242), LBL_at), MK_INT(0LL), MK_INT(0LL)));
  V v_t_246 = heff_intAdd(heff_get(v_t_245, LBL_col), MK_INT(1LL));
  return heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2eload_2eproblemMsg_str0), heff_strAppend(heff_intShow(v_t_244), heff_strAppend(((V)&g_heff_2eload_2eproblemMsg_str1), heff_strAppend(heff_intShow(v_t_246), heff_strAppend(((V)&g_heff_2eload_2eproblemMsg_str2), heff_get(v_p_242, LBL_msg)))))));
}
V g_heff_2eload_2eproblemMsg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2eproblemMsg(a[0], a[1], a[2]);
}
Clo g_heff_2eload_2epkgByPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2epkgByPath_entry, 2, 0};

V g_heff_2eload_2epkgByPath(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_k_242), LBL_path), heff_dup(v_p_241));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_k_242)});
    }
    case TAG_False: {
      V t_0 = v_rest_243;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eload_2epkgByPath_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eload_2epkgByPath(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2ecachedDir_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2ecachedDir_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2ecachedDir_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {64}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2ecachedDir_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2ecachedDir_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2eload_2ecachedDir_lam0(V self, V *args);
Clo g_heff_2eload_2ecachedDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ecachedDir_entry, 3, 0};

V g_heff_2eload_2ecachedDir(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_ps_240), LBL_style);
  V v_sep_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Posix: {
    v_sep_244 = ((V)&g_heff_2eload_2ecachedDir_str0);
    break;
  }
  case TAG_Windows: {
    v_sep_244 = ((V)&g_heff_2eload_2ecachedDir_str1);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2eload_2ecachedDir_str2), v_v_242));
  V v_x2_246 = (g_prelude_2esplitFrom(((V)&g_heff_2eload_2ecachedDir_str3), v_t_245, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2411;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_sep_244);
    v_t_2411 = ((V)&g_heff_2eload_2ecachedDir_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_2411 = ({ V a_0 = heff_clo(g_heff_2eload_2ecachedDir_lam0, 2, 1, (V[]){v_sep_244}); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  HEFF_LAST return g_heff_2eload_2eunder(heff_dup(v_ps_240), heff_get(v_ps_240, LBL_mod), v_t_2411);
}
V g_heff_2eload_2ecachedDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2ecachedDir(a[0], a[1], a[2]);
}
V g_heff_2eload_2ecachedDir_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_y_2410 = args[1];
  V v_sep_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strAppend(v_acc_249, heff_strAppend(v_sep_244, v_y_2410));
}
Clo g_heff_2eload_2etakeUntil_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2etakeUntil_entry, 2, 0};

V g_heff_2eload_2etakeUntil(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_240);
      heff_drop(v_rest_243);
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, NTAG(TAG_Nil)});
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, (g_heff_2eload_2etakeUntil(v_x_240, v_rest_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eload_2etakeUntil_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2etakeUntil(a[0], a[1]);
}
Clo g_heff_2eload_2ecycleAmong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ecycleAmong_entry, 3, 0};

V g_heff_2eload_2ecycleAmong(V v_pkgs_240, V v_stack_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_stack_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_path_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_path_243)}));
    V v_t_246 = (g_prelude_2eany(v_t_245, v_stack_241));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_rest_244);
      V v_xs_247 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_path_243), (g_heff_2eload_2etakeUntil(v_path_243, v_stack_241))});
      V v_t_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_247));
      return heff_tag(TAG_Just, 1, (V[]){v_t_248});
    }
    case TAG_False: {
      V v_t_249 = (g_heff_2eload_2epkgByPath(v_pkgs_240, heff_dup(v_path_243)));
      V v_t_2411;
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        v_t_2411 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_k_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        v_t_2411 = (g_prelude_2emap_24s513(heff_get(v_k_2410, LBL_scope)));
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      V v_x1_2412 = (g_heff_2eload_2ecycleAmong(v_pkgs_240, heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, heff_dup(v_stack_241)}), v_t_2411));
      V v_x2_2413 = (g_heff_2eload_2ecycleAmong(v_pkgs_240, v_stack_241, v_rest_244));
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_Nothing: {
        return v_x2_2413;
      }
      case TAG_Just: {
        V v_x_2414 = heff_field(v_x1_2412, 0);
        V v_ru_24x1_2412_24Just = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
        heff_drop(v_x2_2413);
        return heff_tag_at(v_ru_24x1_2412_24Just, TAG_Just, 1, (V[]){v_x_2414});
      }
      default: return heff_nomatch(v_x1_2412);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eload_2ecycleAmong_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eload_2ecycleAmong(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2efreeName_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2efreeName_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2eload_2efreeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2efreeName_entry, 3, 0};

V g_heff_2eload_2efreeName(V v_taken_240, V v_x_241, V v_n_242) {
top: ;
  V v_t_243 = heff_intLt(heff_dup(v_n_242), MK_INT(2LL));
  V v_x_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_x_244 = heff_dup(v_x_241);
    break;
  }
  case TAG_False: {
    v_x_244 = heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eload_2efreeName_str0), heff_intShow(heff_dup(v_n_242))));
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_x_244}));
  V v_x1_246 = (g_prelude_2eany(v_t_245, v_taken_240));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_True: {
    V t_0 = v_taken_240;
    V t_1 = v_x_241;
    V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
    v_taken_240 = t_0;
    v_x_241 = t_1;
    v_n_242 = t_2;
    goto top;
  }
  case TAG_False: {
    V v_t_247 = heff_intLt(heff_dup(v_n_242), MK_INT(2LL));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_n_242);
      return v_x_241;
    }
    case TAG_False: {
      return heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2eload_2efreeName_str1), heff_intShow(v_n_242)));
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2eload_2efreeName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eload_2efreeName(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2eload_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2enamedGo_entry, 2, 0};

V g_heff_2eload_2enamedGo(V v_taken_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2eload_2efreeName(v_taken_240, heff_get(heff_dup(v_k_242), LBL_own), MK_INT(1LL)));
    V v_t_245 = heff_rec(7, shape_239_65_317_225_344_124_289, (V[]){heff_get(heff_dup(v_k_242), LBL_path), heff_get(heff_dup(v_k_242), LBL_dir), heff_get(heff_dup(v_k_242), LBL_src), heff_get(heff_dup(v_k_242), LBL_own), v_t_244, heff_get(heff_dup(v_k_242), LBL_heff), heff_get(heff_dup(v_k_242), LBL_scope)});
    V v_t_246 = (g_heff_2eload_2efreeName(v_taken_240, heff_get(v_k_242, LBL_own), MK_INT(1LL)));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_heff_2eload_2enamedGo(heff_tag(TAG_Cons, 2, (V[]){v_t_246, v_taken_240}), v_rest_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eload_2enamedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2enamedGo(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2epkgOfGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
Clo g_heff_2eload_2epkgOfGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2epkgOfGo_entry, 4, 0};

V g_heff_2eload_2epkgOfGo(V v_ps_240, V v_x2_241, V v_project_242, V v_from_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_from_243);
    return v_project_242;
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_d_246 = heff_get(heff_dup(v_k_244), LBL_dir);
    V v_t_247 = heff_strEq(heff_dup(v_d_246), ((V)&g_heff_2eload_2epkgOfGo_str0));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_ps_240);
      heff_drop(v_project_242);
      heff_drop(v_from_243);
      heff_drop(v_d_246);
      return heff_dup(v_k_244);
    }
    case TAG_False: {
      V v_t_248 = ({ V b_0 = heff_get(heff_dup(v_ps_240), LBL_style); V a_1 = v_d_246; V a_2 = heff_dup(v_from_243); V r_ = (g_std_2epath_2eisUnder(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop(v_ps_240);
        heff_drop(v_project_242);
        heff_drop(v_from_243);
        return heff_dup(v_k_244);
      }
      case TAG_False: {
        V t_0 = v_ps_240;
        V t_1 = v_rest_245;
        V t_2 = v_project_242;
        V t_3 = v_from_243;
        v_ps_240 = t_0;
        v_x2_241 = t_1;
        v_project_242 = t_2;
        v_from_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eload_2epkgOfGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eload_2epkgOfGo(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2erequiredPlace_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eload_2erequiredPlace_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
V g_heff_2eload_2erequiredPlace_lam0(V self, V *args);
Clo g_heff_2eload_2erequiredPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2erequiredPlace_entry, 5, 0};

V g_heff_2eload_2erequiredPlace(V v_ps_240, V v_pkgs_241, V v_k_242, V v_h_243, V v_rest_244) {
top: ;
  V v_it_249 = (g_prelude_2efilter(heff_clo(g_heff_2eload_2erequiredPlace_lam0, 1, 1, (V[]){v_h_243}), heff_get(v_k_242, LBL_scope)));
  switch (heff_tag_of(v_it_249)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_rest_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_it1_2410 = heff_field(v_it_249, 0);
    V v_ru_24it_249_24Cons = heff_take_reuse_n(v_it_249, 1ULL, 2);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_MkPair: {
      V v_p_2413 = heff_field(v_it1_2410, 1);
      V v_ru_24it1_2410_24MkPair = heff_take_reuse_n(v_it1_2410, 2ULL, 2);
      V v_t_2414 = (g_heff_2eload_2epkgByPath(v_pkgs_241, v_p_2413));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        heff_drop(v_ps_240);
        heff_drop(v_rest_244);
        heff_drop_cell(v_ru_24it_249_24Cons, 2);
        heff_drop_cell(v_ru_24it1_2410_24MkPair, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_Just: {
        V v_q_2415 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 1);
        V v_base_2416 = heff_get(heff_dup(v_q_2415), LBL_src);
        V v_t_2417 = heff_strAppend(heff_get(heff_dup(v_q_2415), LBL_own), heff_dup(v_rest_244));
        V v_xs_2418 = (g_prelude_2esplitFrom(((V)&g_heff_2eload_2erequiredPlace_str0), v_t_2417, MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2419 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2418));
        V v_parts_2423;
        switch (heff_tag_of(v_t_2419)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24it_249_24Cons, 2);
          v_parts_2423 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2420 = heff_field(v_t_2419, 0);
          V v_before_2421 = heff_field(v_t_2419, 1);
          heff_take_n(v_t_2419, 3ULL, 2);
          V v_t_2422 = heff_tag_at(v_ru_24it_249_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2420, ((V)&g_heff_2eload_2erequiredPlace_str1)), v_before_2421});
          v_parts_2423 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_t_2422));
          break;
        }
        default: heff_nomatch(v_t_2419);
        }
        V v_t_2424 = heff_tr(heff_apply(((V)&g_heff_2eload_2eunder_clo), 1, (V[]){v_ps_240}));
        V v_t_2425 = (g_prelude_2efoldl(v_t_2424, heff_dup(v_base_2416), v_parts_2423));
        V v_t_2426 = heff_strAppend(heff_get(v_q_2415, LBL_top), v_rest_244);
        return heff_tag_at(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_rec(4, shape_239_20_234_192, (V[]){v_t_2425, v_base_2416, v_parts_2423, v_t_2426}), NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_it_249);
  }
}
V g_heff_2eload_2erequiredPlace_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eload_2erequiredPlace(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2eload_2erequiredPlace_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_h_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 2);
    v_t_248 = v_x_246;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  return heff_strEq(v_t_248, v_h_243);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eload_2eplacesOf_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eload_2eplacesOf_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eload_2eplacesOf_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eload_2eplacesOf_str19 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str20 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eplacesOf_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eload_2eplacesOf_str23 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
Clo g_heff_2eload_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eplacesOf_entry, 4, 0};

V g_heff_2eload_2eplacesOf(V v_ps_240, V v_pkgs_241, V v_from_242, V v_w_243) {
top: ;
  V v_d_244 = heff_get(heff_dup(v_ps_240), LBL_lib);
  V v_t_245 = heff_strEq(heff_dup(v_d_244), ((V)&g_heff_2eload_2eplacesOf_str0));
  V v_t_249;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_d_244);
    V v_t_246 = heff_strEq(heff_get(heff_dup(v_ps_240), LBL_lib), ((V)&g_heff_2eload_2eplacesOf_str1));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_t_249 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_249 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    break;
  }
  case TAG_False: {
    V v_t_247 = ({ V b_0 = heff_get(heff_dup(v_ps_240), LBL_style); V a_1 = v_d_244; V a_2 = heff_dup(v_from_242); V r_ = (g_std_2epath_2eisUnder(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_t_248 = heff_strEq(heff_get(heff_dup(v_ps_240), LBL_lib), ((V)&g_heff_2eload_2eplacesOf_str2));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        v_t_249 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_249 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      break;
    }
    case TAG_False: {
      v_t_249 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    V v_base_2410 = heff_get(heff_dup(v_ps_240), LBL_lib);
    V v_xs_2411 = (g_prelude_2esplitFrom(((V)&g_heff_2eload_2eplacesOf_str3), heff_dup(v_w_243), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2412 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2411));
    V v_parts_2416;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nil: {
      v_parts_2416 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_last_2413 = heff_field(v_t_2412, 0);
      V v_before_2414 = heff_field(v_t_2412, 1);
      V v_ru_24t_2412_24Cons = heff_take_reuse_n(v_t_2412, 3ULL, 2);
      V v_t_2415 = heff_tag_at(v_ru_24t_2412_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2413, ((V)&g_heff_2eload_2eplacesOf_str4)), v_before_2414});
      v_parts_2416 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_t_2415));
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2417 = heff_tr(heff_apply(((V)&g_heff_2eload_2eunder_clo), 1, (V[]){v_ps_240}));
    V v_t_2418 = (g_prelude_2efoldl(v_t_2417, heff_dup(v_base_2410), v_parts_2416));
    return heff_tag(TAG_Cons, 2, (V[]){heff_rec(4, shape_239_20_234_192, (V[]){v_t_2418, v_base_2410, v_parts_2416, v_w_243}), NTAG(TAG_Nil)});
  }
  case TAG_False: {
    switch (heff_tag_of(v_pkgs_241)) {
    case TAG_Nil: {
      heff_drop(v_ps_240);
      heff_drop(v_from_242);
      heff_drop(v_w_243);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_project_2419 = heff_dup(heff_field(v_pkgs_241, 0));
      V v_deps_2420 = heff_dup(heff_field(v_pkgs_241, 1));
      V v_k_2421 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_deps_2420; V a_2 = v_project_2419; V a_3 = heff_dup(v_from_242); V r_ = (g_heff_2eload_2epkgOfGo(a_0, a_1, a_2, a_3)); heff_drop(v_deps_2420); r_; });
      V v_t_2422 = heff_strEq(heff_get(heff_dup(v_k_2421), LBL_own), ((V)&g_heff_2eload_2eplacesOf_str5));
      V v_t_2457;
      switch (heff_tag_of(v_t_2422)) {
      case TAG_True: {
        V v_base_2423 = heff_get(heff_dup(v_k_2421), LBL_src);
        V v_xs_2424 = (g_prelude_2esplitFrom(((V)&g_heff_2eload_2eplacesOf_str6), heff_dup(v_w_243), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2425 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2424));
        V v_parts_2429;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_Nil: {
          v_parts_2429 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2426 = heff_field(v_t_2425, 0);
          V v_before_2427 = heff_field(v_t_2425, 1);
          V v_ru_24t_2425_24Cons = heff_take_reuse_n(v_t_2425, 3ULL, 2);
          V v_t_2428 = heff_tag_at(v_ru_24t_2425_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2426, ((V)&g_heff_2eload_2eplacesOf_str7)), v_before_2427});
          v_parts_2429 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_t_2428));
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        V v_t_2430 = heff_tr(heff_apply(((V)&g_heff_2eload_2eunder_clo), 1, (V[]){heff_dup(v_ps_240)}));
        V v_t_2431 = (g_prelude_2efoldl(v_t_2430, heff_dup(v_base_2423), v_parts_2429));
        v_t_2457 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(4, shape_239_20_234_192, (V[]){v_t_2431, v_base_2423, v_parts_2429, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_False: {
        V v_t_2432 = (g_prelude_2eindexFrom(((V)&g_heff_2eload_2eplacesOf_str8), heff_dup(v_w_243), MK_INT(0LL)));
        V v_x1_2435;
        switch (heff_tag_of(v_t_2432)) {
        case TAG_Nothing: {
          v_x1_2435 = heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_w_243), ((V)&g_heff_2eload_2eplacesOf_str9)});
          break;
        }
        case TAG_Just: {
          V v_i_2433 = heff_field(v_t_2432, 0);
          heff_take_n(v_t_2432, 1ULL, 1);
          V v_t_2434 = heff_strSlice(heff_dup(v_w_243), heff_dup(v_i_2433), heff_strLength(heff_dup(v_w_243)));
          v_x1_2435 = heff_tag(TAG_MkPair, 2, (V[]){heff_strSlice(heff_dup(v_w_243), MK_INT(0LL), v_i_2433), v_t_2434});
          break;
        }
        default: heff_nomatch(v_t_2432);
        }
        V v_t_2438;
        switch (heff_tag_of(v_x1_2435)) {
        case TAG_MkPair: {
          V v_x_2436 = heff_field(v_x1_2435, 0);
          heff_take_n(v_x1_2435, 1ULL, 2);
          v_t_2438 = v_x_2436;
          break;
        }
        default: heff_nomatch(v_x1_2435);
        }
        V v_t_2439 = heff_strEq(v_t_2438, heff_get(heff_dup(v_k_2421), LBL_own));
        switch (heff_tag_of(v_t_2439)) {
        case TAG_True: {
          V v_base_2440 = heff_get(heff_dup(v_k_2421), LBL_src);
          V v_xs_2441 = (g_prelude_2esplitFrom(((V)&g_heff_2eload_2eplacesOf_str10), heff_dup(v_w_243), MK_INT(0LL), NTAG(TAG_Nil)));
          V v_t_2442 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2441));
          V v_parts_2446;
          switch (heff_tag_of(v_t_2442)) {
          case TAG_Nil: {
            v_parts_2446 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2443 = heff_field(v_t_2442, 0);
            V v_before_2444 = heff_field(v_t_2442, 1);
            V v_ru_24t_2442_24Cons = heff_take_reuse_n(v_t_2442, 3ULL, 2);
            V v_t_2445 = heff_tag_at(v_ru_24t_2442_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2443, ((V)&g_heff_2eload_2eplacesOf_str11)), v_before_2444});
            v_parts_2446 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_t_2445));
            break;
          }
          default: heff_nomatch(v_t_2442);
          }
          V v_t_2447 = (g_prelude_2eindexFrom(((V)&g_heff_2eload_2eplacesOf_str12), heff_dup(v_w_243), MK_INT(0LL)));
          V v_x1_2450;
          switch (heff_tag_of(v_t_2447)) {
          case TAG_Nothing: {
            v_x1_2450 = heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_w_243), ((V)&g_heff_2eload_2eplacesOf_str13)});
            break;
          }
          case TAG_Just: {
            V v_i_2448 = heff_field(v_t_2447, 0);
            heff_take_n(v_t_2447, 1ULL, 1);
            V v_t_2449 = heff_strSlice(heff_dup(v_w_243), heff_dup(v_i_2448), heff_strLength(heff_dup(v_w_243)));
            v_x1_2450 = heff_tag(TAG_MkPair, 2, (V[]){heff_strSlice(heff_dup(v_w_243), MK_INT(0LL), v_i_2448), v_t_2449});
            break;
          }
          default: heff_nomatch(v_t_2447);
          }
          V v_t_2453;
          switch (heff_tag_of(v_x1_2450)) {
          case TAG_MkPair: {
            V v_y_2452 = heff_field(v_x1_2450, 1);
            heff_take_n(v_x1_2450, 2ULL, 2);
            v_t_2453 = v_y_2452;
            break;
          }
          default: heff_nomatch(v_x1_2450);
          }
          V v_m_2454 = heff_strAppend(heff_get(heff_dup(v_k_2421), LBL_top), v_t_2453);
          V v_t_2455 = heff_tr(heff_apply(((V)&g_heff_2eload_2eunder_clo), 1, (V[]){heff_dup(v_ps_240)}));
          V v_t_2456 = (g_prelude_2efoldl(v_t_2455, heff_dup(v_base_2440), v_parts_2446));
          v_t_2457 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(4, shape_239_20_234_192, (V[]){v_t_2456, v_base_2440, v_parts_2446, v_m_2454}), NTAG(TAG_Nil)});
          break;
        }
        case TAG_False: {
          v_t_2457 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_t_2439);
        }
        break;
      }
      default: heff_nomatch(v_t_2422);
      }
      V v_t_2458 = (g_prelude_2eindexFrom(((V)&g_heff_2eload_2eplacesOf_str14), heff_dup(v_w_243), MK_INT(0LL)));
      V v_x1_2461;
      switch (heff_tag_of(v_t_2458)) {
      case TAG_Nothing: {
        v_x1_2461 = heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_w_243), ((V)&g_heff_2eload_2eplacesOf_str15)});
        break;
      }
      case TAG_Just: {
        V v_i_2459 = heff_field(v_t_2458, 0);
        heff_take_n(v_t_2458, 1ULL, 1);
        V v_t_2460 = heff_strSlice(heff_dup(v_w_243), heff_dup(v_i_2459), heff_strLength(heff_dup(v_w_243)));
        v_x1_2461 = heff_tag(TAG_MkPair, 2, (V[]){heff_strSlice(heff_dup(v_w_243), MK_INT(0LL), v_i_2459), v_t_2460});
        break;
      }
      default: heff_nomatch(v_t_2458);
      }
      V v_t_2464;
      switch (heff_tag_of(v_x1_2461)) {
      case TAG_MkPair: {
        V v_x_2462 = heff_field(v_x1_2461, 0);
        heff_take_n(v_x1_2461, 1ULL, 2);
        v_t_2464 = v_x_2462;
        break;
      }
      default: heff_nomatch(v_x1_2461);
      }
      V v_t_2465 = (g_prelude_2eindexFrom(((V)&g_heff_2eload_2eplacesOf_str16), heff_dup(v_w_243), MK_INT(0LL)));
      V v_x1_2468;
      switch (heff_tag_of(v_t_2465)) {
      case TAG_Nothing: {
        v_x1_2468 = heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_w_243), ((V)&g_heff_2eload_2eplacesOf_str17)});
        break;
      }
      case TAG_Just: {
        V v_i_2466 = heff_field(v_t_2465, 0);
        heff_take_n(v_t_2465, 1ULL, 1);
        V v_t_2467 = heff_strSlice(heff_dup(v_w_243), heff_dup(v_i_2466), heff_strLength(heff_dup(v_w_243)));
        v_x1_2468 = heff_tag(TAG_MkPair, 2, (V[]){heff_strSlice(heff_dup(v_w_243), MK_INT(0LL), v_i_2466), v_t_2467});
        break;
      }
      default: heff_nomatch(v_t_2465);
      }
      V v_t_2471;
      switch (heff_tag_of(v_x1_2468)) {
      case TAG_MkPair: {
        V v_y_2470 = heff_field(v_x1_2468, 1);
        heff_take_n(v_x1_2468, 2ULL, 2);
        v_t_2471 = v_y_2470;
        break;
      }
      default: heff_nomatch(v_x1_2468);
      }
      V v_t_2472 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_pkgs_241; V a_2 = heff_dup(v_k_2421); V a_3 = v_t_2464; V a_4 = v_t_2471; V r_ = (g_heff_2eload_2erequiredPlace(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_pkgs_241, 2); r_; });
      V v_base_2473 = heff_get(heff_dup(v_ps_240), LBL_lib);
      V v_xs_2474 = (g_prelude_2esplitFrom(((V)&g_heff_2eload_2eplacesOf_str18), heff_dup(v_w_243), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2475 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2474));
      V v_parts_2479;
      switch (heff_tag_of(v_t_2475)) {
      case TAG_Nil: {
        v_parts_2479 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_last_2476 = heff_field(v_t_2475, 0);
        V v_before_2477 = heff_field(v_t_2475, 1);
        V v_ru_24t_2475_24Cons = heff_take_reuse_n(v_t_2475, 3ULL, 2);
        V v_t_2478 = heff_tag_at(v_ru_24t_2475_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2476, ((V)&g_heff_2eload_2eplacesOf_str19)), v_before_2477});
        v_parts_2479 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_t_2478));
        break;
      }
      default: heff_nomatch(v_t_2475);
      }
      V v_t_2480 = heff_tr(heff_apply(((V)&g_heff_2eload_2eunder_clo), 1, (V[]){heff_dup(v_ps_240)}));
      V v_t_2481 = (g_prelude_2efoldl(v_t_2480, heff_dup(v_base_2473), v_parts_2479));
      V v_t_2482 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(4, shape_239_20_234_192, (V[]){v_t_2481, v_base_2473, v_parts_2479, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      V v_t_2483 = heff_strEq(heff_get(heff_dup(v_k_2421), LBL_own), ((V)&g_heff_2eload_2eplacesOf_str20));
      V v_t_2487;
      switch (heff_tag_of(v_t_2483)) {
      case TAG_True: {
        V v_d_2484 = heff_get(heff_dup(v_k_2421), LBL_src);
        V v_t_2485 = heff_strEq(heff_dup(v_d_2484), ((V)&g_heff_2eload_2eplacesOf_str21));
        V v_x1_2486;
        switch (heff_tag_of(v_t_2485)) {
        case TAG_True: {
          heff_drop(v_from_242);
          heff_drop(v_d_2484);
          v_x1_2486 = NTAG(TAG_True);
          break;
        }
        case TAG_False: {
          v_x1_2486 = ({ V b_0 = heff_get(heff_dup(v_ps_240), LBL_style); V a_1 = v_d_2484; V a_2 = v_from_242; V r_ = (g_std_2epath_2eisUnder(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          break;
        }
        default: heff_nomatch(v_t_2485);
        }
        switch (heff_tag_of(v_x1_2486)) {
        case TAG_True: {
          v_t_2487 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_t_2487 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x1_2486);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_from_242);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2483);
      }
      V v_t_2497;
      switch (heff_tag_of(v_t_2487)) {
      case TAG_True: {
        V v_base_2488 = heff_get(v_k_2421, LBL_dir);
        V v_xs_2489 = (g_prelude_2esplitFrom(((V)&g_heff_2eload_2eplacesOf_str22), heff_dup(v_w_243), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2490 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2489));
        V v_parts_2494;
        switch (heff_tag_of(v_t_2490)) {
        case TAG_Nil: {
          v_parts_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2491 = heff_field(v_t_2490, 0);
          V v_before_2492 = heff_field(v_t_2490, 1);
          V v_ru_24t_2490_24Cons = heff_take_reuse_n(v_t_2490, 3ULL, 2);
          V v_t_2493 = heff_tag_at(v_ru_24t_2490_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2491, ((V)&g_heff_2eload_2eplacesOf_str23)), v_before_2492});
          v_parts_2494 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_t_2493));
          break;
        }
        default: heff_nomatch(v_t_2490);
        }
        V v_t_2495 = heff_tr(heff_apply(((V)&g_heff_2eload_2eunder_clo), 1, (V[]){v_ps_240}));
        V v_t_2496 = (g_prelude_2efoldl(v_t_2495, heff_dup(v_base_2488), v_parts_2494));
        v_t_2497 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(4, shape_239_20_234_192, (V[]){v_t_2496, v_base_2488, v_parts_2494, v_w_243}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_False: {
        heff_drop(v_ps_240);
        heff_drop(v_w_243);
        heff_drop(v_k_2421);
        v_t_2497 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_t_2487);
      }
      V v_t_2498 = (g_prelude_2econcatList(v_t_2482, v_t_2497));
      V v_t_2499 = (g_prelude_2econcatList(v_t_2472, v_t_2498));
      return (g_prelude_2econcatList(v_t_2457, v_t_2499));
    }
    default: return heff_nomatch(v_pkgs_241);
    }
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2eload_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2eplacesOf(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2esameButCase_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2esameButCase_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eload_2esameButCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2esameButCase_entry, 2, 0};

V g_heff_2eload_2esameButCase(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_tr(heff_apply(((V)&g_std_2epath_2elower_2elow_240_clo), 1, (V[]){heff_dup(v_a_240)}));
  V v_t_243 = (g_prelude_2erange(MK_INT(0LL), heff_strLength(v_a_240)));
  V v_x2_244 = (g_prelude_2emap(v_t_242, v_t_243));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2eload_2esameButCase_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_tr(heff_apply(((V)&g_std_2epath_2elower_2elow_240_clo), 1, (V[]){heff_dup(v_b_241)}));
  V v_t_249 = (g_prelude_2erange(MK_INT(0LL), heff_strLength(v_b_241)));
  V v_x2_2410 = (g_prelude_2emap(v_t_248, v_t_249));
  V v_t_2413;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    v_t_2413 = ((V)&g_heff_2eload_2esameButCase_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    v_t_2413 = ({ V a_0 = v_x_2411; V a_1 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2412); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  return heff_strEq(v_t_247, v_t_2413);
}
V g_heff_2eload_2esameButCase_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2esameButCase(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eload_2ecasesIn_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 105, 115, 32, 110, 97, 109, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[59]; } g_heff_2eload_2ecasesIn_str1 = {{0x80000000u, K_STR, 0}, 59, 59, {32, 111, 110, 32, 116, 104, 101, 32, 100, 105, 115, 107, 58, 32, 97, 32, 102, 105, 108, 101, 32, 115, 121, 115, 116, 101, 109, 32, 116, 104, 97, 116, 32, 116, 101, 108, 108, 115, 32, 99, 97, 115, 101, 32, 97, 112, 97, 114, 116, 32, 102, 105, 110, 100, 115, 32, 110, 111, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2ecasesIn_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eload_2ecasesIn_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 104, 111, 108, 100, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[74]; } g_heff_2eload_2ecasesIn_str4 = {{0x80000000u, K_STR, 0}, 74, 74, {58, 32, 110, 97, 109, 101, 115, 32, 116, 104, 97, 116, 32, 100, 105, 102, 102, 101, 114, 32, 111, 110, 108, 121, 32, 105, 110, 32, 99, 97, 115, 101, 32, 97, 114, 101, 32, 111, 110, 101, 32, 102, 105, 108, 101, 32, 119, 104, 101, 114, 101, 32, 99, 97, 115, 101, 32, 105, 115, 32, 110, 111, 116, 32, 116, 111, 108, 100, 32, 97, 112, 97, 114, 116}};
Clo g_heff_2eload_2ecasesIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ecasesIn_entry, 4, 0};

V g_heff_2eload_2ecasesIn(V v_ps_240, V v_d_241, V v_x_242, V v_ns_243) {
top: ;
  switch (heff_tag_of(v_ns_243)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_d_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_n_244 = heff_field(v_ns_243, 0);
    V v_ns2_245 = heff_field(v_ns_243, 1);
    switch (heff_tag_of(v_ns2_245)) {
    case TAG_Nil: {
      V v_t_246 = heff_strEq(heff_dup(v_n_244), heff_dup(v_x_242));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_ps_240);
        heff_drop(v_d_241);
        heff_drop(v_x_242);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V v_st_247 = heff_get(v_ps_240, LBL_style);
        V v_t_248 = (g_std_2epath_2eparse(v_st_247, v_d_241));
        V v_t_249 = (g_std_2epath_2eparse(v_st_247, heff_dup(v_x_242)));
        V v_p_2410 = (g_std_2epath_2ejoin_2eonto_240(v_t_248, v_t_249));
        V v_t_2411 = ({ V a_0 = heff_get(heff_dup(v_p_2410), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2410), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_2412 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2410), LBL_drive), heff_get(v_p_2410, LBL_absolute), v_t_2411});
        V v_t_2413 = ({ V a_0 = v_st_247; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); r_; });
        V v_t_2414 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2eload_2ecasesIn_str0), heff_strAppend(heff_dup(v_n_244), heff_strAppend(((V)&g_heff_2eload_2ecasesIn_str1), v_x_242))));
        return heff_tag(TAG_Just, 1, (V[]){v_t_2414});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_Cons: {
      heff_drop(v_ps_240);
      heff_drop(v_x_242);
      V v_t_2419;
      switch (heff_tag_of(v_ns_243)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2eload_2ecasesIn_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_ns_243, 0);
        V v_xs_2418 = heff_field(v_ns_243, 1);
        v_t_2419 = (g_prelude_2efoldl_24s45(heff_dup(v_x_2417), v_xs_2418));
        break;
      }
      default: heff_nomatch(v_ns_243);
      }
      V v_t_2420 = heff_strAppend(v_d_241, heff_strAppend(((V)&g_heff_2eload_2ecasesIn_str3), heff_strAppend(v_t_2419, ((V)&g_heff_2eload_2ecasesIn_str4))));
      return heff_tag(TAG_Just, 1, (V[]){v_t_2420});
    }
    default: return heff_nomatch(v_ns2_245);
    }
  }
  default: return heff_nomatch(v_ns_243);
  }
}
V g_heff_2eload_2ecasesIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eload_2ecasesIn(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}

static V g_heff_2eload_2eemptySt_val;
static int g_heff_2eload_2eemptySt_st;
static V g_heff_2eload_2eemptySt_init(void) {
  return heff_rec(3, shape_71_72_89, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2eload_2eemptySt_get(void) {
  if (g_heff_2eload_2eemptySt_st == 2) return g_heff_2eload_2eemptySt_val;
  if (g_heff_2eload_2eemptySt_st == 1) heff_fail("defined by itself");
  g_heff_2eload_2eemptySt_st = 1;
  g_heff_2eload_2eemptySt_val = heff_tr(g_heff_2eload_2eemptySt_init());
  g_heff_2eload_2eemptySt_st = 2;
  return g_heff_2eload_2eemptySt_val;
}
Clo g_heff_2eload_2eloadDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eloadDone_entry, 4, 0};

V g_heff_2eload_2eloadDone(V v_ps_240, V v_pk_241, V v_pkgs_242, V v_st_243) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_247 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_244 = heff_dup(heff_field(v_pk_241, 0));
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_why_245 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      v_t_247 = heff_tag(TAG_Cons, 2, (V[]){v_why_245, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Right: {
      heff_take_n(v_x11_244, 0ULL, 1);
      v_t_247 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x11_244);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2410;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_y_249 = heff_field(v_pkgs_242, 1);
    v_t_2410 = heff_dup(v_y_249);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  V v_t_2411 = (g_prelude_2econcatList(v_t_2410, heff_get(heff_dup(v_st_243), LBL_errors)));
  V v_t_2412 = (g_prelude_2econcatList(v_t_247, v_t_2411));
  V v_t_2416;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_2416 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_2413 = heff_field(v_pk_241, 0);
    V v_ru_24pk_241_24Just = heff_take_reuse_n(v_pk_241, 1ULL, 1);
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_Left: {
      heff_take_n(v_x11_2413, 0ULL, 1);
      heff_drop_cell(v_ru_24pk_241_24Just, 1);
      v_t_2416 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2415 = heff_field(v_x11_2413, 0);
      heff_take_n(v_x11_2413, 1ULL, 1);
      v_t_2416 = heff_tag_at(v_ru_24pk_241_24Just, TAG_Just, 1, (V[]){v_p_2415});
      break;
    }
    default: heff_nomatch(v_x11_2413);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2419;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_pkgs_242, 0);
    v_t_2419 = heff_dup(v_x_2417);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  return heff_rec(5, shape_312_89_240_229_230, (V[]){heff_get(v_st_243, LBL_done), v_t_2412, v_ps_240, v_t_2416, v_t_2419});
}
V g_heff_2eload_2eloadDone_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eload_2eloadDone(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eversionsGo_24s877_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
V g_heff_2eload_2eversionsGo_24s877_lam0(V self, V *args);
V g_heff_2eload_2eversionsGo_24s877_lam1(V self, V *args);
V g_heff_2eload_2eversionsGo_24s877_lam4(V self, V *args);
V g_heff_2eload_2eversionsGo_24s877_lam3(V self, V *args);
V g_heff_2eload_2eversionsGo_24s877_lam2(V self, V *args);
Clo g_heff_2eload_2eversionsGo_24s877_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eversionsGo_24s877_entry, 5, 0};

V g_heff_2eload_2eversionsGo_24s877(V v_rd_240, V v_root_241, V v_x3_242, V v_seen_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_rd_240);
    heff_drop(v_root_241);
    return heff_clo(g_heff_2eload_2eversionsGo_24s877_lam0, 2, 2, (V[]){v_seen_243, v_errs_244});
  }
  case TAG_Cons: {
    V v_n_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_249 = heff_strEq(heff_get(heff_dup(v_n_247), LBL_path), heff_dup(v_root_241));
    V v_t_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2412 = (g_prelude_2eany(heff_clo(g_heff_2eload_2eversionsGo_24s877_lam1, 1, 1, (V[]){heff_dup(v_n_247)}), v_seen_243));
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_n_247);
      V t_0 = v_rd_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_seen_243;
      V t_4 = v_errs_244;
      v_rd_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_seen_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    }
    case TAG_False: {
      V v_c_2413 = heff_tr(heff_apply(heff_dup(v_rd_240), 3, (V[]){heff_get(heff_dup(v_n_247), LBL_by), heff_get(heff_dup(v_n_247), LBL_path), heff_get(heff_dup(v_n_247), LBL_version)}));
      return heff_clo(g_heff_2eload_2eversionsGo_24s877_lam2, 2, 7, (V[]){v_c_2413, v_n_247, v_seen_243, v_errs_244, v_rd_240, v_root_241, v_rest_248});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eload_2eversionsGo_24s877_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2eversionsGo_24s877(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eload_2eversionsGo_24s877_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_seen_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_seen_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2eversionsGo_24s877_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_n_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_strEq(heff_get(heff_dup(v_x_2410), LBL_path), heff_get(heff_dup(v_n_247), LBL_path));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    return heff_strEq(heff_get(v_x_2410, LBL_version), heff_get(v_n_247, LBL_version));
  }
  case TAG_False: {
    heff_drop(v_x_2410);
    heff_drop(v_n_247);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2eload_2eversionsGo_24s877_lam4(V self, V *args) {
  V v_r_2425 = args[0];
  V v_n_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_strAppend(heff_get(heff_dup(v_n_247), LBL_path), heff_strAppend(((V)&g_heff_2eload_2eversionsGo_24s877_str0), heff_get(v_n_247, LBL_version)));
  return heff_rec(3, shape_34_239_370, (V[]){v_t_2426, heff_get(heff_dup(v_r_2425), LBL_path), heff_get(v_r_2425, LBL_version)});
}
V g_heff_2eload_2eversionsGo_24s877_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_n_247 = heff_env(self)[0];
  V v_seen_243 = heff_env(self)[1];
  V v_errs_244 = heff_env(self)[2];
  V v_rd_240 = heff_env(self)[3];
  V v_root_241 = heff_env(self)[4];
  V v_rest_248 = heff_env(self)[5];
  V v_hd_2414 = heff_env(self)[6];
  V v_k_2415 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_why_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2418 = heff_rec(3, shape_239_370_244, (V[]){heff_get(heff_dup(v_n_247), LBL_path), heff_get(v_n_247, LBL_version), NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
    V v_t_2420 = (g_prelude_2econcatList(v_seen_243, v_t_2419));
    V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){v_why_2417, NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2econcatList(v_errs_244, v_t_2421));
    V v_t_2423 = (g_heff_2eload_2eversionsGo_24s877(v_rd_240, v_root_241, v_rest_248, v_t_2420, v_t_2422));
    return heff_tail(v_t_2423, 2, (V[]){v_hd_2414, v_k_2415});
  }
  case TAG_Right: {
    V v_pk_2424 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2427 = (g_prelude_2emap(heff_clo(g_heff_2eload_2eversionsGo_24s877_lam4, 1, 1, (V[]){heff_dup(v_n_247)}), heff_get(heff_dup(v_pk_2424), LBL_require)));
    V v_t_2428 = (g_prelude_2econcatList(v_rest_248, v_t_2427));
    V v_t_2429 = heff_rec(3, shape_239_370_244, (V[]){heff_get(heff_dup(v_n_247), LBL_path), heff_get(v_n_247, LBL_version), heff_tag(TAG_Just, 1, (V[]){v_pk_2424})});
    V v_t_2430 = heff_tag(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_t_2431 = (g_prelude_2econcatList(v_seen_243, v_t_2430));
    V v_t_2432 = (g_heff_2eload_2eversionsGo_24s877(v_rd_240, v_root_241, v_t_2428, v_t_2431, v_errs_244));
    return heff_tail(v_t_2432, 2, (V[]){v_hd_2414, v_k_2415});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2eload_2eversionsGo_24s877_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_n_247 = heff_env(self)[1];
  V v_seen_243 = heff_env(self)[2];
  V v_errs_244 = heff_env(self)[3];
  V v_rd_240 = heff_env(self)[4];
  V v_root_241 = heff_env(self)[5];
  V v_rest_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo(g_heff_2eload_2eversionsGo_24s877_lam3, 1, 8, (V[]){v_n_247, v_seen_243, v_errs_244, v_rd_240, v_root_241, v_rest_248, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eversionsOf_24s876_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eload_2eversionsOf_24s876_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116}};
V g_heff_2eload_2eversionsOf_24s876_lam0(V self, V *args);
Clo g_heff_2eload_2eversionsOf_24s876_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eversionsOf_24s876_entry, 2, 0};

V g_heff_2eload_2eversionsOf_24s876(V v_rd_240, V v_root_241) {
top: ;
  V v_t_242 = heff_strEq(heff_get(heff_dup(v_root_241), LBL_module), ((V)&g_heff_2eload_2eversionsOf_24s876_str0));
  V v_by_243;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    v_by_243 = ((V)&g_heff_2eload_2eversionsOf_24s876_str1);
    break;
  }
  case TAG_False: {
    v_by_243 = heff_get(heff_dup(v_root_241), LBL_module);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_245 = (g_prelude_2emap(heff_clo(g_heff_2eload_2eversionsOf_24s876_lam0, 1, 1, (V[]){v_by_243}), heff_get(heff_dup(v_root_241), LBL_require)));
  return (g_heff_2eload_2eversionsGo_24s877(v_rd_240, heff_get(v_root_241, LBL_module), v_t_245, NTAG(TAG_Nil), NTAG(TAG_Nil)));
}
V g_heff_2eload_2eversionsOf_24s876_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2eversionsOf_24s876(a[0], a[1]);
}
V g_heff_2eload_2eversionsOf_24s876_lam0(V self, V *args) {
  V v_r_244 = args[0];
  V v_by_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec(3, shape_34_239_370, (V[]){v_by_243, heff_get(heff_dup(v_r_244), LBL_path), heff_get(v_r_244, LBL_version)});
}
V g_heff_2eload_2ereadEvery_24s883_lam0(V self, V *args); static Clo g_heff_2eload_2ereadEvery_24s883_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ereadEvery_24s883_lam0, 2, 0};
V g_heff_2eload_2ereadEvery_24s883_lam3(V self, V *args);
V g_heff_2eload_2ereadEvery_24s883_lam2(V self, V *args);
V g_heff_2eload_2ereadEvery_24s883_lam1(V self, V *args);
Clo g_heff_2eload_2ereadEvery_24s883_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ereadEvery_24s883_entry, 2, 0};

V g_heff_2eload_2ereadEvery_24s883(V v_read_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    return ((V)&g_heff_2eload_2ereadEvery_24s883_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_apply(heff_dup(v_read_240), 1, (V[]){heff_get(heff_dup(v_pl_244), LBL_path)}));
    return heff_clo(g_heff_2eload_2ereadEvery_24s883_lam1, 2, 4, (V[]){v_c_246, v_read_240, v_rest_245, v_pl_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eload_2ereadEvery_24s883_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2ereadEvery_24s883(a[0], a[1]);
}
V g_heff_2eload_2ereadEvery_24s883_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2ereadEvery_24s883_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_pl_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2414;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop(v_pl_244);
    v_x_2414 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_s_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2413 = heff_rec(4, shape_239_311_245_192, (V[]){heff_get(heff_dup(v_pl_244), LBL_path), v_s_2412, heff_dup(v_pl_244), heff_get(v_pl_244, LBL_module)});
    v_x_2414 = heff_tag(TAG_Cons, 2, (V[]){v_t_2413, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2ereadEvery_24s883_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2eload_2ereadEvery_24s883(v_read_240, v_rest_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2eload_2ereadEvery_24s883_lam3, 1, 3, (V[]){v_x_249, v_pl_244, v_k_248})});
}
V g_heff_2eload_2ereadEvery_24s883_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2eload_2ereadEvery_24s883_lam2, 1, 5, (V[]){v_read_240, v_rest_245, v_hd_247, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eload_2eisRoot_24s869_24s1130_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
V g_heff_2eload_2eisRoot_24s869_24s1130_lam1(V self, V *args); static Clo g_heff_2eload_2eisRoot_24s869_24s1130_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eisRoot_24s869_24s1130_lam1, 1, 0};
V g_heff_2eload_2eisRoot_24s869_24s1130_lam0(V self, V *args);
V g_heff_2eload_2eisRoot_24s869_24s1130_lam3(V self, V *args);
V g_heff_2eload_2eisRoot_24s869_24s1130_lam2(V self, V *args);
Clo g_heff_2eload_2eisRoot_24s869_24s1130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eisRoot_24s869_24s1130_entry, 2, 0};

V g_heff_2eload_2eisRoot_24s869_24s1130(V v_st_240, V v_d_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(v_st_240, v_d_241));
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2eload_2eisRoot_24s869_24s1130_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = ({ V a_0 = heff_get(heff_dup(v_p_244), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_244), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_244), LBL_drive), heff_get(v_p_244, LBL_absolute), v_t_245});
  V v_path_247 = (g_std_2epath_2erender(v_st_240, v_t_246));
  V v_c_2415 = heff_clo(g_heff_2eload_2eisRoot_24s869_24s1130_lam0, 2, 1, (V[]){v_path_247});
  return heff_clo(g_heff_2eload_2eisRoot_24s869_24s1130_lam2, 2, 1, (V[]){v_c_2415});
}
V g_heff_2eload_2eisRoot_24s869_24s1130_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eload_2eisRoot_24s869_24s1130(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eload_2eisRoot_24s869_24s1130_lam1(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2eload_2eisRoot_24s869_24s1130_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k2_249 = args[1];
  V v_path_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_247, ((V)&g_heff_2eload_2eisRoot_24s869_24s1130_lam1_clo)})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(v_hd_248, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eload_2eisRoot_24s869_24s1130_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2420;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    v_x_2420 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2418, 0ULL, 1);
    v_x_2420 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_2417;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2eisRoot_24s869_24s1130_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo(g_heff_2eload_2eisRoot_24s869_24s1130_lam3, 1, 1, (V[]){v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eload_2erootFrom_24s868_24s1129_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
V g_heff_2eload_2erootFrom_24s868_24s1129_lam1(V self, V *args);
V g_heff_2eload_2erootFrom_24s868_24s1129_lam0(V self, V *args);
Clo g_heff_2eload_2erootFrom_24s868_24s1129_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2erootFrom_24s868_24s1129_entry, 3, 0};

V g_heff_2eload_2erootFrom_24s868_24s1129(V v_h_240, V v_start_241, V v_d_242) {
top: ;
  V v_c_243 = ({ V b_0 = heff_get(heff_dup(v_h_240), LBL_style); V a_1 = heff_dup(v_d_242); V r_ = (g_heff_2eload_2eisRoot_24s869_24s1130(b_0, a_1)); heff_drop(b_0); r_; });
  return heff_clo(g_heff_2eload_2erootFrom_24s868_24s1129_lam0, 2, 4, (V[]){v_c_243, v_h_240, v_d_242, v_start_241});
}
V g_heff_2eload_2erootFrom_24s868_24s1129_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2erootFrom_24s868_24s1129(a[0], a[1], a[2]);
}
V g_heff_2eload_2erootFrom_24s868_24s1129_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_start_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_246)) {
  case TAG_True: {
    heff_drop(v_start_241);
    heff_drop(v_hd_244);
    V v_st_247 = heff_get(heff_dup(v_h_240), LBL_style);
    V v_t_248 = (g_std_2epath_2eparse(v_st_247, heff_dup(v_d_242)));
    V v_t_249 = (g_std_2epath_2eparse(v_st_247, ((V)&g_heff_2eload_2erootFrom_24s868_24s1129_str0)));
    V v_p_2410 = (g_std_2epath_2ejoin_2eonto_240(v_t_248, v_t_249));
    V v_t_2411 = ({ V a_0 = heff_get(heff_dup(v_p_2410), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2410), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2412 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2410), LBL_drive), heff_get(v_p_2410, LBL_absolute), v_t_2411});
    V v_t_2413 = ({ V a_0 = v_st_247; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); r_; });
    V v_x_2414 = heff_rec(5, shape_283_317_174_191_327, (V[]){v_d_242, v_t_2413, heff_get(heff_dup(v_h_240), LBL_lib), heff_get(heff_dup(v_h_240), LBL_mod), heff_get(v_h_240, LBL_style)});
    V f_ = v_k_245;
    args[0] = v_x_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_st_2415 = heff_get(heff_dup(v_h_240), LBL_style);
    V v_p_2416 = (g_std_2epath_2eparse(v_st_2415, heff_dup(v_d_242)));
    V v_t_2417 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2416), LBL_segments)));
    V v_xs_2418 = (g_prelude_2edrop(MK_INT(1LL), v_t_2417));
    V v_t_2419 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2418));
    V v_t_2420 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2416), LBL_drive), heff_get(v_p_2416, LBL_absolute), v_t_2419});
    V v_t_2421 = ({ V a_0 = v_st_2415; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); r_; });
    V v_t_2422 = heff_strEq(v_t_2421, heff_dup(v_d_242));
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop(v_d_242);
      heff_drop(v_hd_244);
      V v_t_2423 = heff_rec(5, shape_283_317_174_191_327, (V[]){heff_dup(v_start_241), v_start_241, heff_get(heff_dup(v_h_240), LBL_lib), heff_get(heff_dup(v_h_240), LBL_mod), heff_get(v_h_240, LBL_style)});
      V f_ = v_k_245;
      args[0] = v_t_2423;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_False: {
      V v_st_2424 = heff_get(heff_dup(v_h_240), LBL_style);
      V v_p_2425 = (g_std_2epath_2eparse(v_st_2424, v_d_242));
      V v_t_2426 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2425), LBL_segments)));
      V v_xs_2427 = (g_prelude_2edrop(MK_INT(1LL), v_t_2426));
      V v_t_2428 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2427));
      V v_t_2429 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2425), LBL_drive), heff_get(v_p_2425, LBL_absolute), v_t_2428});
      V v_t_2430 = ({ V a_0 = v_st_2424; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2424); r_; });
      V v_t_2431 = (g_heff_2eload_2erootFrom_24s868_24s1129(v_h_240, v_start_241, v_t_2430));
      return heff_tail(v_t_2431, 2, (V[]){v_hd_244, v_k_245});
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2eload_2erootFrom_24s868_24s1129_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_start_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo(g_heff_2eload_2erootFrom_24s868_24s1129_lam1, 1, 5, (V[]){v_h_240, v_d_242, v_k_245, v_start_241, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eload_2epathsFor_24s867_24s1128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2epathsFor_24s867_24s1128_entry, 2, 0};

V g_heff_2eload_2epathsFor_24s867_24s1128(V v_h_240, V v_file_241) {
top: ;
  V v_st_242 = heff_get(heff_dup(v_h_240), LBL_style);
  V v_p_243 = (g_std_2epath_2eparse(v_st_242, heff_dup(v_file_241)));
  V v_t_244 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_243), LBL_segments)));
  V v_xs_245 = (g_prelude_2edrop(MK_INT(1LL), v_t_244));
  V v_t_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_245));
  V v_t_247 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_243), LBL_drive), heff_get(v_p_243, LBL_absolute), v_t_246});
  V v_t_248 = ({ V a_0 = v_st_242; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); r_; });
  V v_st_249 = heff_get(heff_dup(v_h_240), LBL_style);
  V v_p_2410 = (g_std_2epath_2eparse(v_st_249, v_file_241));
  V v_t_2411 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2410), LBL_segments)));
  V v_xs_2412 = (g_prelude_2edrop(MK_INT(1LL), v_t_2411));
  V v_t_2413 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2412));
  V v_t_2414 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2410), LBL_drive), heff_get(v_p_2410, LBL_absolute), v_t_2413});
  V v_t_2415 = ({ V a_0 = v_st_249; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_249); r_; });
  return (g_heff_2eload_2erootFrom_24s868_24s1129(v_h_240, v_t_248, v_t_2415));
}
V g_heff_2eload_2epathsFor_24s867_24s1128_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2epathsFor_24s867_24s1128(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eload_2ereadPackageAt_24s870_24s1131_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eload_2ereadPackageAt_24s870_24s1131_str1 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
V g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam1(V self, V *args); static Clo g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam1, 1, 0};
V g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam0(V self, V *args);
V g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam3(V self, V *args);
V g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam2(V self, V *args);
Clo g_heff_2eload_2ereadPackageAt_24s870_24s1131_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ereadPackageAt_24s870_24s1131_entry, 1, 0};

V g_heff_2eload_2ereadPackageAt_24s870_24s1131(V v_ps_240) {
top: ;
  V v_st_241 = heff_get(heff_dup(v_ps_240), LBL_style);
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_get(heff_dup(v_ps_240), LBL_root)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2eload_2ereadPackageAt_24s870_24s1131_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = ({ V a_0 = heff_get(heff_dup(v_p_244), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_244), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_244), LBL_drive), heff_get(v_p_244, LBL_absolute), v_t_245});
  V v_path_247 = ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
  V v_c_2415 = heff_clo(g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam0, 2, 1, (V[]){v_path_247});
  return heff_clo(g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam2, 2, 2, (V[]){v_c_2415, v_ps_240});
}
V g_heff_2eload_2ereadPackageAt_24s870_24s1131_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2ereadPackageAt_24s870_24s1131(a[0]);
}
V g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam1(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k2_249 = args[1];
  V v_path_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_247, ((V)&g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam1_clo)})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(v_hd_248, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2431;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    heff_drop(v_ps_240);
    v_x_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Just = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2420 = (g_heff_2eproject_2ereadPackage(heff_dup(v_src_2419)));
    switch (heff_tag_of(v_t_2420)) {
    case TAG_Left: {
      V v_p_2421 = heff_field(v_t_2420, 0);
      V v_ru_24t_2420_24Left = heff_take_reuse_n(v_t_2420, 1ULL, 1);
      V v_st_2422 = heff_get(heff_dup(v_ps_240), LBL_style);
      V v_t_2423 = (g_std_2epath_2eparse(v_st_2422, heff_get(v_ps_240, LBL_root)));
      V v_t_2424 = (g_std_2epath_2eparse(v_st_2422, ((V)&g_heff_2eload_2ereadPackageAt_24s870_24s1131_str1)));
      V v_p_2425 = (g_std_2epath_2ejoin_2eonto_240(v_t_2423, v_t_2424));
      V v_t_2426 = ({ V a_0 = heff_get(heff_dup(v_p_2425), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2425), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2427 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2425), LBL_drive), heff_get(v_p_2425, LBL_absolute), v_t_2426});
      V v_t_2428 = ({ V a_0 = v_st_2422; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); r_; });
      V v_t_2429 = heff_tag_at(v_ru_24x_2418_24Just, TAG_Left, 1, (V[]){(g_heff_2eload_2eproblemMsg(v_t_2428, v_src_2419, v_p_2421))});
      v_x_2431 = heff_tag_at(v_ru_24t_2420_24Left, TAG_Just, 1, (V[]){v_t_2429});
      break;
    }
    case TAG_Right: {
      V v_pk_2430 = heff_field(v_t_2420, 0);
      heff_take_n(v_t_2420, 1ULL, 1);
      heff_drop(v_ps_240);
      heff_drop(v_src_2419);
      v_x_2431 = heff_tag_at(v_ru_24x_2418_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_Right, 1, (V[]){v_pk_2430})});
      break;
    }
    default: heff_nomatch(v_t_2420);
    }
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_2417;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo(g_heff_2eload_2ereadPackageAt_24s870_24s1131_lam3, 1, 2, (V[]){v_ps_240, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eload_2ereadSumAt_24s873_24s1134_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 46, 115, 117, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2ereadSumAt_24s873_24s1134_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eload_2ereadSumAt_24s873_24s1134_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 46, 115, 117, 109}};
V g_heff_2eload_2ereadSumAt_24s873_24s1134_lam1(V self, V *args); static Clo g_heff_2eload_2ereadSumAt_24s873_24s1134_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ereadSumAt_24s873_24s1134_lam1, 1, 0};
V g_heff_2eload_2ereadSumAt_24s873_24s1134_lam0(V self, V *args);
V g_heff_2eload_2ereadSumAt_24s873_24s1134_lam3(V self, V *args);
V g_heff_2eload_2ereadSumAt_24s873_24s1134_lam2(V self, V *args);
Clo g_heff_2eload_2ereadSumAt_24s873_24s1134_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ereadSumAt_24s873_24s1134_entry, 1, 0};

V g_heff_2eload_2ereadSumAt_24s873_24s1134(V v_ps_240) {
top: ;
  V v_st_241 = heff_get(heff_dup(v_ps_240), LBL_style);
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_get(heff_dup(v_ps_240), LBL_root)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2eload_2ereadSumAt_24s873_24s1134_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = ({ V a_0 = heff_get(heff_dup(v_p_244), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_244), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_244), LBL_drive), heff_get(v_p_244, LBL_absolute), v_t_245});
  V v_path_247 = ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
  V v_c_2415 = heff_clo(g_heff_2eload_2ereadSumAt_24s873_24s1134_lam0, 2, 1, (V[]){v_path_247});
  return heff_clo(g_heff_2eload_2ereadSumAt_24s873_24s1134_lam2, 2, 2, (V[]){v_c_2415, v_ps_240});
}
V g_heff_2eload_2ereadSumAt_24s873_24s1134_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2ereadSumAt_24s873_24s1134(a[0]);
}
V g_heff_2eload_2ereadSumAt_24s873_24s1134_lam1(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2eload_2ereadSumAt_24s873_24s1134_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k2_249 = args[1];
  V v_path_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_247, ((V)&g_heff_2eload_2ereadSumAt_24s873_24s1134_lam1_clo)})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(v_hd_248, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eload_2ereadSumAt_24s873_24s1134_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2431;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    heff_drop(v_ps_240);
    v_x_2431 = heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_t_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Just = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2420 = (g_prelude_2esplitFrom(((V)&g_heff_2eload_2ereadSumAt_24s873_24s1134_str1), heff_dup(v_t_2419), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2421 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2420; V r_ = (g_heff_2eproject_2esumGo(a_0, a_1)); heff_drop(v_t_2420); r_; });
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Left: {
      V v_p_2422 = heff_field(v_t_2421, 0);
      heff_take_n(v_t_2421, 1ULL, 1);
      V v_st_2423 = heff_get(heff_dup(v_ps_240), LBL_style);
      V v_t_2424 = (g_std_2epath_2eparse(v_st_2423, heff_get(v_ps_240, LBL_root)));
      V v_t_2425 = (g_std_2epath_2eparse(v_st_2423, ((V)&g_heff_2eload_2ereadSumAt_24s873_24s1134_str2)));
      V v_p_2426 = (g_std_2epath_2ejoin_2eonto_240(v_t_2424, v_t_2425));
      V v_t_2427 = ({ V a_0 = heff_get(heff_dup(v_p_2426), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2426), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2428 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2426), LBL_drive), heff_get(v_p_2426, LBL_absolute), v_t_2427});
      V v_t_2429 = ({ V a_0 = v_st_2423; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2423); r_; });
      v_x_2431 = heff_tag_at(v_ru_24x_2418_24Just, TAG_Left, 1, (V[]){(g_heff_2eload_2eproblemMsg(v_t_2429, v_t_2419, v_p_2422))});
      break;
    }
    case TAG_Right: {
      V v_sums_2430 = heff_field(v_t_2421, 0);
      heff_take_n(v_t_2421, 1ULL, 1);
      heff_drop(v_ps_240);
      heff_drop(v_t_2419);
      v_x_2431 = heff_tag_at(v_ru_24x_2418_24Just, TAG_Right, 1, (V[]){v_sums_2430});
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_2417;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2ereadSumAt_24s873_24s1134_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo(g_heff_2eload_2ereadSumAt_24s873_24s1134_lam3, 1, 2, (V[]){v_ps_240, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eload_2ereadPkgAt_24s875_24s1136_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eload_2ereadPkgAt_24s875_24s1136_str1 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eload_2ereadPkgAt_24s875_24s1136_str2 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 99, 97, 110, 110, 111, 116, 32, 98, 101, 32, 114, 101, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eload_2ereadPkgAt_24s875_24s1136_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eload_2ereadPkgAt_24s875_24s1136_str4 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eload_2ereadPkgAt_24s875_24s1136_str5 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 105, 115, 32, 116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eload_2ereadPkgAt_24s875_24s1136_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {44, 32, 110, 111, 116, 32}};
V g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam1(V self, V *args); static Clo g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam1, 1, 0};
V g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam0(V self, V *args);
V g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam3(V self, V *args);
V g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam2(V self, V *args);
Clo g_heff_2eload_2ereadPkgAt_24s875_24s1136_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ereadPkgAt_24s875_24s1136_entry, 3, 0};

V g_heff_2eload_2ereadPkgAt_24s875_24s1136(V v_ps_240, V v_dir_241, V v_path_242) {
top: ;
  V v_st_243 = heff_get(heff_dup(v_ps_240), LBL_style);
  V v_t_244 = (g_std_2epath_2eparse(v_st_243, heff_dup(v_dir_241)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2eload_2ereadPkgAt_24s875_24s1136_str0)));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = ({ V a_0 = heff_get(heff_dup(v_p_246), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_246), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_248 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_246), LBL_drive), heff_get(v_p_246, LBL_absolute), v_t_247});
  V v_path_249 = ({ V a_0 = v_st_243; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); r_; });
  V v_c_2417 = heff_clo(g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam0, 2, 1, (V[]){v_path_249});
  return heff_clo(g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam2, 2, 4, (V[]){v_c_2417, v_ps_240, v_dir_241, v_path_242});
}
V g_heff_2eload_2ereadPkgAt_24s875_24s1136_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2ereadPkgAt_24s875_24s1136(a[0], a[1], a[2]);
}
V g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam1(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k2_2411 = args[1];
  V v_path_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_249, ((V)&g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam1_clo)})});
  V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2410), LBL_malg), 1, (V[]){v_t_2415}));
  V f_ = heff_get(v_hd_2410, LBL_bind);
  args[0] = v_t_2416;
  args[1] = v_k2_2411;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_k_2419 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2448;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Nothing: {
    heff_drop(v_path_242);
    V v_st_2421 = heff_get(v_ps_240, LBL_style);
    V v_t_2422 = (g_std_2epath_2eparse(v_st_2421, v_dir_241));
    V v_t_2423 = (g_std_2epath_2eparse(v_st_2421, ((V)&g_heff_2eload_2ereadPkgAt_24s875_24s1136_str1)));
    V v_p_2424 = (g_std_2epath_2ejoin_2eonto_240(v_t_2422, v_t_2423));
    V v_t_2425 = ({ V a_0 = heff_get(heff_dup(v_p_2424), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2424), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2426 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2424), LBL_drive), heff_get(v_p_2424, LBL_absolute), v_t_2425});
    V v_t_2427 = ({ V a_0 = v_st_2421; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2421); r_; });
    v_x_2448 = heff_tag(TAG_Left, 1, (V[]){heff_strAppend(v_t_2427, ((V)&g_heff_2eload_2ereadPkgAt_24s875_24s1136_str2))});
    break;
  }
  case TAG_Just: {
    V v_t_2428 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Just = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    V v_t_2429 = (g_heff_2eproject_2ereadPackage(heff_dup(v_t_2428)));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Left: {
      V v_p_2430 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      heff_drop(v_path_242);
      V v_st_2431 = heff_get(v_ps_240, LBL_style);
      V v_t_2432 = (g_std_2epath_2eparse(v_st_2431, v_dir_241));
      V v_t_2433 = (g_std_2epath_2eparse(v_st_2431, ((V)&g_heff_2eload_2ereadPkgAt_24s875_24s1136_str3)));
      V v_p_2434 = (g_std_2epath_2ejoin_2eonto_240(v_t_2432, v_t_2433));
      V v_t_2435 = ({ V a_0 = heff_get(heff_dup(v_p_2434), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2434), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2436 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2434), LBL_drive), heff_get(v_p_2434, LBL_absolute), v_t_2435});
      V v_t_2437 = ({ V a_0 = v_st_2431; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2431); r_; });
      v_x_2448 = heff_tag_at(v_ru_24x_2420_24Just, TAG_Left, 1, (V[]){(g_heff_2eload_2eproblemMsg(v_t_2437, v_t_2428, v_p_2430))});
      break;
    }
    case TAG_Right: {
      V v_pk_2438 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      heff_drop(v_t_2428);
      V v_t_2439 = heff_strEq(heff_get(heff_dup(v_pk_2438), LBL_module), heff_dup(v_path_242));
      switch (heff_tag_of(v_t_2439)) {
      case TAG_True: {
        heff_drop(v_ps_240);
        heff_drop(v_dir_241);
        heff_drop(v_path_242);
        v_x_2448 = heff_tag_at(v_ru_24x_2420_24Just, TAG_Right, 1, (V[]){v_pk_2438});
        break;
      }
      case TAG_False: {
        V v_st_2440 = heff_get(v_ps_240, LBL_style);
        V v_t_2441 = (g_std_2epath_2eparse(v_st_2440, v_dir_241));
        V v_t_2442 = (g_std_2epath_2eparse(v_st_2440, ((V)&g_heff_2eload_2ereadPkgAt_24s875_24s1136_str4)));
        V v_p_2443 = (g_std_2epath_2ejoin_2eonto_240(v_t_2441, v_t_2442));
        V v_t_2444 = ({ V a_0 = heff_get(heff_dup(v_p_2443), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2443), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_2445 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2443), LBL_drive), heff_get(v_p_2443, LBL_absolute), v_t_2444});
        V v_t_2446 = ({ V a_0 = v_st_2440; V a_1 = v_t_2445; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2440); r_; });
        V v_t_2447 = heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2eload_2ereadPkgAt_24s875_24s1136_str5), heff_strAppend(heff_get(v_pk_2438, LBL_module), heff_strAppend(((V)&g_heff_2eload_2ereadPkgAt_24s875_24s1136_str6), v_path_242))));
        v_x_2448 = heff_tag_at(v_ru_24x_2420_24Just, TAG_Left, 1, (V[]){v_t_2447});
        break;
      }
      default: heff_nomatch(v_t_2439);
      }
      break;
    }
    default: heff_nomatch(v_t_2429);
    }
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  V f_ = v_k_2419;
  args[0] = v_x_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo(g_heff_2eload_2ereadPkgAt_24s875_24s1136_lam3, 1, 4, (V[]){v_ps_240, v_dir_241, v_path_242, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eload_2ecachedPkg_24s874_24s1135_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 97, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eload_2ecachedPkg_24s874_24s1135_str1 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 114, 101, 113, 117, 105, 114, 101, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2ecachedPkg_24s874_24s1135_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_heff_2eload_2ecachedPkg_24s874_24s1135_str3 = {{0x80000000u, K_STR, 0}, 38, 38, {44, 32, 119, 104, 105, 99, 104, 32, 105, 115, 32, 110, 111, 116, 32, 102, 101, 116, 99, 104, 101, 100, 58, 32, 114, 117, 110, 32, 96, 104, 101, 102, 102, 32, 103, 101, 116, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eload_2ecachedPkg_24s874_24s1135_str4 = {{0x80000000u, K_STR, 0}, 25, 25, {104, 101, 102, 102, 46, 115, 117, 109, 32, 115, 97, 121, 115, 32, 110, 111, 116, 104, 105, 110, 103, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2ecachedPkg_24s874_24s1135_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eload_2ecachedPkg_24s874_24s1135_str6 = {{0x80000000u, K_STR, 0}, 16, 16, {58, 32, 114, 117, 110, 32, 96, 104, 101, 102, 102, 32, 103, 101, 116, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2ecachedPkg_24s874_24s1135_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eload_2ecachedPkg_24s874_24s1135_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 105, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eload_2ecachedPkg_24s874_24s1135_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 105, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eload_2ecachedPkg_24s874_24s1135_str10 = {{0x80000000u, K_STR, 0}, 20, 20, {44, 32, 97, 110, 100, 32, 104, 101, 102, 102, 46, 115, 117, 109, 32, 115, 97, 121, 115, 32}};
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam0(V self, V *args);
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam1(V self, V *args);
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam3(V self, V *args); static Clo g_heff_2eload_2ecachedPkg_24s874_24s1135_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ecachedPkg_24s874_24s1135_lam3, 1, 0};
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam2(V self, V *args);
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam6(V self, V *args);
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam5(V self, V *args);
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam4(V self, V *args);
Clo g_heff_2eload_2ecachedPkg_24s874_24s1135_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ecachedPkg_24s874_24s1135_entry, 6, 0};

V g_heff_2eload_2ecachedPkg_24s874_24s1135(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_t_247 = (g_prelude_2efilter(heff_clo(g_heff_2eload_2ecachedPkg_24s874_24s1135_lam0, 1, 1, (V[]){heff_dup(v_path_244)}), heff_get(heff_dup(v_root_241), LBL_require)));
  V v_t_2414;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nil: {
    heff_drop(v_root_241);
    v_t_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 2);
    V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2eload_2ecachedPkg_24s874_24s1135_lam1, 1, 1, (V[]){v_r_248}), heff_get(v_root_241, LBL_replace)));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 2);
      v_t_2414 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_p_2412, LBL_dir)});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    V v_t_2415 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_path_2416 = heff_strAppend(v_t_2415, ((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_str0));
    V v_c_2424 = heff_clo(g_heff_2eload_2ecachedPkg_24s874_24s1135_lam2, 2, 1, (V[]){v_path_2416});
    return heff_clo(g_heff_2eload_2ecachedPkg_24s874_24s1135_lam4, 2, 6, (V[]){v_c_2424, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2452 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_st_2453 = heff_get(heff_dup(v_ps_240), LBL_style);
    V v_t_2454 = (g_std_2epath_2eparse(v_st_2453, heff_get(heff_dup(v_ps_240), LBL_root)));
    V v_t_2455 = (g_std_2epath_2eparse(v_st_2453, v_d_2452));
    V v_p_2456 = (g_std_2epath_2ejoin_2eonto_240(v_t_2454, v_t_2455));
    V v_t_2457 = ({ V a_0 = heff_get(heff_dup(v_p_2456), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2456), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2458 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2456), LBL_drive), heff_get(v_p_2456, LBL_absolute), v_t_2457});
    V v_t_2459 = ({ V a_0 = v_st_2453; V a_1 = v_t_2458; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2453); r_; });
    return (g_heff_2eload_2ereadPkgAt_24s875_24s1136(v_ps_240, v_t_2459, v_path_244));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2eload_2ecachedPkg_24s874_24s1135_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2ecachedPkg_24s874_24s1135(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam0(V self, V *args) {
  V v_r_246 = args[0];
  V v_path_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_r_246, LBL_path), v_path_244);
}
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam1(V self, V *args) {
  V v_p_2410 = args[0];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_p_2410, LBL_name), heff_get(v_r_248, LBL_name));
}
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam3(V self, V *args) {
  V v_t_2419 = args[0];
  return v_t_2419;
}
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_path_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2416, ((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_lam3_clo)})});
  V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_2422}));
  V f_ = heff_get(v_hd_2417, LBL_bind);
  args[0] = v_t_2423;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam6(V self, V *args) {
  V v_s_2430 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_strEq(heff_get(heff_dup(v_s_2430), LBL_path), v_path_244);
  switch (heff_tag_of(v_t_2431)) {
  case TAG_True: {
    return heff_strEq(heff_get(v_s_2430, LBL_version), v_v_245);
  }
  case TAG_False: {
    heff_drop(v_s_2430);
    heff_drop(v_v_245);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2431);
  }
}
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_by_243 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_v_245 = heff_env(self)[2];
  V v_k_2426 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2425 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Nothing: {
    heff_drop(v_sums_242);
    heff_drop(v_ps_240);
    heff_drop(v_hd_2425);
    V v_t_2428 = heff_strAppend(v_by_243, heff_strAppend(((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_str1), heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_str2), heff_strAppend(v_v_245, ((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_str3))))));
    V f_ = v_k_2426;
    args[0] = heff_tag(TAG_Left, 1, (V[]){v_t_2428});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_h_2429 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Just = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2432 = (g_prelude_2efilter(heff_clo(g_heff_2eload_2ecachedPkg_24s874_24s1135_lam6, 1, 2, (V[]){heff_dup(v_path_244), heff_dup(v_v_245)}), v_sums_242));
    V v_t_2435;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x_2427_24Just, 1);
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_s_2433 = heff_field(v_t_2432, 0);
      heff_take_n(v_t_2432, 1ULL, 2);
      v_t_2435 = heff_tag_at(v_ru_24x_2427_24Just, TAG_Just, 1, (V[]){heff_get(v_s_2433, LBL_hash)});
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    switch (heff_tag_of(v_t_2435)) {
    case TAG_Nothing: {
      heff_drop(v_ps_240);
      heff_drop(v_hd_2425);
      heff_drop(v_h_2429);
      V v_t_2436 = heff_strAppend(((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_str4), heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_str5), heff_strAppend(v_v_245, ((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_str6)))));
      V f_ = v_k_2426;
      args[0] = heff_tag(TAG_Left, 1, (V[]){v_t_2436});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_want_2437 = heff_field(v_t_2435, 0);
      V v_ru_24t_2435_24Just = heff_take_reuse_n(v_t_2435, 1ULL, 1);
      V v_t_2438 = (g_prelude_2eskipSpaces(heff_dup(v_h_2429), MK_INT(0LL), MK_INT(1LL)));
      V v_t_2439 = heff_intSub(heff_strLength(heff_dup(v_h_2429)), MK_INT(1LL));
      V v_t_2440 = (g_prelude_2eskipSpaces(heff_dup(v_h_2429), v_t_2439, MK_INT(-1LL)));
      V v_t_2441 = heff_strSlice(heff_dup(v_h_2429), v_t_2438, heff_intAdd(v_t_2440, MK_INT(1LL)));
      V v_t_2442 = heff_strEq(v_t_2441, heff_dup(v_want_2437));
      switch (heff_tag_of(v_t_2442)) {
      case TAG_True: {
        heff_drop(v_h_2429);
        heff_drop(v_want_2437);
        heff_drop_cell(v_ru_24t_2435_24Just, 1);
        V v_t_2443 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2444 = (g_heff_2eload_2ereadPkgAt_24s875_24s1136(v_ps_240, v_t_2443, v_path_244));
        return heff_tail(v_t_2444, 2, (V[]){v_hd_2425, v_k_2426});
      }
      case TAG_False: {
        heff_drop(v_hd_2425);
        V v_t_2445 = (g_heff_2eload_2ecachedDir(v_ps_240, heff_dup(v_path_244), heff_dup(v_v_245)));
        V v_t_2446 = (g_prelude_2eskipSpaces(heff_dup(v_h_2429), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2447 = heff_intSub(heff_strLength(heff_dup(v_h_2429)), MK_INT(1LL));
        V v_t_2448 = (g_prelude_2eskipSpaces(heff_dup(v_h_2429), v_t_2447, MK_INT(-1LL)));
        V v_t_2449 = heff_strSlice(v_h_2429, v_t_2446, heff_intAdd(v_t_2448, MK_INT(1LL)));
        V v_t_2450 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_str7), heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_str8), heff_strAppend(v_t_2445, heff_strAppend(((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_str9), heff_strAppend(v_t_2449, heff_strAppend(((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_str10), v_want_2437))))))));
        V v_x_2451 = heff_tag_at(v_ru_24t_2435_24Just, TAG_Left, 1, (V[]){v_t_2450});
        V f_ = v_k_2426;
        args[0] = v_x_2451;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_t_2442);
      }
    }
    default: return heff_nomatch(v_t_2435);
    }
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2eload_2ecachedPkg_24s874_24s1135_lam4(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_by_243 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2424;
  args[0] = heff_dup(v_hd_2425);
  args[1] = heff_clo(g_heff_2eload_2ecachedPkg_24s874_24s1135_lam5, 1, 7, (V[]){v_by_243, v_path_244, v_v_245, v_k_2426, v_sums_242, v_ps_240, v_hd_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eload_2eownDir_24s880_24s1139_str0 = {{0x80000000u, K_STR, 0}, 19, 19, {32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eownDir_24s880_24s1139_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eload_2eownDir_24s880_24s1139_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 104, 111, 108, 100, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2eload_2eownDir_24s880_24s1139_str3 = {{0x80000000u, K_STR, 0}, 60, 60, {58, 32, 97, 32, 112, 97, 99, 107, 97, 103, 101, 39, 115, 32, 115, 114, 99, 47, 32, 104, 111, 108, 100, 115, 32, 111, 110, 101, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121, 44, 32, 110, 97, 109, 101, 100, 32, 97, 115, 32, 116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eload_2eownDir_24s880_24s1139_str4 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 104, 111, 108, 100, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2eload_2eownDir_24s880_24s1139_str5 = {{0x80000000u, K_STR, 0}, 26, 26, {44, 32, 119, 104, 105, 99, 104, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[72]; } g_heff_2eload_2eownDir_24s880_24s1139_str6 = {{0x80000000u, K_STR, 0}, 72, 72, {32, 99, 97, 110, 110, 111, 116, 32, 110, 97, 109, 101, 32, 97, 32, 112, 97, 99, 107, 97, 103, 101, 58, 32, 97, 32, 108, 111, 119, 101, 114, 99, 97, 115, 101, 32, 108, 101, 116, 116, 101, 114, 44, 32, 116, 104, 101, 110, 32, 108, 101, 116, 116, 101, 114, 115, 44, 32, 100, 105, 103, 105, 116, 115, 32, 97, 110, 100, 32, 96, 95, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eownDir_24s880_24s1139_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eload_2eownDir_24s880_24s1139_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 104, 111, 108, 100, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2eload_2eownDir_24s880_24s1139_str9 = {{0x80000000u, K_STR, 0}, 60, 60, {58, 32, 97, 32, 112, 97, 99, 107, 97, 103, 101, 39, 115, 32, 115, 114, 99, 47, 32, 104, 111, 108, 100, 115, 32, 111, 110, 101, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121, 44, 32, 110, 97, 109, 101, 100, 32, 97, 115, 32, 116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101}};
V g_heff_2eload_2eownDir_24s880_24s1139_lam0(V self, V *args); static Clo g_heff_2eload_2eownDir_24s880_24s1139_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eownDir_24s880_24s1139_lam0, 1, 0};
V g_heff_2eload_2eownDir_24s880_24s1139_lam3(V self, V *args); static Clo g_heff_2eload_2eownDir_24s880_24s1139_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eownDir_24s880_24s1139_lam3, 1, 0};
V g_heff_2eload_2eownDir_24s880_24s1139_lam2(V self, V *args);
V g_heff_2eload_2eownDir_24s880_24s1139_lam4(V self, V *args);
V g_heff_2eload_2eownDir_24s880_24s1139_lam1(V self, V *args);
Clo g_heff_2eload_2eownDir_24s880_24s1139_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eownDir_24s880_24s1139_entry, 4, 0};

V g_heff_2eload_2eownDir_24s880_24s1139(V v_ps_240, V v_src_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){heff_dup(v_src_241), ((V)&g_heff_2eload_2eownDir_24s880_24s1139_lam0_clo)})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2eload_2eownDir_24s880_24s1139_lam1, 1, 4, (V[]){v_src_241, v_k_243, v_ps_240, v_hd_242})});
}
V g_heff_2eload_2eownDir_24s880_24s1139_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2eownDir_24s880_24s1139(a[0], a[1], a[2], a[3]);
}
V g_heff_2eload_2eownDir_24s880_24s1139_lam0(V self, V *args) {
  V v_ns_244 = args[0];
  return v_ns_244;
}
V g_heff_2eload_2eownDir_24s880_24s1139_lam3(V self, V *args) {
  V v_ns_2428 = args[0];
  return v_ns_2428;
}
V g_heff_2eload_2eownDir_24s880_24s1139_lam2(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k2_2427 = args[1];
  V v_path_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){v_path_2425, ((V)&g_heff_2eload_2eownDir_24s880_24s1139_lam3_clo)})});
  V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2426), LBL_malg), 1, (V[]){v_t_2431}));
  V f_ = heff_get(v_hd_2426, LBL_bind);
  args[0] = v_t_2432;
  args[1] = v_k2_2427;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eload_2eownDir_24s880_24s1139_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_src_241 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2445;
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Nothing: {
    heff_drop(v_ps_240);
    V v_t_2435 = heff_strAppend(v_src_241, heff_strAppend(((V)&g_heff_2eload_2eownDir_24s880_24s1139_str4), heff_strAppend(v_x_2417, ((V)&g_heff_2eload_2eownDir_24s880_24s1139_str5))));
    v_x_2445 = heff_tag(TAG_Left, 1, (V[]){v_t_2435});
    break;
  }
  case TAG_Just: {
    V v_ru_24x_2434_24Just = heff_take_reuse_n(v_x_2434, 0ULL, 1);
    V v_t_2437 = (g_heff_2eproject_2eisName(heff_dup(v_x_2417)));
    switch (heff_tag_of(v_t_2437)) {
    case TAG_True: {
      heff_drop(v_src_241);
      heff_drop(v_ps_240);
      v_x_2445 = heff_tag_at(v_ru_24x_2434_24Just, TAG_Right, 1, (V[]){v_x_2417});
      break;
    }
    case TAG_False: {
      V v_st_2438 = heff_get(v_ps_240, LBL_style);
      V v_t_2439 = (g_std_2epath_2eparse(v_st_2438, v_src_241));
      V v_t_2440 = (g_std_2epath_2eparse(v_st_2438, v_x_2417));
      V v_p_2441 = (g_std_2epath_2ejoin_2eonto_240(v_t_2439, v_t_2440));
      V v_t_2442 = ({ V a_0 = heff_get(heff_dup(v_p_2441), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2441), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2443 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2441), LBL_drive), heff_get(v_p_2441, LBL_absolute), v_t_2442});
      V v_t_2444 = ({ V a_0 = v_st_2438; V a_1 = v_t_2443; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2438); r_; });
      v_x_2445 = heff_tag_at(v_ru_24x_2434_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_t_2444, ((V)&g_heff_2eload_2eownDir_24s880_24s1139_str6))});
      break;
    }
    default: heff_nomatch(v_t_2437);
    }
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  V f_ = v_k_243;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2eownDir_24s880_24s1139_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_src_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop(v_ps_240);
    heff_drop(v_hd_242);
    V v_t_2410 = heff_tag(TAG_Left, 1, (V[]){heff_strAppend(v_src_241, ((V)&g_heff_2eload_2eownDir_24s880_24s1139_str0))});
    V f_ = v_k_243;
    args[0] = v_t_2410;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_it1_2411 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Just = heff_take_reuse_n(v_x_249, 1ULL, 1);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_Nil: {
      heff_drop(v_ps_240);
      heff_drop(v_hd_242);
      V v_t_2414;
      switch (heff_tag_of(v_it1_2411)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2eload_2eownDir_24s880_24s1139_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_it1_2411, 0);
        V v_xs_2413 = heff_field(v_it1_2411, 1);
        heff_take_n(v_it1_2411, 3ULL, 2);
        v_t_2414 = ({ V a_0 = v_x_2412; V a_1 = v_xs_2413; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2413); r_; });
        break;
      }
      default: heff_nomatch(v_it1_2411);
      }
      V v_t_2415 = heff_strAppend(v_src_241, heff_strAppend(((V)&g_heff_2eload_2eownDir_24s880_24s1139_str2), heff_strAppend(v_t_2414, ((V)&g_heff_2eload_2eownDir_24s880_24s1139_str3))));
      V v_x_2416 = heff_tag_at(v_ru_24x_249_24Just, TAG_Left, 1, (V[]){v_t_2415});
      V f_ = v_k_243;
      args[0] = v_x_2416;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_2417 = heff_dup(heff_field(v_it1_2411, 0));
      V v_it12_2418 = heff_dup(heff_field(v_it1_2411, 1));
      switch (heff_tag_of(v_it12_2418)) {
      case TAG_Nil: {
        heff_drop_tag(v_it1_2411, 2);
        heff_drop_cell(v_ru_24x_249_24Just, 1);
        V v_st_2419 = heff_get(heff_dup(v_ps_240), LBL_style);
        V v_t_2420 = (g_std_2epath_2eparse(v_st_2419, heff_dup(v_src_241)));
        V v_t_2421 = (g_std_2epath_2eparse(v_st_2419, heff_dup(v_x_2417)));
        V v_p_2422 = (g_std_2epath_2ejoin_2eonto_240(v_t_2420, v_t_2421));
        V v_t_2423 = ({ V a_0 = heff_get(heff_dup(v_p_2422), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2422), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_2424 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2422), LBL_drive), heff_get(v_p_2422, LBL_absolute), v_t_2423});
        V v_path_2425 = ({ V a_0 = v_st_2419; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2419); r_; });
        V v_c_2433 = heff_clo(g_heff_2eload_2eownDir_24s880_24s1139_lam2, 2, 1, (V[]){v_path_2425});
        return heff_tail(v_c_2433, 2, (V[]){v_hd_242, heff_clo(g_heff_2eload_2eownDir_24s880_24s1139_lam4, 1, 4, (V[]){v_src_241, v_x_2417, v_ps_240, v_k_243})});
      }
      case TAG_Cons: {
        heff_take_n(v_it12_2418, 0ULL, 2);
        heff_drop(v_ps_240);
        heff_drop(v_hd_242);
        heff_drop(v_x_2417);
        V v_t_2450;
        switch (heff_tag_of(v_it1_2411)) {
        case TAG_Nil: {
          v_t_2450 = ((V)&g_heff_2eload_2eownDir_24s880_24s1139_str7);
          break;
        }
        case TAG_Cons: {
          V v_x_2448 = heff_field(v_it1_2411, 0);
          V v_xs_2449 = heff_field(v_it1_2411, 1);
          heff_take_n(v_it1_2411, 3ULL, 2);
          v_t_2450 = ({ V a_0 = v_x_2448; V a_1 = v_xs_2449; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2449); r_; });
          break;
        }
        default: heff_nomatch(v_it1_2411);
        }
        V v_t_2451 = heff_strAppend(v_src_241, heff_strAppend(((V)&g_heff_2eload_2eownDir_24s880_24s1139_str8), heff_strAppend(v_t_2450, ((V)&g_heff_2eload_2eownDir_24s880_24s1139_str9))));
        V v_x_2452 = heff_tag_at(v_ru_24x_249_24Just, TAG_Left, 1, (V[]){v_t_2451});
        V f_ = v_k_243;
        args[0] = v_x_2452;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_it12_2418);
      }
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  default: return heff_nomatch(v_x_249);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eload_2epkgOf_24s879_24s1138_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eload_2epkgOf_24s879_24s1138_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
V g_heff_2eload_2epkgOf_24s879_24s1138_lam0(V self, V *args);
V g_heff_2eload_2epkgOf_24s879_24s1138_lam1(V self, V *args);
V g_heff_2eload_2epkgOf_24s879_24s1138_lam2(V self, V *args);
V g_heff_2eload_2epkgOf_24s879_24s1138_lam5(V self, V *args);
V g_heff_2eload_2epkgOf_24s879_24s1138_lam4(V self, V *args);
V g_heff_2eload_2epkgOf_24s879_24s1138_lam3(V self, V *args);
Clo g_heff_2eload_2epkgOf_24s879_24s1138_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2epkgOf_24s879_24s1138_entry, 4, 0};

V g_heff_2eload_2epkgOf_24s879_24s1138(V v_ps_240, V v_root_241, V v_x_242, V v_pk_243) {
top: ;
  V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2eload_2epkgOf_24s879_24s1138_lam0, 1, 1, (V[]){heff_dup(v_x_242)}), heff_get(heff_dup(v_root_241), LBL_require)));
  V v_x_2418;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nil: {
    heff_drop(v_root_241);
    v_x_2418 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_get(heff_dup(v_x_242), LBL_path), heff_get(heff_dup(v_x_242), LBL_version)));
    break;
  }
  case TAG_Cons: {
    V v_r_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 2);
    V v_t_249 = (g_prelude_2efilter(heff_clo(g_heff_2eload_2epkgOf_24s879_24s1138_lam1, 1, 1, (V[]){v_r_246}), heff_get(v_root_241, LBL_replace)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_x_2418 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_get(heff_dup(v_x_242), LBL_path), heff_get(heff_dup(v_x_242), LBL_version)));
      break;
    }
    case TAG_Cons: {
      V v_p_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 2);
      V v_st_2412 = heff_get(heff_dup(v_ps_240), LBL_style);
      V v_t_2413 = (g_std_2epath_2eparse(v_st_2412, heff_get(heff_dup(v_ps_240), LBL_root)));
      V v_t_2414 = (g_std_2epath_2eparse(v_st_2412, heff_get(v_p_2410, LBL_dir)));
      V v_p_2415 = (g_std_2epath_2ejoin_2eonto_240(v_t_2413, v_t_2414));
      V v_t_2416 = ({ V a_0 = heff_get(heff_dup(v_p_2415), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2415), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2417 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2415), LBL_drive), heff_get(v_p_2415, LBL_absolute), v_t_2416});
      v_x_2418 = ({ V a_0 = v_st_2412; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); r_; });
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_c_2421 = heff_clo(g_heff_2eload_2epkgOf_24s879_24s1138_lam2, 2, 1, (V[]){v_x_2418});
  return heff_clo(g_heff_2eload_2epkgOf_24s879_24s1138_lam3, 2, 4, (V[]){v_c_2421, v_ps_240, v_pk_243, v_x_242});
}
V g_heff_2eload_2epkgOf_24s879_24s1138_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2epkgOf_24s879_24s1138(a[0], a[1], a[2], a[3]);
}
V g_heff_2eload_2epkgOf_24s879_24s1138_lam0(V self, V *args) {
  V v_r_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_r_244, LBL_path), heff_get(v_x_242, LBL_path));
}
V g_heff_2eload_2epkgOf_24s879_24s1138_lam1(V self, V *args) {
  V v_p_248 = args[0];
  V v_r_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_p_248, LBL_name), heff_get(v_r_246, LBL_name));
}
V g_heff_2eload_2epkgOf_24s879_24s1138_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2epkgOf_24s879_24s1138_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  V v_pk_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_k_2423 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2445;
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    V v_why_2434 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Left = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    heff_drop(v_ps_240);
    heff_drop(v_x_2424);
    heff_drop(v_pk_243);
    heff_drop(v_x_242);
    v_x_2445 = heff_tag_at(v_ru_24x_2433_24Left, TAG_Left, 1, (V[]){v_why_2434});
    break;
  }
  case TAG_Right: {
    V v_name_2435 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Right = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    V v_st_2436 = heff_get(v_ps_240, LBL_style);
    V v_t_2437 = (g_std_2epath_2eparse(v_st_2436, heff_dup(v_x_2424)));
    V v_t_2438 = (g_std_2epath_2eparse(v_st_2436, ((V)&g_heff_2eload_2epkgOf_24s879_24s1138_str1)));
    V v_p_2439 = (g_std_2epath_2ejoin_2eonto_240(v_t_2437, v_t_2438));
    V v_t_2440 = ({ V a_0 = heff_get(heff_dup(v_p_2439), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2439), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2441 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2439), LBL_drive), heff_get(v_p_2439, LBL_absolute), v_t_2440});
    V v_t_2442 = ({ V a_0 = v_st_2436; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); r_; });
    V v_t_2443 = (g_prelude_2emap_24s722(heff_get(heff_dup(v_pk_243), LBL_require)));
    V v_t_2444 = heff_rec(7, shape_239_65_317_225_344_124_289, (V[]){heff_get(v_x_242, LBL_path), v_x_2424, v_t_2442, heff_dup(v_name_2435), v_name_2435, heff_get(v_pk_243, LBL_heff), v_t_2443});
    v_x_2445 = heff_tag_at(v_ru_24x_2433_24Right, TAG_Right, 1, (V[]){v_t_2444});
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  V f_ = v_k_2423;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2epkgOf_24s879_24s1138_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_pk_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_k_2423 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2425 = heff_get(heff_dup(v_ps_240), LBL_style);
  V v_t_2426 = (g_std_2epath_2eparse(v_st_2425, heff_dup(v_x_2424)));
  V v_t_2427 = (g_std_2epath_2eparse(v_st_2425, ((V)&g_heff_2eload_2epkgOf_24s879_24s1138_str0)));
  V v_p_2428 = (g_std_2epath_2ejoin_2eonto_240(v_t_2426, v_t_2427));
  V v_t_2429 = ({ V a_0 = heff_get(heff_dup(v_p_2428), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2428), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2430 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2428), LBL_drive), heff_get(v_p_2428, LBL_absolute), v_t_2429});
  V v_t_2431 = ({ V a_0 = v_st_2425; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2425); r_; });
  V v_c_2432 = heff_tr(heff_apply(((V)&g_heff_2eload_2eownDir_24s880_24s1139_clo), 2, (V[]){heff_dup(v_ps_240), v_t_2431}));
  return heff_tail(v_c_2432, 2, (V[]){v_hd_2422, heff_clo(g_heff_2eload_2epkgOf_24s879_24s1138_lam5, 1, 5, (V[]){v_ps_240, v_x_2424, v_pk_243, v_x_242, v_k_2423})});
}
V g_heff_2eload_2epkgOf_24s879_24s1138_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_pk_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo(g_heff_2eload_2epkgOf_24s879_24s1138_lam4, 1, 5, (V[]){v_ps_240, v_hd_2422, v_pk_243, v_x_242, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eload_2epkgsOf_24s878_24s1137_lam0(V self, V *args);
V g_heff_2eload_2epkgsOf_24s878_24s1137_lam2(V self, V *args);
V g_heff_2eload_2epkgsOf_24s878_24s1137_lam1(V self, V *args);
Clo g_heff_2eload_2epkgsOf_24s878_24s1137_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2epkgsOf_24s878_24s1137_entry, 5, 0};

V g_heff_2eload_2epkgsOf_24s878_24s1137(V v_ps_240, V v_root_241, V v_x3_242, V v_acc_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_root_241);
    return heff_clo(g_heff_2eload_2epkgsOf_24s878_24s1137_lam0, 2, 2, (V[]){v_acc_243, v_errs_244});
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_249 = heff_get(heff_dup(v_x_247), LBL_pkg);
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop(v_x_247);
      V t_0 = v_ps_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_acc_243;
      V t_4 = v_errs_244;
      v_ps_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    }
    case TAG_Just: {
      V v_pk_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_c_2411 = (g_heff_2eload_2epkgOf_24s879_24s1138(heff_dup(v_ps_240), heff_dup(v_root_241), v_x_247, v_pk_2410));
      return heff_clo(g_heff_2eload_2epkgsOf_24s878_24s1137_lam1, 2, 6, (V[]){v_c_2411, v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243});
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eload_2epkgsOf_24s878_24s1137_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2epkgsOf_24s878_24s1137(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eload_2epkgsOf_24s878_24s1137_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_acc_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2epkgsOf_24s878_24s1137_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_errs_244 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_241 = heff_env(self)[2];
  V v_rest_248 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){v_why_2415, NTAG(TAG_Nil)});
    V v_t_2417 = (g_prelude_2econcatList(v_errs_244, v_t_2416));
    V v_t_2418 = (g_heff_2eload_2epkgsOf_24s878_24s1137(v_ps_240, v_root_241, v_rest_248, v_acc_243, v_t_2417));
    return heff_tail(v_t_2418, 2, (V[]){v_hd_2412, v_k_2413});
  }
  case TAG_Right: {
    V v_p_2419 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){v_p_2419, NTAG(TAG_Nil)});
    V v_t_2421 = (g_prelude_2econcatList(v_acc_243, v_t_2420));
    V v_t_2422 = (g_heff_2eload_2epkgsOf_24s878_24s1137(v_ps_240, v_root_241, v_rest_248, v_t_2421, v_errs_244));
    return heff_tail(v_t_2422, 2, (V[]){v_hd_2412, v_k_2413});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2eload_2epkgsOf_24s878_24s1137_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_acc_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo(g_heff_2eload_2epkgsOf_24s878_24s1137_lam2, 1, 7, (V[]){v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eload_2ereachAll_24s872_24s1133_lam3(V self, V *args);
V g_heff_2eload_2ereachAll_24s872_24s1133_lam4(V self, V *args);
V g_heff_2eload_2ereachAll_24s872_24s1133_lam2(V self, V *args);
V g_heff_2eload_2ereachAll_24s872_24s1133_lam1(V self, V *args);
V g_heff_2eload_2ereachAll_24s872_24s1133_lam0(V self, V *args);
Clo g_heff_2eload_2ereachAll_24s872_24s1133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ereachAll_24s872_24s1133_entry, 2, 0};

V g_heff_2eload_2ereachAll_24s872_24s1133(V v_ps_240, V v_root_241) {
top: ;
  V v_c_242 = (g_heff_2eload_2ereadSumAt_24s873_24s1134(heff_dup(v_ps_240)));
  return heff_clo(g_heff_2eload_2ereachAll_24s872_24s1133_lam0, 2, 3, (V[]){v_c_242, v_ps_240, v_root_241});
}
V g_heff_2eload_2ereachAll_24s872_24s1133_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2ereachAll_24s872_24s1133(a[0], a[1]);
}
V g_heff_2eload_2ereachAll_24s872_24s1133_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_seen_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2416; V a_1 = v_seen_2414; V r_ = (g_prelude_2efoldl_24s723(a_0, a_1)); heff_drop(v_seen_2414); r_; });
}
V g_heff_2eload_2ereachAll_24s872_24s1133_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_dup(heff_field(v_x_2419, 0));
    v_t_2422 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V v_t_2425;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    V v_x_2423 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    v_t_2425 = heff_tag(TAG_Cons, 2, (V[]){v_x_2423, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_245, 0ULL, 1);
    v_t_2425 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_2428;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_x_2411, 1);
    heff_take_n(v_x_2411, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2431;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_MkPair: {
    V v_y_2430 = heff_field(v_x_2419, 1);
    heff_take_n(v_x_2419, 2ULL, 2);
    v_t_2431 = v_y_2430;
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V v_t_2432 = (g_prelude_2econcatList(v_t_2428, v_t_2431));
  V v_x_2433 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2422, (g_prelude_2econcatList(v_t_2425, v_t_2432))});
  V f_ = v_k_244;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2ereachAll_24s872_24s1133_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_seen_2414;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_dup(heff_field(v_x_2411, 0));
    v_seen_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2415 = (g_prelude_2efoldl_24s724(NTAG(TAG_Nil), heff_dup(v_seen_2414)));
  V v_t_2417 = (g_prelude_2emap(heff_clo(g_heff_2eload_2ereachAll_24s872_24s1133_lam3, 1, 1, (V[]){v_seen_2414}), v_t_2415));
  V v_c_2418 = (g_heff_2eload_2epkgsOf_24s878_24s1137(v_ps_240, v_root_241, v_t_2417, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  return heff_tail(v_c_2418, 2, (V[]){v_hd_243, heff_clo(g_heff_2eload_2ereachAll_24s872_24s1133_lam4, 1, 3, (V[]){v_x_245, v_x_2411, v_k_244})});
}
V g_heff_2eload_2ereachAll_24s872_24s1133_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_247 = heff_dup(heff_field(v_x_245, 0));
    v_t_248 = v_y_247;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_249 = heff_tr(heff_apply(((V)&g_heff_2eload_2ecachedPkg_24s874_24s1135_clo), 3, (V[]){heff_dup(v_ps_240), heff_dup(v_root_241), v_t_248}));
  V v_c_2410 = (g_heff_2eload_2eversionsOf_24s876(v_t_249, heff_dup(v_root_241)));
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2eload_2ereachAll_24s872_24s1133_lam2, 1, 5, (V[]){v_ps_240, v_root_241, v_hd_243, v_x_245, v_k_244})});
}
V g_heff_2eload_2ereachAll_24s872_24s1133_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_heff_2eload_2ereachAll_24s872_24s1133_lam1, 1, 4, (V[]){v_ps_240, v_root_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eload_2etopNames_24s881_24s1140_lam0(V self, V *args); static Clo g_heff_2eload_2etopNames_24s881_24s1140_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2etopNames_24s881_24s1140_lam0, 1, 0};
V g_heff_2eload_2etopNames_24s881_24s1140_lam1(V self, V *args);
Clo g_heff_2eload_2etopNames_24s881_24s1140_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2etopNames_24s881_24s1140_entry, 3, 0};

V g_heff_2eload_2etopNames_24s881_24s1140(V v_d_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){v_d_240, ((V)&g_heff_2eload_2etopNames_24s881_24s1140_lam0_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2eload_2etopNames_24s881_24s1140_lam1, 1, 1, (V[]){v_k_242})});
}
V g_heff_2eload_2etopNames_24s881_24s1140_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2etopNames_24s881_24s1140(a[0], a[1], a[2]);
}
V g_heff_2eload_2etopNames_24s881_24s1140_lam0(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2eload_2etopNames_24s881_24s1140_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_t_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    v_t_2410 = v_x_249;
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_x_2411 = (g_prelude_2emap_24s725(v_t_2410));
  V f_ = v_k_242;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2epackagesOf_24s871_24s1132_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2epackagesOf_24s871_24s1132_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2epackagesOf_24s871_24s1132_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2epackagesOf_24s871_24s1132_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2epackagesOf_24s871_24s1132_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2epackagesOf_24s871_24s1132_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2epackagesOf_24s871_24s1132_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2epackagesOf_24s871_24s1132_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2epackagesOf_24s871_24s1132_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eload_2epackagesOf_24s871_24s1132_str9 = {{0x80000000u, K_STR, 0}, 30, 30, {112, 97, 99, 107, 97, 103, 101, 115, 32, 114, 101, 113, 117, 105, 114, 101, 32, 111, 110, 101, 32, 97, 110, 111, 116, 104, 101, 114, 58, 32}};
V g_heff_2eload_2epackagesOf_24s871_24s1132_lam0(V self, V *args);
V g_heff_2eload_2epackagesOf_24s871_24s1132_lam5(V self, V *args);
V g_heff_2eload_2epackagesOf_24s871_24s1132_lam4(V self, V *args);
V g_heff_2eload_2epackagesOf_24s871_24s1132_lam3(V self, V *args);
V g_heff_2eload_2epackagesOf_24s871_24s1132_lam2(V self, V *args);
V g_heff_2eload_2epackagesOf_24s871_24s1132_lam1(V self, V *args);
Clo g_heff_2eload_2epackagesOf_24s871_24s1132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2epackagesOf_24s871_24s1132_entry, 2, 0};

V g_heff_2eload_2epackagesOf_24s871_24s1132(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return heff_clo(g_heff_2eload_2epackagesOf_24s871_24s1132_lam0, 2, 1, (V[]){v_ps_240});
  }
  case TAG_Just: {
    V v_root_247 = heff_field(v_x2_241, 0);
    V v_c_248 = (g_heff_2eload_2ereachAll_24s872_24s1133(heff_dup(v_ps_240), heff_dup(v_root_247)));
    return heff_clo(g_heff_2eload_2epackagesOf_24s871_24s1132_lam1, 2, 3, (V[]){v_c_248, v_ps_240, heff_dup(v_root_247)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eload_2epackagesOf_24s871_24s1132_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eload_2epackagesOf_24s871_24s1132(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eload_2epackagesOf_24s871_24s1132_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec(7, shape_239_65_317_225_344_124_289, (V[]){((V)&g_heff_2eload_2epackagesOf_24s871_24s1132_str0), heff_get(heff_dup(v_ps_240), LBL_root), heff_get(v_ps_240, LBL_src), ((V)&g_heff_2eload_2epackagesOf_24s871_24s1132_str1), ((V)&g_heff_2eload_2epackagesOf_24s871_24s1132_str2), ((V)&g_heff_2eload_2epackagesOf_24s871_24s1132_str3), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = heff_tag(TAG_MkPair, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V f_ = v_k_243;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2epackagesOf_24s871_24s1132_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_root_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2415 = (g_prelude_2emap_24s722(heff_get(heff_dup(v_root_247), LBL_require)));
  V v_t_2416 = heff_rec(7, shape_239_65_317_225_344_124_289, (V[]){heff_get(heff_dup(v_root_247), LBL_module), heff_get(heff_dup(v_ps_240), LBL_root), heff_get(heff_dup(v_ps_240), LBL_src), ((V)&g_heff_2eload_2epackagesOf_24s871_24s1132_str4), ((V)&g_heff_2eload_2epackagesOf_24s871_24s1132_str5), heff_get(heff_dup(v_root_247), LBL_heff), v_t_2415});
  V v_t_2417 = (g_prelude_2econcatList(v_x_2413, v_x_2414));
  V v_t_2418 = (g_prelude_2econcatList(v_x_2412, v_t_2417));
  V v_t_2421;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_dup(heff_field(v_x_2411, 0));
    v_t_2421 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){v_t_2416, (g_heff_2eload_2enamedGo(v_t_2418, v_t_2421))});
  V v_t_2425;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_y_2424 = heff_dup(heff_field(v_x_2411, 1));
    v_t_2425 = v_y_2424;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2426 = (g_prelude_2emap_24s722(heff_get(heff_dup(v_root_247), LBL_require)));
  V v_t_2427 = heff_rec(7, shape_239_65_317_225_344_124_289, (V[]){heff_get(heff_dup(v_root_247), LBL_module), heff_get(heff_dup(v_ps_240), LBL_root), heff_get(v_ps_240, LBL_src), ((V)&g_heff_2eload_2epackagesOf_24s871_24s1132_str6), ((V)&g_heff_2eload_2epackagesOf_24s871_24s1132_str7), heff_get(heff_dup(v_root_247), LBL_heff), v_t_2426});
  V v_t_2430;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 2);
    v_t_2430 = v_x_2428;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2431 = heff_tag(TAG_Cons, 2, (V[]){heff_get(v_root_247, LBL_module), NTAG(TAG_Nil)});
  V v_t_2432 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){v_t_2427, v_t_2430}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2431; V r_ = (g_heff_2eload_2ecycleAmong(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2437;
  switch (heff_tag_of(v_t_2432)) {
  case TAG_Nothing: {
    v_t_2437 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_c_2433 = heff_field(v_t_2432, 0);
    heff_take_n(v_t_2432, 1ULL, 1);
    V v_t_2436;
    switch (heff_tag_of(v_c_2433)) {
    case TAG_Nil: {
      v_t_2436 = ((V)&g_heff_2eload_2epackagesOf_24s871_24s1132_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2434 = heff_field(v_c_2433, 0);
      V v_xs_2435 = heff_field(v_c_2433, 1);
      heff_take_n(v_c_2433, 3ULL, 2);
      v_t_2436 = ({ V a_0 = v_x_2434; V a_1 = v_xs_2435; V r_ = (g_prelude_2efoldl_24s726(a_0, a_1)); heff_drop(v_xs_2435); r_; });
      break;
    }
    default: heff_nomatch(v_c_2433);
    }
    v_t_2437 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2eload_2epackagesOf_24s871_24s1132_str9), v_t_2436), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2432);
  }
  V v_x_2438 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2422, (g_prelude_2econcatList(v_t_2425, v_t_2437))});
  V f_ = v_k_2410;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2epackagesOf_24s871_24s1132_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eload_2etopNames_24s881_24s1140(heff_get(heff_dup(v_ps_240), LBL_lib), v_hd_249, heff_clo(g_heff_2eload_2epackagesOf_24s871_24s1132_lam5, 1, 6, (V[]){v_root_247, v_ps_240, v_x_2413, v_x_2412, v_x_2411, v_k_2410})));
}
V g_heff_2eload_2epackagesOf_24s871_24s1132_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eload_2etopNames_24s881_24s1140(heff_get(heff_dup(v_ps_240), LBL_root), heff_dup(v_hd_249), heff_clo(g_heff_2eload_2epackagesOf_24s871_24s1132_lam4, 1, 6, (V[]){v_ps_240, v_hd_249, v_root_247, v_x_2412, v_x_2411, v_k_2410})));
}
V g_heff_2eload_2epackagesOf_24s871_24s1132_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eload_2etopNames_24s881_24s1140(heff_get(heff_dup(v_ps_240), LBL_src), heff_dup(v_hd_249), heff_clo(g_heff_2eload_2epackagesOf_24s871_24s1132_lam3, 1, 5, (V[]){v_ps_240, v_hd_249, v_root_247, v_x_2411, v_k_2410})));
}
V g_heff_2eload_2epackagesOf_24s871_24s1132_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo(g_heff_2eload_2epackagesOf_24s871_24s1132_lam2, 1, 4, (V[]){v_ps_240, v_hd_249, v_root_247, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eload_2ereadEvery_24s883_24s1142_lam0(V self, V *args); static Clo g_heff_2eload_2ereadEvery_24s883_24s1142_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ereadEvery_24s883_24s1142_lam0, 1, 0};
V g_heff_2eload_2ereadEvery_24s883_24s1142_lam2(V self, V *args);
V g_heff_2eload_2ereadEvery_24s883_24s1142_lam1(V self, V *args);
Clo g_heff_2eload_2ereadEvery_24s883_24s1142_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2ereadEvery_24s883_24s1142_entry, 3, 0};

V g_heff_2eload_2ereadEvery_24s883_24s1142(V v_x2_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_pl_243 = heff_field(v_x2_240, 0);
    V v_rest_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_ReadFile, 2, (V[]){heff_get(heff_dup(v_pl_243), LBL_path), ((V)&g_heff_2eload_2ereadEvery_24s883_24s1142_lam0_clo)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2eload_2ereadEvery_24s883_24s1142_lam1, 1, 4, (V[]){v_rest_244, v_p_241, v_pl_243, v_p_242})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eload_2ereadEvery_24s883_24s1142_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2ereadEvery_24s883_24s1142(a[0], a[1], a[2]);
}
V g_heff_2eload_2ereadEvery_24s883_24s1142_lam0(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2eload_2ereadEvery_24s883_24s1142_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_pl_243 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2415;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop(v_pl_243);
    v_x_2415 = v_x_2412;
    break;
  }
  case TAG_Just: {
    V v_s_2413 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    V v_t_2414 = heff_rec(4, shape_239_311_245_192, (V[]){heff_get(heff_dup(v_pl_243), LBL_path), v_s_2413, heff_dup(v_pl_243), heff_get(v_pl_243, LBL_module)});
    v_x_2415 = heff_tag(TAG_Cons, 2, (V[]){v_t_2414, v_x_2412});
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_p_242;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2ereadEvery_24s883_24s1142_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_pl_243 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2411 = heff_tr(heff_apply(((V)&g_heff_2eload_2ereadEvery_24s883_24s1142_clo), 1, (V[]){v_rest_244}));
  return heff_tail(v_c_2411, 2, (V[]){v_p_241, heff_clo(g_heff_2eload_2ereadEvery_24s883_24s1142_lam2, 1, 3, (V[]){v_x_2410, v_pl_243, v_p_242})});
}
V g_heff_2eload_2epartsNamed_24s884_24s1143_lam0(V self, V *args); static Clo g_heff_2eload_2epartsNamed_24s884_24s1143_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2epartsNamed_24s884_24s1143_lam0, 1, 0};
V g_heff_2eload_2epartsNamed_24s884_24s1143_lam2(V self, V *args);
V g_heff_2eload_2epartsNamed_24s884_24s1143_lam1(V self, V *args);
Clo g_heff_2eload_2epartsNamed_24s884_24s1143_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2epartsNamed_24s884_24s1143_entry, 5, 0};

V g_heff_2eload_2epartsNamed_24s884_24s1143(V v_ps_240, V v_d_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_d_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_Nothing)});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag_at(v_ru_24x3_242_24Cons, TAG_ReadDir, 2, (V[]){heff_dup(v_d_241), ((V)&g_heff_2eload_2epartsNamed_24s884_24s1143_lam0_clo)})});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2410}));
    return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2eload_2epartsNamed_24s884_24s1143_lam1, 1, 6, (V[]){v_p_244, v_x_245, v_ps_240, v_d_241, v_rest_246, v_p_243})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eload_2epartsNamed_24s884_24s1143_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2epartsNamed_24s884_24s1143(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eload_2epartsNamed_24s884_24s1143_lam0(V self, V *args) {
  V v_ns_247 = args[0];
  return v_ns_247;
}
V g_heff_2eload_2epartsNamed_24s884_24s1143_lam2(V self, V *args) {
  V v_n_2414 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eload_2esameButCase(v_n_2414, v_x_245));
}
V g_heff_2eload_2epartsNamed_24s884_24s1143_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    heff_drop(v_x_245);
    heff_drop(v_ps_240);
    heff_drop(v_d_241);
    heff_drop(v_rest_246);
    heff_drop(v_p_243);
    V f_ = v_p_244;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_ns_2413 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    V v_t_2415 = (g_prelude_2efilter(heff_clo(g_heff_2eload_2epartsNamed_24s884_24s1143_lam2, 1, 1, (V[]){heff_dup(v_x_245)}), v_ns_2413));
    V v_t_2416 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = heff_dup(v_d_241); V a_2 = heff_dup(v_x_245); V a_3 = v_t_2415; V r_ = (g_heff_2eload_2ecasesIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2415); r_; });
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      V v_st_2417 = heff_get(heff_dup(v_ps_240), LBL_style);
      V v_t_2418 = (g_std_2epath_2eparse(v_st_2417, v_d_241));
      V v_t_2419 = (g_std_2epath_2eparse(v_st_2417, v_x_245));
      V v_p_2420 = (g_std_2epath_2ejoin_2eonto_240(v_t_2418, v_t_2419));
      V v_t_2421 = ({ V a_0 = heff_get(heff_dup(v_p_2420), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2420), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2422 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2420), LBL_drive), heff_get(v_p_2420, LBL_absolute), v_t_2421});
      V v_t_2423 = ({ V a_0 = v_st_2417; V a_1 = v_t_2422; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); r_; });
      return (g_heff_2eload_2epartsNamed_24s884_24s1143(v_ps_240, v_t_2423, v_rest_246, v_p_243, v_p_244));
    }
    case TAG_Just: {
      V v_why_2424 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      heff_drop(v_x_245);
      heff_drop(v_ps_240);
      heff_drop(v_d_241);
      heff_drop(v_rest_246);
      heff_drop(v_p_243);
      V f_ = v_p_244;
      args[0] = heff_tag(TAG_Just, 1, (V[]){v_why_2424});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_x_2412);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eloadMany_24s882_24s1141_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eload_2eloadMany_24s882_24s1141_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {58, 32, 110, 111, 32, 109, 111, 100, 117, 108, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eload_2eloadMany_24s882_24s1141_str2 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 40, 108, 111, 111, 107, 101, 100, 32, 102, 111, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eloadMany_24s882_24s1141_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eloadMany_24s882_24s1141_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eload_2eloadMany_24s882_24s1141_str5 = {{0x80000000u, K_STR, 0}, 12, 12, {58, 32, 105, 109, 112, 111, 114, 116, 105, 110, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eload_2eloadMany_24s882_24s1141_str6 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 105, 115, 32, 97, 32, 99, 121, 99, 108, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eloadMany_24s882_24s1141_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eload_2eloadMany_24s882_24s1141_str8 = {{0x80000000u, K_STR, 0}, 9, 9, {58, 32, 109, 111, 100, 117, 108, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2eload_2eloadMany_24s882_24s1141_str9 = {{0x80000000u, K_STR, 0}, 24, 24, {32, 105, 115, 32, 109, 111, 114, 101, 32, 116, 104, 97, 110, 32, 111, 110, 101, 32, 102, 105, 108, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eload_2eloadMany_24s882_24s1141_str10 = {{0x80000000u, K_STR, 0}, 12, 12, {58, 32, 105, 109, 112, 111, 114, 116, 105, 110, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eload_2eloadMany_24s882_24s1141_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2eload_2eloadMany_24s882_24s1141_lam0(V self, V *args);
V g_heff_2eload_2eloadMany_24s882_24s1141_lam4(V self, V *args);
V g_heff_2eload_2eloadMany_24s882_24s1141_lam3(V self, V *args);
V g_heff_2eload_2eloadMany_24s882_24s1141_lam2(V self, V *args);
V g_heff_2eload_2eloadMany_24s882_24s1141_lam1(V self, V *args);
Clo g_heff_2eload_2eloadMany_24s882_24s1141_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eloadMany_24s882_24s1141_entry, 7, 0};

V g_heff_2eload_2eloadMany_24s882_24s1141(V v_ps_240, V v_pkgs_241, V v_stack_242, V v_from_243, V v_x6_244, V v_st_245, V v_rs_246) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_stack_242);
    heff_drop(v_from_243);
    return heff_clo(g_heff_2eload_2eloadMany_24s882_24s1141_lam0, 2, 2, (V[]){v_st_245, v_rs_246});
  }
  case TAG_Cons: {
    V v_w_249 = heff_field(v_x6_244, 0);
    V v_rest_2410 = heff_field(v_x6_244, 1);
    heff_take_n(v_x6_244, 3ULL, 2);
    V v_t_2411 = (g_heff_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_249)));
    V v_c_2412 = heff_tr(heff_apply(((V)&g_heff_2eload_2ereadEvery_24s883_24s1142_clo), 1, (V[]){v_t_2411}));
    return heff_clo(g_heff_2eload_2eloadMany_24s882_24s1141_lam1, 2, 9, (V[]){v_c_2412, v_ps_240, v_pkgs_241, v_from_243, v_w_249, v_st_245, v_stack_242, v_rest_2410, v_rs_246});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eload_2eloadMany_24s882_24s1141_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2eloadMany_24s882_24s1141(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eload_2eloadMany_24s882_24s1141_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_st_245 = heff_env(self)[0];
  V v_rs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_st_245, v_rs_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2eloadMany_24s882_24s1141_lam4(V self, V *args) {
  V v_x_2474 = args[0];
  V v_f_2426 = heff_env(self)[0];
  V v_w_249 = heff_env(self)[1];
  V v_rs_246 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_pkgs_241 = heff_env(self)[4];
  V v_stack_242 = heff_env(self)[5];
  V v_from_243 = heff_env(self)[6];
  V v_rest_2410 = heff_env(self)[7];
  V v_hd_2413 = heff_env(self)[8];
  V v_k_2414 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_st_2477;
  switch (heff_tag_of(v_x_2474)) {
  case TAG_MkPair: {
    V v_x_2475 = heff_dup(heff_field(v_x_2474, 0));
    v_st_2477 = v_x_2475;
    break;
  }
  default: heff_nomatch(v_x_2474);
  }
  V v_m_2478 = heff_get(heff_dup(v_f_2426), LBL_module);
  V v_renames_2481;
  switch (heff_tag_of(v_x_2474)) {
  case TAG_MkPair: {
    V v_y_2480 = heff_field(v_x_2474, 1);
    heff_take_n(v_x_2474, 2ULL, 2);
    v_renames_2481 = v_y_2480;
    break;
  }
  default: heff_nomatch(v_x_2474);
  }
  V v_t_2482 = heff_rec(4, shape_192_239_311_272, (V[]){heff_dup(v_m_2478), heff_get(heff_dup(v_f_2426), LBL_path), heff_get(heff_dup(v_f_2426), LBL_source), v_renames_2481});
  V v_t_2483 = heff_tag(TAG_Cons, 2, (V[]){v_t_2482, NTAG(TAG_Nil)});
  V v_t_2484 = (g_prelude_2econcatList(heff_get(heff_dup(v_st_2477), LBL_done), v_t_2483));
  V v_t_2485 = heff_tag(TAG_Cons, 2, (V[]){v_m_2478, heff_get(heff_dup(v_st_2477), LBL_doneMods)});
  V v_t_2486 = heff_rec(3, shape_71_72_89, (V[]){v_t_2484, v_t_2485, heff_get(v_st_2477, LBL_errors)});
  V v_m_2487 = heff_get(v_f_2426, LBL_module);
  V v_t_2488 = heff_strEq(heff_dup(v_w_249), heff_dup(v_m_2487));
  V v_t_2489;
  switch (heff_tag_of(v_t_2488)) {
  case TAG_True: {
    heff_drop(v_w_249);
    heff_drop(v_m_2487);
    v_t_2489 = v_rs_246;
    break;
  }
  case TAG_False: {
    v_t_2489 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_w_249, v_m_2487}), v_rs_246});
    break;
  }
  default: heff_nomatch(v_t_2488);
  }
  V v_t_2490 = (g_heff_2eload_2eloadMany_24s882_24s1141(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_rest_2410, v_t_2486, v_t_2489));
  return heff_tail(v_t_2490, 2, (V[]){v_hd_2413, v_k_2414});
}
V g_heff_2eload_2eloadMany_24s882_24s1141_lam3(V self, V *args) {
  V v_x_2453 = args[0];
  V v_f_2426 = heff_env(self)[0];
  V v_stack_242 = heff_env(self)[1];
  V v_others_2427 = heff_env(self)[2];
  V v_st_245 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_w_249 = heff_env(self)[6];
  V v_ps_240 = heff_env(self)[7];
  V v_pkgs_241 = heff_env(self)[8];
  V v_hd_2413 = heff_env(self)[9];
  V v_rs_246 = heff_env(self)[10];
  V v_rest_2410 = heff_env(self)[11];
  V v_k_2414 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V v_t_2454 = heff_tag(TAG_Cons, 2, (V[]){heff_get(heff_dup(v_f_2426), LBL_module), heff_dup(v_stack_242)});
  V v_t_2455 = (g_heff_2eimport_2eimportsOf(heff_get(heff_dup(v_f_2426), LBL_module), heff_get(heff_dup(v_f_2426), LBL_source)));
  V v_imps_2456 = heff_get(v_t_2455, LBL_imports);
  V v_t_2457 = (g_prelude_2emap_24s426(v_imps_2456));
  V v_t_2458 = (g_heff_2edriver_2enubStrD(v_t_2457));
  V v_t_2472;
  switch (heff_tag_of(v_x_2453)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_others_2427)) {
    case TAG_Nil: {
      heff_drop_tag(v_x_2415, 2);
      v_t_2472 = v_st_245;
      break;
    }
    case TAG_Cons: {
      V v_ru_24others_2427_24Cons = heff_take_reuse_n(v_others_2427, 0ULL, 2);
      V v_x2_2461 = (g_prelude_2emap_24s727(v_x_2415));
      V v_t_2464;
      switch (heff_tag_of(v_x2_2461)) {
      case TAG_Nil: {
        v_t_2464 = ((V)&g_heff_2eload_2eloadMany_24s882_24s1141_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2462 = heff_field(v_x2_2461, 0);
        V v_xs_2463 = heff_field(v_x2_2461, 1);
        heff_take_n(v_x2_2461, 3ULL, 2);
        v_t_2464 = ({ V a_0 = v_x_2462; V a_1 = v_xs_2463; V r_ = (g_prelude_2efoldl_24s728(a_0, a_1)); heff_drop(v_xs_2463); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2461);
      }
      V v_e_2465 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1141_str8), heff_strAppend(heff_dup(v_w_249), heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1141_str9), v_t_2464))));
      V v_t_2466 = heff_tag_at(v_ru_24others_2427_24Cons, TAG_Cons, 2, (V[]){v_e_2465, NTAG(TAG_Nil)});
      V v_t_2467 = (g_prelude_2econcatList(heff_get(heff_dup(v_st_245), LBL_errors), v_t_2466));
      v_t_2472 = heff_rec(3, shape_71_72_89, (V[]){heff_get(heff_dup(v_st_245), LBL_done), heff_get(v_st_245, LBL_doneMods), v_t_2467});
      break;
    }
    default: heff_nomatch(v_others_2427);
    }
    break;
  }
  case TAG_Just: {
    V v_why_2468 = heff_field(v_x_2453, 0);
    heff_take_n(v_x_2453, 1ULL, 1);
    heff_drop(v_others_2427);
    heff_drop_tag(v_x_2415, 2);
    V v_t_2469 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1141_str10), heff_strAppend(heff_dup(v_w_249), heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1141_str11), v_why_2468))));
    V v_t_2470 = heff_tag(TAG_Cons, 2, (V[]){v_t_2469, NTAG(TAG_Nil)});
    V v_t_2471 = (g_prelude_2econcatList(heff_get(heff_dup(v_st_245), LBL_errors), v_t_2470));
    v_t_2472 = heff_rec(3, shape_71_72_89, (V[]){heff_get(heff_dup(v_st_245), LBL_done), heff_get(v_st_245, LBL_doneMods), v_t_2471});
    break;
  }
  default: heff_nomatch(v_x_2453);
  }
  V v_c_2473 = (g_heff_2eload_2eloadMany_24s882_24s1141(heff_dup(v_ps_240), heff_dup(v_pkgs_241), v_t_2454, heff_get(heff_dup(v_f_2426), LBL_path), v_t_2458, v_t_2472, NTAG(TAG_Nil)));
  return heff_tail(v_c_2473, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2eload_2eloadMany_24s882_24s1141_lam4, 1, 10, (V[]){v_f_2426, v_w_249, v_rs_246, v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_rest_2410, v_hd_2413, v_k_2414})});
}
V g_heff_2eload_2eloadMany_24s882_24s1141_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_pkgs_241 = heff_env(self)[1];
  V v_from_243 = heff_env(self)[2];
  V v_w_249 = heff_env(self)[3];
  V v_st_245 = heff_env(self)[4];
  V v_stack_242 = heff_env(self)[5];
  V v_rest_2410 = heff_env(self)[6];
  V v_rs_246 = heff_env(self)[7];
  V v_hd_2413 = heff_env(self)[8];
  V v_k_2414 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nil: {
    V v_places_2416 = (g_heff_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_249)));
    V v_x2_2417 = (g_prelude_2emap_24s727(v_places_2416));
    V v_t_2420;
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2eload_2eloadMany_24s882_24s1141_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_xs_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      v_t_2420 = ({ V a_0 = v_x_2418; V a_1 = v_xs_2419; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2417);
    }
    V v_e_2421 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1141_str1), heff_strAppend(v_w_249, heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1141_str2), heff_strAppend(v_t_2420, ((V)&g_heff_2eload_2eloadMany_24s882_24s1141_str3))))));
    V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){v_e_2421, NTAG(TAG_Nil)});
    V v_t_2423 = (g_prelude_2econcatList(heff_get(heff_dup(v_st_245), LBL_errors), v_t_2422));
    V v_t_2424 = heff_rec(3, shape_71_72_89, (V[]){heff_get(heff_dup(v_st_245), LBL_done), heff_get(v_st_245, LBL_doneMods), v_t_2423});
    V v_t_2425 = (g_heff_2eload_2eloadMany_24s882_24s1141(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_rest_2410, v_t_2424, v_rs_246));
    return heff_tail(v_t_2425, 2, (V[]){v_hd_2413, v_k_2414});
  }
  case TAG_Cons: {
    V v_f_2426 = heff_dup(heff_field(v_x_2415, 0));
    V v_others_2427 = heff_dup(heff_field(v_x_2415, 1));
    V v_t_2428 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_f_2426), LBL_module)}));
    V v_t_2429 = ({ V a_0 = v_t_2428; V b_1 = heff_get(heff_dup(v_st_245), LBL_doneMods); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      heff_drop_tag(v_x_2415, 2);
      heff_drop(v_others_2427);
      V v_m_2430 = heff_get(v_f_2426, LBL_module);
      V v_t_2431 = heff_strEq(heff_dup(v_w_249), heff_dup(v_m_2430));
      V v_t_2432;
      switch (heff_tag_of(v_t_2431)) {
      case TAG_True: {
        heff_drop(v_w_249);
        heff_drop(v_m_2430);
        v_t_2432 = v_rs_246;
        break;
      }
      case TAG_False: {
        v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_w_249, v_m_2430}), v_rs_246});
        break;
      }
      default: heff_nomatch(v_t_2431);
      }
      V v_t_2433 = (g_heff_2eload_2eloadMany_24s882_24s1141(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_rest_2410, v_st_245, v_t_2432));
      return heff_tail(v_t_2433, 2, (V[]){v_hd_2413, v_k_2414});
    }
    case TAG_False: {
      V v_t_2434 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_f_2426), LBL_module)}));
      V v_t_2435 = (g_prelude_2eany(v_t_2434, v_stack_242));
      switch (heff_tag_of(v_t_2435)) {
      case TAG_True: {
        heff_drop_tag(v_x_2415, 2);
        heff_drop(v_others_2427);
        V v_m_2436 = heff_get(heff_dup(v_f_2426), LBL_module);
        V v_t_2437 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_stack_242)));
        V v_t_2438 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_m_2436), NTAG(TAG_Nil)});
        V v_x2_2439 = (g_prelude_2econcatList(v_t_2437, v_t_2438));
        V v_t_2442;
        switch (heff_tag_of(v_x2_2439)) {
        case TAG_Nil: {
          v_t_2442 = ((V)&g_heff_2eload_2eloadMany_24s882_24s1141_str4);
          break;
        }
        case TAG_Cons: {
          V v_x_2440 = heff_field(v_x2_2439, 0);
          V v_xs_2441 = heff_field(v_x2_2439, 1);
          heff_take_n(v_x2_2439, 3ULL, 2);
          v_t_2442 = ({ V a_0 = v_x_2440; V a_1 = v_xs_2441; V r_ = (g_prelude_2efoldl_24s726(a_0, a_1)); heff_drop(v_xs_2441); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2439);
        }
        V v_e_2443 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1141_str5), heff_strAppend(v_m_2436, heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1141_str6), v_t_2442))));
        V v_t_2444 = heff_tag(TAG_Cons, 2, (V[]){v_e_2443, NTAG(TAG_Nil)});
        V v_t_2445 = (g_prelude_2econcatList(heff_get(heff_dup(v_st_245), LBL_errors), v_t_2444));
        V v_t_2446 = heff_rec(3, shape_71_72_89, (V[]){heff_get(heff_dup(v_st_245), LBL_done), heff_get(v_st_245, LBL_doneMods), v_t_2445});
        V v_m_2447 = heff_get(v_f_2426, LBL_module);
        V v_t_2448 = heff_strEq(heff_dup(v_w_249), heff_dup(v_m_2447));
        V v_t_2449;
        switch (heff_tag_of(v_t_2448)) {
        case TAG_True: {
          heff_drop(v_w_249);
          heff_drop(v_m_2447);
          v_t_2449 = v_rs_246;
          break;
        }
        case TAG_False: {
          v_t_2449 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_w_249, v_m_2447}), v_rs_246});
          break;
        }
        default: heff_nomatch(v_t_2448);
        }
        V v_t_2450 = (g_heff_2eload_2eloadMany_24s882_24s1141(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_rest_2410, v_t_2446, v_t_2449));
        return heff_tail(v_t_2450, 2, (V[]){v_hd_2413, v_k_2414});
      }
      case TAG_False: {
        V v_t_2451 = heff_get(heff_get(heff_dup(v_f_2426), LBL_place), LBL_base);
        V v_t_2452 = heff_get(heff_get(heff_dup(v_f_2426), LBL_place), LBL_parts);
        return (g_heff_2eload_2epartsNamed_24s884_24s1143(heff_dup(v_ps_240), v_t_2451, v_t_2452, heff_dup(v_hd_2413), heff_clo(g_heff_2eload_2eloadMany_24s882_24s1141_lam3, 1, 13, (V[]){v_f_2426, v_stack_242, v_others_2427, v_st_245, v_x_2415, v_from_243, v_w_249, v_ps_240, v_pkgs_241, v_hd_2413, v_rs_246, v_rest_2410, v_k_2414})));
      }
      default: return heff_nomatch(v_t_2435);
      }
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2eload_2eloadMany_24s882_24s1141_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_pkgs_241 = heff_env(self)[2];
  V v_from_243 = heff_env(self)[3];
  V v_w_249 = heff_env(self)[4];
  V v_st_245 = heff_env(self)[5];
  V v_stack_242 = heff_env(self)[6];
  V v_rest_2410 = heff_env(self)[7];
  V v_rs_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2eload_2eloadMany_24s882_24s1141_lam2, 1, 10, (V[]){v_ps_240, v_pkgs_241, v_from_243, v_w_249, v_st_245, v_stack_242, v_rest_2410, v_rs_246, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eload_2eloadProgramWith_24s866_24s1127_str0 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 110, 110, 111, 116, 32, 114, 101, 97, 100, 32}};
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam4(V self, V *args); static Clo g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam4, 1, 0};
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam6(V self, V *args);
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam5(V self, V *args);
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam3(V self, V *args);
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam2(V self, V *args);
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam1(V self, V *args);
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam0(V self, V *args);
Clo g_heff_2eload_2eloadProgramWith_24s866_24s1127_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eloadProgramWith_24s866_24s1127_entry, 2, 0};

V g_heff_2eload_2eloadProgramWith_24s866_24s1127(V v_h_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2eload_2epathsFor_24s867_24s1128(v_h_240, heff_dup(v_file_241)));
  return heff_clo(g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam0, 2, 2, (V[]){v_c_242, v_file_241});
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2eloadProgramWith_24s866_24s1127(a[0], a[1]);
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam4(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_src_2424 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2439;
  switch (heff_tag_of(v_x_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_dup(heff_field(v_x_2436, 0));
    v_st_2439 = v_x_2437;
    break;
  }
  default: heff_nomatch(v_x_2436);
  }
  V v_m_2440 = (g_heff_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_renames_2443;
  switch (heff_tag_of(v_x_2436)) {
  case TAG_MkPair: {
    V v_y_2442 = heff_field(v_x_2436, 1);
    heff_take_n(v_x_2436, 2ULL, 2);
    v_renames_2443 = v_y_2442;
    break;
  }
  default: heff_nomatch(v_x_2436);
  }
  V v_t_2444 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(4, shape_192_239_311_272, (V[]){heff_dup(v_m_2440), v_file_241, v_src_2424, v_renames_2443}), NTAG(TAG_Nil)});
  V v_t_2445 = (g_prelude_2econcatList(heff_get(heff_dup(v_st_2439), LBL_done), v_t_2444));
  V v_t_2446 = heff_tag(TAG_Cons, 2, (V[]){v_m_2440, heff_get(heff_dup(v_st_2439), LBL_doneMods)});
  V v_t_2447 = heff_rec(3, shape_71_72_89, (V[]){v_t_2445, v_t_2446, heff_get(v_st_2439, LBL_errors)});
  V v_x_2448 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2447; V r_ = (g_heff_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
  V f_ = v_k_244;
  args[0] = v_x_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2eload_2eloadProgramWith_24s866_24s1127_str0), v_file_241), NTAG(TAG_Nil)});
    V v_t_2421 = (g_prelude_2econcatList(NTAG(TAG_Nil), v_t_2420));
    V v_t_2422 = heff_rec(3, shape_71_72_89, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2421});
    V v_x_2423 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2422; V r_ = (g_heff_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
    V f_ = v_k_244;
    args[0] = v_x_2423;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2424 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    V v_t_2427;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_dup(heff_field(v_x_2413, 0));
      v_t_2427 = v_x_2425;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_t_2428 = (g_heff_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
    V v_t_2429 = heff_tag(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
    V v_t_2430 = (g_heff_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
    V v_t_2431 = (g_heff_2eimport_2eimportsOf(v_t_2430, heff_dup(v_src_2424)));
    V v_imps_2432 = heff_get(v_t_2431, LBL_imports);
    V v_t_2433 = (g_prelude_2emap_24s426(v_imps_2432));
    V v_t_2434 = (g_heff_2edriver_2enubStrD(v_t_2433));
    V v_c_2435 = (g_heff_2eload_2eloadMany_24s882_24s1141(heff_dup(v_x_245), v_t_2427, v_t_2429, heff_dup(v_file_241), v_t_2434, heff_dup(g_heff_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
    return heff_tail(v_c_2435, 2, (V[]){v_hd_243, heff_clo(g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam6, 1, 6, (V[]){v_x_245, v_file_241, v_src_2424, v_x_247, v_x_2413, v_k_244})});
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){heff_dup(v_file_241), ((V)&g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam4_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2418, heff_clo(g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam5, 1, 6, (V[]){v_file_241, v_x_245, v_x_247, v_x_2413, v_k_244, v_hd_243})});
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_248 = heff_dup(heff_field(v_x_247, 0));
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      heff_take_n(v_x11_248, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      v_t_2411 = heff_tag_at(v_ru_24x11_248_24Right, TAG_Just, 1, (V[]){v_p_2410});
      break;
    }
    default: heff_nomatch(v_x11_248);
    }
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_c_2412 = ({ V a_0 = heff_dup(v_x_245); V a_1 = v_t_2411; V r_ = (g_heff_2eload_2epackagesOf_24s871_24s1132(a_0, a_1)); heff_drop(v_t_2411); r_; });
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam3, 1, 5, (V[]){v_file_241, v_hd_243, v_x_245, v_x_247, v_k_244})});
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = (g_heff_2eload_2ereadPackageAt_24s870_24s1131(heff_dup(v_x_245)));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_file_241, v_k_244})});
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_heff_2eload_2eloadProgramWith_24s866_24s1127_lam1, 1, 3, (V[]){v_hd_243, v_file_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}

static V g_heff_2eload_2eloadProgram_24s865_24s1126_val;
static int g_heff_2eload_2eloadProgram_24s865_24s1126_st;
static V g_heff_2eload_2eloadProgram_24s865_24s1126_init(void) {
  return ((V)&g_heff_2eload_2eloadProgramWith_24s866_24s1127_clo);
}
V g_heff_2eload_2eloadProgram_24s865_24s1126_get(void) {
  if (g_heff_2eload_2eloadProgram_24s865_24s1126_st == 2) return g_heff_2eload_2eloadProgram_24s865_24s1126_val;
  if (g_heff_2eload_2eloadProgram_24s865_24s1126_st == 1) heff_fail("defined by itself");
  g_heff_2eload_2eloadProgram_24s865_24s1126_st = 1;
  g_heff_2eload_2eloadProgram_24s865_24s1126_val = heff_tr(g_heff_2eload_2eloadProgram_24s865_24s1126_init());
  g_heff_2eload_2eloadProgram_24s865_24s1126_st = 2;
  return g_heff_2eload_2eloadProgram_24s865_24s1126_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eloadMany_24s882_24s1226_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eload_2eloadMany_24s882_24s1226_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {58, 32, 110, 111, 32, 109, 111, 100, 117, 108, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eload_2eloadMany_24s882_24s1226_str2 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 40, 108, 111, 111, 107, 101, 100, 32, 102, 111, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eloadMany_24s882_24s1226_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eloadMany_24s882_24s1226_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eload_2eloadMany_24s882_24s1226_str5 = {{0x80000000u, K_STR, 0}, 12, 12, {58, 32, 105, 109, 112, 111, 114, 116, 105, 110, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eload_2eloadMany_24s882_24s1226_str6 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 105, 115, 32, 97, 32, 99, 121, 99, 108, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eload_2eloadMany_24s882_24s1226_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eload_2eloadMany_24s882_24s1226_str8 = {{0x80000000u, K_STR, 0}, 9, 9, {58, 32, 109, 111, 100, 117, 108, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2eload_2eloadMany_24s882_24s1226_str9 = {{0x80000000u, K_STR, 0}, 24, 24, {32, 105, 115, 32, 109, 111, 114, 101, 32, 116, 104, 97, 110, 32, 111, 110, 101, 32, 102, 105, 108, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eload_2eloadMany_24s882_24s1226_str10 = {{0x80000000u, K_STR, 0}, 12, 12, {58, 32, 105, 109, 112, 111, 114, 116, 105, 110, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eload_2eloadMany_24s882_24s1226_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2eload_2eloadMany_24s882_24s1226_lam0(V self, V *args);
V g_heff_2eload_2eloadMany_24s882_24s1226_lam4(V self, V *args);
V g_heff_2eload_2eloadMany_24s882_24s1226_lam3(V self, V *args);
V g_heff_2eload_2eloadMany_24s882_24s1226_lam2(V self, V *args);
V g_heff_2eload_2eloadMany_24s882_24s1226_lam1(V self, V *args);
Clo g_heff_2eload_2eloadMany_24s882_24s1226_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eloadMany_24s882_24s1226_entry, 8, 0};

V g_heff_2eload_2eloadMany_24s882_24s1226(V v_read_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_x6_245, V v_st_246, V v_rs_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    return heff_clo(g_heff_2eload_2eloadMany_24s882_24s1226_lam0, 2, 2, (V[]){v_st_246, v_rs_247});
  }
  case TAG_Cons: {
    V v_w_2410 = heff_field(v_x6_245, 0);
    V v_rest_2411 = heff_field(v_x6_245, 1);
    heff_take_n(v_x6_245, 3ULL, 2);
    V v_t_2412 = (g_heff_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2410)));
    V v_c_2413 = (g_heff_2eload_2ereadEvery_24s883(heff_dup(v_read_240), v_t_2412));
    return heff_clo(g_heff_2eload_2eloadMany_24s882_24s1226_lam1, 2, 10, (V[]){v_c_2413, v_ps_241, v_pkgs_242, v_from_244, v_w_2410, v_st_246, v_read_240, v_stack_243, v_rest_2411, v_rs_247});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eload_2eloadMany_24s882_24s1226_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2eloadMany_24s882_24s1226(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eload_2eloadMany_24s882_24s1226_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_st_246 = heff_env(self)[0];
  V v_rs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_st_246, v_rs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2eloadMany_24s882_24s1226_lam4(V self, V *args) {
  V v_x_2475 = args[0];
  V v_f_2427 = heff_env(self)[0];
  V v_w_2410 = heff_env(self)[1];
  V v_rs_247 = heff_env(self)[2];
  V v_read_240 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_pkgs_242 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_from_244 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_hd_2414 = heff_env(self)[9];
  V v_k_2415 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_st_2478;
  switch (heff_tag_of(v_x_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_dup(heff_field(v_x_2475, 0));
    v_st_2478 = v_x_2476;
    break;
  }
  default: heff_nomatch(v_x_2475);
  }
  V v_m_2479 = heff_get(heff_dup(v_f_2427), LBL_module);
  V v_renames_2482;
  switch (heff_tag_of(v_x_2475)) {
  case TAG_MkPair: {
    V v_y_2481 = heff_field(v_x_2475, 1);
    heff_take_n(v_x_2475, 2ULL, 2);
    v_renames_2482 = v_y_2481;
    break;
  }
  default: heff_nomatch(v_x_2475);
  }
  V v_t_2483 = heff_rec(4, shape_192_239_311_272, (V[]){heff_dup(v_m_2479), heff_get(heff_dup(v_f_2427), LBL_path), heff_get(heff_dup(v_f_2427), LBL_source), v_renames_2482});
  V v_t_2484 = heff_tag(TAG_Cons, 2, (V[]){v_t_2483, NTAG(TAG_Nil)});
  V v_t_2485 = (g_prelude_2econcatList(heff_get(heff_dup(v_st_2478), LBL_done), v_t_2484));
  V v_t_2486 = heff_tag(TAG_Cons, 2, (V[]){v_m_2479, heff_get(heff_dup(v_st_2478), LBL_doneMods)});
  V v_t_2487 = heff_rec(3, shape_71_72_89, (V[]){v_t_2485, v_t_2486, heff_get(v_st_2478, LBL_errors)});
  V v_m_2488 = heff_get(v_f_2427, LBL_module);
  V v_t_2489 = heff_strEq(heff_dup(v_w_2410), heff_dup(v_m_2488));
  V v_t_2490;
  switch (heff_tag_of(v_t_2489)) {
  case TAG_True: {
    heff_drop(v_w_2410);
    heff_drop(v_m_2488);
    v_t_2490 = v_rs_247;
    break;
  }
  case TAG_False: {
    v_t_2490 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2488}), v_rs_247});
    break;
  }
  default: heff_nomatch(v_t_2489);
  }
  V v_t_2491 = (g_heff_2eload_2eloadMany_24s882_24s1226(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2487, v_t_2490));
  return heff_tail(v_t_2491, 2, (V[]){v_hd_2414, v_k_2415});
}
V g_heff_2eload_2eloadMany_24s882_24s1226_lam3(V self, V *args) {
  V v_x_2454 = args[0];
  V v_f_2427 = heff_env(self)[0];
  V v_stack_243 = heff_env(self)[1];
  V v_others_2428 = heff_env(self)[2];
  V v_st_246 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_from_244 = heff_env(self)[5];
  V v_w_2410 = heff_env(self)[6];
  V v_read_240 = heff_env(self)[7];
  V v_ps_241 = heff_env(self)[8];
  V v_pkgs_242 = heff_env(self)[9];
  V v_hd_2414 = heff_env(self)[10];
  V v_rs_247 = heff_env(self)[11];
  V v_rest_2411 = heff_env(self)[12];
  V v_k_2415 = heff_env(self)[13];
  heff_clo_take(self, 14);
  V v_t_2455 = heff_tag(TAG_Cons, 2, (V[]){heff_get(heff_dup(v_f_2427), LBL_module), heff_dup(v_stack_243)});
  V v_t_2456 = (g_heff_2eimport_2eimportsOf(heff_get(heff_dup(v_f_2427), LBL_module), heff_get(heff_dup(v_f_2427), LBL_source)));
  V v_imps_2457 = heff_get(v_t_2456, LBL_imports);
  V v_t_2458 = (g_prelude_2emap_24s426(v_imps_2457));
  V v_t_2459 = (g_heff_2edriver_2enubStrD(v_t_2458));
  V v_t_2473;
  switch (heff_tag_of(v_x_2454)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_others_2428)) {
    case TAG_Nil: {
      heff_drop_tag(v_x_2416, 2);
      v_t_2473 = v_st_246;
      break;
    }
    case TAG_Cons: {
      V v_ru_24others_2428_24Cons = heff_take_reuse_n(v_others_2428, 0ULL, 2);
      V v_x2_2462 = (g_prelude_2emap_24s727(v_x_2416));
      V v_t_2465;
      switch (heff_tag_of(v_x2_2462)) {
      case TAG_Nil: {
        v_t_2465 = ((V)&g_heff_2eload_2eloadMany_24s882_24s1226_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2463 = heff_field(v_x2_2462, 0);
        V v_xs_2464 = heff_field(v_x2_2462, 1);
        heff_take_n(v_x2_2462, 3ULL, 2);
        v_t_2465 = ({ V a_0 = v_x_2463; V a_1 = v_xs_2464; V r_ = (g_prelude_2efoldl_24s728(a_0, a_1)); heff_drop(v_xs_2464); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2462);
      }
      V v_e_2466 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1226_str8), heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1226_str9), v_t_2465))));
      V v_t_2467 = heff_tag_at(v_ru_24others_2428_24Cons, TAG_Cons, 2, (V[]){v_e_2466, NTAG(TAG_Nil)});
      V v_t_2468 = (g_prelude_2econcatList(heff_get(heff_dup(v_st_246), LBL_errors), v_t_2467));
      v_t_2473 = heff_rec(3, shape_71_72_89, (V[]){heff_get(heff_dup(v_st_246), LBL_done), heff_get(v_st_246, LBL_doneMods), v_t_2468});
      break;
    }
    default: heff_nomatch(v_others_2428);
    }
    break;
  }
  case TAG_Just: {
    V v_why_2469 = heff_field(v_x_2454, 0);
    heff_take_n(v_x_2454, 1ULL, 1);
    heff_drop(v_others_2428);
    heff_drop_tag(v_x_2416, 2);
    V v_t_2470 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1226_str10), heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1226_str11), v_why_2469))));
    V v_t_2471 = heff_tag(TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
    V v_t_2472 = (g_prelude_2econcatList(heff_get(heff_dup(v_st_246), LBL_errors), v_t_2471));
    v_t_2473 = heff_rec(3, shape_71_72_89, (V[]){heff_get(heff_dup(v_st_246), LBL_done), heff_get(v_st_246, LBL_doneMods), v_t_2472});
    break;
  }
  default: heff_nomatch(v_x_2454);
  }
  V v_c_2474 = (g_heff_2eload_2eloadMany_24s882_24s1226(heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), v_t_2455, heff_get(heff_dup(v_f_2427), LBL_path), v_t_2459, v_t_2473, NTAG(TAG_Nil)));
  return heff_tail(v_c_2474, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2eload_2eloadMany_24s882_24s1226_lam4, 1, 11, (V[]){v_f_2427, v_w_2410, v_rs_247, v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_hd_2414, v_k_2415})});
}
V g_heff_2eload_2eloadMany_24s882_24s1226_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_rs_247 = heff_env(self)[8];
  V v_hd_2414 = heff_env(self)[9];
  V v_k_2415 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nil: {
    V v_places_2417 = (g_heff_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2410)));
    V v_x2_2418 = (g_prelude_2emap_24s727(v_places_2417));
    V v_t_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2eload_2eloadMany_24s882_24s1226_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_t_2421 = ({ V a_0 = v_x_2419; V a_1 = v_xs_2420; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_e_2422 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1226_str1), heff_strAppend(v_w_2410, heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1226_str2), heff_strAppend(v_t_2421, ((V)&g_heff_2eload_2eloadMany_24s882_24s1226_str3))))));
    V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){v_e_2422, NTAG(TAG_Nil)});
    V v_t_2424 = (g_prelude_2econcatList(heff_get(heff_dup(v_st_246), LBL_errors), v_t_2423));
    V v_t_2425 = heff_rec(3, shape_71_72_89, (V[]){heff_get(heff_dup(v_st_246), LBL_done), heff_get(v_st_246, LBL_doneMods), v_t_2424});
    V v_t_2426 = (g_heff_2eload_2eloadMany_24s882_24s1226(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2425, v_rs_247));
    return heff_tail(v_t_2426, 2, (V[]){v_hd_2414, v_k_2415});
  }
  case TAG_Cons: {
    V v_f_2427 = heff_dup(heff_field(v_x_2416, 0));
    V v_others_2428 = heff_dup(heff_field(v_x_2416, 1));
    V v_t_2429 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_f_2427), LBL_module)}));
    V v_t_2430 = ({ V a_0 = v_t_2429; V b_1 = heff_get(heff_dup(v_st_246), LBL_doneMods); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2430)) {
    case TAG_True: {
      heff_drop_tag(v_x_2416, 2);
      heff_drop(v_others_2428);
      V v_m_2431 = heff_get(v_f_2427, LBL_module);
      V v_t_2432 = heff_strEq(heff_dup(v_w_2410), heff_dup(v_m_2431));
      V v_t_2433;
      switch (heff_tag_of(v_t_2432)) {
      case TAG_True: {
        heff_drop(v_w_2410);
        heff_drop(v_m_2431);
        v_t_2433 = v_rs_247;
        break;
      }
      case TAG_False: {
        v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2431}), v_rs_247});
        break;
      }
      default: heff_nomatch(v_t_2432);
      }
      V v_t_2434 = (g_heff_2eload_2eloadMany_24s882_24s1226(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_st_246, v_t_2433));
      return heff_tail(v_t_2434, 2, (V[]){v_hd_2414, v_k_2415});
    }
    case TAG_False: {
      V v_t_2435 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_f_2427), LBL_module)}));
      V v_t_2436 = (g_prelude_2eany(v_t_2435, v_stack_243));
      switch (heff_tag_of(v_t_2436)) {
      case TAG_True: {
        heff_drop_tag(v_x_2416, 2);
        heff_drop(v_others_2428);
        V v_m_2437 = heff_get(heff_dup(v_f_2427), LBL_module);
        V v_t_2438 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2439 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_m_2437), NTAG(TAG_Nil)});
        V v_x2_2440 = (g_prelude_2econcatList(v_t_2438, v_t_2439));
        V v_t_2443;
        switch (heff_tag_of(v_x2_2440)) {
        case TAG_Nil: {
          v_t_2443 = ((V)&g_heff_2eload_2eloadMany_24s882_24s1226_str4);
          break;
        }
        case TAG_Cons: {
          V v_x_2441 = heff_field(v_x2_2440, 0);
          V v_xs_2442 = heff_field(v_x2_2440, 1);
          heff_take_n(v_x2_2440, 3ULL, 2);
          v_t_2443 = ({ V a_0 = v_x_2441; V a_1 = v_xs_2442; V r_ = (g_prelude_2efoldl_24s726(a_0, a_1)); heff_drop(v_xs_2442); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2440);
        }
        V v_e_2444 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1226_str5), heff_strAppend(v_m_2437, heff_strAppend(((V)&g_heff_2eload_2eloadMany_24s882_24s1226_str6), v_t_2443))));
        V v_t_2445 = heff_tag(TAG_Cons, 2, (V[]){v_e_2444, NTAG(TAG_Nil)});
        V v_t_2446 = (g_prelude_2econcatList(heff_get(heff_dup(v_st_246), LBL_errors), v_t_2445));
        V v_t_2447 = heff_rec(3, shape_71_72_89, (V[]){heff_get(heff_dup(v_st_246), LBL_done), heff_get(v_st_246, LBL_doneMods), v_t_2446});
        V v_m_2448 = heff_get(v_f_2427, LBL_module);
        V v_t_2449 = heff_strEq(heff_dup(v_w_2410), heff_dup(v_m_2448));
        V v_t_2450;
        switch (heff_tag_of(v_t_2449)) {
        case TAG_True: {
          heff_drop(v_w_2410);
          heff_drop(v_m_2448);
          v_t_2450 = v_rs_247;
          break;
        }
        case TAG_False: {
          v_t_2450 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2448}), v_rs_247});
          break;
        }
        default: heff_nomatch(v_t_2449);
        }
        V v_t_2451 = (g_heff_2eload_2eloadMany_24s882_24s1226(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2447, v_t_2450));
        return heff_tail(v_t_2451, 2, (V[]){v_hd_2414, v_k_2415});
      }
      case TAG_False: {
        V v_t_2452 = heff_get(heff_get(heff_dup(v_f_2427), LBL_place), LBL_base);
        V v_t_2453 = heff_get(heff_get(heff_dup(v_f_2427), LBL_place), LBL_parts);
        return (g_heff_2eload_2epartsNamed_24s884_24s1143(heff_dup(v_ps_241), v_t_2452, v_t_2453, heff_dup(v_hd_2414), heff_clo(g_heff_2eload_2eloadMany_24s882_24s1226_lam3, 1, 14, (V[]){v_f_2427, v_stack_243, v_others_2428, v_st_246, v_x_2416, v_from_244, v_w_2410, v_read_240, v_ps_241, v_pkgs_242, v_hd_2414, v_rs_247, v_rest_2411, v_k_2415})));
      }
      default: return heff_nomatch(v_t_2436);
      }
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2eload_2eloadMany_24s882_24s1226_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_pkgs_242 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_st_246 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo(g_heff_2eload_2eloadMany_24s882_24s1226_lam2, 1, 11, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2410, v_st_246, v_read_240, v_stack_243, v_rest_2411, v_rs_247, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eload_2eloadProgramWith_24s866_24s1225_str0 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 110, 110, 111, 116, 32, 114, 101, 97, 100, 32}};
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam5(V self, V *args);
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam4(V self, V *args);
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam3(V self, V *args);
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam2(V self, V *args);
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam1(V self, V *args);
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam0(V self, V *args);
Clo g_heff_2eload_2eloadProgramWith_24s866_24s1225_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eload_2eloadProgramWith_24s866_24s1225_entry, 3, 0};

V g_heff_2eload_2eloadProgramWith_24s866_24s1225(V v_read_240, V v_h_241, V v_file_242) {
top: ;
  V v_c_243 = (g_heff_2eload_2epathsFor_24s867_24s1128(v_h_241, heff_dup(v_file_242)));
  return heff_clo(g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam0, 2, 3, (V[]){v_c_243, v_read_240, v_file_242});
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_entry(V self, V *a) {
  (void)self;
  return g_heff_2eload_2eloadProgramWith_24s866_24s1225(a[0], a[1], a[2]);
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_src_2421 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2436;
  switch (heff_tag_of(v_x_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_dup(heff_field(v_x_2433, 0));
    v_st_2436 = v_x_2434;
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  V v_m_2437 = (g_heff_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_renames_2440;
  switch (heff_tag_of(v_x_2433)) {
  case TAG_MkPair: {
    V v_y_2439 = heff_field(v_x_2433, 1);
    heff_take_n(v_x_2433, 2ULL, 2);
    v_renames_2440 = v_y_2439;
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  V v_t_2441 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(4, shape_192_239_311_272, (V[]){heff_dup(v_m_2437), v_file_242, v_src_2421, v_renames_2440}), NTAG(TAG_Nil)});
  V v_t_2442 = (g_prelude_2econcatList(heff_get(heff_dup(v_st_2436), LBL_done), v_t_2441));
  V v_t_2443 = heff_tag(TAG_Cons, 2, (V[]){v_m_2437, heff_get(heff_dup(v_st_2436), LBL_doneMods)});
  V v_t_2444 = heff_rec(3, shape_71_72_89, (V[]){v_t_2442, v_t_2443, heff_get(v_st_2436, LBL_errors)});
  V v_x_2445 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2444; V r_ = (g_heff_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
  V f_ = v_k_245;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_hd_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_read_240);
    heff_drop(v_hd_244);
    V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2eload_2eloadProgramWith_24s866_24s1225_str0), v_file_242), NTAG(TAG_Nil)});
    V v_t_2418 = (g_prelude_2econcatList(NTAG(TAG_Nil), v_t_2417));
    V v_t_2419 = heff_rec(3, shape_71_72_89, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2418});
    V v_x_2420 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2419; V r_ = (g_heff_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
    V f_ = v_k_245;
    args[0] = v_x_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2421 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_dup(heff_field(v_x_2414, 0));
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_t_2425 = (g_heff_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
    V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_heff_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
    V v_t_2428 = (g_heff_2eimport_2eimportsOf(v_t_2427, heff_dup(v_src_2421)));
    V v_imps_2429 = heff_get(v_t_2428, LBL_imports);
    V v_t_2430 = (g_prelude_2emap_24s426(v_imps_2429));
    V v_t_2431 = (g_heff_2edriver_2enubStrD(v_t_2430));
    V v_c_2432 = (g_heff_2eload_2eloadMany_24s882_24s1226(v_read_240, heff_dup(v_x_246), v_t_2424, v_t_2426, heff_dup(v_file_242), v_t_2431, heff_dup(g_heff_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
    return heff_tail(v_c_2432, 2, (V[]){v_hd_244, heff_clo(g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam5, 1, 6, (V[]){v_x_246, v_file_242, v_src_2421, v_x_248, v_x_2414, v_k_245})});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415 = heff_tr(heff_apply(heff_dup(v_read_240), 1, (V[]){heff_dup(v_file_242)}));
  return heff_tail(v_c_2415, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam4, 1, 7, (V[]){v_file_242, v_x_246, v_x_248, v_x_2414, v_k_245, v_read_240, v_hd_244})});
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_249 = heff_dup(heff_field(v_x_248, 0));
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      heff_take_n(v_x11_249, 0ULL, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      v_t_2412 = heff_tag_at(v_ru_24x11_249_24Right, TAG_Just, 1, (V[]){v_p_2411});
      break;
    }
    default: heff_nomatch(v_x11_249);
    }
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_c_2413 = ({ V a_0 = heff_dup(v_x_246); V a_1 = v_t_2412; V r_ = (g_heff_2eload_2epackagesOf_24s871_24s1132(a_0, a_1)); heff_drop(v_t_2412); r_; });
  return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam3, 1, 6, (V[]){v_read_240, v_file_242, v_hd_244, v_x_246, v_x_248, v_k_245})});
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_247 = (g_heff_2eload_2ereadPackageAt_24s870_24s1131(heff_dup(v_x_246)));
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam2, 1, 5, (V[]){v_x_246, v_hd_244, v_read_240, v_file_242, v_k_245})});
}
V g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo(g_heff_2eload_2eloadProgramWith_24s866_24s1225_lam1, 1, 4, (V[]){v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}