// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_PAs 26446
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatBytes 60255
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_SetPath 11095
#define TAG_TagVariant 25174
#define LBL_anys 9494734
#define LBL_arms 9498206
#define LBL_chk 308000
#define LBL_decl 9574769
#define LBL_end 310101
#define LBL_inf 313947
#define LBL_msg 317947
#define LBL_order 307364712
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_typ 324869
#define LBL_v 336
#define LBL_x 338
static uint32_t shape_arms__order__anys[] = {LBL_arms, LBL_order, LBL_anys};
static uint32_t shape_inf__chk__typ__decl[] = {LBL_inf, LBL_chk, LBL_typ, LBL_decl};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_span__msg[] = {LBL_span, LBL_msg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eclauses_2eanyC(V, V);
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_clo;
V g_heff_2eelab_2eclauses_2eappendC(V, V);
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_clo;
V g_heff_2eelab_2eclauses_2ecatMaybesC(V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo;
V g_heff_2eelab_2eclauses_2ecatMaybesC_24dps(V, V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_clo;
V g_heff_2eelab_2eclauses_2ecolName(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolName_clo;
V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_clo;
V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_clo;
V g_heff_2eelab_2eclauses_2econcatMapC(V, V);
V g_heff_2eelab_2eclauses_2econcatMapC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_clo;
V g_heff_2eelab_2eclauses_2edesugar(V, V, V, V);
V g_heff_2eelab_2eclauses_2edesugar_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edesugar_clo;
V g_heff_2eelab_2eclauses_2edesugarCols(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2edesugarCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edesugarCols_clo;
V g_heff_2eelab_2eclauses_2edropC(V, V);
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropC_clo;
V g_heff_2eelab_2eclauses_2efoldr2(V, V, V);
V g_heff_2eelab_2eclauses_2efoldr2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efoldr2_clo;
V g_heff_2eelab_2eclauses_2eforC(V, V);
V g_heff_2eelab_2eclauses_2eforC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eforC_clo;
V g_heff_2eelab_2eclauses_2efreshIn(V, V, V);
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efreshIn_clo;
V g_heff_2eelab_2eclauses_2eidents_get(void);
V g_heff_2eelab_2eclauses_2eidentsChkF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_clo;
V g_heff_2eelab_2eclauses_2eidentsDeclF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsDeclF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsDeclF_clo;
V g_heff_2eelab_2eclauses_2eidentsInfF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsInfF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsInfF_clo;
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(V, V);
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_clo;
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_clo;
V g_heff_2eelab_2eclauses_2elookupField(V, V);
V g_heff_2eelab_2eclauses_2elookupField_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elookupField_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll(V, V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_clo;
V g_heff_2eelab_2eclauses_2enoRecMix(V, V);
V g_heff_2eelab_2eclauses_2enoRecMix_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enoRecMix_clo;
V g_heff_2eelab_2eclauses_2enthC(V, V);
V g_heff_2eelab_2eclauses_2enthC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enthC_clo;
V g_heff_2eelab_2eclauses_2enubStr_24dps(V, V);
V g_heff_2eelab_2eclauses_2enubStr_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_24dps_clo;
V g_heff_2eelab_2eclauses_2epat(V);
V g_heff_2eelab_2eclauses_2epat_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epat_clo;
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatBinds_24dps(V, V);
V g_heff_2eelab_2eclauses_2epatBinds_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_24dps_clo;
V g_heff_2eelab_2eclauses_2epatIdents(V, V);
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_clo;
V g_heff_2eelab_2eclauses_2epatVars(V);
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_clo;
V g_heff_2eelab_2eclauses_2epatVars_24dps(V, V);
V g_heff_2eelab_2eclauses_2epatVars_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_24dps_clo;
V g_heff_2eelab_2eclauses_2epeelAs(V, V, V);
V g_heff_2eelab_2eclauses_2epeelAs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelAs_clo;
V g_heff_2eelab_2eclauses_2epeelCols(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelCols_clo;
V g_heff_2eelab_2eclauses_2epiIdents(V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_clo;
V g_heff_2eelab_2eclauses_2erecSpecialize(V, V, V, V);
V g_heff_2eelab_2eclauses_2erecSpecialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecSpecialize_clo;
V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_clo;
V g_heff_2eelab_2eclauses_2erenameEquation(V, V);
V g_heff_2eelab_2eclauses_2erenameEquation_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameEquation_clo;
V g_heff_2eelab_2eclauses_2erenameInfF(V, V);
V g_heff_2eelab_2eclauses_2erenameInfF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameInfF_clo;
V g_heff_2eelab_2eclauses_2erenamePi(V, V);
V g_heff_2eelab_2eclauses_2erenamePi_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamePi_clo;
V g_heff_2eelab_2eclauses_2erenameSeq(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eclauses_2etagColGo(V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColGo_clo;
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_clo;
V g_heff_2eelab_2eclauses_2etakeC(V, V);
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s1892599875x1770628292(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s1892599875x1770628292_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s1892599875x1770628292_clo;
V g_heff_2eelab_2eclauses_2eupToGo(V, V);
V g_heff_2eelab_2eclauses_2eupToGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eupToGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s2103553821x564582624(V, V);
V g_list_2emap_24s2103553821x564582624_entry(V self, V *a);
extern Clo g_list_2emap_24s2103553821x564582624_clo;
V g_map_2eempty_get(void);
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2eelab_2eclauses_2econcatMapC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2econcatMapC(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2eclauses_2econcatMapC(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2eclauses_2eappendC(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2econcatMapC(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecatMaybesC_entry, 1, 0};

V g_heff_2eelab_2eclauses_2ecatMaybesC(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2eclauses_2ecatMaybesC_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecatMaybesC(a[0]);
}
Clo g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_entry, 2, 0};

V g_heff_2eelab_2eclauses_2ecatMaybesC_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecatMaybesC_24dps(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2enubStr_24dps_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2enubStr_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enubStr_24dps_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enubStr_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_248 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2eclauses_2enubStr_24dps_lam0, 1, 1, (V[]){v_x_242}), v_xs_243));
    V t_0 = v_t_248;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2enubStr_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enubStr_24dps(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2enubStr_24dps_lam0(V self, V *args) {
  V v_y_246 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool(!heff_strEq_c(heff_dup(v_y_246), heff_dup(v_x_242)));
  heff_drop(v_y_246);
  heff_drop(v_x_242);
  return v_ret_24bool;
}
Clo g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776_entry, 1, 0};

V g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = (g_heff_2eelab_2eclauses_2epat(v_x_241));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      V v_e_244 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Left = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      heff_drop(v_xs_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_tag_at_n(v_ru_24x1_243_24Left, TAG_Left, 1, (V[]){v_e_244});
    }
    case TAG_Right: {
      V v_x_245 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Right = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      V v_x1_246 = (g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776(v_xs_242));
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Left: {
        V v_e_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_x_245);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Left, 1, (V[]){v_e_247});
      }
      case TAG_Right: {
        V v_x_248 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_x_248})});
      }
      default: return heff_nomatch(v_x1_246);
      }
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776(a[0]);
}
Clo g_heff_2eelab_2eclauses_2epatVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatVars_entry, 1, 0};

V g_heff_2eelab_2eclauses_2epatVars(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PVar: {
    V v_x_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
  }
  case TAG_PTag: {
    V v_ps_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    return ({ V a_0 = v_ps_243; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a_0)); heff_drop(v_ps_243); r_; });
  }
  case TAG_PLit: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PRec: {
    V v_fps_246 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    return ({ V a_0 = v_fps_246; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a_0)); heff_drop(v_fps_246); r_; });
  }
  case TAG_PAs: {
    V v_x_248 = heff_field(v_x1_240, 0);
    V v_p_249 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24PAs = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x1_240_24PAs, TAG_Cons, 2, (V[]){v_x_248, heff_hole()});
    V v_u_2411 = (g_heff_2eelab_2eclauses_2epatVars_24dps(v_p_249, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatVars(a[0]);
}
Clo g_heff_2eelab_2eclauses_2epiIdents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epiIdents_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epiIdents(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_t_245 = heff_field(v_x2_241, 2);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){heff_dup(v_t_245), v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), v_t_246});
  }
  case TAG_PiImplicit: {
    V v_x_247 = heff_field(v_x2_241, 0);
    V v_t_2410 = heff_field(v_x2_241, 3);
    V v_d_2411 = heff_field(v_x2_241, 4);
    V v_t_2413;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_Nothing: {
      v_t_2413 = v_acc_242;
      break;
    }
    case TAG_Just: {
      V v_c_2412 = heff_field(v_d_2411, 0);
      v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_c_2412), v_acc_242}));
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    V v_t_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){heff_dup(v_t_2410), v_t_2413}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_247), v_t_2414});
  }
  case TAG_PiInstance: {
    V v_x_2415 = heff_field(v_x2_241, 0);
    V v_t_2418 = heff_field(v_x2_241, 3);
    V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){heff_dup(v_t_2418), v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2415), v_t_2419});
  }
  case TAG_PiAnon: {
    V v_d_2420 = heff_field(v_x2_241, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){heff_dup(v_d_2420), v_acc_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2epiIdents_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2epiIdents(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2epatIdents(heff_dup(v_x_242), v_acc_241));
    V t_0 = v_xs_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2eidentsInfF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsInfF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsInfF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsInfF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsInfF(V v_r_240, V v_n_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_243 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_n1_243)) {
    case TAG_IVar: {
      V v_x_245 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_245, v_acc_242});
    }
    case TAG_IInt: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IFloat: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IString: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IBytes: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IRune: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IApp: {
      V v_h_2411 = heff_field(v_n1_243, 0);
      V v_args_2412 = heff_field(v_n1_243, 1);
      heff_take_n(v_n1_243, 3ULL, 2);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2422 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsInfF_lam0, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_args_2412; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2412); r_; });
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_h_2411, v_t_2422});
    }
    case TAG_IAnn: {
      V v_c_2423 = heff_field(v_n1_243, 0);
      V v_t_2424 = heff_field(v_n1_243, 1);
      heff_take_n(v_n1_243, 3ULL, 2);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2425 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 2, (V[]){v_t_2424, v_acc_242}));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2423, v_t_2425});
    }
    case TAG_ISpec: {
      V v_a_2426 = heff_field(v_n1_243, 0);
      V v_v_2429 = heff_field(v_n1_243, 3);
      heff_take_n(v_n1_243, 9ULL, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2430 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){v_v_2429, v_acc_242}));
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_a_2426, v_t_2430});
    }
    case TAG_IUpdate: {
      V v_a_2431 = heff_field(v_n1_243, 0);
      V v_fs_2432 = heff_field(v_n1_243, 1);
      heff_take_n(v_n1_243, 3ULL, 2);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2441 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsInfF_lam1, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_fs_2432; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_fs_2432); r_; });
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_a_2431, v_t_2441});
    }
    case TAG_IAnnLam: {
      V v_x_2442 = heff_field(v_n1_243, 0);
      V v_t_2444 = heff_field(v_n1_243, 2);
      V v_b_2445 = heff_field(v_n1_243, 3);
      heff_take_n(v_n1_243, 13ULL, 4);
      V v_t_2446 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 2, (V[]){v_b_2445, v_acc_242}));
      V v_t_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2444, v_t_2446}));
      return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2442, v_t_2447});
    }
    case TAG_IInvalid: {
      heff_take_n(v_n1_243, 0ULL, 3);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_INominal: {
      V v_i_2451 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_i_2451, v_acc_242});
    }
    case TAG_ILitEq: {
      V v_x_2452 = heff_field(v_n1_243, 0);
      V v_eq_2454 = heff_field(v_n1_243, 2);
      V v_lit_2455 = heff_field(v_n1_243, 3);
      heff_take_n(v_n1_243, 13ULL, 4);
      V v_t_2456 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_lit_2455, v_acc_242}));
      return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2452, heff_tag_n(TAG_Cons, 2, (V[]){v_eq_2454, v_t_2456})});
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsInfF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsInfF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsInfF_lam0(V self, V *args) {
  V v_x2_2413 = args[0];
  V v_acc_2414 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_At: {
    V v_x21_2415 = heff_field(v_x2_2413, 0);
    V v_ru_24x2_2413_24At = heff_take_reuse_n(v_x2_2413, 1ULL, 2);
    switch (heff_tag_of(v_x21_2415)) {
    case TAG_ArgExplicit: {
      V v_c_2417 = heff_field(v_x21_2415, 0);
      heff_take_n(v_x21_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_2413_24At, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      args[0] = v_c_2417;
      args[1] = v_acc_2414;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_ArgProject: {
      heff_take_n(v_x21_2415, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24x2_2413_24At, 2);
      return v_acc_2414;
    }
    case TAG_ArgNamed: {
      V v_x_2419 = heff_field(v_x21_2415, 0);
      V v_c_2420 = heff_field(v_x21_2415, 1);
      heff_take_n(v_x21_2415, 3ULL, 2);
      V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2420, v_acc_2414}));
      return heff_tag_at_n(v_ru_24x2_2413_24At, TAG_Cons, 2, (V[]){v_x_2419, v_t_2421});
    }
    default: return heff_nomatch(v_x21_2415);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2eelab_2eclauses_2eidentsInfF_lam1(V self, V *args) {
  V v_x2_2433 = args[0];
  V v_acc_2434 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_At: {
    V v_x21_2435 = heff_field(v_x2_2433, 0);
    heff_take_n(v_x2_2433, 1ULL, 2);
    switch (heff_tag_of(v_x21_2435)) {
    case TAG_SetPath: {
      V v_path_2437 = heff_field(v_x21_2435, 0);
      V v_e_2438 = heff_field(v_x21_2435, 1);
      heff_take_n(v_x21_2435, 3ULL, 2);
      V v_t_2439 = (g_list_2emap_24s1415906091x1371825187(v_path_2437));
      V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_e_2438, v_acc_2434}));
      return (g_prelude_2e_2b_2b(v_t_2439, v_t_2440));
    }
    default: return heff_nomatch(v_x21_2435);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2eelab_2eclauses_2eidents_lam0(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam0, 2, 0};
V g_heff_2eelab_2eclauses_2eidents_lam1(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam1, 2, 0};
V g_heff_2eelab_2eclauses_2eidents_lam2(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam2, 2, 0};
V g_heff_2eelab_2eclauses_2eidents_lam3(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam3, 2, 0};

static V g_heff_2eelab_2eclauses_2eidents_val;
static HEFF_ONCE g_heff_2eelab_2eclauses_2eidents_st;
static V g_heff_2eelab_2eclauses_2eidents_init(void) {
  return heff_rec_n(4, shape_inf__chk__typ__decl, (V[]){((V)&g_heff_2eelab_2eclauses_2eidents_lam0_clo), ((V)&g_heff_2eelab_2eclauses_2eidents_lam1_clo), ((V)&g_heff_2eelab_2eclauses_2eidents_lam2_clo), ((V)&g_heff_2eelab_2eclauses_2eidents_lam3_clo)});
}
V g_heff_2eelab_2eclauses_2eidents_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eclauses_2eidents_st)) return g_heff_2eelab_2eclauses_2eidents_val;
  return heff_global(&g_heff_2eelab_2eclauses_2eidents_val, &g_heff_2eelab_2eclauses_2eidents_st, g_heff_2eelab_2eclauses_2eidents_init);
}
V g_heff_2eelab_2eclauses_2eidents_lam0(V self, V *args) {
  V v_n_240 = args[0];
  V v_acc_241 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsInfF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_n_240, v_acc_241));
}
V g_heff_2eelab_2eclauses_2eidents_lam1(V self, V *args) {
  V v_n_242 = args[0];
  V v_acc_243 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsChkF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_n_242, v_acc_243));
}
V g_heff_2eelab_2eclauses_2eidents_lam2(V self, V *args) {
  V v_n_244 = args[0];
  V v_acc_245 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsTypF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_n_244, v_acc_245));
}
V g_heff_2eelab_2eclauses_2eidents_lam3(V self, V *args) {
  V v_d_246 = args[0];
  V v_acc_247 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsDeclF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_d_246, v_acc_247));
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2410 = (g_heff_2eelab_2eclauses_2enamesOfAll(heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 2)), v_a_248, v_acc_241));
        break;
      }
      case TAG_BadVariant: {
        V v_a_249 = heff_field(v_a_244, 0);
        v_t_2410 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_a_249, v_acc_241));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2410;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(V v_n_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_242 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24At = heff_take_reuse_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_n1_242)) {
    case TAG_IVar: {
      V v_x_244 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24n_240_24At, TAG_Cons, 2, (V[]){v_x_244, v_acc_241});
    }
    case TAG_IInt: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      return v_acc_241;
    }
    case TAG_IFloat: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      return v_acc_241;
    }
    case TAG_IString: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      return v_acc_241;
    }
    case TAG_IBytes: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      return v_acc_241;
    }
    case TAG_IRune: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      return v_acc_241;
    }
    case TAG_IApp: {
      V v_h_2410 = heff_field(v_n1_242, 0);
      V v_args_2411 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      V v_acc_2412 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(v_args_2411, v_acc_241));
      V t_0 = v_h_2410;
      V t_1 = v_acc_2412;
      v_n_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_IAnn: {
      V v_c_2413 = heff_field(v_n1_242, 0);
      V v_t_2414 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      V v_acc_2415 = ({ V a_0 = v_t_2414; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_t_2414); r_; });
      HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_c_2413, v_acc_2415);
    }
    case TAG_ISpec: {
      V v_a_2416 = heff_field(v_n1_242, 0);
      V v_v_2419 = heff_field(v_n1_242, 3);
      heff_take_n(v_n1_242, 9ULL, 4);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      V v_acc_2420 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_v_2419, v_acc_241));
      V t_0 = v_a_2416;
      V t_1 = v_acc_2420;
      v_n_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_IUpdate: {
      V v_a_2421 = heff_field(v_n1_242, 0);
      V v_fs_2422 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      V v_acc_2423 = ({ V a_0 = v_fs_2422; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(a_0, a_1)); heff_drop(v_fs_2422); r_; });
      V t_0 = v_a_2421;
      V t_1 = v_acc_2423;
      v_n_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_IAnnLam: {
      V v_x_2424 = heff_field(v_n1_242, 0);
      V v_t_2426 = heff_field(v_n1_242, 2);
      V v_b_2427 = heff_field(v_n1_242, 3);
      heff_take_n(v_n1_242, 13ULL, 4);
      V v_acc_2428 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_b_2427, v_acc_241));
      V v_t_2429 = ({ V a_0 = v_t_2426; V a_1 = v_acc_2428; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_t_2426); r_; });
      return heff_tag_at_n(v_ru_24n_240_24At, TAG_Cons, 2, (V[]){v_x_2424, v_t_2429});
    }
    case TAG_IInvalid: {
      heff_take_n(v_n1_242, 0ULL, 3);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      return v_acc_241;
    }
    case TAG_INominal: {
      V v_i_2433 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      V t_0 = v_i_2433;
      V t_1 = v_acc_241;
      v_n_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_ILitEq: {
      V v_x_2434 = heff_field(v_n1_242, 0);
      V v_eq_2436 = heff_field(v_n1_242, 2);
      V v_lit_2437 = heff_field(v_n1_242, 3);
      heff_take_n(v_n1_242, 13ULL, 4);
      V v_t_2438 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_lit_2437, v_acc_241));
      return heff_tag_at_n(v_ru_24n_240_24At, TAG_Cons, 2, (V[]){v_x_2434, heff_tag_n(TAG_Cons, 2, (V[]){v_eq_2436, v_t_2438})});
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(V v_x2_240, V v_acc_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 1ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_CInf: {
      V v_i_245 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_246 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_i_245, v_acc_241));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
    }
    case TAG_CType: {
      V v_t_247 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_t_247); r_; });
      return heff_setField(v_d_242, MK_INT(1LL), v_t_248);
    }
    case TAG_CLam: {
      V v_x_249 = heff_field(v_x21_243, 0);
      V v_b_2411 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_x_249, heff_hole()});
      V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_b_2411;
      V t_1 = v_acc_241;
      V t_2 = v_cell_2412;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CImplicitLam: {
      V v_x_2414 = heff_field(v_x21_243, 0);
      V v_b_2416 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_x_2414, heff_hole()});
      V v_u_2418 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_b_2416;
      V t_1 = v_acc_241;
      V t_2 = v_cell_2417;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CAnnLam: {
      V v_x_2419 = heff_field(v_x21_243, 0);
      V v_t_2421 = heff_field(v_x21_243, 2);
      V v_b_2422 = heff_field(v_x21_243, 3);
      heff_take_n(v_x21_243, 13ULL, 4);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2423 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_2422, v_acc_241));
      V v_t_2424 = ({ V a_0 = v_t_2421; V a_1 = v_acc_2423; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_t_2421); r_; });
      return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2419, v_t_2424}));
    }
    case TAG_CTag: {
      V v_args_2427 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 4ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2428 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 1)); V a_1 = v_args_2427; V a_2 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2427); r_; });
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2428);
    }
    case TAG_CStruct: {
      V v_fs_2429 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2430 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(v_fs_2429, v_acc_241));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2430);
    }
    case TAG_CMatch: {
      V v_s_2431 = heff_field(v_x21_243, 0);
      V v_alts_2432 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2433 = ({ V a_0 = v_alts_2432; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(a_0, a_1)); heff_drop(v_alts_2432); r_; });
      V v_t_2434 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_s_2431, v_acc_2433));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2434);
    }
    case TAG_CLetIn: {
      V v_rhs_2435 = heff_field(v_x21_243, 0);
      V v_a_2436 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2442;
      switch (heff_tag_of(v_a_2436)) {
      case TAG_At: {
        V v_x21_2437 = heff_field(v_a_2436, 0);
        heff_take_n(v_a_2436, 1ULL, 2);
        switch (heff_tag_of(v_x21_2437)) {
        case TAG_MkAlt: {
          V v_p_2439 = heff_field(v_x21_2437, 0);
          V v_b_2440 = heff_field(v_x21_2437, 1);
          heff_take_n(v_x21_2437, 3ULL, 2);
          V v_t_2441 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_2440, v_acc_241));
          v_acc_2442 = (g_heff_2eelab_2eclauses_2epatIdents(v_p_2439, v_t_2441));
          break;
        }
        default: heff_nomatch(v_x21_2437);
        }
        break;
      }
      default: heff_nomatch(v_a_2436);
      }
      V v_t_2443 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_rhs_2435, v_acc_2442));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2443);
    }
    case TAG_CLocal: {
      V v_body_2444 = heff_field(v_x21_243, 0);
      V v_ds_2445 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2446 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 3)); V a_1 = v_ds_2445; V a_2 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ds_2445); r_; });
      V t_0 = v_body_2444;
      V t_1 = v_acc_2446;
      V t_2 = v_d_242;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CAbandon: {
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_CNominal: {
      V v_c_2447 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V t_0 = v_c_2447;
      V t_1 = v_acc_241;
      V t_2 = v_d_242;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(v_acc_241, heff_dup(v_x_242)));
    V t_0 = v_xs_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efreshIn_str0, 1, "'");
HEFF_LIT(g_heff_2eelab_2eclauses_2efreshIn_str1, 1, "'");
Clo g_heff_2eelab_2eclauses_2efreshIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efreshIn_entry, 3, 0};

V g_heff_2eelab_2eclauses_2efreshIn(V v_used_240, V v_bound_241, V v_x_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
  V v_t_244 = (g_list_2eany(v_t_243, v_used_240));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V t_0 = v_used_240;
    V t_1 = v_bound_241;
    V t_2 = heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2eclauses_2efreshIn_str0));
    v_used_240 = t_0;
    v_bound_241 = t_1;
    v_x_242 = t_2;
    goto top;
  } else {
    heff_drop(v_t_244);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_bound_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_used_240;
      V t_1 = v_bound_241;
      V t_2 = heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2eclauses_2efreshIn_str1));
      v_used_240 = t_0;
      v_bound_241 = t_1;
      v_x_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_246);
      return v_x_242;
    }
  }
}
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2efreshIn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2epatBinds_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatBinds_24dps_entry, 2, 0};

V g_heff_2eelab_2eclauses_2epatBinds_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      V v_t_245 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
      return heff_setField(v_d_241, MK_INT(1LL), v_t_245);
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_249 = ({ V a_0 = v_ps_248; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_248); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_249);
    }
    case TAG_PatOp: {
      V v_ps_2412 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2413 = ({ V a_0 = v_ps_2412; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_2412); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2413);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBytes: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2419 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2420 = ({ V a_0 = v_fs_2419; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(a_0)); heff_drop(v_fs_2419); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2420);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2422 = heff_field(v_p1_242, 0);
      V v_q_2424 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 5ULL, 3);
      V v_cell_2425 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2422, heff_hole()});
      V v_u_2426 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2425));
      heff_drop(v_u_2426);
      V t_0 = v_q_2424;
      V t_1 = v_cell_2425;
      v_p_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatBinds_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatBinds_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2erenameSeq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameSeq_entry, 3, 0};

V g_heff_2eelab_2eclauses_2erenameSeq(V v_f_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_b_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_m_243)}));
    V v_t_246 = heff_tr(heff_call(heff_dup(v_b_241), 1, (V[]){v_m_243}));
    V v_t_247;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_f_240);
      heff_drop(v_b_241);
      heff_drop(v_t_246);
      v_t_247 = v_rest_244;
    } else {
      heff_drop(v_t_246);
      v_t_247 = (g_heff_2eelab_2eclauses_2erenameSeq(v_f_240, v_b_241, v_rest_244));
    }
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_t_247});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2erenameSeq_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameSeq(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2erenameEquation_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameEquation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameEquation_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameEquation(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 15ULL, 4);
      V v_t_2411 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2erenameEquation_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_ps_246));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_t_2411);
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_rhs_247}), v_sp_243});
      } else {
        heff_drop(v_t_2411);
        V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_rhs_247}));
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_t_2412}), v_sp_243});
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameEquation_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameEquation(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameEquation_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_249 = (g_heff_2eelab_2eclauses_2epatBinds(v_p_248));
  V v_t_2410 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_240, 0, 5)}));
  return ({ V a_0 = v_t_2410; V a_1 = v_xs_249; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_249); r_; });
}
Clo g_heff_2eelab_2eclauses_2erenamePi_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenamePi_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenamePi(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ysp_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_244}));
    return heff_tag_at_n(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, (V[]){v_y_242, v_ysp_243, v_t_245});
  }
  case TAG_PiImplicit: {
    V v_y_246 = heff_field(v_x2_241, 0);
    V v_ysp_247 = heff_field(v_x2_241, 1);
    V v_bsp_248 = heff_field(v_x2_241, 2);
    V v_t_249 = heff_field(v_x2_241, 3);
    V v_d_2410 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_2411 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 1, (V[]){v_t_249}));
    V v_t_2414;
    switch (heff_tag_of(v_d_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 5);
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_c_2412 = heff_field(v_d_2410, 0);
      V v_ru_24d_2410_24Just = heff_take_reuse_n(v_d_2410, 1ULL, 1);
      V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2412}));
      v_t_2414 = heff_tag_at_n(v_ru_24d_2410_24Just, TAG_Just, 1, (V[]){v_t_2413});
      break;
    }
    default: heff_nomatch(v_d_2410);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_y_246, v_ysp_247, v_bsp_248, v_t_2411, v_t_2414});
  }
  case TAG_PiInstance: {
    V v_y_2415 = heff_field(v_x2_241, 0);
    V v_ysp_2416 = heff_field(v_x2_241, 1);
    V v_bsp_2417 = heff_field(v_x2_241, 2);
    V v_t_2418 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2418}));
    return heff_tag_at_n(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, (V[]){v_y_2415, v_ysp_2416, v_bsp_2417, v_t_2419});
  }
  case TAG_PiAnon: {
    V v_d_2420 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_d_2420}));
    return heff_tag_at_n(v_ru_24x2_241_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2421});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenamePi_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenamePi(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameInfF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameInfF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameInfF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameInfF_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameInfF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_IVar: {
      V v_y_244 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24IVar = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      if (heff_strEq_c(v_y_244, heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_tag(v_n_241, 2);
        V v_t_246 = heff_tag_at_n(v_ru_24n1_242_24IVar, TAG_IVar, 1, (V[]){heff_get_n(v_r_240, 1, 5)});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_sp_243});
      } else {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop_cell(v_ru_24n1_242_24IVar, 1);
        return v_n_241;
      }
    }
    case TAG_IInt: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IFloat: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IString: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IBytes: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IRune: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IApp: {
      V v_h_2412 = heff_field(v_n1_242, 0);
      V v_args_2413 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24IApp = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 1, (V[]){v_h_2412}));
      V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameInfF_lam0, 1, 1, (V[]){v_r_240}), v_args_2413));
      return heff_tag_at_n(v_ru_24n1_242_24IApp, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2414, v_t_2424}), v_sp_243});
    }
    case TAG_IAnn: {
      V v_c_2425 = heff_field(v_n1_242, 0);
      V v_t_2426 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24IAnn = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2427 = heff_tr(heff_call(heff_take_field(v_r_240, 3), 1, (V[]){v_c_2425}));
      V v_t_2428 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2426}));
      return heff_tag_at_n(v_ru_24n1_242_24IAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_2427, v_t_2428}), v_sp_243});
    }
    case TAG_ISpec: {
      V v_a_2429 = heff_field(v_n1_242, 0);
      V v_f_2430 = heff_field(v_n1_242, 1);
      V v_fsp_2431 = heff_field(v_n1_242, 2);
      V v_val_2432 = heff_field(v_n1_242, 3);
      V v_ru_24n1_242_24ISpec = heff_take_reuse_n(v_n1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2433 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 1, (V[]){v_a_2429}));
      V v_t_2434 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_val_2432}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24ISpec, TAG_ISpec, 4, (V[]){v_t_2433, v_f_2430, v_fsp_2431, v_t_2434}), v_sp_243});
    }
    case TAG_IUpdate: {
      V v_a_2435 = heff_field(v_n1_242, 0);
      V v_fs_2436 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24IUpdate = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 1, (V[]){v_a_2435}));
      V v_t_2444 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameInfF_lam1, 1, 1, (V[]){v_r_240}), v_fs_2436));
      return heff_tag_at_n(v_ru_24n1_242_24IUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_IUpdate, 2, (V[]){v_t_2437, v_t_2444}), v_sp_243});
    }
    case TAG_IAnnLam: {
      V v_y_2445 = heff_field(v_n1_242, 0);
      V v_ysp_2446 = heff_field(v_n1_242, 1);
      V v_t_2447 = heff_field(v_n1_242, 2);
      V v_b_2448 = heff_field(v_n1_242, 3);
      V v_ru_24n1_242_24IAnnLam = heff_take_reuse_n(v_n1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2449 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 1, (V[]){v_t_2447}));
      V v_t_2451;
      if (heff_strEq_c(heff_dup(v_y_2445), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_rec(v_r_240, 5);
        v_t_2451 = v_b_2448;
      } else {
        v_t_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_b_2448}));
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24IAnnLam, TAG_IAnnLam, 4, (V[]){v_y_2445, v_ysp_2446, v_t_2449, v_t_2451}), v_sp_243});
    }
    case TAG_IInvalid: {
      heff_take_n(v_n1_242, 0ULL, 3);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_INominal: {
      V v_i_2455 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24INominal = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2456 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_i_2455}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24INominal, TAG_INominal, 1, (V[]){v_t_2456}), v_sp_243});
    }
    case TAG_ILitEq: {
      V v_y_2457 = heff_field(v_n1_242, 0);
      V v_ysp_2458 = heff_field(v_n1_242, 1);
      V v_eq_2459 = heff_field(v_n1_242, 2);
      V v_lit_2460 = heff_field(v_n1_242, 3);
      V v_ru_24n1_242_24ILitEq = heff_take_reuse_n(v_n1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2462;
      if (heff_strEq_c(heff_dup(v_y_2457), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop(v_y_2457);
        v_t_2462 = heff_dup(heff_rfield(v_r_240, 1));
      } else {
        v_t_2462 = v_y_2457;
      }
      V v_t_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_lit_2460}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24ILitEq, TAG_ILitEq, 4, (V[]){v_t_2462, v_ysp_2458, v_eq_2459, v_t_2463}), v_sp_243});
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameInfF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameInfF(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameInfF_lam0(V self, V *args) {
  V v_a_2415 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2415)) {
  case TAG_At: {
    V v_a1_2416 = heff_dup(heff_field(v_a_2415, 0));
    V v_sp_2417 = heff_dup(heff_field(v_a_2415, 1));
    switch (heff_tag_of(v_a1_2416)) {
    case TAG_ArgExplicit: {
      V v_c_2418 = heff_field(v_a1_2416, 0);
      V v_ru_24a1_2416_24ArgExplicit = heff_take_reuse_n(v_a1_2416, 1ULL, 1);
      heff_drop_tag(v_a_2415, 2);
      V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2418}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a1_2416_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_2419}), v_sp_2417});
    }
    case TAG_ArgProject: {
      heff_take_n(v_a1_2416, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_2417);
      return v_a_2415;
    }
    case TAG_ArgNamed: {
      V v_y_2421 = heff_field(v_a1_2416, 0);
      V v_c_2422 = heff_field(v_a1_2416, 1);
      V v_ru_24a1_2416_24ArgNamed = heff_take_reuse_n(v_a1_2416, 3ULL, 2);
      heff_drop_tag(v_a_2415, 2);
      V v_t_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2422}));
      return heff_tag_at_n(v_ru_24a1_2416_24ArgNamed, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_y_2421, v_t_2423}), v_sp_2417});
    }
    default: return heff_nomatch(v_a1_2416);
    }
  }
  default: return heff_nomatch(v_a_2415);
  }
}
V g_heff_2eelab_2eclauses_2erenameInfF_lam1(V self, V *args) {
  V v_f_2438 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_2438)) {
  case TAG_At: {
    V v_it1_2439 = heff_field(v_f_2438, 0);
    V v_fsp_2440 = heff_field(v_f_2438, 1);
    V v_ru_24f_2438_24At = heff_take_reuse_n(v_f_2438, 3ULL, 2);
    switch (heff_tag_of(v_it1_2439)) {
    case TAG_SetPath: {
      V v_path_2441 = heff_field(v_it1_2439, 0);
      V v_e_2442 = heff_field(v_it1_2439, 1);
      heff_take_n(v_it1_2439, 3ULL, 2);
      V v_t_2443 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_e_2442}));
      return heff_tag_at_n(v_ru_24f_2438_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_path_2441, v_t_2443}), v_fsp_2440});
    }
    default: return heff_nomatch(v_it1_2439);
    }
  }
  default: return heff_nomatch(v_f_2438);
  }
}
Clo g_heff_2eelab_2eclauses_2elookupField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elookupField_entry, 2, 0};

V g_heff_2eelab_2eclauses_2elookupField(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_g_244 = heff_field(v_x21_242, 0);
      V v_p_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c(heff_dup(v_f_240), heff_dup(v_g_244))) {
        heff_drop(v_f_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_245)});
      } else {
        V t_0 = v_f_240;
        V t_1 = v_rest_243;
        v_f_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2elookupField_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2elookupField(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_str1, 42, "a record and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_str2, 46, "a record and a literal match the same argument");
V g_heff_2eelab_2eclauses_2enoRecMix_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2enoRecMix_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2enoRecMix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enoRecMix_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enoRecMix(V v_rows_240, V v_c_241) {
top: ;
  V v_t_2415 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2enoRecMix_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_rows_240));
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    HEFF_LAST return g_heff_2eelab_2eclauses_2eforC(v_rows_240, heff_clo_n(g_heff_2eelab_2eclauses_2enoRecMix_lam1, 1, 1, (V[]){v_c_241}));
  } else {
    heff_drop(v_c_241);
    heff_drop(v_t_2415);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
}
V g_heff_2eelab_2eclauses_2enoRecMix_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enoRecMix(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2enoRecMix_lam0(V self, V *args) {
  V v_row_242 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = ({ V b_0 = heff_get_n(v_row_242, 0, 2); V a_1 = v_c_241; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    v_x1_245 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2enoRecMix_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    v_x1_245 = v_p_244;
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  switch (heff_tag_of(v_x1_245)) {
  case TAG_PVar: {
    heff_take_n(v_x1_245, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_245, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_245, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_245, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_245, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eelab_2eclauses_2enoRecMix_lam1(V self, V *args) {
  V v_row_2416 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = ({ V b_0 = heff_get_n(v_row_2416, 0, 2); V a_1 = v_c_241; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Just: {
    V v_p_2418 = heff_field(v_t_2417, 0);
    V v_ru_24t_2417_24Just = heff_take_reuse_n(v_t_2417, 1ULL, 1);
    switch (heff_tag_of(v_p_2418)) {
    case TAG_PVar: {
      heff_take_n(v_p_2418, 0ULL, 1);
      return heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PTag: {
      V v_sp_2422 = heff_field(v_p_2418, 2);
      heff_take_n(v_p_2418, 4ULL, 3);
      return heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_sp_2422, ((V)&g_heff_2eelab_2eclauses_2enoRecMix_str1)})});
    }
    case TAG_PLit: {
      V v_l_2423 = heff_field(v_p_2418, 0);
      heff_take_n(v_p_2418, 1ULL, 1);
      V v_span_2426;
      switch (heff_tag_of(v_l_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_field(v_l_2423, 1);
        heff_take_n(v_l_2423, 2ULL, 2);
        v_span_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_l_2423);
      }
      return heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_span_2426, ((V)&g_heff_2eelab_2eclauses_2enoRecMix_str2)})});
    }
    case TAG_PRec: {
      heff_take_n(v_p_2418, 0ULL, 2);
      return heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PAs: {
      heff_take_n(v_p_2418, 0ULL, 2);
      return heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_p_2418);
    }
  }
  default: return heff_nomatch(v_t_2417);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str4, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str5, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str6, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str7, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str8, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str9, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str10, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str11, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str12, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str13, 1, "_");
V g_heff_2eelab_2eclauses_2erecSpecialize_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erecSpecialize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_entry, 4, 0};

V g_heff_2eelab_2eclauses_2erecSpecialize(V v_c_240, V v_fs_241, V v_v_242, V v_r_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_243, 0), heff_dup(v_c_240)));
  V v_t_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_t_246 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_t_246 = v_p_245;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_PVar: {
    V v_ru_24t_246_24PVar = heff_take_reuse_n(v_t_246, 0ULL, 1);
    V v_ys_248 = (g_list_2emap_24s2103553821x564582624(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str1), v_fs_241));
    V v_xs_249 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2410 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_249)));
    V v_t_2411 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_249));
    V v_t_2412 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_248, v_t_2411));
    V v_pats_2413 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2410, v_t_2412));
    V v_t_2414 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_243, 0), v_c_240));
    V v_x2_2416;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nothing: {
      v_x2_2416 = heff_tag_at_n(v_ru_24t_246_24PVar, TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str2)});
      break;
    }
    case TAG_Just: {
      V v_p_2415 = heff_field(v_t_2414, 0);
      heff_take_n(v_t_2414, 1ULL, 1);
      heff_drop_cell(v_ru_24t_246_24PVar, 1);
      v_x2_2416 = v_p_2415;
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_e_2417 = heff_get_n(v_r_243, 1, 2);
    V v_rhs_2430;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_PVar: {
      V v_x_2418 = heff_field(v_x2_2416, 0);
      heff_take_n(v_x2_2416, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_x_2418), ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str3))) {
        heff_drop(v_v_242);
        heff_drop(v_x_2418);
        v_rhs_2430 = v_e_2417;
      } else {
        if (heff_strEq_c(heff_dup(v_x_2418), heff_dup(v_v_242))) {
          heff_drop(v_v_242);
          heff_drop(v_x_2418);
          v_rhs_2430 = v_e_2417;
        } else {
          V v_t_2421 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2418, v_v_242));
          v_rhs_2430 = heff_tr(heff_call(heff_get_n(v_t_2421, 3, 5), 1, (V[]){v_e_2417}));
        }
      }
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_x2_2416, 0ULL, 3);
      heff_drop(v_v_242);
      v_rhs_2430 = v_e_2417;
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_x2_2416, 0ULL, 1);
      heff_drop(v_v_242);
      v_rhs_2430 = v_e_2417;
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_x2_2416, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2430 = v_e_2417;
      break;
    }
    case TAG_PAs: {
      heff_take_n(v_x2_2416, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2430 = v_e_2417;
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2413, v_rhs_2430});
  }
  case TAG_PTag: {
    heff_take_n(v_t_246, 0ULL, 3);
    V v_ys_2434 = (g_list_2emap_24s2103553821x564582624(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str4), v_fs_241));
    V v_xs_2435 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2436 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2435)));
    V v_t_2437 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2435));
    V v_t_2438 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2434, v_t_2437));
    V v_pats_2439 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2436, v_t_2438));
    V v_t_2440 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_243, 0), v_c_240));
    V v_x2_2442;
    switch (heff_tag_of(v_t_2440)) {
    case TAG_Nothing: {
      v_x2_2442 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str5)});
      break;
    }
    case TAG_Just: {
      V v_p_2441 = heff_field(v_t_2440, 0);
      heff_take_n(v_t_2440, 1ULL, 1);
      v_x2_2442 = v_p_2441;
      break;
    }
    default: heff_nomatch(v_t_2440);
    }
    V v_e_2443 = heff_get_n(v_r_243, 1, 2);
    V v_rhs_2456;
    switch (heff_tag_of(v_x2_2442)) {
    case TAG_PVar: {
      V v_x_2444 = heff_field(v_x2_2442, 0);
      heff_take_n(v_x2_2442, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_x_2444), ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str6))) {
        heff_drop(v_v_242);
        heff_drop(v_x_2444);
        v_rhs_2456 = v_e_2443;
      } else {
        if (heff_strEq_c(heff_dup(v_x_2444), heff_dup(v_v_242))) {
          heff_drop(v_v_242);
          heff_drop(v_x_2444);
          v_rhs_2456 = v_e_2443;
        } else {
          V v_t_2447 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2444, v_v_242));
          v_rhs_2456 = heff_tr(heff_call(heff_get_n(v_t_2447, 3, 5), 1, (V[]){v_e_2443}));
        }
      }
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_x2_2442, 0ULL, 3);
      heff_drop(v_v_242);
      v_rhs_2456 = v_e_2443;
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_x2_2442, 0ULL, 1);
      heff_drop(v_v_242);
      v_rhs_2456 = v_e_2443;
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_x2_2442, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2456 = v_e_2443;
      break;
    }
    case TAG_PAs: {
      heff_take_n(v_x2_2442, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2456 = v_e_2443;
      break;
    }
    default: heff_nomatch(v_x2_2442);
    }
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2439, v_rhs_2456});
  }
  case TAG_PLit: {
    V v_ru_24t_246_24PLit = heff_take_reuse_n(v_t_246, 0ULL, 1);
    V v_ys_2458 = (g_list_2emap_24s2103553821x564582624(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str7), v_fs_241));
    V v_xs_2459 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2460 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2459)));
    V v_t_2461 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2459));
    V v_t_2462 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2458, v_t_2461));
    V v_pats_2463 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2460, v_t_2462));
    V v_t_2464 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_243, 0), v_c_240));
    V v_x2_2466;
    switch (heff_tag_of(v_t_2464)) {
    case TAG_Nothing: {
      v_x2_2466 = heff_tag_at_n(v_ru_24t_246_24PLit, TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str8)});
      break;
    }
    case TAG_Just: {
      V v_p_2465 = heff_field(v_t_2464, 0);
      heff_take_n(v_t_2464, 1ULL, 1);
      heff_drop_cell(v_ru_24t_246_24PLit, 1);
      v_x2_2466 = v_p_2465;
      break;
    }
    default: heff_nomatch(v_t_2464);
    }
    V v_e_2467 = heff_get_n(v_r_243, 1, 2);
    V v_rhs_2480;
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_PVar: {
      V v_x_2468 = heff_field(v_x2_2466, 0);
      heff_take_n(v_x2_2466, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_x_2468), ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str9))) {
        heff_drop(v_v_242);
        heff_drop(v_x_2468);
        v_rhs_2480 = v_e_2467;
      } else {
        if (heff_strEq_c(heff_dup(v_x_2468), heff_dup(v_v_242))) {
          heff_drop(v_v_242);
          heff_drop(v_x_2468);
          v_rhs_2480 = v_e_2467;
        } else {
          V v_t_2471 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2468, v_v_242));
          v_rhs_2480 = heff_tr(heff_call(heff_get_n(v_t_2471, 3, 5), 1, (V[]){v_e_2467}));
        }
      }
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_x2_2466, 0ULL, 3);
      heff_drop(v_v_242);
      v_rhs_2480 = v_e_2467;
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_x2_2466, 0ULL, 1);
      heff_drop(v_v_242);
      v_rhs_2480 = v_e_2467;
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_x2_2466, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2480 = v_e_2467;
      break;
    }
    case TAG_PAs: {
      heff_take_n(v_x2_2466, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2480 = v_e_2467;
      break;
    }
    default: heff_nomatch(v_x2_2466);
    }
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2463, v_rhs_2480});
  }
  case TAG_PRec: {
    V v_fps_2481 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    heff_drop(v_v_242);
    V v_ys_2486 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam0, 1, 1, (V[]){v_fps_2481}), v_fs_241));
    V v_xs_2487 = heff_take_field(v_r_243, 0);
    V v_t_2488 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2487)));
    V v_t_2489 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_2487));
    V v_t_2490 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2486, v_t_2489));
    V v_pats_2491 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2488, v_t_2490));
    return ({ V rv_0 = v_pats_2491; V rr_ = heff_rec_reuse_nf(v_r_243, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  case TAG_PAs: {
    heff_take_n(v_t_246, 0ULL, 2);
    V v_ys_2494 = (g_list_2emap_24s2103553821x564582624(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str11), v_fs_241));
    V v_xs_2495 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2496 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2495)));
    V v_t_2497 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2495));
    V v_t_2498 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2494, v_t_2497));
    V v_pats_2499 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2496, v_t_2498));
    V v_t_24100 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_243, 0), v_c_240));
    V v_x2_24102;
    switch (heff_tag_of(v_t_24100)) {
    case TAG_Nothing: {
      v_x2_24102 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str12)});
      break;
    }
    case TAG_Just: {
      V v_p_24101 = heff_field(v_t_24100, 0);
      heff_take_n(v_t_24100, 1ULL, 1);
      v_x2_24102 = v_p_24101;
      break;
    }
    default: heff_nomatch(v_t_24100);
    }
    V v_e_24103 = heff_get_n(v_r_243, 1, 2);
    V v_rhs_24116;
    switch (heff_tag_of(v_x2_24102)) {
    case TAG_PVar: {
      V v_x_24104 = heff_field(v_x2_24102, 0);
      heff_take_n(v_x2_24102, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_x_24104), ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str13))) {
        heff_drop(v_v_242);
        heff_drop(v_x_24104);
        v_rhs_24116 = v_e_24103;
      } else {
        if (heff_strEq_c(heff_dup(v_x_24104), heff_dup(v_v_242))) {
          heff_drop(v_v_242);
          heff_drop(v_x_24104);
          v_rhs_24116 = v_e_24103;
        } else {
          V v_t_24107 = (g_heff_2eelab_2eclauses_2erenamer(v_x_24104, v_v_242));
          v_rhs_24116 = heff_tr(heff_call(heff_get_n(v_t_24107, 3, 5), 1, (V[]){v_e_24103}));
        }
      }
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_x2_24102, 0ULL, 3);
      heff_drop(v_v_242);
      v_rhs_24116 = v_e_24103;
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_x2_24102, 0ULL, 1);
      heff_drop(v_v_242);
      v_rhs_24116 = v_e_24103;
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_x2_24102, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_24116 = v_e_24103;
      break;
    }
    case TAG_PAs: {
      heff_take_n(v_x2_24102, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_24116 = v_e_24103;
      break;
    }
    default: heff_nomatch(v_x2_24102);
    }
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2499, v_rhs_24116});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erecSpecialize(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam0(V self, V *args) {
  V v_f_2483 = args[0];
  V v_fps_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2484 = ({ V a_0 = v_f_2483; V a_1 = v_fps_2481; V r_ = (g_heff_2eelab_2eclauses_2elookupField(a_0, a_1)); heff_drop(v_fps_2481); r_; });
  switch (heff_tag_of(v_x1_2484)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str10)});
  }
  case TAG_Just: {
    V v_p_2485 = heff_field(v_x1_2484, 0);
    heff_take_n(v_x1_2484, 1ULL, 1);
    return v_p_2485;
  }
  default: return heff_nomatch(v_x1_2484);
  }
}
Clo g_heff_2eelab_2eclauses_2epeelCols_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epeelCols_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epeelCols(V v_x1_240, V v_ps_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_ps_241, v_e_242});
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x1_240, 0);
    V v_vs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_ps_241)) {
    case TAG_Nil: {
      heff_drop(v_v_243);
      heff_drop(v_vs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_rec_n(2, shape_pats__rhs, (V[]){v_ps_241, v_e_242});
    }
    case TAG_Cons: {
      V v_p_245 = heff_field(v_ps_241, 0);
      V v_ps2_246 = heff_field(v_ps_241, 1);
      heff_take_n(v_ps_241, 3ULL, 2);
      V v_t_247 = (g_heff_2eelab_2eclauses_2epeelAs(v_v_243, v_p_245, v_e_242));
      switch (heff_tag_of(v_t_247)) {
      case TAG_MkPair: {
        V v_p_27_248 = heff_field(v_t_247, 0);
        V v_e_27_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        V v_r_2410 = (g_heff_2eelab_2eclauses_2epeelCols(v_vs_244, v_ps2_246, v_e_27_249));
        V v_t_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_27_248, heff_dup(heff_rfield(v_r_2410, 0))});
        return ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_r_2410, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_ps_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epeelCols(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_str2, 1, "_");
Clo g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_entry, 7, 0};

V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_p_246) {
top: ;
  switch (heff_tag_of(v_p_246)) {
  case TAG_PVar: {
    heff_take_n(v_p_246, 0ULL, 1);
    V v_t_248 = (g_heff_2eelab_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
    V v_v_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      v_v_2410 = ((V)&g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_str0);
      break;
    }
    case TAG_Just: {
      V v_v_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_v_2410 = v_v_249;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2411 = heff_rec_n(3, shape_arms__order__anys, (V[]){heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2412 = (g_heff_2eelab_2eclauses_2etagColGo(heff_dup(v_c_245), v_v_2410, v_t_2411, v_rows_244));
    HEFF_LAST return g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2412);
  }
  case TAG_PTag: {
    heff_take_n(v_p_246, 0ULL, 3);
    V v_t_2416 = (g_heff_2eelab_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
    V v_v_2418;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      v_v_2418 = ((V)&g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_str1);
      break;
    }
    case TAG_Just: {
      V v_v_2417 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      v_v_2418 = v_v_2417;
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_t_2419 = heff_rec_n(3, shape_arms__order__anys, (V[]){heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2420 = (g_heff_2eelab_2eclauses_2etagColGo(heff_dup(v_c_245), v_v_2418, v_t_2419, v_rows_244));
    HEFF_LAST return g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2420);
  }
  case TAG_PLit: {
    V v_l_2421 = heff_field(v_p_246, 0);
    V v_ru_24p_246_24PLit = heff_take_reuse_n(v_p_246, 1ULL, 1);
    V v_x1_2422 = (g_heff_2eelab_2eclauses_2enoRecMix(v_rows_244, heff_dup(v_c_245)));
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_Left: {
      V v_e_2423 = heff_field(v_x1_2422, 0);
      heff_take_n(v_x1_2422, 1ULL, 1);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      heff_drop(v_l_2421);
      return heff_tag_at_n(v_ru_24p_246_24PLit, TAG_Left, 1, (V[]){v_e_2423});
    }
    case TAG_Right: {
      heff_take_n(v_x1_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24p_246_24PLit, 1);
      return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_sp_242; V a_3 = v_vars_243; V a_4 = v_rows_244; V a_5 = v_c_245; V a_6 = v_l_2421; V r_ = (g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rows_244); r_; });
    }
    default: return heff_nomatch(v_x1_2422);
    }
  }
  case TAG_PRec: {
    heff_take_n(v_p_246, 0ULL, 2);
    return (g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245));
  }
  case TAG_PAs: {
    heff_take_n(v_p_246, 0ULL, 2);
    V v_t_2429 = (g_heff_2eelab_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
    V v_v_2431;
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      v_v_2431 = ((V)&g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_str2);
      break;
    }
    case TAG_Just: {
      V v_v_2430 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      v_v_2431 = v_v_2430;
      break;
    }
    default: heff_nomatch(v_t_2429);
    }
    V v_t_2432 = heff_rec_n(3, shape_arms__order__anys, (V[]){heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2433 = (g_heff_2eelab_2eclauses_2etagColGo(heff_dup(v_c_245), v_v_2431, v_t_2432, v_rows_244));
    HEFF_LAST return g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2433);
  }
  default: return heff_nomatch(v_p_246);
  }
}
V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2edesugarCols_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2edesugarCols_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2edesugarCols_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edesugarCols_entry, 5, 0};

V g_heff_2eelab_2eclauses_2edesugarCols(V v_params_240, V v_sp_241, V v_rows_242, V v_used_243, V v_cols_244) {
top: ;
  V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edesugarCols_lam0, 1, 1, (V[]){heff_dup(v_cols_244)}), v_rows_242));
  V v_x1_247 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(v_used_243, heff_dup(v_cols_244), heff_dup(v_sp_241), heff_dup(v_cols_244), v_t_246));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Left: {
    V v_e_248 = heff_field(v_x1_247, 0);
    V v_ru_24x1_247_24Left = heff_take_reuse_n(v_x1_247, 1ULL, 1);
    heff_drop_rec(v_sp_241, 2);
    heff_drop(v_cols_244);
    return heff_tag_at_n(v_ru_24x1_247_24Left, TAG_Left, 1, (V[]){v_e_248});
  }
  case TAG_Right: {
    V v_x_249 = heff_field(v_x1_247, 0);
    V v_ru_24x1_247_24Right = heff_take_reuse_n(v_x1_247, 1ULL, 1);
    V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_params_240));
    V v_t_2411 = (g_heff_2eelab_2eclauses_2edropC(v_t_2410, v_cols_244));
    V v_t_2418 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2edesugarCols_lam1, 2, 1, (V[]){v_sp_241}); V a_1 = v_x_249; V a_2 = v_t_2411; V r_ = heff_tr(g_heff_2eelab_2eclauses_2efoldr2(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
    return heff_tag_at_n(v_ru_24x1_247_24Right, TAG_Right, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2eelab_2eclauses_2edesugarCols_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2eelab_2eclauses_2edesugarCols(a0, a[1], a[2], a3, a[4]); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2eelab_2eclauses_2edesugarCols_lam0(V self, V *args) {
  V v_row_245 = args[0];
  V v_cols_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_cols_244, heff_dup(heff_rfield(v_row_245, 0)), heff_get_n(v_row_245, 1, 2)));
}
V g_heff_2eelab_2eclauses_2edesugarCols_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_b_2413 = args[1];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_2416;
  switch (heff_tag_of(v_b_2413)) {
  case TAG_At: {
    V v_s_2415 = heff_dup(heff_field(v_b_2413, 1));
    v_b_2416 = v_s_2415;
    break;
  }
  default: heff_nomatch(v_b_2413);
  }
  V v_t_2417 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_nf(v_b_2416, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2412, v_sp_241, v_b_2413}), v_t_2417});
}
Clo g_heff_2eelab_2eclauses_2etraverseC_24s1892599875x1770628292_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etraverseC_24s1892599875x1770628292_entry, 1, 0};

V g_heff_2eelab_2eclauses_2etraverseC_24s1892599875x1770628292(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_248 = heff_field(v_a_243, 3);
        heff_take_n(v_a_243, 12ULL, 4);
        V v_a_249 = (g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776(v_a_247));
        switch (heff_tag_of(v_a_249)) {
        case TAG_Left: {
          V v_a_2410 = heff_field(v_a_249, 0);
          V v_ru_24a_249_24Left = heff_take_reuse_n(v_a_249, 1ULL, 1);
          heff_drop(v_a_248);
          v_x1_2412 = heff_tag_at_n(v_ru_24a_249_24Left, TAG_Left, 1, (V[]){v_a_2410});
          break;
        }
        case TAG_Right: {
          V v_a_2411 = heff_field(v_a_249, 0);
          V v_ru_24a_249_24Right = heff_take_reuse_n(v_a_249, 1ULL, 1);
          v_x1_2412 = heff_tag_at_n(v_ru_24a_249_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_a_2411, v_a_248})});
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x1_2412, 0);
      V v_ru_24x1_2412_24Left = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
      heff_drop(v_xs_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_tag_at_n(v_ru_24x1_2412_24Left, TAG_Left, 1, (V[]){v_e_2413});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x1_2412, 0);
      V v_ru_24x1_2412_24Right = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
      V v_x1_2415 = (g_heff_2eelab_2eclauses_2etraverseC_24s1892599875x1770628292(v_xs_242));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_Left: {
        V v_e_2416 = heff_field(v_x1_2415, 0);
        heff_take_n(v_x1_2415, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_x_2414);
        return heff_tag_at_n(v_ru_24x1_2412_24Right, TAG_Left, 1, (V[]){v_e_2416});
      }
      case TAG_Right: {
        V v_x_2417 = heff_field(v_x1_2415, 0);
        heff_take_n(v_x1_2415, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2412_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2414, v_x_2417})});
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_x1_2412);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2etraverseC_24s1892599875x1770628292_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etraverseC_24s1892599875x1770628292(a[0]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_str0, 43, "a definition by equations needs an equation");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_str1, 11, " pattern(s)");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_str2, 6, "` has ");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_str3, 19, "every equation of `");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_str4, 18, "the equations of `");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_str5, 37, "` match fewer arguments than it names");
V g_heff_2eelab_2eclauses_2edesugar_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2edesugar_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2edesugar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edesugar_entry, 4, 0};

V g_heff_2eelab_2eclauses_2edesugar(V v_f_240, V v_params_241, V v_eqNs_242, V v_sp_243) {
top: ;
  V v_x1_244 = (g_heff_2eelab_2eclauses_2etraverseC_24s1892599875x1770628292(v_eqNs_242));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Left: {
    V v_e_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Left = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_f_240);
    heff_drop(v_params_241);
    heff_drop(v_sp_243);
    return heff_tag_at_n(v_ru_24x1_244_24Left, TAG_Left, 1, (V[]){v_e_245});
  }
  case TAG_Right: {
    V v_x_246 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Right = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_2410;
    switch (heff_tag_of(v_x_246)) {
    case TAG_Nil: {
      v_x1_2410 = heff_tag_at_n(v_ru_24x1_244_24Right, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){heff_dup(v_sp_243), ((V)&g_heff_2eelab_2eclauses_2edesugar_str0)})});
      break;
    }
    case TAG_Cons: {
      V v_r_247 = heff_dup(heff_field(v_x_246, 0));
      V v_t_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_r_247, 0, 2); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      v_x1_2410 = heff_tag_at_n(v_ru_24x1_244_24Right, TAG_Right, 1, (V[]){v_t_249});
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x1_2410, 0);
      V v_ru_24x1_2410_24Left = heff_take_reuse_n(v_x1_2410, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_params_241);
      heff_drop(v_sp_243);
      heff_drop(v_x_246);
      return heff_tag_at_n(v_ru_24x1_2410_24Left, TAG_Left, 1, (V[]){v_e_2411});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x1_2410, 0);
      V v_ru_24x1_2410_24Right = heff_take_reuse_n(v_x1_2410, 1ULL, 1);
      V v_x1_2423 = (g_heff_2eelab_2eclauses_2eforC(v_x_246, heff_clo_n(g_heff_2eelab_2eclauses_2edesugar_lam0, 1, 2, (V[]){heff_dup(v_x_2412), heff_dup(v_f_240)})));
      switch (heff_tag_of(v_x1_2423)) {
      case TAG_Left: {
        V v_e_2424 = heff_field(v_x1_2423, 0);
        heff_take_n(v_x1_2423, 1ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_params_241);
        heff_drop(v_sp_243);
        heff_drop(v_x_246);
        heff_drop(v_x_2412);
        return heff_tag_at_n(v_ru_24x1_2410_24Right, TAG_Left, 1, (V[]){v_e_2424});
      }
      case TAG_Right: {
        V v_ru_24x1_2423_24Right = heff_take_reuse_n(v_x1_2423, 0ULL, 1);
        V v_t_2426 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_params_241));
        V v_e_2429;
        if (heff_intLt_c(heff_dup(v_x_2412), v_t_2426)) {
          V v_t_2428 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2edesugar_str4), heff_strAppend(heff_dup(v_f_240), ((V)&g_heff_2eelab_2eclauses_2edesugar_str5)));
          v_e_2429 = heff_tag_at_n(v_ru_24x1_2410_24Right, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){heff_dup(v_sp_243), v_t_2428})});
        } else {
          v_e_2429 = heff_tag_at_n(v_ru_24x1_2410_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        switch (heff_tag_of(v_e_2429)) {
        case TAG_Left: {
          V v_e_2430 = heff_field(v_e_2429, 0);
          heff_take_n(v_e_2429, 1ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_params_241);
          heff_drop(v_sp_243);
          heff_drop(v_x_246);
          heff_drop(v_x_2412);
          return heff_tag_at_n(v_ru_24x1_2423_24Right, TAG_Left, 1, (V[]){v_e_2430});
        }
        case TAG_Right: {
          heff_take_n(v_e_2429, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2423_24Right, 1);
          V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, NTAG(TAG_Nil)});
          V v_t_2433 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_params_241), v_t_2432));
          V v_used_2434 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(v_x_246, v_t_2433));
          V v_t_2435 = (g_heff_2eelab_2eclauses_2eupToGo(MK_INT(0LL), v_x_2412));
          V v_t_2437 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edesugar_lam1, 1, 3, (V[]){heff_dup(v_used_2434), heff_dup(v_params_241), heff_dup(v_x_246)}), v_t_2435));
          return ({ V a_0 = v_params_241; V a_1 = v_sp_243; V a_2 = v_x_246; V a_3 = v_used_2434; V a_4 = v_t_2437; V r_ = (g_heff_2eelab_2eclauses_2edesugarCols(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_params_241); heff_drop(v_used_2434); r_; });
        }
        default: return heff_nomatch(v_e_2429);
        }
      }
      default: return heff_nomatch(v_x1_2423);
      }
    }
    default: return heff_nomatch(v_x1_2410);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2eelab_2eclauses_2edesugar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2edesugar(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eclauses_2edesugar_lam0(V self, V *args) {
  V v_r_2413 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_r_2413, 0)));
  if (heff_intEq_c(v_t_2414, heff_dup(v_x_2412))) {
    heff_drop_rec(v_r_2413, 2);
    heff_drop(v_x_2412);
    heff_drop(v_f_240);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  } else {
    V v_t_2416 = heff_get_n(v_r_2413, 1, 2);
    V v_span_2419;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_At: {
      V v_s_2418 = heff_field(v_t_2416, 1);
      heff_take_n(v_t_2416, 2ULL, 2);
      v_span_2419 = v_s_2418;
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_t_2420 = heff_strAppend(heff_intShow(v_x_2412), ((V)&g_heff_2eelab_2eclauses_2edesugar_str1));
    V v_t_2421 = heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2edesugar_str2), v_t_2420));
    V v_t_2422 = heff_rec_n(2, shape_span__msg, (V[]){v_span_2419, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2edesugar_str3), v_t_2421)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2422});
  }
}
V g_heff_2eelab_2eclauses_2edesugar_lam1(V self, V *args) {
  V v_i_2436 = args[0];
  V v_used_2434 = heff_env(self)[0];
  V v_params_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_used_2434; V a_1 = v_params_241; V a_2 = v_x_246; V a_3 = v_i_2436; V r_ = (g_heff_2eelab_2eclauses_2ecolName(a_0, a_1, a_2, a_3)); heff_drop(v_used_2434); heff_drop(v_params_241); r_; });
}