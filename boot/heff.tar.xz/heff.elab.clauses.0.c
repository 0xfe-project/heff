// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgEvidence 24309
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648 39892
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_PAs 26446
#define TAG_PBin 33976
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define LBL_bits 9519565
#define LBL_chk 308000
#define LBL_decl 9574769
#define LBL_end 310101
#define LBL_flags 298871457
#define LBL_go 10063
#define LBL_inf 313947
#define LBL_len 316559
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_scrutinee 73860976
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_terms 311608737
#define LBL_tree 10063973
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_v 336
#define LBL_value 313331083
#define LBL_x 338
static uint32_t shape_bits__terms[] = {LBL_bits, LBL_terms};
static uint32_t shape_inf__chk__typ__decl[] = {LBL_inf, LBL_chk, LBL_typ, LBL_decl};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_scrutinee__tree[] = {LBL_scrutinee, LBL_tree};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eclauses_2eallC(V, V);
V g_heff_2eelab_2eclauses_2eallC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eallC_clo;
V g_heff_2eelab_2eclauses_2eandC(V, V, V);
V g_heff_2eelab_2eclauses_2eandC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eandC_clo;
V g_heff_2eelab_2eclauses_2eandC_24tok3(V, V, V, V);
V g_heff_2eelab_2eclauses_2eandC_24tok3_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eandC_24tok3_clo;
V g_heff_2eelab_2eclauses_2eanyC(V, V);
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_clo;
V g_heff_2eelab_2eclauses_2eappendC(V, V);
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120(V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_clo;
V g_heff_2eelab_2eclauses_2eappendC_24tok2(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24tok2_clo;
V g_heff_2eelab_2eclauses_2earmSub(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmSub_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmSub_clo;
V g_heff_2eelab_2eclauses_2earmSubName(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmSubName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmSubName_clo;
V g_heff_2eelab_2eclauses_2easBitsC(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2easBitsC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2easBitsC_clo;
V g_heff_2eelab_2eclauses_2ebinBind(V);
V g_heff_2eelab_2eclauses_2ebinBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinBind_clo;
HeffT2 g_heff_2eelab_2eclauses_2ebinChecks_24cpr(V, V, V);
V g_heff_2eelab_2eclauses_2ebinTestGo(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ebinTestGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTestGo_clo;
V g_heff_2eelab_2eclauses_2ebinTestOf(V, V, V);
V g_heff_2eelab_2eclauses_2ebinTestOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTestOf_clo;
HeffT2 g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr(V, V, V, V, V, V, V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecatMaybesC(V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo;
V g_heff_2eelab_2eclauses_2ecatMaybesC_24dps(V, V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_clo;
V g_heff_2eelab_2eclauses_2ecodeTest(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecodeTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecodeTest_clo;
V g_heff_2eelab_2eclauses_2ecolFrom(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolFrom_clo;
V g_heff_2eelab_2eclauses_2ecolPick(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolPick_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolPick_clo;
HeffT2 g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2econcatMapC(V, V);
V g_heff_2eelab_2eclauses_2econcatMapC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_clo;
V g_heff_2eelab_2eclauses_2edropC(V, V);
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropC_clo;
V g_heff_2eelab_2eclauses_2efloatRead(V, V, V, V);
V g_heff_2eelab_2eclauses_2efloatRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efloatRead_clo;
V g_heff_2eelab_2eclauses_2efloatTest(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2efloatTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efloatTest_clo;
V g_heff_2eelab_2eclauses_2efreshIn(V, V, V);
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efreshIn_clo;
V g_heff_2eelab_2eclauses_2eidents_get(void);
V g_heff_2eelab_2eclauses_2eidentsChkF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_clo;
V g_heff_2eelab_2eclauses_2eidentsDeclF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsDeclF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsDeclF_clo;
V g_heff_2eelab_2eclauses_2eidentsInfF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsInfF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsInfF_clo;
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(V, V);
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_clo;
V g_heff_2eelab_2eclauses_2eintRead(V, V, V, V);
V g_heff_2eelab_2eclauses_2eintRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eintRead_clo;
V g_heff_2eelab_2eclauses_2elookupField(V, V);
V g_heff_2eelab_2eclauses_2elookupField_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elookupField_clo;
HeffT2 g_heff_2eelab_2eclauses_2elookupField_24cpr(V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC(V, V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2emapWithIndexC_clo;
V g_heff_2eelab_2eclauses_2enameFits(V, V, V);
V g_heff_2eelab_2eclauses_2enameFits_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enameFits_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll(V, V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_clo;
HeffT2 g_heff_2eelab_2eclauses_2enthC_24cpr(V, V);
V g_heff_2eelab_2eclauses_2enubStr(V);
V g_heff_2eelab_2eclauses_2enubStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_clo;
V g_heff_2eelab_2eclauses_2enubStr_24dps(V, V);
V g_heff_2eelab_2eclauses_2enubStr_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_24dps_clo;
V g_heff_2eelab_2eclauses_2eoffC(V, V);
V g_heff_2eelab_2eclauses_2eoffC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eoffC_clo;
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatBinds_24dps(V, V);
V g_heff_2eelab_2eclauses_2epatBinds_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_24dps_clo;
V g_heff_2eelab_2eclauses_2epatBinds_24tok2(V, V);
V g_heff_2eelab_2eclauses_2epatBinds_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_24tok2_clo;
V g_heff_2eelab_2eclauses_2epatIdents(V, V);
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_clo;
V g_heff_2eelab_2eclauses_2epatIdents_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2epatIdents_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_24dps_clo;
V g_heff_2eelab_2eclauses_2epatIdents_24tok2(V, V, V);
V g_heff_2eelab_2eclauses_2epatIdents_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_24tok2_clo;
V g_heff_2eelab_2eclauses_2epatVars(V);
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_clo;
V g_heff_2eelab_2eclauses_2epatVars_24dps(V, V);
V g_heff_2eelab_2eclauses_2epatVars_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_24dps_clo;
V g_heff_2eelab_2eclauses_2epeelCols(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelCols_clo;
HeffT2 g_heff_2eelab_2eclauses_2epeelCols_24cpr(V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents(V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_clo;
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_clo;
V g_heff_2eelab_2eclauses_2erecSpecialize(V, V, V, V);
V g_heff_2eelab_2eclauses_2erecSpecialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecSpecialize_clo;
V g_heff_2eelab_2eclauses_2erenameEquation(V, V);
V g_heff_2eelab_2eclauses_2erenameEquation_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameEquation_clo;
V g_heff_2eelab_2eclauses_2erenameInfF(V, V);
V g_heff_2eelab_2eclauses_2erenameInfF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameInfF_clo;
V g_heff_2eelab_2eclauses_2erenamePi(V, V);
V g_heff_2eelab_2eclauses_2erenamePi_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamePi_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eclauses_2erestC(V, V);
V g_heff_2eelab_2eclauses_2erestC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erestC_clo;
V g_heff_2eelab_2eclauses_2esegTest(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esegTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esegTest_clo;
V g_heff_2eelab_2eclauses_2etakeC(V, V);
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_clo;
V g_heff_2eelab_2eclauses_2ewholeBin(V, V);
V g_heff_2eelab_2eclauses_2ewholeBin_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ewholeBin_clo;
V g_heff_2eelab_2eclauses_2ewidthBy(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ewidthBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ewidthBy_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1846289357x1055790465(V, V);
V g_list_2emap_24s1846289357x1055790465_entry(V self, V *a);
extern Clo g_list_2emap_24s1846289357x1055790465_clo;
V g_list_2emap_24s502656580x1955732096(V);
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_clo;
V g_list_2emap_24s796727596x829078925(V);
V g_list_2emap_24s796727596x829078925_entry(V self, V *a);
extern Clo g_list_2emap_24s796727596x829078925_clo;
V g_list_2emap_24s939813003x1383013550(V);
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_heff_2eelab_2eclauses_2econcatMapC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2econcatMapC(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2eclauses_2econcatMapC(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2eclauses_2eappendC(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2econcatMapC(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecatMaybesC_entry, 1, 0};

V g_heff_2eelab_2eclauses_2ecatMaybesC(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2eclauses_2ecatMaybesC_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecatMaybesC(a[0]);
}
Clo g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_entry, 2, 0};

V g_heff_2eelab_2eclauses_2ecatMaybesC_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecatMaybesC_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2enubStr_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enubStr_24dps_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enubStr_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2enubStr_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enubStr_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2epatVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatVars_entry, 1, 0};

V g_heff_2eelab_2eclauses_2epatVars(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PVar: {
    V v_x_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
  }
  case TAG_PTag: {
    V v_ps_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    return ({ V a_0 = v_ps_243; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a_0)); heff_drop(v_ps_243); r_; });
  }
  case TAG_PLit: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PRec: {
    V v_fps_246 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    return ({ V a_0 = v_fps_246; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a_0)); heff_drop(v_fps_246); r_; });
  }
  case TAG_PAs: {
    V v_x_248 = heff_field(v_x1_240, 0);
    V v_p_249 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24PAs = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x1_240_24PAs, TAG_Cons, 2, (V[]){v_x_248, heff_hole()});
    V v_u_2411 = (g_heff_2eelab_2eclauses_2epatVars_24dps(v_p_249, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  case TAG_PBin: {
    V v_segs_2412 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24PBin = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    V v_t_2414 = (g_list_2emap_24s502656580x1955732096(heff_dup(v_segs_2412)));
    V v_t_2415 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2414));
    V v_t_2416 = (g_list_2emap_24s939813003x1383013550(v_segs_2412));
    V v_t_2417 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2416));
    return (g_heff_2eelab_2eclauses_2eappendC_24tok2(v_ru_24x1_240_24PBin, v_t_2415, v_t_2417));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatVars(a[0]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_248 = heff_field(v_a_244, 2);
        heff_take_n(v_a_244, 5ULL, 5);
        V v_t_2415;
        switch (heff_tag_of(v_a_248)) {
        case TAG_SizeDefault: {
          v_t_2415 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SizeNumber: {
          heff_take_n(v_a_248, 0ULL, 1);
          v_t_2415 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SizeName: {
          V v_a_2412 = heff_field(v_a_248, 0);
          heff_take_n(v_a_248, 1ULL, 3);
          v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_a_2412});
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        V v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
        V v_t_2417 = (g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120(v_acc_241, v_t_2416));
        v_t_2418 = (g_heff_2eelab_2eclauses_2epatIdents_24tok2(v_ru_24x_242_24At, v_a_246, v_t_2417));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2418;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2epiIdents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epiIdents_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epiIdents(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  V v_typ_243 = heff_take_field(v_r_240, 2);
  V v_chk_244 = heff_get_n(v_r_240, 1, 4);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_245 = heff_field(v_x2_241, 0);
    V v_t_247 = heff_field(v_x2_241, 2);
    heff_drop(v_chk_244);
    V v_t_248 = heff_tr(heff_call(v_typ_243, 2, (V[]){heff_dup(v_t_247), v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_t_248});
  }
  case TAG_PiImplicit: {
    V v_x_249 = heff_field(v_x2_241, 0);
    V v_t_2412 = heff_field(v_x2_241, 3);
    V v_d_2413 = heff_field(v_x2_241, 4);
    V v_t_2415;
    switch (heff_tag_of(v_d_2413)) {
    case TAG_Nothing: {
      heff_drop(v_chk_244);
      v_t_2415 = v_acc_242;
      break;
    }
    case TAG_Just: {
      V v_c_2414 = heff_field(v_d_2413, 0);
      v_t_2415 = heff_tr(heff_call(v_chk_244, 2, (V[]){heff_dup(v_c_2414), v_acc_242}));
      break;
    }
    default: heff_nomatch(v_d_2413);
    }
    V v_t_2416 = heff_tr(heff_call(v_typ_243, 2, (V[]){heff_dup(v_t_2412), v_t_2415}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_249), v_t_2416});
  }
  case TAG_PiInstance: {
    V v_x_2417 = heff_field(v_x2_241, 0);
    V v_t_2420 = heff_field(v_x2_241, 3);
    heff_drop(v_chk_244);
    V v_t_2421 = heff_tr(heff_call(v_typ_243, 2, (V[]){heff_dup(v_t_2420), v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2417), v_t_2421});
  }
  case TAG_PiAnon: {
    V v_d_2422 = heff_field(v_x2_241, 0);
    heff_drop(v_chk_244);
    return heff_tail(v_typ_243, 2, (V[]){heff_dup(v_d_2422), v_acc_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2epiIdents_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2epiIdents(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2epatIdents(heff_dup(v_x_242), v_acc_241));
    V t_0 = v_xs_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2eidentsInfF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsInfF_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsInfF_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsInfF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsInfF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsInfF(V v_r_240, V v_n_241, V v_acc_242) {
top: ;
  V v_inf_243 = heff_take_field(v_r_240, 0);
  V v_chk_244 = heff_take_field(v_r_240, 1);
  V v_typ_245 = heff_get_n(v_r_240, 2, 4);
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_n1_246)) {
    case TAG_IVar: {
      V v_x_248 = heff_field(v_n1_246, 0);
      heff_take_n(v_n1_246, 1ULL, 1);
      heff_drop(v_inf_243);
      heff_drop(v_chk_244);
      heff_drop(v_typ_245);
      return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_248, v_acc_242});
    }
    case TAG_IInt: {
      heff_take_n(v_n1_246, 0ULL, 1);
      heff_drop(v_inf_243);
      heff_drop(v_chk_244);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IFloat: {
      heff_take_na(v_n1_246, 0ULL, 1);
      heff_drop(v_inf_243);
      heff_drop(v_chk_244);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IString: {
      heff_take_n(v_n1_246, 0ULL, 1);
      heff_drop(v_inf_243);
      heff_drop(v_chk_244);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IBytes: {
      heff_take_n(v_n1_246, 0ULL, 1);
      heff_drop(v_inf_243);
      heff_drop(v_chk_244);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IPrim: {
      heff_take_n(v_n1_246, 0ULL, 1);
      heff_drop(v_inf_243);
      heff_drop(v_chk_244);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IRune: {
      heff_take_n(v_n1_246, 0ULL, 1);
      heff_drop(v_inf_243);
      heff_drop(v_chk_244);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IApp: {
      V v_h_2415 = heff_field(v_n1_246, 0);
      V v_args_2416 = heff_field(v_n1_246, 1);
      heff_take_n(v_n1_246, 3ULL, 2);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2427 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsInfF_lam0, 2, 1, (V[]){v_chk_244}); V a_1 = v_args_2416; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2416); r_; });
      return heff_tail(v_inf_243, 2, (V[]){v_h_2415, v_t_2427});
    }
    case TAG_IAnn: {
      V v_c_2428 = heff_field(v_n1_246, 0);
      V v_t_2429 = heff_field(v_n1_246, 1);
      heff_take_n(v_n1_246, 3ULL, 2);
      heff_drop(v_inf_243);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2430 = heff_tr(heff_call(v_typ_245, 2, (V[]){v_t_2429, v_acc_242}));
      return heff_tail(v_chk_244, 2, (V[]){v_c_2428, v_t_2430});
    }
    case TAG_ISpec: {
      V v_a_2431 = heff_field(v_n1_246, 0);
      V v_v_2434 = heff_field(v_n1_246, 3);
      heff_take_n(v_n1_246, 9ULL, 4);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2435 = heff_tr(heff_call(v_chk_244, 2, (V[]){v_v_2434, v_acc_242}));
      return heff_tail(v_inf_243, 2, (V[]){v_a_2431, v_t_2435});
    }
    case TAG_IUpdate: {
      V v_a_2436 = heff_field(v_n1_246, 0);
      V v_fs_2437 = heff_field(v_n1_246, 1);
      heff_take_n(v_n1_246, 3ULL, 2);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2446 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsInfF_lam1, 2, 1, (V[]){v_chk_244}); V a_1 = v_fs_2437; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_fs_2437); r_; });
      return heff_tail(v_inf_243, 2, (V[]){v_a_2436, v_t_2446});
    }
    case TAG_IAnnLam: {
      V v_x_2447 = heff_field(v_n1_246, 0);
      V v_t_2449 = heff_field(v_n1_246, 2);
      V v_b_2450 = heff_field(v_n1_246, 3);
      heff_take_n(v_n1_246, 13ULL, 4);
      heff_drop(v_chk_244);
      V v_t_2451 = heff_tr(heff_call(v_inf_243, 2, (V[]){v_b_2450, v_acc_242}));
      V v_t_2452 = heff_tr(heff_call(v_typ_245, 2, (V[]){v_t_2449, v_t_2451}));
      return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2447, v_t_2452});
    }
    case TAG_IInvalid: {
      heff_take_n(v_n1_246, 0ULL, 3);
      heff_drop(v_inf_243);
      heff_drop(v_chk_244);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_INominal: {
      V v_i_2456 = heff_field(v_n1_246, 0);
      heff_take_n(v_n1_246, 1ULL, 1);
      heff_drop(v_chk_244);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return heff_tail(v_inf_243, 2, (V[]){v_i_2456, v_acc_242});
    }
    case TAG_ILitEq: {
      V v_x_2457 = heff_field(v_n1_246, 0);
      V v_eq_2459 = heff_field(v_n1_246, 2);
      V v_lit_2460 = heff_field(v_n1_246, 3);
      heff_take_n(v_n1_246, 13ULL, 4);
      heff_drop(v_inf_243);
      heff_drop(v_typ_245);
      V v_t_2461 = heff_tr(heff_call(v_chk_244, 2, (V[]){v_lit_2460, v_acc_242}));
      return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2457, heff_tag_n(TAG_Cons, 2, (V[]){v_eq_2459, v_t_2461})});
    }
    case TAG_ILazy: {
      V v_c_2462 = heff_field(v_n1_246, 0);
      heff_take_n(v_n1_246, 1ULL, 1);
      heff_drop(v_inf_243);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return heff_tail(v_chk_244, 2, (V[]){v_c_2462, v_acc_242});
    }
    case TAG_ITuple: {
      V v_cs_2463 = heff_field(v_n1_246, 0);
      heff_take_n(v_n1_246, 1ULL, 1);
      heff_drop(v_inf_243);
      heff_drop(v_typ_245);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2464 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_2463));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsInfF_lam2, 2, 1, (V[]){v_chk_244}); V a_1 = v_acc_242; V a_2 = v_t_2464; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2464); r_; });
    }
    default: return heff_nomatch(v_n1_246);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsInfF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsInfF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsInfF_lam0(V self, V *args) {
  V v_x2_2417 = args[0];
  V v_acc_2418 = args[1];
  V v_chk_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_At: {
    V v_x21_2419 = heff_field(v_x2_2417, 0);
    V v_ru_24x2_2417_24At = heff_take_reuse_n(v_x2_2417, 1ULL, 2);
    switch (heff_tag_of(v_x21_2419)) {
    case TAG_ArgExplicit: {
      V v_c_2421 = heff_field(v_x21_2419, 0);
      heff_take_n(v_x21_2419, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_2417_24At, 2);
      V f_ = v_chk_244;
      args[0] = v_c_2421;
      args[1] = v_acc_2418;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_ArgProject: {
      heff_take_n(v_x21_2419, 0ULL, 1);
      heff_drop(v_chk_244);
      heff_drop_cell(v_ru_24x2_2417_24At, 2);
      return v_acc_2418;
    }
    case TAG_ArgNamed: {
      V v_x_2423 = heff_field(v_x21_2419, 0);
      V v_c_2424 = heff_field(v_x21_2419, 1);
      heff_take_n(v_x21_2419, 3ULL, 2);
      V v_t_2425 = heff_tr(heff_call(v_chk_244, 2, (V[]){v_c_2424, v_acc_2418}));
      return heff_tag_at_n(v_ru_24x2_2417_24At, TAG_Cons, 2, (V[]){v_x_2423, v_t_2425});
    }
    case TAG_ArgEvidence: {
      V v_x_2426 = heff_field(v_x21_2419, 0);
      heff_take_n(v_x21_2419, 1ULL, 1);
      heff_drop(v_chk_244);
      return heff_tag_at_n(v_ru_24x2_2417_24At, TAG_Cons, 2, (V[]){v_x_2426, v_acc_2418});
    }
    default: return heff_nomatch(v_x21_2419);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2eelab_2eclauses_2eidentsInfF_lam1(V self, V *args) {
  V v_x2_2438 = args[0];
  V v_acc_2439 = args[1];
  V v_chk_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_At: {
    V v_x21_2440 = heff_field(v_x2_2438, 0);
    V v_ru_24x2_2438_24At = heff_take_reuse_n(v_x2_2438, 1ULL, 2);
    switch (heff_tag_of(v_x21_2440)) {
    case TAG_SetPath: {
      V v_path_2442 = heff_field(v_x21_2440, 0);
      V v_e_2443 = heff_field(v_x21_2440, 1);
      heff_take_n(v_x21_2440, 3ULL, 2);
      V v_t_2444 = (g_list_2emap_24s1415906091x1371825187(v_path_2442));
      V v_t_2445 = heff_tr(heff_call(v_chk_244, 2, (V[]){v_e_2443, v_acc_2439}));
      return (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_2438_24At, v_t_2444, v_t_2445));
    }
    default: return heff_nomatch(v_x21_2440);
    }
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2eelab_2eclauses_2eidentsInfF_lam2(V self, V *args) {
  V v_acc_2465 = args[0];
  V v_x_2466 = args[1];
  V v_chk_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_chk_244;
  args[0] = v_x_2466;
  args[1] = v_acc_2465;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eclauses_2eidents_lam0(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam0, 2, 0};
V g_heff_2eelab_2eclauses_2eidents_lam1(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam1, 2, 0};
V g_heff_2eelab_2eclauses_2eidents_lam2(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam2, 2, 0};
V g_heff_2eelab_2eclauses_2eidents_lam3(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam3, 2, 0};

static V g_heff_2eelab_2eclauses_2eidents_val;
static HEFF_ONCE g_heff_2eelab_2eclauses_2eidents_st;
static V g_heff_2eelab_2eclauses_2eidents_init(void) {
  return heff_rec_n(4, shape_inf__chk__typ__decl, (V[]){((V)&g_heff_2eelab_2eclauses_2eidents_lam0_clo), ((V)&g_heff_2eelab_2eclauses_2eidents_lam1_clo), ((V)&g_heff_2eelab_2eclauses_2eidents_lam2_clo), ((V)&g_heff_2eelab_2eclauses_2eidents_lam3_clo)});
}
V g_heff_2eelab_2eclauses_2eidents_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eclauses_2eidents_st)) return g_heff_2eelab_2eclauses_2eidents_val;
  return heff_global(&g_heff_2eelab_2eclauses_2eidents_val, &g_heff_2eelab_2eclauses_2eidents_st, g_heff_2eelab_2eclauses_2eidents_init);
}
V g_heff_2eelab_2eclauses_2eidents_lam0(V self, V *args) {
  V v_n_240 = args[0];
  V v_acc_241 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsInfF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_n_240, v_acc_241));
}
V g_heff_2eelab_2eclauses_2eidents_lam1(V self, V *args) {
  V v_n_242 = args[0];
  V v_acc_243 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsChkF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_n_242, v_acc_243));
}
V g_heff_2eelab_2eclauses_2eidents_lam2(V self, V *args) {
  V v_n_244 = args[0];
  V v_acc_245 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsTypF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_n_244, v_acc_245));
}
V g_heff_2eelab_2eclauses_2eidents_lam3(V self, V *args) {
  V v_d_246 = args[0];
  V v_acc_247 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsDeclF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_d_246, v_acc_247));
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2410 = (g_heff_2eelab_2eclauses_2enamesOfAll(heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 2)), v_a_248, v_acc_241));
        break;
      }
      case TAG_BadVariant: {
        V v_a_249 = heff_field(v_a_244, 0);
        v_t_2410 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(heff_dup(v_a_249), v_acc_241));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2410;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str5, 0, "");
Clo g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(V v_n_240, V v_acc_241) {
top: ;
  return (g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle(NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648), ((V)&g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str0), ((V)&g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str1), ((V)&g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str2), ((V)&g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str3), v_n_240, v_acc_241, ((V)&g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str4), ((V)&g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str5)));
}
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(V v_x2_240, V v_acc_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 1ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_CInf: {
      V v_i_245 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_246 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_i_245, v_acc_241));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
    }
    case TAG_CType: {
      V v_t_247 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_248 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_247, v_acc_241));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_248);
    }
    case TAG_CLam: {
      V v_x_249 = heff_field(v_x21_243, 0);
      V v_b_2411 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_x_249, heff_hole()});
      V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_b_2411;
      V t_1 = v_acc_241;
      V t_2 = v_cell_2412;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CImplicitLam: {
      V v_x_2414 = heff_field(v_x21_243, 0);
      V v_b_2416 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_x_2414, heff_hole()});
      V v_u_2418 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_b_2416;
      V t_1 = v_acc_241;
      V t_2 = v_cell_2417;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CAnnLam: {
      V v_x_2419 = heff_field(v_x21_243, 0);
      V v_t_2421 = heff_field(v_x21_243, 2);
      V v_b_2422 = heff_field(v_x21_243, 3);
      heff_take_n(v_x21_243, 13ULL, 4);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2423 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_2422, v_acc_241));
      V v_t_2424 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_2421, v_acc_2423));
      return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2419, v_t_2424}));
    }
    case TAG_CTag: {
      V v_args_2427 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 4ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2428 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 1)); V a_1 = v_args_2427; V a_2 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2427); r_; });
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2428);
    }
    case TAG_CStruct: {
      V v_fs_2429 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2430 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(v_fs_2429, v_acc_241));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2430);
    }
    case TAG_CMatch: {
      V v_s_2431 = heff_field(v_x21_243, 0);
      V v_alts_2432 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2433 = ({ V a_0 = v_alts_2432; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(a_0, a_1)); heff_drop(v_alts_2432); r_; });
      V v_t_2434 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_s_2431, v_acc_2433));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2434);
    }
    case TAG_CLetIn: {
      V v_rhs_2435 = heff_field(v_x21_243, 0);
      V v_a_2436 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      V v_acc_2442;
      switch (heff_tag_of(v_a_2436)) {
      case TAG_At: {
        V v_x21_2437 = heff_field(v_a_2436, 0);
        heff_take_n(v_a_2436, 1ULL, 2);
        switch (heff_tag_of(v_x21_2437)) {
        case TAG_MkAlt: {
          V v_p_2439 = heff_field(v_x21_2437, 0);
          V v_b_2440 = heff_field(v_x21_2437, 1);
          heff_take_n(v_x21_2437, 3ULL, 2);
          V v_t_2441 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_2440, v_acc_241));
          v_acc_2442 = (g_heff_2eelab_2eclauses_2epatIdents_24tok2(v_ru_24x2_240_24At, v_p_2439, v_t_2441));
          break;
        }
        default: heff_nomatch(v_x21_2437);
        }
        break;
      }
      default: heff_nomatch(v_a_2436);
      }
      V v_t_2443 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_rhs_2435, v_acc_2442));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2443);
    }
    case TAG_CLocal: {
      V v_body_2444 = heff_field(v_x21_243, 0);
      V v_ds_2445 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2446 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 3)); V a_1 = v_ds_2445; V a_2 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ds_2445); r_; });
      V t_0 = v_body_2444;
      V t_1 = v_acc_2446;
      V t_2 = v_d_242;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CAbandon: {
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_CNominal: {
      V v_c_2447 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V t_0 = v_c_2447;
      V t_1 = v_acc_241;
      V t_2 = v_d_242;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(v_acc_241, heff_dup(v_x_242)));
    V t_0 = v_xs_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efreshIn_str0, 1, "'");
HEFF_LIT(g_heff_2eelab_2eclauses_2efreshIn_str1, 1, "'");
Clo g_heff_2eelab_2eclauses_2efreshIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efreshIn_entry, 3, 0};

V g_heff_2eelab_2eclauses_2efreshIn(V v_used_240, V v_bound_241, V v_x_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
  V v_t_244 = (g_list_2eany(v_t_243, v_used_240));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V t_0 = v_used_240;
    V t_1 = v_bound_241;
    V t_2 = heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2eclauses_2efreshIn_str0));
    v_used_240 = t_0;
    v_bound_241 = t_1;
    v_x_242 = t_2;
    goto top;
  } else {
    heff_drop(v_t_244);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_bound_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_used_240;
      V t_1 = v_bound_241;
      V t_2 = heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2eclauses_2efreshIn_str1));
      v_used_240 = t_0;
      v_bound_241 = t_1;
      v_x_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_246);
      return v_x_242;
    }
  }
}
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2efreshIn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2epatBinds_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatBinds_24dps_entry, 2, 0};

V g_heff_2eelab_2eclauses_2epatBinds_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      V v_t_245 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
      return heff_setField(v_d_241, MK_INT(1LL), v_t_245);
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_249 = ({ V a_0 = v_ps_248; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_248); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_249);
    }
    case TAG_PatOp: {
      V v_ps_2412 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2413 = ({ V a_0 = v_ps_2412; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_2412); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2413);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      V v_segs_2417 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2418 = ({ V a_0 = v_segs_2417; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(a_0)); heff_drop(v_segs_2417); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2418);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2420 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2421 = ({ V a_0 = v_fs_2420; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(a_0)); heff_drop(v_fs_2420); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2421);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2423 = heff_field(v_p1_242, 0);
      V v_q_2425 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 5ULL, 3);
      V v_cell_2426 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2423, heff_hole()});
      V v_u_2427 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2426));
      heff_drop(v_u_2427);
      V t_0 = v_q_2425;
      V t_1 = v_cell_2426;
      v_p_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatBinds_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatBinds_24dps(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameEquation_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameEquation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameEquation_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameEquation(V v_r_240, V v_x2_241) {
top: ;
  V v_x_242 = heff_take_field(v_r_240, 0);
  V v_chk_243 = heff_get_n(v_r_240, 3, 5);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_sp_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkEquation: {
      V v_f_246 = heff_field(v_x21_244, 0);
      V v_fsp_247 = heff_field(v_x21_244, 1);
      V v_ps_248 = heff_field(v_x21_244, 2);
      V v_rhs_249 = heff_field(v_x21_244, 3);
      heff_take_n(v_x21_244, 15ULL, 4);
      V v_t_2413 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2erenameEquation_lam0, 1, 1, (V[]){v_x_242}), v_ps_248));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_chk_243);
        heff_drop(v_t_2413);
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_246, v_fsp_247, v_ps_248, v_rhs_249}), v_sp_245});
      } else {
        heff_drop(v_t_2413);
        V v_t_2414 = heff_tr(heff_call(v_chk_243, 1, (V[]){v_rhs_249}));
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_246, v_fsp_247, v_ps_248, v_t_2414}), v_sp_245});
      }
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameEquation_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameEquation(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameEquation_lam0(V self, V *args) {
  V v_p_2410 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2411 = (g_heff_2eelab_2eclauses_2epatBinds(v_p_2410));
  V v_t_2412 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_x_242}));
  return ({ V a_0 = v_t_2412; V a_1 = v_xs_2411; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2411); r_; });
}
Clo g_heff_2eelab_2eclauses_2erenamePi_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenamePi_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenamePi(V v_r_240, V v_x2_241) {
top: ;
  V v_typ_242 = heff_take_field(v_r_240, 4);
  V v_chk_243 = heff_get_n(v_r_240, 3, 5);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_y_244 = heff_field(v_x2_241, 0);
    V v_ysp_245 = heff_field(v_x2_241, 1);
    V v_t_246 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    heff_drop(v_chk_243);
    V v_t_247 = heff_tr(heff_call(v_typ_242, 1, (V[]){v_t_246}));
    return heff_tag_at_n(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, (V[]){v_y_244, v_ysp_245, v_t_247});
  }
  case TAG_PiImplicit: {
    V v_y_248 = heff_field(v_x2_241, 0);
    V v_ysp_249 = heff_field(v_x2_241, 1);
    V v_bsp_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = heff_field(v_x2_241, 3);
    V v_d_2412 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_2413 = heff_tr(heff_call(v_typ_242, 1, (V[]){v_t_2411}));
    V v_t_2416;
    switch (heff_tag_of(v_d_2412)) {
    case TAG_Nothing: {
      heff_drop(v_chk_243);
      v_t_2416 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_c_2414 = heff_field(v_d_2412, 0);
      V v_ru_24d_2412_24Just = heff_take_reuse_n(v_d_2412, 1ULL, 1);
      V v_t_2415 = heff_tr(heff_call(v_chk_243, 1, (V[]){v_c_2414}));
      v_t_2416 = heff_tag_at_n(v_ru_24d_2412_24Just, TAG_Just, 1, (V[]){v_t_2415});
      break;
    }
    default: heff_nomatch(v_d_2412);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_y_248, v_ysp_249, v_bsp_2410, v_t_2413, v_t_2416});
  }
  case TAG_PiInstance: {
    V v_y_2417 = heff_field(v_x2_241, 0);
    V v_ysp_2418 = heff_field(v_x2_241, 1);
    V v_bsp_2419 = heff_field(v_x2_241, 2);
    V v_t_2420 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    heff_drop(v_chk_243);
    V v_t_2421 = heff_tr(heff_call(v_typ_242, 1, (V[]){v_t_2420}));
    return heff_tag_at_n(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, (V[]){v_y_2417, v_ysp_2418, v_bsp_2419, v_t_2421});
  }
  case TAG_PiAnon: {
    V v_d_2422 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    heff_drop(v_chk_243);
    V v_t_2423 = heff_tr(heff_call(v_typ_242, 1, (V[]){v_d_2422}));
    return heff_tag_at_n(v_ru_24x2_241_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2423});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenamePi_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenamePi(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameInfF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameInfF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameInfF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameInfF_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameInfF(V v_r_240, V v_n_241) {
top: ;
  V v_x_242 = heff_take_field(v_r_240, 0);
  V v_v_243 = heff_take_field(v_r_240, 1);
  V v_inf_244 = heff_take_field(v_r_240, 2);
  V v_chk_245 = heff_take_field(v_r_240, 3);
  V v_typ_246 = heff_get_n(v_r_240, 4, 5);
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_247 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_n1_247)) {
    case TAG_IVar: {
      V v_y_249 = heff_field(v_n1_247, 0);
      V v_ru_24n1_247_24IVar = heff_take_reuse_n(v_n1_247, 1ULL, 1);
      heff_drop(v_inf_244);
      heff_drop(v_chk_245);
      heff_drop(v_typ_246);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2411 = heff_dup(heff_field(v_n_241, 1));
        if (heff_strEq_c(v_y_249, v_x_242)) {
          heff_drop_tag(v_n_241, 2);
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_247_24IVar, TAG_IVar, 1, (V[]){v_v_243}), v_sp_2411});
        } else {
          heff_drop(v_v_243);
          heff_drop_cell(v_ru_24n1_247_24IVar, 1);
          heff_drop(v_sp_2411);
          return v_n_241;
        }
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_IInt: {
      heff_take_n(v_n1_247, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_inf_244);
      heff_drop(v_chk_245);
      heff_drop(v_typ_246);
      return v_n_241;
    }
    case TAG_IFloat: {
      heff_take_na(v_n1_247, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_inf_244);
      heff_drop(v_chk_245);
      heff_drop(v_typ_246);
      return v_n_241;
    }
    case TAG_IString: {
      heff_take_n(v_n1_247, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_inf_244);
      heff_drop(v_chk_245);
      heff_drop(v_typ_246);
      return v_n_241;
    }
    case TAG_IBytes: {
      heff_take_n(v_n1_247, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_inf_244);
      heff_drop(v_chk_245);
      heff_drop(v_typ_246);
      return v_n_241;
    }
    case TAG_IPrim: {
      heff_take_n(v_n1_247, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_inf_244);
      heff_drop(v_chk_245);
      heff_drop(v_typ_246);
      return v_n_241;
    }
    case TAG_IRune: {
      heff_take_n(v_n1_247, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_inf_244);
      heff_drop(v_chk_245);
      heff_drop(v_typ_246);
      return v_n_241;
    }
    case TAG_IApp: {
      V v_h_2418 = heff_field(v_n1_247, 0);
      V v_args_2419 = heff_field(v_n1_247, 1);
      V v_ru_24n1_247_24IApp = heff_take_reuse_n(v_n1_247, 3ULL, 2);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_typ_246);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2421 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2422 = heff_tr(heff_call(v_inf_244, 1, (V[]){v_h_2418}));
        V v_t_2437 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameInfF_lam0, 1, 1, (V[]){v_chk_245}), v_args_2419));
        return heff_tag_at_n(v_ru_24n_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_247_24IApp, TAG_IApp, 2, (V[]){v_t_2422, v_t_2437}), v_sp_2421});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_IAnn: {
      V v_c_2438 = heff_field(v_n1_247, 0);
      V v_t_2439 = heff_field(v_n1_247, 1);
      V v_ru_24n1_247_24IAnn = heff_take_reuse_n(v_n1_247, 3ULL, 2);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_inf_244);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2441 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2442 = heff_tr(heff_call(v_chk_245, 1, (V[]){v_c_2438}));
        V v_t_2443 = heff_tr(heff_call(v_typ_246, 1, (V[]){v_t_2439}));
        return heff_tag_at_n(v_ru_24n_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_247_24IAnn, TAG_IAnn, 2, (V[]){v_t_2442, v_t_2443}), v_sp_2441});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_ISpec: {
      V v_a_2444 = heff_field(v_n1_247, 0);
      V v_f_2445 = heff_field(v_n1_247, 1);
      V v_fsp_2446 = heff_field(v_n1_247, 2);
      V v_val_2447 = heff_field(v_n1_247, 3);
      V v_ru_24n1_247_24ISpec = heff_take_reuse_n(v_n1_247, 15ULL, 4);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_typ_246);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2449 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2450 = heff_tr(heff_call(v_inf_244, 1, (V[]){v_a_2444}));
        V v_t_2451 = heff_tr(heff_call(v_chk_245, 1, (V[]){v_val_2447}));
        return heff_tag_at_n(v_ru_24n_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_247_24ISpec, TAG_ISpec, 4, (V[]){v_t_2450, v_f_2445, v_fsp_2446, v_t_2451}), v_sp_2449});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_IUpdate: {
      V v_a_2452 = heff_field(v_n1_247, 0);
      V v_fs_2453 = heff_field(v_n1_247, 1);
      V v_ru_24n1_247_24IUpdate = heff_take_reuse_n(v_n1_247, 3ULL, 2);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_typ_246);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2455 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2456 = heff_tr(heff_call(v_inf_244, 1, (V[]){v_a_2452}));
        V v_t_2463 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameInfF_lam1, 1, 1, (V[]){v_chk_245}), v_fs_2453));
        return heff_tag_at_n(v_ru_24n_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_247_24IUpdate, TAG_IUpdate, 2, (V[]){v_t_2456, v_t_2463}), v_sp_2455});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_IAnnLam: {
      V v_y_2464 = heff_field(v_n1_247, 0);
      V v_ysp_2465 = heff_field(v_n1_247, 1);
      V v_t_2466 = heff_field(v_n1_247, 2);
      V v_b_2467 = heff_field(v_n1_247, 3);
      V v_ru_24n1_247_24IAnnLam = heff_take_reuse_n(v_n1_247, 15ULL, 4);
      heff_drop(v_v_243);
      heff_drop(v_chk_245);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2469 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2470 = heff_tr(heff_call(v_typ_246, 1, (V[]){v_t_2466}));
        V v_t_2471;
        if (heff_strEq_c_lent(v_y_2464, v_x_242, 2)) {
          heff_drop(v_inf_244);
          v_t_2471 = v_b_2467;
        } else {
          v_t_2471 = heff_tr(heff_call(v_inf_244, 1, (V[]){v_b_2467}));
        }
        return heff_tag_at_n(v_ru_24n_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_247_24IAnnLam, TAG_IAnnLam, 4, (V[]){v_y_2464, v_ysp_2465, v_t_2470, v_t_2471}), v_sp_2469});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_IInvalid: {
      heff_take_n(v_n1_247, 0ULL, 3);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_inf_244);
      heff_drop(v_chk_245);
      heff_drop(v_typ_246);
      return v_n_241;
    }
    case TAG_INominal: {
      V v_i_2475 = heff_field(v_n1_247, 0);
      V v_ru_24n1_247_24INominal = heff_take_reuse_n(v_n1_247, 1ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_chk_245);
      heff_drop(v_typ_246);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2477 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2478 = heff_tr(heff_call(v_inf_244, 1, (V[]){v_i_2475}));
        return heff_tag_at_n(v_ru_24n_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_247_24INominal, TAG_INominal, 1, (V[]){v_t_2478}), v_sp_2477});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_ILitEq: {
      V v_y_2479 = heff_field(v_n1_247, 0);
      V v_ysp_2480 = heff_field(v_n1_247, 1);
      V v_eq_2481 = heff_field(v_n1_247, 2);
      V v_lit_2482 = heff_field(v_n1_247, 3);
      V v_ru_24n1_247_24ILitEq = heff_take_reuse_n(v_n1_247, 15ULL, 4);
      heff_drop(v_inf_244);
      heff_drop(v_typ_246);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2484 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2485;
        if (heff_strEq_c_lent(v_y_2479, v_x_242, 2)) {
          heff_drop(v_y_2479);
          v_t_2485 = v_v_243;
        } else {
          heff_drop(v_v_243);
          v_t_2485 = v_y_2479;
        }
        V v_t_2486 = heff_tr(heff_call(v_chk_245, 1, (V[]){v_lit_2482}));
        return heff_tag_at_n(v_ru_24n_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_247_24ILitEq, TAG_ILitEq, 4, (V[]){v_t_2485, v_ysp_2480, v_eq_2481, v_t_2486}), v_sp_2484});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_ILazy: {
      V v_c_2487 = heff_field(v_n1_247, 0);
      V v_ru_24n1_247_24ILazy = heff_take_reuse_n(v_n1_247, 1ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_inf_244);
      heff_drop(v_typ_246);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2489 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2490 = heff_tr(heff_call(v_chk_245, 1, (V[]){v_c_2487}));
        return heff_tag_at_n(v_ru_24n_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_247_24ILazy, TAG_ILazy, 1, (V[]){v_t_2490}), v_sp_2489});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_ITuple: {
      V v_cs_2491 = heff_field(v_n1_247, 0);
      V v_ru_24n1_247_24ITuple = heff_take_reuse_n(v_n1_247, 1ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_v_243);
      heff_drop(v_inf_244);
      heff_drop(v_typ_246);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2493 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2494 = (g_list_2emap(v_chk_245, v_cs_2491));
        return heff_tag_at_n(v_ru_24n_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_247_24ITuple, TAG_ITuple, 1, (V[]){v_t_2494}), v_sp_2493});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    default: return heff_nomatch(v_n1_247);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameInfF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameInfF(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameInfF_lam0(V self, V *args) {
  V v_a_2423 = args[0];
  V v_chk_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2423)) {
  case TAG_At: {
    V v_a1_2424 = heff_dup(heff_field(v_a_2423, 0));
    switch (heff_tag_of(v_a1_2424)) {
    case TAG_ArgExplicit: {
      V v_c_2426 = heff_field(v_a1_2424, 0);
      V v_ru_24a1_2424_24ArgExplicit = heff_take_reuse_n(v_a1_2424, 1ULL, 1);
      switch (heff_tag_of(v_a_2423)) {
      case TAG_At: {
        V v_sp_2428 = heff_field(v_a_2423, 1);
        V v_ru_24a_2423_24At = heff_take_reuse_n(v_a_2423, 2ULL, 2);
        V v_t_2429 = heff_tr(heff_call(v_chk_245, 1, (V[]){v_c_2426}));
        return heff_tag_at_n(v_ru_24a_2423_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a1_2424_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_2429}), v_sp_2428});
      }
      default: return heff_nomatch(v_a_2423);
      }
    }
    case TAG_ArgProject: {
      heff_take_n(v_a1_2424, 0ULL, 1);
      heff_drop(v_chk_245);
      return v_a_2423;
    }
    case TAG_ArgNamed: {
      V v_y_2431 = heff_field(v_a1_2424, 0);
      V v_c_2432 = heff_field(v_a1_2424, 1);
      V v_ru_24a1_2424_24ArgNamed = heff_take_reuse_n(v_a1_2424, 3ULL, 2);
      switch (heff_tag_of(v_a_2423)) {
      case TAG_At: {
        V v_sp_2434 = heff_field(v_a_2423, 1);
        V v_ru_24a_2423_24At = heff_take_reuse_n(v_a_2423, 2ULL, 2);
        V v_t_2435 = heff_tr(heff_call(v_chk_245, 1, (V[]){v_c_2432}));
        return heff_tag_at_n(v_ru_24a_2423_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a1_2424_24ArgNamed, TAG_ArgNamed, 2, (V[]){v_y_2431, v_t_2435}), v_sp_2434});
      }
      default: return heff_nomatch(v_a_2423);
      }
    }
    case TAG_ArgEvidence: {
      heff_take_n(v_a1_2424, 0ULL, 1);
      heff_drop(v_chk_245);
      return v_a_2423;
    }
    default: return heff_nomatch(v_a1_2424);
    }
  }
  default: return heff_nomatch(v_a_2423);
  }
}
V g_heff_2eelab_2eclauses_2erenameInfF_lam1(V self, V *args) {
  V v_f_2457 = args[0];
  V v_chk_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_2457)) {
  case TAG_At: {
    V v_it1_2458 = heff_field(v_f_2457, 0);
    V v_fsp_2459 = heff_field(v_f_2457, 1);
    V v_ru_24f_2457_24At = heff_take_reuse_n(v_f_2457, 3ULL, 2);
    switch (heff_tag_of(v_it1_2458)) {
    case TAG_SetPath: {
      V v_path_2460 = heff_field(v_it1_2458, 0);
      V v_e_2461 = heff_field(v_it1_2458, 1);
      heff_take_n(v_it1_2458, 3ULL, 2);
      V v_t_2462 = heff_tr(heff_call(v_chk_245, 1, (V[]){v_e_2461}));
      return heff_tag_at_n(v_ru_24f_2457_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_path_2460, v_t_2462}), v_fsp_2459});
    }
    default: return heff_nomatch(v_it1_2458);
    }
  }
  default: return heff_nomatch(v_f_2457);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2enameFits_str0, 1, "_");
V g_heff_2eelab_2eclauses_2enameFits_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2enameFits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enameFits_entry, 3, 0};

V g_heff_2eelab_2eclauses_2enameFits(V v_x_240, V v_c_241, V v_rows_242) {
top: ;
  return (g_heff_2eelab_2eclauses_2eallC(heff_clo_n(g_heff_2eelab_2eclauses_2enameFits_lam0, 1, 2, (V[]){v_c_241, v_x_240}), v_rows_242));
}
V g_heff_2eelab_2eclauses_2enameFits_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2enameFits(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2eclauses_2enameFits_lam0(V self, V *args) {
  V v_row_243 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_pats_244 = heff_take_field(v_row_243, 0);
  V v_rhs_245 = heff_get_n(v_row_243, 1, 2);
  HeffT2 v_t_246 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(v_pats_244), v_c_241));
  V v_t_2421;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_p_249 = v_field_248;
      switch (heff_tag_of(v_p_249)) {
      case TAG_PVar: {
        V v_x_2410 = heff_field(v_p_249, 0);
        heff_take_n(v_p_249, 1ULL, 1);
        v_t_2421 = heff_bool(heff_strEq_c_lent(v_x_240, v_x_2410, 0));
        heff_drop(v_x_2410);
        break;
      }
      case TAG_PTag: {
        heff_take_n(v_p_249, 0ULL, 3);
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PLit: {
        heff_take_n(v_p_249, 0ULL, 1);
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PRec: {
        heff_take_n(v_p_249, 0ULL, 2);
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PAs: {
        V v_x_2417 = heff_field(v_p_249, 0);
        heff_take_n(v_p_249, 1ULL, 2);
        v_t_2421 = heff_bool(heff_strEq_c_lent(v_x_240, v_x_2417, 0));
        heff_drop(v_x_2417);
        break;
      }
      case TAG_PBin: {
        heff_take_n(v_p_249, 0ULL, 2);
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_p_249);
      }
    } else {
      heff_drop(v_field_248);
      v_t_2421 = heff_bool(heff_strEq_c_lent(v_x_240, ((V)&g_heff_2eelab_2eclauses_2enameFits_str0), 2));
    }
  }
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_x_240);
    heff_drop(v_pats_244);
    heff_drop(v_rhs_245);
    heff_drop(v_t_2421);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2421);
    V v_t_2422 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_rhs_245, NTAG(TAG_Nil)));
    V v_xs_2423 = ({ V a_0 = v_pats_244; V a_1 = v_t_2422; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(a_0, a_1)); heff_drop(v_pats_244); r_; });
    V v_t_2424 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_x_240}));
    V v_x1_2425 = ({ V a_0 = v_t_2424; V a_1 = v_xs_2423; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2423); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2425) == NTAG(TAG_True)));
    heff_drop(v_x1_2425);
    return v_ret_24bool;
  }
}
Clo g_heff_2eelab_2eclauses_2earmSub_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2earmSub_entry, 7, 0};

V g_heff_2eelab_2eclauses_2earmSub(V v_used_240, V v_bound_241, V v_rows_242, V v_c_243, V v_t_244, V v_v_245, V v_i_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_t_244, 2, 4), heff_dup(v_i_246)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_p_2410 = v_field_249;
      V v_t_2422;
      switch (heff_tag_of(v_p_2410)) {
      case TAG_PVar: {
        V v_x_2411 = heff_field(v_p_2410, 0);
        V v_ru_24p_2410_24PVar = heff_take_reuse_n(v_p_2410, 1ULL, 1);
        v_t_2422 = heff_tag_at_n(v_ru_24p_2410_24PVar, TAG_Just, 1, (V[]){v_x_2411});
        break;
      }
      case TAG_PTag: {
        heff_take_n(v_p_2410, 0ULL, 3);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PLit: {
        heff_take_n(v_p_2410, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PRec: {
        heff_take_n(v_p_2410, 0ULL, 2);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PAs: {
        V v_x_2418 = heff_field(v_p_2410, 0);
        heff_take_n(v_p_2410, 1ULL, 2);
        v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2418});
        break;
      }
      case TAG_PBin: {
        heff_take_n(v_p_2410, 0ULL, 2);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_p_2410);
      }
      return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_rows_242; V a_3 = v_c_243; V a_4 = v_v_245; V a_5 = v_i_246; V a_6 = v_t_2422; V r_ = (g_heff_2eelab_2eclauses_2earmSubName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2422); r_; });
    } else {
      heff_drop(v_c_243);
      heff_drop(v_field_249);
      V v_t_2423 = heff_intShow(heff_intAdd(v_i_246, MK_INT(1LL)));
      return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_v_245, v_t_2423)));
    }
  }
}
V g_heff_2eelab_2eclauses_2earmSub_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2earmSub(a0, a1, a2, a[3], a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_heff_2eelab_2eclauses_2elookupField_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_g_244 = heff_field(v_x21_242, 0);
      V v_p_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_f_240, v_g_244, 2)) {
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_245}});
      } else {
        heff_drop(v_p_245);
        V t_0 = v_f_240;
        V t_1 = v_rest_243;
        v_f_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2eelab_2eclauses_2elookupField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elookupField_entry, 2, 0};

V g_heff_2eelab_2eclauses_2elookupField(V v_f_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2eelab_2eclauses_2elookupField_24cpr(v_f_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2eclauses_2elookupField_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2elookupField(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str4, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str5, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str6, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str7, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str8, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str9, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str10, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str11, 1, "_");
V g_heff_2eelab_2eclauses_2erecSpecialize_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSpecialize_lam1(V self, V *args); static Clo g_heff_2eelab_2eclauses_2erecSpecialize_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_lam1, 1, 0};
V g_heff_2eelab_2eclauses_2erecSpecialize_lam2(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSpecialize_lam3(V self, V *args); static Clo g_heff_2eelab_2eclauses_2erecSpecialize_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_lam3, 1, 0};
V g_heff_2eelab_2eclauses_2erecSpecialize_lam4(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSpecialize_lam5(V self, V *args); static Clo g_heff_2eelab_2eclauses_2erecSpecialize_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_lam5, 1, 0};
V g_heff_2eelab_2eclauses_2erecSpecialize_lam6(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSpecialize_lam7(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSpecialize_lam8(V self, V *args); static Clo g_heff_2eelab_2eclauses_2erecSpecialize_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_lam8, 1, 0};
V g_heff_2eelab_2eclauses_2erecSpecialize_lam9(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSpecialize_lam10(V self, V *args); static Clo g_heff_2eelab_2eclauses_2erecSpecialize_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_lam10, 1, 0};
Clo g_heff_2eelab_2eclauses_2erecSpecialize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_entry, 4, 0};

V g_heff_2eelab_2eclauses_2erecSpecialize(V v_c_240, V v_fs_241, V v_v_242, V v_r_243) {
top: ;
  V v_pats_244 = heff_take_field(v_r_243, 0);
  V v_rhs_245 = heff_get_n(v_r_243, 1, 2);
  HeffT2 v_t_246 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(v_pats_244), heff_dup(v_c_240)));
  V v_t_2410;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_p_249 = v_field_248;
      v_t_2410 = v_p_249;
    } else {
      heff_drop(v_field_248);
      v_t_2410 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str0)});
    }
  }
  switch (heff_tag_of(v_t_2410)) {
  case TAG_PVar: {
    heff_take_n(v_t_2410, 0ULL, 1);
    V v_ys_2412 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str1), v_fs_241));
    V v_xs_2413 = heff_dup(v_pats_244);
    V v_t_2414 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2413)));
    V v_t_2415 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2413));
    V v_t_2416 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2412, v_t_2415));
    V v_pats_2417 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2414, v_t_2416));
    HeffT2 v_t_2418 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_pats_244, v_c_240));
    V v_t_2436;
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_p_2421 = v_field_2420;
        v_t_2436 = heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam0, 1, 2, (V[]){v_p_2421, v_v_242});
      } else {
        heff_drop(v_v_242);
        heff_drop(v_field_2420);
        v_t_2436 = ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_lam1_clo);
      }
    }
    V v_rhs_2437 = heff_tr(heff_call(v_t_2436, 1, (V[]){v_rhs_245}));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2417, v_rhs_2437});
  }
  case TAG_PTag: {
    heff_take_n(v_t_2410, 0ULL, 3);
    V v_ys_2441 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str3), v_fs_241));
    V v_xs_2442 = heff_dup(v_pats_244);
    V v_t_2443 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2442)));
    V v_t_2444 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2442));
    V v_t_2445 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2441, v_t_2444));
    V v_pats_2446 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2443, v_t_2445));
    HeffT2 v_t_2447 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_pats_244, v_c_240));
    V v_t_2465;
    {
      V v_field_2449 = v_t_2447.f[1];
      int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
      if ((v_tag_2448 == ((int64_t)0ULL))) {
        V v_p_2450 = v_field_2449;
        v_t_2465 = heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam2, 1, 2, (V[]){v_p_2450, v_v_242});
      } else {
        heff_drop(v_v_242);
        heff_drop(v_field_2449);
        v_t_2465 = ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_lam3_clo);
      }
    }
    V v_rhs_2466 = heff_tr(heff_call(v_t_2465, 1, (V[]){v_rhs_245}));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2446, v_rhs_2466});
  }
  case TAG_PLit: {
    heff_take_n(v_t_2410, 0ULL, 1);
    V v_ys_2468 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str5), v_fs_241));
    V v_xs_2469 = heff_dup(v_pats_244);
    V v_t_2470 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2469)));
    V v_t_2471 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2469));
    V v_t_2472 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2468, v_t_2471));
    V v_pats_2473 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2470, v_t_2472));
    HeffT2 v_t_2474 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_pats_244, v_c_240));
    V v_t_2492;
    {
      V v_field_2476 = v_t_2474.f[1];
      int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
      if ((v_tag_2475 == ((int64_t)0ULL))) {
        V v_p_2477 = v_field_2476;
        v_t_2492 = heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam4, 1, 2, (V[]){v_p_2477, v_v_242});
      } else {
        heff_drop(v_v_242);
        heff_drop(v_field_2476);
        v_t_2492 = ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_lam5_clo);
      }
    }
    V v_rhs_2493 = heff_tr(heff_call(v_t_2492, 1, (V[]){v_rhs_245}));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2473, v_rhs_2493});
  }
  case TAG_PRec: {
    V v_fps_2494 = heff_field(v_t_2410, 0);
    V v_ru_24t_2410_24PRec = heff_take_reuse_n(v_t_2410, 1ULL, 2);
    heff_drop(v_v_242);
    V v_ys_24101 = (g_list_2emap_24tok2(v_ru_24t_2410_24PRec, heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam6, 1, 1, (V[]){v_fps_2494}), v_fs_241));
    V v_xs_24102 = v_pats_244;
    V v_t_24103 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_24102)));
    V v_t_24104 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_24102));
    V v_t_24105 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_24101, v_t_24104));
    V v_pats_24106 = (g_heff_2eelab_2eclauses_2eappendC(v_t_24103, v_t_24105));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_24106, v_rhs_245});
  }
  case TAG_PAs: {
    V v_ru_24t_2410_24PAs = heff_take_reuse_n(v_t_2410, 0ULL, 2);
    V v_ys_24109 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str8), v_fs_241));
    V v_xs_24110 = heff_dup(v_pats_244);
    V v_t_24111 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_24110)));
    V v_t_24112 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_24110));
    V v_t_24113 = (g_heff_2eelab_2eclauses_2eappendC_24tok2(v_ru_24t_2410_24PAs, v_ys_24109, v_t_24112));
    V v_pats_24114 = (g_heff_2eelab_2eclauses_2eappendC(v_t_24111, v_t_24113));
    HeffT2 v_t_24115 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_pats_244, v_c_240));
    V v_t_24133;
    {
      V v_field_24117 = v_t_24115.f[1];
      int64_t v_tag_24116 = ((int64_t)v_t_24115.f[0]);
      if ((v_tag_24116 == ((int64_t)0ULL))) {
        V v_p_24118 = v_field_24117;
        v_t_24133 = heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam7, 1, 2, (V[]){v_p_24118, v_v_242});
      } else {
        heff_drop(v_v_242);
        heff_drop(v_field_24117);
        v_t_24133 = ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_lam8_clo);
      }
    }
    V v_rhs_24134 = heff_tr(heff_call(v_t_24133, 1, (V[]){v_rhs_245}));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_24114, v_rhs_24134});
  }
  case TAG_PBin: {
    V v_ru_24t_2410_24PBin = heff_take_reuse_n(v_t_2410, 0ULL, 2);
    V v_ys_24137 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str10), v_fs_241));
    V v_xs_24138 = heff_dup(v_pats_244);
    V v_t_24139 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_24138)));
    V v_t_24140 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_24138));
    V v_t_24141 = (g_heff_2eelab_2eclauses_2eappendC_24tok2(v_ru_24t_2410_24PBin, v_ys_24137, v_t_24140));
    V v_pats_24142 = (g_heff_2eelab_2eclauses_2eappendC(v_t_24139, v_t_24141));
    HeffT2 v_t_24143 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_pats_244, v_c_240));
    V v_t_24161;
    {
      V v_field_24145 = v_t_24143.f[1];
      int64_t v_tag_24144 = ((int64_t)v_t_24143.f[0]);
      if ((v_tag_24144 == ((int64_t)0ULL))) {
        V v_p_24146 = v_field_24145;
        v_t_24161 = heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam9, 1, 2, (V[]){v_p_24146, v_v_242});
      } else {
        heff_drop(v_v_242);
        heff_drop(v_field_24145);
        v_t_24161 = ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_lam10_clo);
      }
    }
    V v_rhs_24162 = heff_tr(heff_call(v_t_24161, 1, (V[]){v_rhs_245}));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_24142, v_rhs_24162});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erecSpecialize(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam0(V self, V *args) {
  V v_e_2422 = args[0];
  V v_p_2421 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2421)) {
  case TAG_PVar: {
    V v_x_2423 = heff_field(v_p_2421, 0);
    heff_take_n(v_p_2421, 1ULL, 1);
    if ((heff_strEq_c_lent(v_x_2423, ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str2), 2) ? 0 : !heff_strEq_c_lent(v_x_2423, v_v_242, 0))) {
      V v_t_2424 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2423, v_v_242));
      V f_ = heff_get_n(v_t_2424, 3, 5);
      args[0] = v_e_2422;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_v_242);
      heff_drop(v_x_2423);
      return v_e_2422;
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_2421, 0ULL, 3);
    heff_drop(v_v_242);
    return v_e_2422;
  }
  case TAG_PLit: {
    heff_take_n(v_p_2421, 0ULL, 1);
    heff_drop(v_v_242);
    return v_e_2422;
  }
  case TAG_PRec: {
    heff_take_n(v_p_2421, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2422;
  }
  case TAG_PAs: {
    heff_take_n(v_p_2421, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2422;
  }
  case TAG_PBin: {
    heff_take_n(v_p_2421, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2422;
  }
  default: return heff_nomatch(v_p_2421);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam1(V self, V *args) {
  V v_e_2435 = args[0];
  return v_e_2435;
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam2(V self, V *args) {
  V v_e_2451 = args[0];
  V v_p_2450 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2450)) {
  case TAG_PVar: {
    V v_x_2452 = heff_field(v_p_2450, 0);
    heff_take_n(v_p_2450, 1ULL, 1);
    if ((heff_strEq_c_lent(v_x_2452, ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str4), 2) ? 0 : !heff_strEq_c_lent(v_x_2452, v_v_242, 0))) {
      V v_t_2453 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2452, v_v_242));
      V f_ = heff_get_n(v_t_2453, 3, 5);
      args[0] = v_e_2451;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_v_242);
      heff_drop(v_x_2452);
      return v_e_2451;
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_2450, 0ULL, 3);
    heff_drop(v_v_242);
    return v_e_2451;
  }
  case TAG_PLit: {
    heff_take_n(v_p_2450, 0ULL, 1);
    heff_drop(v_v_242);
    return v_e_2451;
  }
  case TAG_PRec: {
    heff_take_n(v_p_2450, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2451;
  }
  case TAG_PAs: {
    heff_take_n(v_p_2450, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2451;
  }
  case TAG_PBin: {
    heff_take_n(v_p_2450, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2451;
  }
  default: return heff_nomatch(v_p_2450);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam3(V self, V *args) {
  V v_e_2464 = args[0];
  return v_e_2464;
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam4(V self, V *args) {
  V v_e_2478 = args[0];
  V v_p_2477 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2477)) {
  case TAG_PVar: {
    V v_x_2479 = heff_field(v_p_2477, 0);
    heff_take_n(v_p_2477, 1ULL, 1);
    if ((heff_strEq_c_lent(v_x_2479, ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str6), 2) ? 0 : !heff_strEq_c_lent(v_x_2479, v_v_242, 0))) {
      V v_t_2480 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2479, v_v_242));
      V f_ = heff_get_n(v_t_2480, 3, 5);
      args[0] = v_e_2478;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_v_242);
      heff_drop(v_x_2479);
      return v_e_2478;
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_2477, 0ULL, 3);
    heff_drop(v_v_242);
    return v_e_2478;
  }
  case TAG_PLit: {
    heff_take_n(v_p_2477, 0ULL, 1);
    heff_drop(v_v_242);
    return v_e_2478;
  }
  case TAG_PRec: {
    heff_take_n(v_p_2477, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2478;
  }
  case TAG_PAs: {
    heff_take_n(v_p_2477, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2478;
  }
  case TAG_PBin: {
    heff_take_n(v_p_2477, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2478;
  }
  default: return heff_nomatch(v_p_2477);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam5(V self, V *args) {
  V v_e_2491 = args[0];
  return v_e_2491;
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam6(V self, V *args) {
  V v_f_2496 = args[0];
  V v_fps_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2497 = ({ V a_0 = v_f_2496; V a_1 = v_fps_2494; HeffT2 r_ = (g_heff_2eelab_2eclauses_2elookupField_24cpr(a_0, a_1)); heff_drop(v_f_2496); r_; });
  {
    V v_field_2499 = v_t_2497.f[1];
    int64_t v_tag_2498 = ((int64_t)v_t_2497.f[0]);
    if ((v_tag_2498 == ((int64_t)0ULL))) {
      V v_p_24100 = v_field_2499;
      return v_p_24100;
    } else {
      heff_drop(v_field_2499);
      return heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str7)});
    }
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam7(V self, V *args) {
  V v_e_24119 = args[0];
  V v_p_24118 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_24118)) {
  case TAG_PVar: {
    V v_x_24120 = heff_field(v_p_24118, 0);
    heff_take_n(v_p_24118, 1ULL, 1);
    if ((heff_strEq_c_lent(v_x_24120, ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str9), 2) ? 0 : !heff_strEq_c_lent(v_x_24120, v_v_242, 0))) {
      V v_t_24121 = (g_heff_2eelab_2eclauses_2erenamer(v_x_24120, v_v_242));
      V f_ = heff_get_n(v_t_24121, 3, 5);
      args[0] = v_e_24119;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_v_242);
      heff_drop(v_x_24120);
      return v_e_24119;
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_24118, 0ULL, 3);
    heff_drop(v_v_242);
    return v_e_24119;
  }
  case TAG_PLit: {
    heff_take_n(v_p_24118, 0ULL, 1);
    heff_drop(v_v_242);
    return v_e_24119;
  }
  case TAG_PRec: {
    heff_take_n(v_p_24118, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_24119;
  }
  case TAG_PAs: {
    heff_take_n(v_p_24118, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_24119;
  }
  case TAG_PBin: {
    heff_take_n(v_p_24118, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_24119;
  }
  default: return heff_nomatch(v_p_24118);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam8(V self, V *args) {
  V v_e_24132 = args[0];
  return v_e_24132;
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam9(V self, V *args) {
  V v_e_24147 = args[0];
  V v_p_24146 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_24146)) {
  case TAG_PVar: {
    V v_x_24148 = heff_field(v_p_24146, 0);
    heff_take_n(v_p_24146, 1ULL, 1);
    if ((heff_strEq_c_lent(v_x_24148, ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str11), 2) ? 0 : !heff_strEq_c_lent(v_x_24148, v_v_242, 0))) {
      V v_t_24149 = (g_heff_2eelab_2eclauses_2erenamer(v_x_24148, v_v_242));
      V f_ = heff_get_n(v_t_24149, 3, 5);
      args[0] = v_e_24147;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_v_242);
      heff_drop(v_x_24148);
      return v_e_24147;
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_24146, 0ULL, 3);
    heff_drop(v_v_242);
    return v_e_24147;
  }
  case TAG_PLit: {
    heff_take_n(v_p_24146, 0ULL, 1);
    heff_drop(v_v_242);
    return v_e_24147;
  }
  case TAG_PRec: {
    heff_take_n(v_p_24146, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_24147;
  }
  case TAG_PAs: {
    heff_take_n(v_p_24146, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_24147;
  }
  case TAG_PBin: {
    heff_take_n(v_p_24146, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_24147;
  }
  default: return heff_nomatch(v_p_24146);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam10(V self, V *args) {
  V v_e_24160 = args[0];
  return v_e_24160;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_str0, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_str1, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_str2, 5, "False");
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_str3, 5, "False");
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_str4, 5, "False");
Clo g_heff_2eelab_2eclauses_2eandC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eandC_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eandC(V v_c_240, V v_rest_241, V v_sp_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_str0)}), heff_dup(v_sp_242)});
  V v_x1_244 = ({ V a_0 = v_t_243; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_At: {
    V v_s_246 = heff_field(v_x1_244, 1);
    heff_take_n(v_x1_244, 2ULL, 2);
    v_t_247 = v_s_246;
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_t_248 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_242, 0)); V rr_ = heff_rec_reuse_nf(v_t_247, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_249 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_str1), heff_dup(v_sp_242), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_t_248)}), heff_dup(v_rest_241)});
  V v_t_2413;
  switch (heff_tag_of(v_rest_241)) {
  case TAG_At: {
    V v_s_2412 = heff_field(v_rest_241, 1);
    heff_take_n(v_rest_241, 2ULL, 2);
    v_t_2413 = v_s_2412;
    break;
  }
  default: heff_nomatch(v_rest_241);
  }
  V v_t_2414 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_str2)}), heff_dup(v_sp_242)});
  V v_x1_2416 = ({ V a_0 = v_t_2415; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_At: {
    V v_s_2418 = heff_field(v_x1_2416, 1);
    heff_take_n(v_x1_2416, 2ULL, 2);
    v_t_2419 = v_s_2418;
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2420 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_242, 0)); V rr_ = heff_rec_reuse_nf(v_t_2419, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2421 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_str3), heff_dup(v_sp_242), NTAG(TAG_Nil)});
  V v_t_2422 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_str4), heff_dup(v_sp_242), NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_t_2420)}), heff_tag_n(TAG_At, 2, (V[]){v_t_2422, heff_dup(v_sp_242)})});
  V v_t_2424 = ({ V rv_1 = heff_dup(heff_rfield(v_sp_242, 1)); V rr_ = heff_rec_reuse_nf(v_t_2420, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_t_2424}), NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_t_2414}), v_t_2425});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_c_240, v_t_2426}), v_sp_242});
}
V g_heff_2eelab_2eclauses_2eandC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eandC(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eoffC_str0, 6, "intAdd");
V g_heff_2eelab_2eclauses_2eoffC_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eoffC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eoffC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eoffC(V v_o_240, V v_sp_241) {
top: ;
  V v_bits_242 = heff_take_field(v_o_240, 0);
  V v_terms_243 = heff_get_n(v_o_240, 1, 2);
  V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_bits_242}), heff_dup(v_sp_241)});
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_244}), heff_dup(v_sp_241)});
  return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eoffC_lam0, 2, 1, (V[]){v_sp_241}); V a_1 = v_t_245; V a_2 = v_terms_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_terms_243); r_; });
}
V g_heff_2eelab_2eclauses_2eoffC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eoffC(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2eoffC_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_t_247 = args[1];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), heff_tag_n(TAG_Cons, 2, (V[]){v_acc_246, v_t_248})));
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eoffC_str0)}), heff_dup(v_sp_241)});
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2410, v_t_249}), heff_dup(v_sp_241)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), v_sp_241});
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efloatRead_str0, 11, "floatOfBits");
Clo g_heff_2eelab_2eclauses_2efloatRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efloatRead_entry, 4, 0};

V g_heff_2eelab_2eclauses_2efloatRead(V v_k_240, V v_off_241, V v_n_242, V v_flags_243) {
top: ;
  V v_sp_244 = heff_dup(heff_rfield(v_k_240, 6));
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_n_242)}), heff_dup(v_sp_244)});
  V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_245}), v_sp_244});
  V v_t_247 = heff_rec_n(2, shape_bits__terms, (V[]){v_n_242, NTAG(TAG_Nil)});
  V v_i_248 = (g_heff_2eelab_2eclauses_2eintRead(heff_dup(v_k_240), v_off_241, v_t_247, v_flags_243));
  V v_t_2411;
  switch (heff_tag_of(v_i_248)) {
  case TAG_At: {
    V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
    v_t_2411 = v_s_2410;
    break;
  }
  default: heff_nomatch(v_i_248);
  }
  V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  V v_args_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2413});
  V v_sp_2415 = heff_get_n(v_k_240, 6, 7);
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2efloatRead_str0)}), heff_dup(v_sp_2415)});
  V v_t_2417 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2415), v_args_2414));
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2417}), v_sp_2415});
}
V g_heff_2eelab_2eclauses_2efloatRead_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2efloatRead(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efloatTest_str0, 7, "floatEq");
Clo g_heff_2eelab_2eclauses_2efloatTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efloatTest_entry, 5, 0};

V g_heff_2eelab_2eclauses_2efloatTest(V v_k_240, V v_off_241, V v_s_242, V v_v_243, V v_rest_244) {
top: ;
  V v_size_245 = heff_take_field(v_s_242, 2);
  V v_flags_246 = heff_get_n(v_s_242, 3, 5);
  switch (heff_tag_of(v_v_243)) {
  case TAG_At: {
    V v_v1_247 = heff_field(v_v_243, 0);
    V v_xsp_248 = heff_field(v_v_243, 1);
    V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
    switch (heff_tag_of(v_v1_247)) {
    case TAG_PatVar: {
      heff_take_n(v_v1_247, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop(v_size_245);
      heff_drop(v_flags_246);
      heff_drop(v_xsp_248);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatTag: {
      heff_take_n(v_v1_247, 0ULL, 3);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop(v_size_245);
      heff_drop(v_flags_246);
      heff_drop(v_xsp_248);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatOp: {
      heff_take_n(v_v1_247, 0ULL, 3);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop(v_size_245);
      heff_drop(v_flags_246);
      heff_drop(v_xsp_248);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatInt: {
      heff_take_n(v_v1_247, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop(v_size_245);
      heff_drop(v_flags_246);
      heff_drop(v_xsp_248);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatFloat: {
      double v_x_2417 = heff_tflat_f64(v_v1_247, 0);
      V v_ru_24v1_247_24PatFloat = heff_take_reuse_na(v_v1_247, 0ULL, 1);
      V v_t_2422;
      switch (heff_tag_of(v_size_245)) {
      case TAG_SizeDefault: {
        v_t_2422 = MK_INT(64LL);
        break;
      }
      case TAG_SizeNumber: {
        V v_n_2418 = heff_field(v_size_245, 0);
        heff_take_n(v_size_245, 1ULL, 1);
        v_t_2422 = v_n_2418;
        break;
      }
      case TAG_SizeName: {
        heff_take_n(v_size_245, 0ULL, 3);
        v_t_2422 = MK_INT(64LL);
        break;
      }
      default: heff_nomatch(v_size_245);
      }
      V v_i_2423 = (g_heff_2eelab_2eclauses_2efloatRead(heff_dup(v_k_240), v_off_241, v_t_2422, v_flags_246));
      V v_t_2426;
      switch (heff_tag_of(v_i_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_dup(heff_field(v_i_2423, 1));
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_i_2423);
      }
      V v_t_2427 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2423}), v_t_2426});
      V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_nf(v_ru_24v1_247_24PatFloat, TAG_IFloat, 1, 1u, (V[]){heff_word_f64(v_x_2417)}), heff_dup(v_xsp_248)});
      V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2428}), v_xsp_248});
      V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
      V v_args_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2430});
      V v_sp_2432 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2efloatTest_str0)}), heff_dup(v_sp_2432)});
      V v_t_2434 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2432), v_args_2431));
      V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2433, v_t_2434}), v_sp_2432});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2435, v_rest_244, heff_get_n(v_k_240, 6, 7)));
    }
    case TAG_PatString: {
      heff_take_n(v_v1_247, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop(v_size_245);
      heff_drop(v_flags_246);
      heff_drop(v_xsp_248);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatBinary: {
      heff_take_n(v_v1_247, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop(v_size_245);
      heff_drop(v_flags_246);
      heff_drop(v_xsp_248);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatRune: {
      heff_take_n(v_v1_247, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop(v_size_245);
      heff_drop(v_flags_246);
      heff_drop(v_xsp_248);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatRecord: {
      heff_take_n(v_v1_247, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop(v_size_245);
      heff_drop(v_flags_246);
      heff_drop(v_xsp_248);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatWord: {
      heff_take_n(v_v1_247, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop(v_size_245);
      heff_drop(v_flags_246);
      heff_drop(v_xsp_248);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatAs: {
      heff_take_n(v_v1_247, 0ULL, 3);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop(v_size_245);
      heff_drop(v_flags_246);
      heff_drop(v_xsp_248);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    default: return heff_nomatch(v_v1_247);
    }
  }
  default: return heff_nomatch(v_v_243);
  }
}
V g_heff_2eelab_2eclauses_2efloatTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2efloatTest(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecodeTest_str0, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecodeTest_str1, 5, "intEq");
Clo g_heff_2eelab_2eclauses_2ecodeTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecodeTest_entry, 4, 0};

V g_heff_2eelab_2eclauses_2ecodeTest(V v_k_240, V v_c_241, V v_v_242, V v_rest_243) {
top: ;
  switch (heff_tag_of(v_v_242)) {
  case TAG_At: {
    V v_v1_244 = heff_field(v_v_242, 0);
    V v_ru_24v_242_24At = heff_take_reuse_n(v_v_242, 1ULL, 2);
    switch (heff_tag_of(v_v1_244)) {
    case TAG_PatVar: {
      heff_take_n(v_v1_244, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatTag: {
      heff_take_n(v_v1_244, 0ULL, 3);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatOp: {
      heff_take_n(v_v1_244, 0ULL, 3);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatInt: {
      V v_n_2413 = heff_field(v_v1_244, 0);
      V v_ru_24v1_244_24PatInt = heff_take_reuse_n(v_v1_244, 1ULL, 1);
      V v_sp_2414 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2415 = heff_tag_at_n(v_ru_24v_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ecodeTest_str0)}), heff_dup(v_sp_2414)});
      V v_t_2418;
      switch (heff_tag_of(v_c_241)) {
      case TAG_At: {
        V v_s_2417 = heff_dup(heff_field(v_c_241, 1));
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24v1_244_24PatInt, TAG_CInf, 1, (V[]){v_c_241}), v_t_2418});
      V v_sp_2420 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_n_2413}), heff_dup(v_sp_2420)});
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2421}), v_sp_2420});
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
      V v_t_2424 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2414), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2423})));
      V v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2415, v_t_2424}), v_sp_2414});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2425, v_rest_243, heff_get_n(v_k_240, 6, 7)));
    }
    case TAG_PatFloat: {
      heff_take_na(v_v1_244, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatString: {
      heff_take_n(v_v1_244, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatBinary: {
      heff_take_n(v_v1_244, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatRune: {
      V v_n_2429 = heff_field(v_v1_244, 0);
      V v_ru_24v1_244_24PatRune = heff_take_reuse_n(v_v1_244, 1ULL, 1);
      V v_sp_2430 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2431 = heff_tag_at_n(v_ru_24v_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ecodeTest_str1)}), heff_dup(v_sp_2430)});
      V v_t_2434;
      switch (heff_tag_of(v_c_241)) {
      case TAG_At: {
        V v_s_2433 = heff_dup(heff_field(v_c_241, 1));
        v_t_2434 = v_s_2433;
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24v1_244_24PatRune, TAG_CInf, 1, (V[]){v_c_241}), v_t_2434});
      V v_sp_2436 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_n_2429}), heff_dup(v_sp_2436)});
      V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2437}), v_sp_2436});
      V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
      V v_t_2440 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2430), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2439})));
      V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2431, v_t_2440}), v_sp_2430});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2441, v_rest_243, heff_get_n(v_k_240, 6, 7)));
    }
    case TAG_PatRecord: {
      heff_take_n(v_v1_244, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatWord: {
      heff_take_n(v_v1_244, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatAs: {
      heff_take_n(v_v1_244, 0ULL, 3);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    default: return heff_nomatch(v_v1_244);
    }
  }
  default: return heff_nomatch(v_v_242);
  }
}
V g_heff_2eelab_2eclauses_2ecodeTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecodeTest(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinTestGo_str0, 5, "intEq");
Clo g_heff_2eelab_2eclauses_2ebinTestGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebinTestGo_entry, 6, 0};

V g_heff_2eelab_2eclauses_2ebinTestGo(V v_t_240, V v_k_241, V v_env_242, V v_i_243, V v_off_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop(v_env_242);
    heff_drop(v_i_243);
    V v_t_246 = (g_heff_2eelab_2eclauses_2eoffC(v_off_244, heff_dup(heff_rfield(v_k_241, 6))));
    V v_sp_247 = heff_dup(heff_rfield(v_k_241, 6));
    V v_t_248 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_241, 2)});
    V v_t_249 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, heff_dup(v_sp_247)})});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_247}), NTAG(TAG_Nil)});
    V v_args_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2410});
    V v_sp_2412 = heff_get_n(v_k_241, 6, 7);
    V v_t_2413 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2412), v_args_2411));
    V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinTestGo_str0)}), heff_dup(v_sp_2412)});
    V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2414, v_t_2413}), heff_dup(v_sp_2412)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2415}), v_sp_2412});
  }
  case TAG_Cons: {
    V v_s_2416 = heff_field(v_x6_245, 0);
    V v_rest_2417 = heff_field(v_x6_245, 1);
    V v_t_2418 = (g_heff_2eelab_2eclauses_2ewidthBy(v_env_242, heff_dup(heff_rfield(v_s_2416, 4)), heff_dup(heff_rfield(v_s_2416, 1)), heff_rfield(v_s_2416, 2), heff_rfield(v_s_2416, 0)));
    return (g_heff_2eelab_2eclauses_2esegTest(v_t_240, v_k_241, v_env_242, v_i_243, v_off_244, heff_dup(v_s_2416), heff_dup(v_rest_2417), v_t_2418, heff_dup(heff_rfield(v_s_2416, 1))));
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eelab_2eclauses_2ebinTestGo_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2eelab_2eclauses_2ebinTestGo(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erestC_str0, 10, "bitsLength");
HEFF_LIT(g_heff_2eelab_2eclauses_2erestC_str1, 6, "intSub");
Clo g_heff_2eelab_2eclauses_2erestC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erestC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erestC(V v_k_240, V v_off_241) {
top: ;
  V v_span_242 = heff_take_field(v_k_240, 6);
  V v_v_243 = heff_get_n(v_k_240, 0, 7);
  V v_sp_244 = heff_dup(v_span_242);
  V v_sp_245 = heff_dup(v_span_242);
  V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_v_243}), heff_dup(v_sp_245)});
  V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_246}), v_sp_245});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_t_248));
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erestC_str0)}), heff_dup(v_sp_244)});
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2410, v_t_249}), heff_dup(v_sp_244)});
  V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), v_sp_244});
  V v_t_2413 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(v_span_242)));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_args_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2414});
  V v_sp_2416 = v_span_242;
  V v_t_2417 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2416), v_args_2415));
  V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erestC_str1)}), heff_dup(v_sp_2416)});
  V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2418, v_t_2417}), heff_dup(v_sp_2416)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2419}), v_sp_2416});
}
V g_heff_2eelab_2eclauses_2erestC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erestC(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2easBitsC_str0, 11, "bitsOfBytes");
Clo g_heff_2eelab_2eclauses_2easBitsC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2easBitsC_entry, 5, 0};

V g_heff_2eelab_2eclauses_2easBitsC(V v_x1_240, V v_v_241, V v_x_242, V v_sp_243, V v_body_244) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2easBitsC_str0)}), heff_dup(v_sp_243)});
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_v_241}), heff_dup(v_sp_243)});
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_246}), heff_dup(v_sp_243)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_t_248));
    V v_rhs_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_245, v_t_249}), heff_dup(v_sp_243)});
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_242}), heff_dup(v_sp_243)});
    V v_t_2414;
    switch (heff_tag_of(v_body_244)) {
    case TAG_At: {
      V v_s_2413 = heff_dup(heff_field(v_body_244, 1));
      v_t_2414 = v_s_2413;
      break;
    }
    default: heff_nomatch(v_body_244);
    }
    V v_t_2415 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_243, 0)); V rr_ = heff_rec_reuse_nf(v_t_2414, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2411, v_body_244}), v_t_2415});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2410, v_t_2416}), v_sp_243});
  } else {
    heff_drop(v_v_241);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    return v_body_244;
  }
}
V g_heff_2eelab_2eclauses_2easBitsC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2easBitsC(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epeelCols_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epeelCols_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epeelCols(V v_x1_240, V v_x2_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2eelab_2eclauses_2epeelCols_24cpr(v_x1_240, v_x2_241, v_e_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epeelCols(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2ecolFrom_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ecolFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecolFrom_entry, 4, 0};

V g_heff_2eelab_2eclauses_2ecolFrom(V v_used_240, V v_taken_241, V v_rows_242, V v_i_243) {
top: ;
  V v_t_2420 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ecolFrom_lam0, 1, 1, (V[]){heff_dup(v_i_243)}), heff_dup(v_rows_242)));
  V v_t_2421 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2420));
  V v_t_2422 = (g_heff_2eelab_2eclauses_2enubStr(v_t_2421));
  return ({ V a_0 = v_used_240; V a_1 = v_taken_241; V a_2 = v_rows_242; V a_3 = v_i_243; V a_4 = v_t_2422; V r_ = (g_heff_2eelab_2eclauses_2ecolPick(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rows_242); heff_drop(v_t_2422); r_; });
}
V g_heff_2eelab_2eclauses_2ecolFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2ecolFrom(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2ecolFrom_lam0(V self, V *args) {
  V v_r_244 = args[0];
  V v_i_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_245 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_r_244, 0, 2), v_i_243));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_p_248 = v_field_247;
      switch (heff_tag_of(v_p_248)) {
      case TAG_PVar: {
        V v_x_249 = heff_field(v_p_248, 0);
        V v_ru_24p_248_24PVar = heff_take_reuse_n(v_p_248, 1ULL, 1);
        return heff_tag_at_n(v_ru_24p_248_24PVar, TAG_Just, 1, (V[]){v_x_249});
      }
      case TAG_PTag: {
        heff_take_n(v_p_248, 0ULL, 3);
        return NTAG(TAG_Nothing);
      }
      case TAG_PLit: {
        heff_take_n(v_p_248, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_PRec: {
        heff_take_n(v_p_248, 0ULL, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_PAs: {
        V v_x_2416 = heff_field(v_p_248, 0);
        heff_take_n(v_p_248, 1ULL, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){v_x_2416});
      }
      case TAG_PBin: {
        heff_take_n(v_p_248, 0ULL, 2);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_p_248);
      }
    } else {
      heff_drop(v_field_247);
      return NTAG(TAG_Nothing);
    }
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str4, 12, "builtin.Bool");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str5, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str6, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str7, 5, "False");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str8, 5, "False");
V g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_segs_246, V v_bsp_247, V v_xs_248, V v_ys_249, V v_k_2410, V v_made_2411) {
top: ;
  HeffT2 v_t_2412 = (g_heff_2eelab_2eclauses_2ebinChecks_24cpr(v_rows_244, heff_dup(v_c_245), heff_dup(v_bsp_247)));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      heff_drop(v_segs_246);
      heff_drop_rec(v_bsp_247, 2);
      heff_drop(v_xs_248);
      heff_drop(v_ys_249);
      heff_drop_rec(v_k_2410, 7);
      V v_e_2415 = v_field_2414;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2415}});
    } else {
      V v_x_2416 = v_field_2414;
      heff_drop(v_x_2416);
      V v_bound_2417 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ys_249), heff_dup(v_bound_241)));
      V v_vars_2418 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_vars_243), heff_dup(v_ys_249)));
      V v_rows_2433 = (g_heff_2eelab_2eclauses_2emapWithIndexC(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam0, 2, 3, (V[]){heff_dup(v_c_245), v_xs_248, heff_dup(v_ys_249)}), heff_dup(v_rows_244)));
      V v_t_2437 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam1, 1, 1, (V[]){heff_dup(v_vars_2418)}), v_rows_2433));
      HeffT2 v_t_2438 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(heff_dup(v_used_240), v_bound_2417, heff_dup(v_sp_242), v_vars_2418, v_t_2437));
      {
        V v_field_2440 = v_t_2438.f[1];
        int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
        if ((v_tag_2439 == ((int64_t)0ULL))) {
          heff_drop(v_used_240);
          heff_drop(v_bound_241);
          heff_drop(v_sp_242);
          heff_drop(v_vars_243);
          heff_drop(v_rows_244);
          heff_drop(v_c_245);
          heff_drop(v_segs_246);
          heff_drop_rec(v_bsp_247, 2);
          heff_drop(v_ys_249);
          heff_drop_rec(v_k_2410, 7);
          V v_e_2441 = v_field_2440;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2441}});
        } else {
          V v_x_2442 = v_field_2440;
          V v_rows_2443 = (g_heff_2eelab_2eclauses_2edropC(MK_INT(1LL), v_rows_244));
          V v_t_2447 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam2, 1, 1, (V[]){heff_dup(v_vars_243)}), v_rows_2443));
          HeffT2 v_t_2448 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(v_used_240, v_bound_241, v_sp_242, heff_dup(v_vars_243), v_t_2447));
          {
            V v_field_2450 = v_t_2448.f[1];
            int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
            if ((v_tag_2449 == ((int64_t)0ULL))) {
              heff_drop(v_vars_243);
              heff_drop(v_c_245);
              heff_drop(v_segs_246);
              heff_drop_rec(v_bsp_247, 2);
              heff_drop(v_ys_249);
              heff_drop_rec(v_k_2410, 7);
              heff_drop(v_x_2442);
              V v_e_2451 = v_field_2450;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2451}});
            } else {
              V v_x_2452 = v_field_2450;
              HeffT2 v_t_2453 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, v_c_245));
              V v_t_2457;
              {
                V v_field_2455 = v_t_2453.f[1];
                int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
                if ((v_tag_2454 == ((int64_t)0ULL))) {
                  V v_v_2456 = v_field_2455;
                  v_t_2457 = v_v_2456;
                } else {
                  heff_drop(v_field_2455);
                  v_t_2457 = ((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str2);
                }
              }
              V v_t_2458 = heff_dup(heff_rfield(v_k_2410, 1));
              V v_t_2459;
              if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
                heff_drop(v_t_2458);
                v_t_2459 = NTAG(TAG_Nothing);
              } else {
                heff_drop(v_t_2458);
                v_t_2459 = (g_heff_2eelab_2eclauses_2ewholeBin(v_segs_246, ((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str3)));
              }
              V v_t_2460 = (g_heff_2eelab_2eclauses_2ebinTestOf(heff_dup(v_k_2410), heff_dup(v_segs_246), v_t_2459));
              V v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str4)}), heff_dup(v_bsp_247)});
              V v_t_2462 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_t_2461}), heff_dup(v_bsp_247)});
              V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_2460, v_t_2462}), heff_dup(v_bsp_247)});
              V v_t_2464 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str5)}), heff_dup(v_bsp_247)});
              V v_x1_2465 = ({ V a_0 = v_t_2464; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
              V v_t_2468;
              switch (heff_tag_of(v_x1_2465)) {
              case TAG_At: {
                V v_s_2467 = heff_field(v_x1_2465, 1);
                heff_take_n(v_x1_2465, 2ULL, 2);
                v_t_2468 = v_s_2467;
                break;
              }
              default: heff_nomatch(v_x1_2465);
              }
              V v_t_2469 = ({ V rv_0 = heff_dup(heff_rfield(v_bsp_247, 0)); V rr_ = heff_rec_reuse_nf(v_t_2468, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              V v_t_2470 = (g_heff_2eelab_2eclauses_2ebinBind(heff_dup(v_k_2410)));
              V v_t_2471 = heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
              V v_e_2472 = heff_tr(heff_call(heff_get_n(v_t_2470, 0, 1), 6, (V[]){NTAG(TAG_Nil), MK_INT(0LL), v_ys_249, v_t_2471, v_segs_246, v_x_2442}));
              V v_t_2473 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str6), heff_dup(v_bsp_247), NTAG(TAG_Nil)});
              V v_t_2474 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2473, heff_dup(v_t_2469)}), heff_dup(v_e_2472)});
              V v_t_2477;
              switch (heff_tag_of(v_e_2472)) {
              case TAG_At: {
                V v_s_2476 = heff_field(v_e_2472, 1);
                heff_take_n(v_e_2472, 2ULL, 2);
                v_t_2477 = v_s_2476;
                break;
              }
              default: heff_nomatch(v_e_2472);
              }
              V v_t_2478 = ({ V rv_1 = heff_get_n(v_t_2477, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2469, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2479 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str7)}), heff_dup(v_bsp_247)});
              V v_x1_2480 = ({ V a_0 = v_t_2479; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
              V v_t_2483;
              switch (heff_tag_of(v_x1_2480)) {
              case TAG_At: {
                V v_s_2482 = heff_field(v_x1_2480, 1);
                heff_take_n(v_x1_2480, 2ULL, 2);
                v_t_2483 = v_s_2482;
                break;
              }
              default: heff_nomatch(v_x1_2480);
              }
              V v_t_2484 = ({ V rv_0 = heff_dup(heff_rfield(v_bsp_247, 0)); V rr_ = heff_rec_reuse_nf(v_t_2483, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              V v_t_2485 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str8), heff_dup(v_bsp_247), NTAG(TAG_Nil)});
              V v_t_2486 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2485, heff_dup(v_t_2484)}), heff_dup(v_x_2452)});
              V v_t_2489;
              switch (heff_tag_of(v_x_2452)) {
              case TAG_At: {
                V v_s_2488 = heff_field(v_x_2452, 1);
                heff_take_n(v_x_2452, 2ULL, 2);
                v_t_2489 = v_s_2488;
                break;
              }
              default: heff_nomatch(v_x_2452);
              }
              V v_t_2490 = ({ V rv_1 = heff_get_n(v_t_2489, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2484, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2486, v_t_2490}), NTAG(TAG_Nil)});
              V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2474, v_t_2478}), v_t_2491});
              V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_2463, v_t_2492}), heff_dup(v_bsp_247)});
              V v_f_2494 = (g_heff_2eelab_2eclauses_2easBitsC(v_made_2411, v_t_2457, heff_get_n(v_k_2410, 0, 7), v_bsp_247, v_t_2493));
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2494}});
            }
          }
        }
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam0(V self, V *args) {
  V v_i_2419 = args[0];
  V v_row_2420 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_248 = heff_env(self)[1];
  V v_ys_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_pats_2421 = heff_take_field(v_row_2420, 0);
  V v_rhs_2422 = heff_get_n(v_row_2420, 1, 2);
  if (heff_intEq_c(v_i_2419, MK_INT(0LL))) {
    heff_drop(v_ys_249);
    V v_xs_2423 = v_pats_2421;
    V v_t_2424 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_245), heff_dup(v_xs_2423)));
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str0)}), NTAG(TAG_Nil)});
    V v_t_2426 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_245, MK_INT(1LL)), v_xs_2423));
    V v_t_2427 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2425, v_t_2426));
    V v_t_2428 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2424, v_t_2427));
    V v_t_2429 = (g_list_2emap_24s796727596x829078925(v_xs_248));
    V v_pats_2430 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2428, v_t_2429));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2430, v_rhs_2422});
  } else {
    heff_drop(v_c_245);
    heff_drop(v_xs_248);
    V v_t_2431 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str1), v_ys_249));
    V v_pats_2432 = (g_heff_2eelab_2eclauses_2eappendC(v_pats_2421, v_t_2431));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2432, v_rhs_2422});
  }
}
V g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam1(V self, V *args) {
  V v_row_2434 = args[0];
  V v_vars_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_pats_2435 = heff_take_field(v_row_2434, 0);
  V v_rhs_2436 = heff_get_n(v_row_2434, 1, 2);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2418, v_pats_2435, v_rhs_2436));
}
V g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam2(V self, V *args) {
  V v_row_2444 = args[0];
  V v_vars_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_pats_2445 = heff_take_field(v_row_2444, 0);
  V v_rhs_2446 = heff_get_n(v_row_2444, 1, 2);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_243, v_pats_2445, v_rhs_2446));
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr(V v_sp_240, V v_rows_241, V v_used_242, V v_x_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr_lam0, 1, 1, (V[]){heff_dup(v_x_243)}), v_rows_241));
  HeffT2 v_t_2411 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), v_used_242}), v_t_244, v_sp_240, v_t_245, v_t_2410));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop(v_x_243);
      V v_e_2414 = v_field_2413;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2414}});
    } else {
      V v_x_2415 = v_field_2413;
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(2, shape_scrutinee__tree, (V[]){v_x_243, v_x_2415})}});
    }
  }
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr_lam0(V self, V *args) {
  V v_row_246 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_pats_247 = heff_take_field(v_row_246, 0);
  V v_rhs_248 = heff_get_n(v_row_246, 1, 2);
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
  return (g_heff_2eelab_2eclauses_2epeelCols(v_t_249, v_pats_247, v_rhs_248));
}
Clo g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      V v_x_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_ys_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2epatIdents_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatIdents_24tok2_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epatIdents_24tok2(V v_tok_240, V v_p_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_243 = heff_field(v_p_241, 0);
    heff_take_n(v_p_241, 1ULL, 2);
    switch (heff_tag_of(v_p1_243)) {
    case TAG_PatVar: {
      V v_x_245 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_245, v_acc_242});
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 4ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      return ({ V a_0 = v_ps_248; V a_1 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_248); r_; });
    }
    case TAG_PatOp: {
      V v_x_249 = heff_field(v_p1_243, 0);
      V v_ps_2411 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 5ULL, 3);
      V v_t_2412 = ({ V a_0 = v_ps_2411; V a_1 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_2411); r_; });
      return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_249, v_t_2412});
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return v_acc_242;
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return v_acc_242;
    }
    case TAG_PatString: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return v_acc_242;
    }
    case TAG_PatBinary: {
      V v_segs_2416 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return (g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749(v_segs_2416, v_acc_242));
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return v_acc_242;
    }
    case TAG_PatRecord: {
      V v_fs_2418 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return (g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(v_fs_2418, v_acc_242));
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return v_acc_242;
    }
    case TAG_PatAs: {
      V v_x_2420 = heff_field(v_p1_243, 0);
      V v_q_2422 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 5ULL, 3);
      V v_cell_2423 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_2420, heff_hole()});
      V v_u_2424 = (g_heff_2eelab_2eclauses_2epatIdents_24dps(v_q_2422, v_acc_242, heff_dup(v_cell_2423)));
      heff_drop(v_u_2424);
      return v_cell_2423;
    }
    default: return heff_nomatch(v_p1_243);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eelab_2eclauses_2epatIdents_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatIdents_24tok2(a[0], a[1], a[2]);
}