// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648 39892
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_PAs 26446
#define TAG_PBin 33976
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define LBL_bits 9519565
#define LBL_chk 308000
#define LBL_decl 9574769
#define LBL_end 310101
#define LBL_flags 298871457
#define LBL_go 10063
#define LBL_inf 313947
#define LBL_len 316559
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_scrutinee 73860976
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_terms 311608737
#define LBL_tree 10063973
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_v 336
#define LBL_value 313331083
#define LBL_x 338
static uint32_t shape_bits__terms[] = {LBL_bits, LBL_terms};
static uint32_t shape_inf__chk__typ__decl[] = {LBL_inf, LBL_chk, LBL_typ, LBL_decl};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_scrutinee__tree[] = {LBL_scrutinee, LBL_tree};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eclauses_2eallC(V, V);
V g_heff_2eelab_2eclauses_2eallC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eallC_clo;
V g_heff_2eelab_2eclauses_2eandC(V, V, V);
V g_heff_2eelab_2eclauses_2eandC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eandC_clo;
V g_heff_2eelab_2eclauses_2eanyC(V, V);
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_clo;
V g_heff_2eelab_2eclauses_2eanyC_24s44140518x185484176(V, V);
V g_heff_2eelab_2eclauses_2eanyC_24s44140518x185484176_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_24s44140518x185484176_clo;
V g_heff_2eelab_2eclauses_2eappendC(V, V);
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120(V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_clo;
V g_heff_2eelab_2eclauses_2earmSub(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmSub_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmSub_clo;
V g_heff_2eelab_2eclauses_2earmSubName(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmSubName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmSubName_clo;
V g_heff_2eelab_2eclauses_2easBitsC(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2easBitsC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2easBitsC_clo;
V g_heff_2eelab_2eclauses_2ebinBind(V);
V g_heff_2eelab_2eclauses_2ebinBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinBind_clo;
HeffT2 g_heff_2eelab_2eclauses_2ebinChecks_24cpr(V, V, V);
V g_heff_2eelab_2eclauses_2ebinTestGo(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ebinTestGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTestGo_clo;
V g_heff_2eelab_2eclauses_2ebinTestOf(V, V, V);
V g_heff_2eelab_2eclauses_2ebinTestOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTestOf_clo;
HeffT2 g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr(V, V, V, V, V, V, V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecatMaybesC(V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo;
V g_heff_2eelab_2eclauses_2ecatMaybesC_24dps(V, V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_clo;
V g_heff_2eelab_2eclauses_2ecodeTest(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecodeTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecodeTest_clo;
V g_heff_2eelab_2eclauses_2ecolFrom(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolFrom_clo;
V g_heff_2eelab_2eclauses_2ecolPick(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolPick_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolPick_clo;
HeffT2 g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2econcatMapC(V, V);
V g_heff_2eelab_2eclauses_2econcatMapC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_clo;
V g_heff_2eelab_2eclauses_2edropC(V, V);
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropC_clo;
V g_heff_2eelab_2eclauses_2efloatRead(V, V, V, V);
V g_heff_2eelab_2eclauses_2efloatRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efloatRead_clo;
V g_heff_2eelab_2eclauses_2efloatTest(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2efloatTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efloatTest_clo;
V g_heff_2eelab_2eclauses_2efreshIn(V, V, V);
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efreshIn_clo;
V g_heff_2eelab_2eclauses_2eidents_get(void);
V g_heff_2eelab_2eclauses_2eidentsChkF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_clo;
V g_heff_2eelab_2eclauses_2eidentsDeclF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsDeclF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsDeclF_clo;
V g_heff_2eelab_2eclauses_2eidentsInfF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsInfF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsInfF_clo;
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(V, V);
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_clo;
V g_heff_2eelab_2eclauses_2eintRead(V, V, V, V);
V g_heff_2eelab_2eclauses_2eintRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eintRead_clo;
V g_heff_2eelab_2eclauses_2elookupField(V, V);
V g_heff_2eelab_2eclauses_2elookupField_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elookupField_clo;
HeffT2 g_heff_2eelab_2eclauses_2elookupField_24cpr(V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC(V, V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2emapWithIndexC_clo;
V g_heff_2eelab_2eclauses_2enameFits(V, V, V);
V g_heff_2eelab_2eclauses_2enameFits_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enameFits_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll(V, V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_clo;
HeffT2 g_heff_2eelab_2eclauses_2enthC_24cpr(V, V);
V g_heff_2eelab_2eclauses_2enubStr(V);
V g_heff_2eelab_2eclauses_2enubStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_clo;
V g_heff_2eelab_2eclauses_2enubStr_24dps(V, V);
V g_heff_2eelab_2eclauses_2enubStr_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_24dps_clo;
V g_heff_2eelab_2eclauses_2eoffC(V, V);
V g_heff_2eelab_2eclauses_2eoffC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eoffC_clo;
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatBinds_24dps(V, V);
V g_heff_2eelab_2eclauses_2epatBinds_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_24dps_clo;
V g_heff_2eelab_2eclauses_2epatIdents(V, V);
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_clo;
V g_heff_2eelab_2eclauses_2epatVars(V);
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_clo;
V g_heff_2eelab_2eclauses_2epatVars_24dps(V, V);
V g_heff_2eelab_2eclauses_2epatVars_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_24dps_clo;
V g_heff_2eelab_2eclauses_2epeelCols(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelCols_clo;
HeffT2 g_heff_2eelab_2eclauses_2epeelCols_24cpr(V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents(V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_clo;
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_clo;
V g_heff_2eelab_2eclauses_2erecSpecialize(V, V, V, V);
V g_heff_2eelab_2eclauses_2erecSpecialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecSpecialize_clo;
V g_heff_2eelab_2eclauses_2erenameEquation(V, V);
V g_heff_2eelab_2eclauses_2erenameEquation_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameEquation_clo;
V g_heff_2eelab_2eclauses_2erenameInfF(V, V);
V g_heff_2eelab_2eclauses_2erenameInfF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameInfF_clo;
V g_heff_2eelab_2eclauses_2erenamePi(V, V);
V g_heff_2eelab_2eclauses_2erenamePi_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamePi_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eclauses_2erestC(V, V);
V g_heff_2eelab_2eclauses_2erestC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erestC_clo;
V g_heff_2eelab_2eclauses_2esegTest(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esegTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esegTest_clo;
V g_heff_2eelab_2eclauses_2etakeC(V, V);
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_clo;
V g_heff_2eelab_2eclauses_2ewholeBin(V, V);
V g_heff_2eelab_2eclauses_2ewholeBin_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ewholeBin_clo;
V g_heff_2eelab_2eclauses_2ewidthBy(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ewidthBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ewidthBy_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1846289357x1055790465(V, V);
V g_list_2emap_24s1846289357x1055790465_entry(V self, V *a);
extern Clo g_list_2emap_24s1846289357x1055790465_clo;
V g_list_2emap_24s502656580x1955732096(V);
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_clo;
V g_list_2emap_24s796727596x829078925(V);
V g_list_2emap_24s796727596x829078925_entry(V self, V *a);
extern Clo g_list_2emap_24s796727596x829078925_clo;
V g_list_2emap_24s939813003x1383013550(V);
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2eelab_2eclauses_2econcatMapC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2econcatMapC(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2eclauses_2econcatMapC(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2eclauses_2eappendC(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2econcatMapC(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecatMaybesC_entry, 1, 0};

V g_heff_2eelab_2eclauses_2ecatMaybesC(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2eclauses_2ecatMaybesC_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecatMaybesC(a[0]);
}
Clo g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_entry, 2, 0};

V g_heff_2eelab_2eclauses_2ecatMaybesC_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ecatMaybesC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecatMaybesC_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2enubStr_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enubStr_24dps_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enubStr_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2efilter_24s727803713x1346936525(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2enubStr_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enubStr_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2epatVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatVars_entry, 1, 0};

V g_heff_2eelab_2eclauses_2epatVars(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PVar: {
    V v_x_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
  }
  case TAG_PTag: {
    V v_ps_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    return ({ V a_0 = v_ps_243; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a_0)); heff_drop(v_ps_243); r_; });
  }
  case TAG_PLit: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PRec: {
    V v_fps_246 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    return ({ V a_0 = v_fps_246; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a_0)); heff_drop(v_fps_246); r_; });
  }
  case TAG_PAs: {
    V v_x_248 = heff_field(v_x1_240, 0);
    V v_p_249 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24PAs = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x1_240_24PAs, TAG_Cons, 2, (V[]){v_x_248, heff_hole()});
    V v_u_2411 = (g_heff_2eelab_2eclauses_2epatVars_24dps(v_p_249, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  case TAG_PBin: {
    V v_segs_2412 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V v_t_2414 = (g_list_2emap_24s502656580x1955732096(heff_dup(v_segs_2412)));
    V v_t_2415 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2414));
    V v_t_2416 = (g_list_2emap_24s939813003x1383013550(v_segs_2412));
    V v_t_2417 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2416));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_2415, v_t_2417));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatVars(a[0]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_248 = heff_field(v_a_244, 2);
        heff_take_n(v_a_244, 5ULL, 5);
        V v_t_2415;
        switch (heff_tag_of(v_a_248)) {
        case TAG_SizeDefault: {
          v_t_2415 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SizeNumber: {
          heff_take_n(v_a_248, 0ULL, 1);
          v_t_2415 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SizeName: {
          V v_a_2412 = heff_field(v_a_248, 0);
          heff_take_n(v_a_248, 1ULL, 3);
          v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_a_2412});
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        V v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
        V v_t_2417 = (g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120(v_acc_241, v_t_2416));
        v_t_2418 = (g_heff_2eelab_2eclauses_2epatIdents(v_a_246, v_t_2417));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2418;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2epiIdents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epiIdents_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epiIdents(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_t_245 = heff_field(v_x2_241, 2);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){heff_dup(v_t_245), v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), v_t_246});
  }
  case TAG_PiImplicit: {
    V v_x_247 = heff_field(v_x2_241, 0);
    V v_t_2410 = heff_field(v_x2_241, 3);
    V v_d_2411 = heff_field(v_x2_241, 4);
    V v_t_2413;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_Nothing: {
      v_t_2413 = v_acc_242;
      break;
    }
    case TAG_Just: {
      V v_c_2412 = heff_field(v_d_2411, 0);
      v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_c_2412), v_acc_242}));
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    V v_t_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){heff_dup(v_t_2410), v_t_2413}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_247), v_t_2414});
  }
  case TAG_PiInstance: {
    V v_x_2415 = heff_field(v_x2_241, 0);
    V v_t_2418 = heff_field(v_x2_241, 3);
    V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){heff_dup(v_t_2418), v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2415), v_t_2419});
  }
  case TAG_PiAnon: {
    V v_d_2420 = heff_field(v_x2_241, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){heff_dup(v_d_2420), v_acc_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2epiIdents_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2epiIdents(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2epatIdents(heff_dup(v_x_242), v_acc_241));
    V t_0 = v_xs_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2eidentsInfF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsInfF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsInfF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsInfF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsInfF(V v_r_240, V v_n_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_243 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_n1_243)) {
    case TAG_IVar: {
      V v_x_245 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_245, v_acc_242});
    }
    case TAG_IInt: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IFloat: {
      heff_take_na(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IString: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IBytes: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IPrim: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IRune: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IApp: {
      V v_h_2412 = heff_field(v_n1_243, 0);
      V v_args_2413 = heff_field(v_n1_243, 1);
      heff_take_n(v_n1_243, 3ULL, 2);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2423 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsInfF_lam0, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_args_2413; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2413); r_; });
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_h_2412, v_t_2423});
    }
    case TAG_IAnn: {
      V v_c_2424 = heff_field(v_n1_243, 0);
      V v_t_2425 = heff_field(v_n1_243, 1);
      heff_take_n(v_n1_243, 3ULL, 2);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2426 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 2, (V[]){v_t_2425, v_acc_242}));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2424, v_t_2426});
    }
    case TAG_ISpec: {
      V v_a_2427 = heff_field(v_n1_243, 0);
      V v_v_2430 = heff_field(v_n1_243, 3);
      heff_take_n(v_n1_243, 9ULL, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2431 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){v_v_2430, v_acc_242}));
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_a_2427, v_t_2431});
    }
    case TAG_IUpdate: {
      V v_a_2432 = heff_field(v_n1_243, 0);
      V v_fs_2433 = heff_field(v_n1_243, 1);
      heff_take_n(v_n1_243, 3ULL, 2);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2442 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsInfF_lam1, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_fs_2433; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_fs_2433); r_; });
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_a_2432, v_t_2442});
    }
    case TAG_IAnnLam: {
      V v_x_2443 = heff_field(v_n1_243, 0);
      V v_t_2445 = heff_field(v_n1_243, 2);
      V v_b_2446 = heff_field(v_n1_243, 3);
      heff_take_n(v_n1_243, 13ULL, 4);
      V v_t_2447 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 2, (V[]){v_b_2446, v_acc_242}));
      V v_t_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2445, v_t_2447}));
      return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2443, v_t_2448});
    }
    case TAG_IInvalid: {
      heff_take_n(v_n1_243, 0ULL, 3);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_INominal: {
      V v_i_2452 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_i_2452, v_acc_242});
    }
    case TAG_ILitEq: {
      V v_x_2453 = heff_field(v_n1_243, 0);
      V v_eq_2455 = heff_field(v_n1_243, 2);
      V v_lit_2456 = heff_field(v_n1_243, 3);
      heff_take_n(v_n1_243, 13ULL, 4);
      V v_t_2457 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_lit_2456, v_acc_242}));
      return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2453, heff_tag_n(TAG_Cons, 2, (V[]){v_eq_2455, v_t_2457})});
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsInfF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsInfF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsInfF_lam0(V self, V *args) {
  V v_x2_2414 = args[0];
  V v_acc_2415 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_At: {
    V v_x21_2416 = heff_field(v_x2_2414, 0);
    V v_ru_24x2_2414_24At = heff_take_reuse_n(v_x2_2414, 1ULL, 2);
    switch (heff_tag_of(v_x21_2416)) {
    case TAG_ArgExplicit: {
      V v_c_2418 = heff_field(v_x21_2416, 0);
      heff_take_n(v_x21_2416, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_2414_24At, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      args[0] = v_c_2418;
      args[1] = v_acc_2415;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_ArgProject: {
      heff_take_n(v_x21_2416, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24x2_2414_24At, 2);
      return v_acc_2415;
    }
    case TAG_ArgNamed: {
      V v_x_2420 = heff_field(v_x21_2416, 0);
      V v_c_2421 = heff_field(v_x21_2416, 1);
      heff_take_n(v_x21_2416, 3ULL, 2);
      V v_t_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2421, v_acc_2415}));
      return heff_tag_at_n(v_ru_24x2_2414_24At, TAG_Cons, 2, (V[]){v_x_2420, v_t_2422});
    }
    default: return heff_nomatch(v_x21_2416);
    }
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2eelab_2eclauses_2eidentsInfF_lam1(V self, V *args) {
  V v_x2_2434 = args[0];
  V v_acc_2435 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_At: {
    V v_x21_2436 = heff_field(v_x2_2434, 0);
    heff_take_n(v_x2_2434, 1ULL, 2);
    switch (heff_tag_of(v_x21_2436)) {
    case TAG_SetPath: {
      V v_path_2438 = heff_field(v_x21_2436, 0);
      V v_e_2439 = heff_field(v_x21_2436, 1);
      heff_take_n(v_x21_2436, 3ULL, 2);
      V v_t_2440 = (g_list_2emap_24s1415906091x1371825187(v_path_2438));
      V v_t_2441 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_e_2439, v_acc_2435}));
      return (g_prelude_2e_2b_2b(v_t_2440, v_t_2441));
    }
    default: return heff_nomatch(v_x21_2436);
    }
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_heff_2eelab_2eclauses_2eidents_lam0(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam0, 2, 0};
V g_heff_2eelab_2eclauses_2eidents_lam1(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam1, 2, 0};
V g_heff_2eelab_2eclauses_2eidents_lam2(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam2, 2, 0};
V g_heff_2eelab_2eclauses_2eidents_lam3(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam3, 2, 0};

static V g_heff_2eelab_2eclauses_2eidents_val;
static HEFF_ONCE g_heff_2eelab_2eclauses_2eidents_st;
static V g_heff_2eelab_2eclauses_2eidents_init(void) {
  return heff_rec_n(4, shape_inf__chk__typ__decl, (V[]){((V)&g_heff_2eelab_2eclauses_2eidents_lam0_clo), ((V)&g_heff_2eelab_2eclauses_2eidents_lam1_clo), ((V)&g_heff_2eelab_2eclauses_2eidents_lam2_clo), ((V)&g_heff_2eelab_2eclauses_2eidents_lam3_clo)});
}
V g_heff_2eelab_2eclauses_2eidents_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eclauses_2eidents_st)) return g_heff_2eelab_2eclauses_2eidents_val;
  return heff_global(&g_heff_2eelab_2eclauses_2eidents_val, &g_heff_2eelab_2eclauses_2eidents_st, g_heff_2eelab_2eclauses_2eidents_init);
}
V g_heff_2eelab_2eclauses_2eidents_lam0(V self, V *args) {
  V v_n_240 = args[0];
  V v_acc_241 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsInfF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_n_240, v_acc_241));
}
V g_heff_2eelab_2eclauses_2eidents_lam1(V self, V *args) {
  V v_n_242 = args[0];
  V v_acc_243 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsChkF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_n_242, v_acc_243));
}
V g_heff_2eelab_2eclauses_2eidents_lam2(V self, V *args) {
  V v_n_244 = args[0];
  V v_acc_245 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsTypF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_n_244, v_acc_245));
}
V g_heff_2eelab_2eclauses_2eidents_lam3(V self, V *args) {
  V v_d_246 = args[0];
  V v_acc_247 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsDeclF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_d_246, v_acc_247));
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2410 = (g_heff_2eelab_2eclauses_2enamesOfAll(heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 2)), v_a_248, v_acc_241));
        break;
      }
      case TAG_BadVariant: {
        V v_a_249 = heff_field(v_a_244, 0);
        v_t_2410 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(heff_dup(v_a_249), v_acc_241));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2410;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str5, 0, "");
Clo g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(V v_n_240, V v_acc_241) {
top: ;
  return (g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle(NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648), ((V)&g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str0), ((V)&g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str1), ((V)&g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str2), ((V)&g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str3), v_n_240, v_acc_241, ((V)&g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str4), ((V)&g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_str5)));
}
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(V v_x2_240, V v_acc_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 1ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_CInf: {
      V v_i_245 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_246 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_i_245, v_acc_241));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
    }
    case TAG_CType: {
      V v_t_247 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_248 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_247, v_acc_241));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_248);
    }
    case TAG_CLam: {
      V v_x_249 = heff_field(v_x21_243, 0);
      V v_b_2411 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_x_249, heff_hole()});
      V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_b_2411;
      V t_1 = v_acc_241;
      V t_2 = v_cell_2412;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CImplicitLam: {
      V v_x_2414 = heff_field(v_x21_243, 0);
      V v_b_2416 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_x_2414, heff_hole()});
      V v_u_2418 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_b_2416;
      V t_1 = v_acc_241;
      V t_2 = v_cell_2417;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CAnnLam: {
      V v_x_2419 = heff_field(v_x21_243, 0);
      V v_t_2421 = heff_field(v_x21_243, 2);
      V v_b_2422 = heff_field(v_x21_243, 3);
      heff_take_n(v_x21_243, 13ULL, 4);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2423 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_2422, v_acc_241));
      V v_t_2424 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_2421, v_acc_2423));
      return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2419, v_t_2424}));
    }
    case TAG_CTag: {
      V v_args_2427 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 4ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2428 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 1)); V a_1 = v_args_2427; V a_2 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2427); r_; });
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2428);
    }
    case TAG_CStruct: {
      V v_fs_2429 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2430 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(v_fs_2429, v_acc_241));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2430);
    }
    case TAG_CMatch: {
      V v_s_2431 = heff_field(v_x21_243, 0);
      V v_alts_2432 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2433 = ({ V a_0 = v_alts_2432; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(a_0, a_1)); heff_drop(v_alts_2432); r_; });
      V v_t_2434 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_s_2431, v_acc_2433));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2434);
    }
    case TAG_CLetIn: {
      V v_rhs_2435 = heff_field(v_x21_243, 0);
      V v_a_2436 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2442;
      switch (heff_tag_of(v_a_2436)) {
      case TAG_At: {
        V v_x21_2437 = heff_field(v_a_2436, 0);
        heff_take_n(v_a_2436, 1ULL, 2);
        switch (heff_tag_of(v_x21_2437)) {
        case TAG_MkAlt: {
          V v_p_2439 = heff_field(v_x21_2437, 0);
          V v_b_2440 = heff_field(v_x21_2437, 1);
          heff_take_n(v_x21_2437, 3ULL, 2);
          V v_t_2441 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_2440, v_acc_241));
          v_acc_2442 = (g_heff_2eelab_2eclauses_2epatIdents(v_p_2439, v_t_2441));
          break;
        }
        default: heff_nomatch(v_x21_2437);
        }
        break;
      }
      default: heff_nomatch(v_a_2436);
      }
      V v_t_2443 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_rhs_2435, v_acc_2442));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2443);
    }
    case TAG_CLocal: {
      V v_body_2444 = heff_field(v_x21_243, 0);
      V v_ds_2445 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2446 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 3)); V a_1 = v_ds_2445; V a_2 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ds_2445); r_; });
      V t_0 = v_body_2444;
      V t_1 = v_acc_2446;
      V t_2 = v_d_242;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CAbandon: {
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_CNominal: {
      V v_c_2447 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V t_0 = v_c_2447;
      V t_1 = v_acc_241;
      V t_2 = v_d_242;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(v_acc_241, heff_dup(v_x_242)));
    V t_0 = v_xs_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efreshIn_str0, 1, "'");
HEFF_LIT(g_heff_2eelab_2eclauses_2efreshIn_str1, 1, "'");
Clo g_heff_2eelab_2eclauses_2efreshIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efreshIn_entry, 3, 0};

V g_heff_2eelab_2eclauses_2efreshIn(V v_used_240, V v_bound_241, V v_x_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
  V v_t_244 = (g_list_2eany(v_t_243, v_used_240));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V t_0 = v_used_240;
    V t_1 = v_bound_241;
    V t_2 = heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2eclauses_2efreshIn_str0));
    v_used_240 = t_0;
    v_bound_241 = t_1;
    v_x_242 = t_2;
    goto top;
  } else {
    heff_drop(v_t_244);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_bound_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_used_240;
      V t_1 = v_bound_241;
      V t_2 = heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2eclauses_2efreshIn_str1));
      v_used_240 = t_0;
      v_bound_241 = t_1;
      v_x_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_246);
      return v_x_242;
    }
  }
}
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2efreshIn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2epatBinds_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatBinds_24dps_entry, 2, 0};

V g_heff_2eelab_2eclauses_2epatBinds_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      V v_t_245 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
      return heff_setField(v_d_241, MK_INT(1LL), v_t_245);
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_249 = ({ V a_0 = v_ps_248; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_248); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_249);
    }
    case TAG_PatOp: {
      V v_ps_2412 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2413 = ({ V a_0 = v_ps_2412; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_2412); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2413);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      V v_segs_2417 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2418 = ({ V a_0 = v_segs_2417; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(a_0)); heff_drop(v_segs_2417); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2418);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2420 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2421 = ({ V a_0 = v_fs_2420; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(a_0)); heff_drop(v_fs_2420); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2421);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2423 = heff_field(v_p1_242, 0);
      V v_q_2425 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 5ULL, 3);
      V v_cell_2426 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2423, heff_hole()});
      V v_u_2427 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2426));
      heff_drop(v_u_2427);
      V t_0 = v_q_2425;
      V t_1 = v_cell_2426;
      v_p_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatBinds_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatBinds_24dps(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameEquation_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameEquation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameEquation_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameEquation(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 15ULL, 4);
      V v_t_2411 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2erenameEquation_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_ps_246));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_t_2411);
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_rhs_247}), v_sp_243});
      } else {
        heff_drop(v_t_2411);
        V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_rhs_247}));
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_t_2412}), v_sp_243});
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameEquation_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameEquation(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameEquation_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_249 = (g_heff_2eelab_2eclauses_2epatBinds(v_p_248));
  V v_t_2410 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_240, 0, 5)}));
  return ({ V a_0 = v_t_2410; V a_1 = v_xs_249; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_249); r_; });
}
Clo g_heff_2eelab_2eclauses_2erenamePi_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenamePi_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenamePi(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ysp_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_244}));
    return heff_tag_at_n(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, (V[]){v_y_242, v_ysp_243, v_t_245});
  }
  case TAG_PiImplicit: {
    V v_y_246 = heff_field(v_x2_241, 0);
    V v_ysp_247 = heff_field(v_x2_241, 1);
    V v_bsp_248 = heff_field(v_x2_241, 2);
    V v_t_249 = heff_field(v_x2_241, 3);
    V v_d_2410 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_2411 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 1, (V[]){v_t_249}));
    V v_t_2414;
    switch (heff_tag_of(v_d_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 5);
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_c_2412 = heff_field(v_d_2410, 0);
      V v_ru_24d_2410_24Just = heff_take_reuse_n(v_d_2410, 1ULL, 1);
      V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2412}));
      v_t_2414 = heff_tag_at_n(v_ru_24d_2410_24Just, TAG_Just, 1, (V[]){v_t_2413});
      break;
    }
    default: heff_nomatch(v_d_2410);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_y_246, v_ysp_247, v_bsp_248, v_t_2411, v_t_2414});
  }
  case TAG_PiInstance: {
    V v_y_2415 = heff_field(v_x2_241, 0);
    V v_ysp_2416 = heff_field(v_x2_241, 1);
    V v_bsp_2417 = heff_field(v_x2_241, 2);
    V v_t_2418 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2418}));
    return heff_tag_at_n(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, (V[]){v_y_2415, v_ysp_2416, v_bsp_2417, v_t_2419});
  }
  case TAG_PiAnon: {
    V v_d_2420 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_d_2420}));
    return heff_tag_at_n(v_ru_24x2_241_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2421});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenamePi_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenamePi(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameInfF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameInfF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameInfF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameInfF_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameInfF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_IVar: {
      V v_y_244 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24IVar = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      if (heff_strEq_c(v_y_244, heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_tag(v_n_241, 2);
        V v_t_246 = heff_tag_at_n(v_ru_24n1_242_24IVar, TAG_IVar, 1, (V[]){heff_get_n(v_r_240, 1, 5)});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_sp_243});
      } else {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop_cell(v_ru_24n1_242_24IVar, 1);
        return v_n_241;
      }
    }
    case TAG_IInt: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IFloat: {
      heff_take_na(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IString: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IBytes: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IPrim: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IRune: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IApp: {
      V v_h_2413 = heff_field(v_n1_242, 0);
      V v_args_2414 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24IApp = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 1, (V[]){v_h_2413}));
      V v_t_2425 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameInfF_lam0, 1, 1, (V[]){v_r_240}), v_args_2414));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24IApp, TAG_IApp, 2, (V[]){v_t_2415, v_t_2425}), v_sp_243});
    }
    case TAG_IAnn: {
      V v_c_2426 = heff_field(v_n1_242, 0);
      V v_t_2427 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24IAnn = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2428 = heff_tr(heff_call(heff_take_field(v_r_240, 3), 1, (V[]){v_c_2426}));
      V v_t_2429 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2427}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24IAnn, TAG_IAnn, 2, (V[]){v_t_2428, v_t_2429}), v_sp_243});
    }
    case TAG_ISpec: {
      V v_a_2430 = heff_field(v_n1_242, 0);
      V v_f_2431 = heff_field(v_n1_242, 1);
      V v_fsp_2432 = heff_field(v_n1_242, 2);
      V v_val_2433 = heff_field(v_n1_242, 3);
      V v_ru_24n1_242_24ISpec = heff_take_reuse_n(v_n1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2434 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 1, (V[]){v_a_2430}));
      V v_t_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_val_2433}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24ISpec, TAG_ISpec, 4, (V[]){v_t_2434, v_f_2431, v_fsp_2432, v_t_2435}), v_sp_243});
    }
    case TAG_IUpdate: {
      V v_a_2436 = heff_field(v_n1_242, 0);
      V v_fs_2437 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24IUpdate = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 1, (V[]){v_a_2436}));
      V v_t_2445 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameInfF_lam1, 1, 1, (V[]){v_r_240}), v_fs_2437));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24IUpdate, TAG_IUpdate, 2, (V[]){v_t_2438, v_t_2445}), v_sp_243});
    }
    case TAG_IAnnLam: {
      V v_y_2446 = heff_field(v_n1_242, 0);
      V v_ysp_2447 = heff_field(v_n1_242, 1);
      V v_t_2448 = heff_field(v_n1_242, 2);
      V v_b_2449 = heff_field(v_n1_242, 3);
      V v_ru_24n1_242_24IAnnLam = heff_take_reuse_n(v_n1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2450 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 1, (V[]){v_t_2448}));
      V v_t_2452;
      if (heff_strEq_c(heff_dup(v_y_2446), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_rec(v_r_240, 5);
        v_t_2452 = v_b_2449;
      } else {
        v_t_2452 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_b_2449}));
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24IAnnLam, TAG_IAnnLam, 4, (V[]){v_y_2446, v_ysp_2447, v_t_2450, v_t_2452}), v_sp_243});
    }
    case TAG_IInvalid: {
      heff_take_n(v_n1_242, 0ULL, 3);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_INominal: {
      V v_i_2456 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24INominal = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2457 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_i_2456}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24INominal, TAG_INominal, 1, (V[]){v_t_2457}), v_sp_243});
    }
    case TAG_ILitEq: {
      V v_y_2458 = heff_field(v_n1_242, 0);
      V v_ysp_2459 = heff_field(v_n1_242, 1);
      V v_eq_2460 = heff_field(v_n1_242, 2);
      V v_lit_2461 = heff_field(v_n1_242, 3);
      V v_ru_24n1_242_24ILitEq = heff_take_reuse_n(v_n1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2463;
      if (heff_strEq_c(heff_dup(v_y_2458), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop(v_y_2458);
        v_t_2463 = heff_dup(heff_rfield(v_r_240, 1));
      } else {
        v_t_2463 = v_y_2458;
      }
      V v_t_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_lit_2461}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24ILitEq, TAG_ILitEq, 4, (V[]){v_t_2463, v_ysp_2459, v_eq_2460, v_t_2464}), v_sp_243});
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameInfF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameInfF(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameInfF_lam0(V self, V *args) {
  V v_a_2416 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2416)) {
  case TAG_At: {
    V v_a1_2417 = heff_dup(heff_field(v_a_2416, 0));
    V v_sp_2418 = heff_dup(heff_field(v_a_2416, 1));
    switch (heff_tag_of(v_a1_2417)) {
    case TAG_ArgExplicit: {
      V v_c_2419 = heff_field(v_a1_2417, 0);
      V v_ru_24a1_2417_24ArgExplicit = heff_take_reuse_n(v_a1_2417, 1ULL, 1);
      heff_drop_tag(v_a_2416, 2);
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2419}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a1_2417_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_2420}), v_sp_2418});
    }
    case TAG_ArgProject: {
      heff_take_n(v_a1_2417, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_2418);
      return v_a_2416;
    }
    case TAG_ArgNamed: {
      V v_y_2422 = heff_field(v_a1_2417, 0);
      V v_c_2423 = heff_field(v_a1_2417, 1);
      V v_ru_24a1_2417_24ArgNamed = heff_take_reuse_n(v_a1_2417, 3ULL, 2);
      heff_drop_tag(v_a_2416, 2);
      V v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2423}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a1_2417_24ArgNamed, TAG_ArgNamed, 2, (V[]){v_y_2422, v_t_2424}), v_sp_2418});
    }
    default: return heff_nomatch(v_a1_2417);
    }
  }
  default: return heff_nomatch(v_a_2416);
  }
}
V g_heff_2eelab_2eclauses_2erenameInfF_lam1(V self, V *args) {
  V v_f_2439 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_2439)) {
  case TAG_At: {
    V v_it1_2440 = heff_field(v_f_2439, 0);
    V v_fsp_2441 = heff_field(v_f_2439, 1);
    V v_ru_24f_2439_24At = heff_take_reuse_n(v_f_2439, 3ULL, 2);
    switch (heff_tag_of(v_it1_2440)) {
    case TAG_SetPath: {
      V v_path_2442 = heff_field(v_it1_2440, 0);
      V v_e_2443 = heff_field(v_it1_2440, 1);
      heff_take_n(v_it1_2440, 3ULL, 2);
      V v_t_2444 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_e_2443}));
      return heff_tag_at_n(v_ru_24f_2439_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_path_2442, v_t_2444}), v_fsp_2441});
    }
    default: return heff_nomatch(v_it1_2440);
    }
  }
  default: return heff_nomatch(v_f_2439);
  }
}
Clo g_heff_2eelab_2eclauses_2eanyC_24s44140518x185484176_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eanyC_24s44140518x185484176_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eanyC_24s44140518x185484176(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_DeclEquations: {
        V v_a_246 = heff_field(v_a_244, 0);
        if (heff_strEq_c_lent(v_lit_240, v_a_246, 0)) {
          return NTAG(TAG_True);
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_DeclDefine: {
        V v_a_2412 = heff_field(v_a_244, 0);
        if (heff_strEq_c_lent(v_lit_240, v_a_2412, 0)) {
          return NTAG(TAG_True);
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_DeclTheory: {
        V v_a_2418 = heff_field(v_a_244, 0);
        if (heff_strEq_c_lent(v_lit_240, v_a_2418, 0)) {
          return NTAG(TAG_True);
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_DeclPrimitive: {
        V v_a_2423 = heff_field(v_a_244, 0);
        if (heff_strEq_c_lent(v_lit_240, v_a_2423, 0)) {
          return NTAG(TAG_True);
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_DeclTest: {
        V v_a_2427 = heff_field(v_a_244, 0);
        if (heff_strEq_c_lent(v_lit_240, v_a_2427, 0)) {
          return NTAG(TAG_True);
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_DeclWatch: {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_a_244);
      }
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eanyC_24s44140518x185484176_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2eanyC_24s44140518x185484176(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2enameFits_str0, 1, "_");
V g_heff_2eelab_2eclauses_2enameFits_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2enameFits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enameFits_entry, 3, 0};

V g_heff_2eelab_2eclauses_2enameFits(V v_x_240, V v_c_241, V v_rows_242) {
top: ;
  return (g_heff_2eelab_2eclauses_2eallC(heff_clo_n(g_heff_2eelab_2eclauses_2enameFits_lam0, 1, 2, (V[]){v_c_241, v_x_240}), v_rows_242));
}
V g_heff_2eelab_2eclauses_2enameFits_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2enameFits(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2eclauses_2enameFits_lam0(V self, V *args) {
  V v_row_243 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_244 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(heff_rfield(v_row_243, 0)), v_c_241));
  V v_t_2420;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_p_248 = v_field_246;
      switch (heff_tag_of(v_p_248)) {
      case TAG_PVar: {
        V v_x_249 = heff_field(v_p_248, 0);
        heff_take_n(v_p_248, 1ULL, 1);
        v_t_2420 = heff_strEq_lent(v_x_240, v_x_249, 2);
        break;
      }
      case TAG_PTag: {
        heff_take_n(v_p_248, 0ULL, 3);
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_PLit: {
        heff_take_n(v_p_248, 0ULL, 1);
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_PRec: {
        heff_take_n(v_p_248, 0ULL, 2);
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_PAs: {
        V v_x_2416 = heff_field(v_p_248, 0);
        heff_take_n(v_p_248, 1ULL, 2);
        v_t_2420 = heff_strEq_lent(v_x_240, v_x_2416, 2);
        break;
      }
      case TAG_PBin: {
        heff_take_n(v_p_248, 0ULL, 2);
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_p_248);
      }
    } else {
      heff_drop(v_field_246);
      v_t_2420 = heff_strEq_lent(v_x_240, ((V)&g_heff_2eelab_2eclauses_2enameFits_str0), 2);
    }
  }
  V v_ret_24bool = heff_bool(((heff_dup(v_t_2420) == NTAG(TAG_True)) || ({ V v_t_2421 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(heff_rfield(v_row_243, 1)), NTAG(TAG_Nil))); int c_ = ({ V v_xs_2422 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(heff_rfield(v_row_243, 0), heff_dup(v_t_2421))); int c_ = ({ V v_t_2423 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_240)})); int c_ = ({ V v_x1_2424 = (g_list_2eany(heff_dup(v_t_2423), v_xs_2422)); int c_ = !(heff_dup(v_x1_2424) == NTAG(TAG_True)); heff_drop(v_x1_2424); c_; }); heff_drop(v_t_2423); c_; }); heff_drop(v_xs_2422); c_; }); heff_drop(v_t_2421); c_; })));
  heff_drop_rec(v_row_243, 2);
  heff_drop(v_x_240);
  heff_drop(v_t_2420);
  return v_ret_24bool;
}
Clo g_heff_2eelab_2eclauses_2earmSub_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2earmSub_entry, 7, 0};

V g_heff_2eelab_2eclauses_2earmSub(V v_used_240, V v_bound_241, V v_rows_242, V v_c_243, V v_t_244, V v_v_245, V v_i_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_t_244, 2, 4), heff_dup(v_i_246)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_p_2411 = v_field_249;
      V v_t_2423;
      switch (heff_tag_of(v_p_2411)) {
      case TAG_PVar: {
        V v_x_2412 = heff_field(v_p_2411, 0);
        V v_ru_24p_2411_24PVar = heff_take_reuse_n(v_p_2411, 1ULL, 1);
        v_t_2423 = heff_tag_at_n(v_ru_24p_2411_24PVar, TAG_Just, 1, (V[]){v_x_2412});
        break;
      }
      case TAG_PTag: {
        heff_take_n(v_p_2411, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PLit: {
        heff_take_n(v_p_2411, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PRec: {
        heff_take_n(v_p_2411, 0ULL, 2);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PAs: {
        V v_x_2419 = heff_field(v_p_2411, 0);
        heff_take_n(v_p_2411, 1ULL, 2);
        v_t_2423 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
        break;
      }
      case TAG_PBin: {
        heff_take_n(v_p_2411, 0ULL, 2);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_p_2411);
      }
      return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_rows_242; V a_3 = v_c_243; V a_4 = v_v_245; V a_5 = v_i_246; V a_6 = v_t_2423; V r_ = (g_heff_2eelab_2eclauses_2earmSubName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2423); r_; });
    } else {
      heff_drop(v_c_243);
      heff_drop(v_field_249);
      V v_t_2424 = heff_intShow(heff_intAdd(v_i_246, MK_INT(1LL)));
      return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_v_245, v_t_2424)));
    }
  }
}
V g_heff_2eelab_2eclauses_2earmSub_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2earmSub(a0, a1, a2, a[3], a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_heff_2eelab_2eclauses_2elookupField_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_g_244 = heff_field(v_x21_242, 0);
      V v_p_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_f_240, v_g_244, 2)) {
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_245}});
      } else {
        heff_drop(v_p_245);
        V t_0 = v_f_240;
        V t_1 = v_rest_243;
        v_f_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2eelab_2eclauses_2elookupField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elookupField_entry, 2, 0};

V g_heff_2eelab_2eclauses_2elookupField(V v_f_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2eelab_2eclauses_2elookupField_24cpr(v_f_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2eclauses_2elookupField_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2elookupField(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str4, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str5, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str6, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str7, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str8, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str9, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str10, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str11, 1, "_");
V g_heff_2eelab_2eclauses_2erecSpecialize_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSpecialize_lam1(V self, V *args); static Clo g_heff_2eelab_2eclauses_2erecSpecialize_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_lam1, 1, 0};
V g_heff_2eelab_2eclauses_2erecSpecialize_lam2(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSpecialize_lam3(V self, V *args); static Clo g_heff_2eelab_2eclauses_2erecSpecialize_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_lam3, 1, 0};
V g_heff_2eelab_2eclauses_2erecSpecialize_lam4(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSpecialize_lam5(V self, V *args); static Clo g_heff_2eelab_2eclauses_2erecSpecialize_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_lam5, 1, 0};
V g_heff_2eelab_2eclauses_2erecSpecialize_lam6(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSpecialize_lam7(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSpecialize_lam8(V self, V *args); static Clo g_heff_2eelab_2eclauses_2erecSpecialize_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_lam8, 1, 0};
V g_heff_2eelab_2eclauses_2erecSpecialize_lam9(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSpecialize_lam10(V self, V *args); static Clo g_heff_2eelab_2eclauses_2erecSpecialize_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_lam10, 1, 0};
Clo g_heff_2eelab_2eclauses_2erecSpecialize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_entry, 4, 0};

V g_heff_2eelab_2eclauses_2erecSpecialize(V v_c_240, V v_fs_241, V v_v_242, V v_r_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(heff_rfield(v_r_243, 0)), heff_dup(v_c_240)));
  V v_t_249;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_p_248 = v_field_246;
      v_t_249 = v_p_248;
    } else {
      heff_drop(v_field_246);
      v_t_249 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str0)});
    }
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_PVar: {
    heff_take_n(v_t_249, 0ULL, 1);
    V v_ys_2411 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str1), v_fs_241));
    V v_xs_2412 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2413 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2412)));
    V v_t_2414 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2412));
    V v_t_2415 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2411, v_t_2414));
    V v_pats_2416 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2413, v_t_2415));
    HeffT2 v_t_2417 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_take_field(v_r_243, 0), v_c_240));
    V v_t_2438;
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_p_2421 = v_field_2419;
        v_t_2438 = heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam0, 1, 2, (V[]){v_p_2421, v_v_242});
      } else {
        heff_drop(v_v_242);
        heff_drop(v_field_2419);
        v_t_2438 = ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_lam1_clo);
      }
    }
    V v_rhs_2439 = heff_tr(heff_call(v_t_2438, 1, (V[]){heff_get_n(v_r_243, 1, 2)}));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2416, v_rhs_2439});
  }
  case TAG_PTag: {
    heff_take_n(v_t_249, 0ULL, 3);
    V v_ys_2443 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str3), v_fs_241));
    V v_xs_2444 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2445 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2444)));
    V v_t_2446 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2444));
    V v_t_2447 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2443, v_t_2446));
    V v_pats_2448 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2445, v_t_2447));
    HeffT2 v_t_2449 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_take_field(v_r_243, 0), v_c_240));
    V v_t_2470;
    {
      V v_field_2451 = v_t_2449.f[1];
      int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
      if ((v_tag_2450 == ((int64_t)0ULL))) {
        V v_p_2453 = v_field_2451;
        v_t_2470 = heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam2, 1, 2, (V[]){v_p_2453, v_v_242});
      } else {
        heff_drop(v_v_242);
        heff_drop(v_field_2451);
        v_t_2470 = ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_lam3_clo);
      }
    }
    V v_rhs_2471 = heff_tr(heff_call(v_t_2470, 1, (V[]){heff_get_n(v_r_243, 1, 2)}));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2448, v_rhs_2471});
  }
  case TAG_PLit: {
    heff_take_n(v_t_249, 0ULL, 1);
    V v_ys_2473 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str5), v_fs_241));
    V v_xs_2474 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2475 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2474)));
    V v_t_2476 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2474));
    V v_t_2477 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2473, v_t_2476));
    V v_pats_2478 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2475, v_t_2477));
    HeffT2 v_t_2479 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_take_field(v_r_243, 0), v_c_240));
    V v_t_24100;
    {
      V v_field_2481 = v_t_2479.f[1];
      int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
      if ((v_tag_2480 == ((int64_t)0ULL))) {
        V v_p_2483 = v_field_2481;
        v_t_24100 = heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam4, 1, 2, (V[]){v_p_2483, v_v_242});
      } else {
        heff_drop(v_v_242);
        heff_drop(v_field_2481);
        v_t_24100 = ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_lam5_clo);
      }
    }
    V v_rhs_24101 = heff_tr(heff_call(v_t_24100, 1, (V[]){heff_get_n(v_r_243, 1, 2)}));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2478, v_rhs_24101});
  }
  case TAG_PRec: {
    V v_fps_24102 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 2);
    heff_drop(v_v_242);
    V v_ys_24110 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam6, 1, 1, (V[]){v_fps_24102}), v_fs_241));
    V v_xs_24111 = heff_take_field(v_r_243, 0);
    V v_t_24112 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_24111)));
    V v_t_24113 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_24111));
    V v_t_24114 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_24110, v_t_24113));
    V v_pats_24115 = (g_heff_2eelab_2eclauses_2eappendC(v_t_24112, v_t_24114));
    return ({ V rv_0 = v_pats_24115; V rr_ = heff_rec_reuse_nf(v_r_243, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  case TAG_PAs: {
    heff_take_n(v_t_249, 0ULL, 2);
    V v_ys_24118 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str8), v_fs_241));
    V v_xs_24119 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_24120 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_24119)));
    V v_t_24121 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_24119));
    V v_t_24122 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_24118, v_t_24121));
    V v_pats_24123 = (g_heff_2eelab_2eclauses_2eappendC(v_t_24120, v_t_24122));
    HeffT2 v_t_24124 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_take_field(v_r_243, 0), v_c_240));
    V v_t_24145;
    {
      V v_field_24126 = v_t_24124.f[1];
      int64_t v_tag_24125 = ((int64_t)v_t_24124.f[0]);
      if ((v_tag_24125 == ((int64_t)0ULL))) {
        V v_p_24128 = v_field_24126;
        v_t_24145 = heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam7, 1, 2, (V[]){v_p_24128, v_v_242});
      } else {
        heff_drop(v_v_242);
        heff_drop(v_field_24126);
        v_t_24145 = ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_lam8_clo);
      }
    }
    V v_rhs_24146 = heff_tr(heff_call(v_t_24145, 1, (V[]){heff_get_n(v_r_243, 1, 2)}));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_24123, v_rhs_24146});
  }
  case TAG_PBin: {
    heff_take_n(v_t_249, 0ULL, 2);
    V v_ys_24149 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str10), v_fs_241));
    V v_xs_24150 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_24151 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_24150)));
    V v_t_24152 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_24150));
    V v_t_24153 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_24149, v_t_24152));
    V v_pats_24154 = (g_heff_2eelab_2eclauses_2eappendC(v_t_24151, v_t_24153));
    HeffT2 v_t_24155 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_take_field(v_r_243, 0), v_c_240));
    V v_t_24176;
    {
      V v_field_24157 = v_t_24155.f[1];
      int64_t v_tag_24156 = ((int64_t)v_t_24155.f[0]);
      if ((v_tag_24156 == ((int64_t)0ULL))) {
        V v_p_24159 = v_field_24157;
        v_t_24176 = heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam9, 1, 2, (V[]){v_p_24159, v_v_242});
      } else {
        heff_drop(v_v_242);
        heff_drop(v_field_24157);
        v_t_24176 = ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_lam10_clo);
      }
    }
    V v_rhs_24177 = heff_tr(heff_call(v_t_24176, 1, (V[]){heff_get_n(v_r_243, 1, 2)}));
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_24154, v_rhs_24177});
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erecSpecialize(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam0(V self, V *args) {
  V v_e_2422 = args[0];
  V v_p_2421 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2421)) {
  case TAG_PVar: {
    V v_x_2423 = heff_field(v_p_2421, 0);
    heff_take_n(v_p_2421, 1ULL, 1);
    if (heff_strEq_c_lent(v_x_2423, ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str2), 2)) {
      heff_drop(v_v_242);
      heff_drop(v_x_2423);
      return v_e_2422;
    } else {
      if (heff_strEq_c_lent(v_x_2423, v_v_242, 0)) {
        heff_drop(v_v_242);
        heff_drop(v_x_2423);
        return v_e_2422;
      } else {
        V v_t_2426 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2423, v_v_242));
        V f_ = heff_get_n(v_t_2426, 3, 5);
        args[0] = v_e_2422;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_2421, 0ULL, 3);
    heff_drop(v_v_242);
    return v_e_2422;
  }
  case TAG_PLit: {
    heff_take_n(v_p_2421, 0ULL, 1);
    heff_drop(v_v_242);
    return v_e_2422;
  }
  case TAG_PRec: {
    heff_take_n(v_p_2421, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2422;
  }
  case TAG_PAs: {
    heff_take_n(v_p_2421, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2422;
  }
  case TAG_PBin: {
    heff_take_n(v_p_2421, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2422;
  }
  default: return heff_nomatch(v_p_2421);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam1(V self, V *args) {
  V v_e_2437 = args[0];
  return v_e_2437;
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam2(V self, V *args) {
  V v_e_2454 = args[0];
  V v_p_2453 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2453)) {
  case TAG_PVar: {
    V v_x_2455 = heff_field(v_p_2453, 0);
    heff_take_n(v_p_2453, 1ULL, 1);
    if (heff_strEq_c_lent(v_x_2455, ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str4), 2)) {
      heff_drop(v_v_242);
      heff_drop(v_x_2455);
      return v_e_2454;
    } else {
      if (heff_strEq_c_lent(v_x_2455, v_v_242, 0)) {
        heff_drop(v_v_242);
        heff_drop(v_x_2455);
        return v_e_2454;
      } else {
        V v_t_2458 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2455, v_v_242));
        V f_ = heff_get_n(v_t_2458, 3, 5);
        args[0] = v_e_2454;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_2453, 0ULL, 3);
    heff_drop(v_v_242);
    return v_e_2454;
  }
  case TAG_PLit: {
    heff_take_n(v_p_2453, 0ULL, 1);
    heff_drop(v_v_242);
    return v_e_2454;
  }
  case TAG_PRec: {
    heff_take_n(v_p_2453, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2454;
  }
  case TAG_PAs: {
    heff_take_n(v_p_2453, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2454;
  }
  case TAG_PBin: {
    heff_take_n(v_p_2453, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2454;
  }
  default: return heff_nomatch(v_p_2453);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam3(V self, V *args) {
  V v_e_2469 = args[0];
  return v_e_2469;
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam4(V self, V *args) {
  V v_e_2484 = args[0];
  V v_p_2483 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2483)) {
  case TAG_PVar: {
    V v_x_2485 = heff_field(v_p_2483, 0);
    heff_take_n(v_p_2483, 1ULL, 1);
    if (heff_strEq_c_lent(v_x_2485, ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str6), 2)) {
      heff_drop(v_v_242);
      heff_drop(v_x_2485);
      return v_e_2484;
    } else {
      if (heff_strEq_c_lent(v_x_2485, v_v_242, 0)) {
        heff_drop(v_v_242);
        heff_drop(v_x_2485);
        return v_e_2484;
      } else {
        V v_t_2488 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2485, v_v_242));
        V f_ = heff_get_n(v_t_2488, 3, 5);
        args[0] = v_e_2484;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_2483, 0ULL, 3);
    heff_drop(v_v_242);
    return v_e_2484;
  }
  case TAG_PLit: {
    heff_take_n(v_p_2483, 0ULL, 1);
    heff_drop(v_v_242);
    return v_e_2484;
  }
  case TAG_PRec: {
    heff_take_n(v_p_2483, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2484;
  }
  case TAG_PAs: {
    heff_take_n(v_p_2483, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2484;
  }
  case TAG_PBin: {
    heff_take_n(v_p_2483, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_2484;
  }
  default: return heff_nomatch(v_p_2483);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam5(V self, V *args) {
  V v_e_2499 = args[0];
  return v_e_2499;
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam6(V self, V *args) {
  V v_f_24104 = args[0];
  V v_fps_24102 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24105 = ({ V a_0 = v_f_24104; V a_1 = v_fps_24102; HeffT2 r_ = (g_heff_2eelab_2eclauses_2elookupField_24cpr(a_0, a_1)); heff_drop(v_f_24104); r_; });
  {
    V v_field_24107 = v_t_24105.f[1];
    int64_t v_tag_24106 = ((int64_t)v_t_24105.f[0]);
    if ((v_tag_24106 == ((int64_t)0ULL))) {
      V v_p_24109 = v_field_24107;
      return v_p_24109;
    } else {
      heff_drop(v_field_24107);
      return heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str7)});
    }
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam7(V self, V *args) {
  V v_e_24129 = args[0];
  V v_p_24128 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_24128)) {
  case TAG_PVar: {
    V v_x_24130 = heff_field(v_p_24128, 0);
    heff_take_n(v_p_24128, 1ULL, 1);
    if (heff_strEq_c_lent(v_x_24130, ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str9), 2)) {
      heff_drop(v_v_242);
      heff_drop(v_x_24130);
      return v_e_24129;
    } else {
      if (heff_strEq_c_lent(v_x_24130, v_v_242, 0)) {
        heff_drop(v_v_242);
        heff_drop(v_x_24130);
        return v_e_24129;
      } else {
        V v_t_24133 = (g_heff_2eelab_2eclauses_2erenamer(v_x_24130, v_v_242));
        V f_ = heff_get_n(v_t_24133, 3, 5);
        args[0] = v_e_24129;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_24128, 0ULL, 3);
    heff_drop(v_v_242);
    return v_e_24129;
  }
  case TAG_PLit: {
    heff_take_n(v_p_24128, 0ULL, 1);
    heff_drop(v_v_242);
    return v_e_24129;
  }
  case TAG_PRec: {
    heff_take_n(v_p_24128, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_24129;
  }
  case TAG_PAs: {
    heff_take_n(v_p_24128, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_24129;
  }
  case TAG_PBin: {
    heff_take_n(v_p_24128, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_24129;
  }
  default: return heff_nomatch(v_p_24128);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam8(V self, V *args) {
  V v_e_24144 = args[0];
  return v_e_24144;
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam9(V self, V *args) {
  V v_e_24160 = args[0];
  V v_p_24159 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_24159)) {
  case TAG_PVar: {
    V v_x_24161 = heff_field(v_p_24159, 0);
    heff_take_n(v_p_24159, 1ULL, 1);
    if (heff_strEq_c_lent(v_x_24161, ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str11), 2)) {
      heff_drop(v_v_242);
      heff_drop(v_x_24161);
      return v_e_24160;
    } else {
      if (heff_strEq_c_lent(v_x_24161, v_v_242, 0)) {
        heff_drop(v_v_242);
        heff_drop(v_x_24161);
        return v_e_24160;
      } else {
        V v_t_24164 = (g_heff_2eelab_2eclauses_2erenamer(v_x_24161, v_v_242));
        V f_ = heff_get_n(v_t_24164, 3, 5);
        args[0] = v_e_24160;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_24159, 0ULL, 3);
    heff_drop(v_v_242);
    return v_e_24160;
  }
  case TAG_PLit: {
    heff_take_n(v_p_24159, 0ULL, 1);
    heff_drop(v_v_242);
    return v_e_24160;
  }
  case TAG_PRec: {
    heff_take_n(v_p_24159, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_24160;
  }
  case TAG_PAs: {
    heff_take_n(v_p_24159, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_24160;
  }
  case TAG_PBin: {
    heff_take_n(v_p_24159, 0ULL, 2);
    heff_drop(v_v_242);
    return v_e_24160;
  }
  default: return heff_nomatch(v_p_24159);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam10(V self, V *args) {
  V v_e_24175 = args[0];
  return v_e_24175;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_str0, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_str1, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_str2, 5, "False");
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_str3, 5, "False");
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_str4, 5, "False");
Clo g_heff_2eelab_2eclauses_2eandC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eandC_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eandC(V v_c_240, V v_rest_241, V v_sp_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_str0)}), heff_dup(v_sp_242)});
  V v_x1_244 = ({ V a_0 = v_t_243; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_At: {
    V v_s_246 = heff_field(v_x1_244, 1);
    heff_take_n(v_x1_244, 2ULL, 2);
    v_t_247 = v_s_246;
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_t_248 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_242, 0)); V rr_ = heff_rec_reuse_nf(v_t_247, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_249 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_str1), heff_dup(v_sp_242), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_t_248)}), heff_dup(v_rest_241)});
  V v_t_2413;
  switch (heff_tag_of(v_rest_241)) {
  case TAG_At: {
    V v_s_2412 = heff_field(v_rest_241, 1);
    heff_take_n(v_rest_241, 2ULL, 2);
    v_t_2413 = v_s_2412;
    break;
  }
  default: heff_nomatch(v_rest_241);
  }
  V v_t_2414 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_str2)}), heff_dup(v_sp_242)});
  V v_x1_2416 = ({ V a_0 = v_t_2415; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_At: {
    V v_s_2418 = heff_field(v_x1_2416, 1);
    heff_take_n(v_x1_2416, 2ULL, 2);
    v_t_2419 = v_s_2418;
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2420 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_242, 0)); V rr_ = heff_rec_reuse_nf(v_t_2419, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2421 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_str3), heff_dup(v_sp_242), NTAG(TAG_Nil)});
  V v_t_2422 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_str4), heff_dup(v_sp_242), NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_t_2420)}), heff_tag_n(TAG_At, 2, (V[]){v_t_2422, heff_dup(v_sp_242)})});
  V v_t_2424 = ({ V rv_1 = heff_dup(heff_rfield(v_sp_242, 1)); V rr_ = heff_rec_reuse_nf(v_t_2420, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_t_2424}), NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_t_2414}), v_t_2425});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_c_240, v_t_2426}), v_sp_242});
}
V g_heff_2eelab_2eclauses_2eandC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eandC(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eoffC_str0, 6, "intAdd");
V g_heff_2eelab_2eclauses_2eoffC_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eoffC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eoffC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eoffC(V v_o_240, V v_sp_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_IInt, 1, (V[]){heff_take_field(v_o_240, 0)});
  V v_t_243 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_242, heff_dup(v_sp_241)})});
  return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eoffC_lam0, 2, 1, (V[]){heff_dup(v_sp_241)}); V a_1 = heff_tag_n(TAG_At, 2, (V[]){v_t_243, v_sp_241}); V b_2 = heff_get_n(v_o_240, 1, 2); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2eelab_2eclauses_2eoffC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eoffC(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2eoffC_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_t_245 = args[1];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), heff_tag_n(TAG_Cons, 2, (V[]){v_acc_244, v_t_246})));
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eoffC_str0)}), heff_dup(v_sp_241)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_247}), heff_dup(v_sp_241)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), v_sp_241});
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efloatRead_str0, 11, "floatOfBits");
Clo g_heff_2eelab_2eclauses_2efloatRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efloatRead_entry, 4, 0};

V g_heff_2eelab_2eclauses_2efloatRead(V v_k_240, V v_off_241, V v_n_242, V v_flags_243) {
top: ;
  V v_sp_244 = heff_dup(heff_rfield(v_k_240, 6));
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_n_242)}), heff_dup(v_sp_244)});
  V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_245}), v_sp_244});
  V v_t_247 = heff_rec_n(2, shape_bits__terms, (V[]){v_n_242, NTAG(TAG_Nil)});
  V v_i_248 = (g_heff_2eelab_2eclauses_2eintRead(heff_dup(v_k_240), v_off_241, v_t_247, v_flags_243));
  V v_t_2411;
  switch (heff_tag_of(v_i_248)) {
  case TAG_At: {
    V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
    v_t_2411 = v_s_2410;
    break;
  }
  default: heff_nomatch(v_i_248);
  }
  V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  V v_args_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2413});
  V v_sp_2415 = heff_get_n(v_k_240, 6, 7);
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2efloatRead_str0)}), heff_dup(v_sp_2415)});
  V v_t_2417 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2415), v_args_2414));
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2417}), v_sp_2415});
}
V g_heff_2eelab_2eclauses_2efloatRead_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2efloatRead(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efloatTest_str0, 7, "floatEq");
Clo g_heff_2eelab_2eclauses_2efloatTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efloatTest_entry, 5, 0};

V g_heff_2eelab_2eclauses_2efloatTest(V v_k_240, V v_off_241, V v_s_242, V v_v_243, V v_rest_244) {
top: ;
  switch (heff_tag_of(v_v_243)) {
  case TAG_At: {
    V v_v1_245 = heff_field(v_v_243, 0);
    V v_xsp_246 = heff_field(v_v_243, 1);
    V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
    switch (heff_tag_of(v_v1_245)) {
    case TAG_PatVar: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_xsp_246);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatTag: {
      heff_take_n(v_v1_245, 0ULL, 3);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_xsp_246);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatOp: {
      heff_take_n(v_v1_245, 0ULL, 3);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_xsp_246);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatInt: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_xsp_246);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatFloat: {
      double v_x_2415 = heff_tflat_f64(v_v1_245, 0);
      V v_ru_24v1_245_24PatFloat = heff_take_reuse_na(v_v1_245, 0ULL, 1);
      V v_t_2416 = heff_take_field(v_s_242, 2);
      V v_t_2421;
      switch (heff_tag_of(v_t_2416)) {
      case TAG_SizeDefault: {
        v_t_2421 = MK_INT(64LL);
        break;
      }
      case TAG_SizeNumber: {
        V v_n_2417 = heff_field(v_t_2416, 0);
        heff_take_n(v_t_2416, 1ULL, 1);
        v_t_2421 = v_n_2417;
        break;
      }
      case TAG_SizeName: {
        heff_take_n(v_t_2416, 0ULL, 3);
        v_t_2421 = MK_INT(64LL);
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
      V v_i_2422 = (g_heff_2eelab_2eclauses_2efloatRead(heff_dup(v_k_240), v_off_241, v_t_2421, heff_get_n(v_s_242, 3, 5)));
      V v_t_2425;
      switch (heff_tag_of(v_i_2422)) {
      case TAG_At: {
        V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_i_2422);
      }
      V v_t_2426 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2422}), v_t_2425});
      V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_nf(v_ru_24v1_245_24PatFloat, TAG_IFloat, 1, 1u, (V[]){heff_word_f64(v_x_2415)}), heff_dup(v_xsp_246)});
      V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2427}), v_xsp_246});
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      V v_args_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2429});
      V v_sp_2431 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2efloatTest_str0)}), heff_dup(v_sp_2431)});
      V v_t_2433 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2431), v_args_2430));
      V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2432, v_t_2433}), v_sp_2431});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2434, v_rest_244, heff_get_n(v_k_240, 6, 7)));
    }
    case TAG_PatString: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_xsp_246);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatBinary: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_xsp_246);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatRune: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_xsp_246);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatRecord: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_xsp_246);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatWord: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_xsp_246);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    case TAG_PatAs: {
      heff_take_n(v_v1_245, 0ULL, 3);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_off_241);
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_xsp_246);
      heff_drop_cell(v_ru_24v_243_24At, 2);
      return v_rest_244;
    }
    default: return heff_nomatch(v_v1_245);
    }
  }
  default: return heff_nomatch(v_v_243);
  }
}
V g_heff_2eelab_2eclauses_2efloatTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2efloatTest(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecodeTest_str0, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecodeTest_str1, 5, "intEq");
Clo g_heff_2eelab_2eclauses_2ecodeTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecodeTest_entry, 4, 0};

V g_heff_2eelab_2eclauses_2ecodeTest(V v_k_240, V v_c_241, V v_v_242, V v_rest_243) {
top: ;
  switch (heff_tag_of(v_v_242)) {
  case TAG_At: {
    V v_v1_244 = heff_field(v_v_242, 0);
    V v_ru_24v_242_24At = heff_take_reuse_n(v_v_242, 1ULL, 2);
    switch (heff_tag_of(v_v1_244)) {
    case TAG_PatVar: {
      heff_take_n(v_v1_244, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatTag: {
      heff_take_n(v_v1_244, 0ULL, 3);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatOp: {
      heff_take_n(v_v1_244, 0ULL, 3);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatInt: {
      V v_n_2413 = heff_field(v_v1_244, 0);
      V v_ru_24v1_244_24PatInt = heff_take_reuse_n(v_v1_244, 1ULL, 1);
      V v_sp_2414 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2415 = heff_tag_at_n(v_ru_24v_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ecodeTest_str0)}), heff_dup(v_sp_2414)});
      V v_t_2418;
      switch (heff_tag_of(v_c_241)) {
      case TAG_At: {
        V v_s_2417 = heff_dup(heff_field(v_c_241, 1));
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24v1_244_24PatInt, TAG_CInf, 1, (V[]){v_c_241}), v_t_2418});
      V v_sp_2420 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_n_2413}), heff_dup(v_sp_2420)});
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2421}), v_sp_2420});
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
      V v_t_2424 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2414), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2423})));
      V v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2415, v_t_2424}), v_sp_2414});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2425, v_rest_243, heff_get_n(v_k_240, 6, 7)));
    }
    case TAG_PatFloat: {
      heff_take_na(v_v1_244, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatString: {
      heff_take_n(v_v1_244, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatBinary: {
      heff_take_n(v_v1_244, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatRune: {
      V v_n_2429 = heff_field(v_v1_244, 0);
      V v_ru_24v1_244_24PatRune = heff_take_reuse_n(v_v1_244, 1ULL, 1);
      V v_sp_2430 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2431 = heff_tag_at_n(v_ru_24v_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ecodeTest_str1)}), heff_dup(v_sp_2430)});
      V v_t_2434;
      switch (heff_tag_of(v_c_241)) {
      case TAG_At: {
        V v_s_2433 = heff_dup(heff_field(v_c_241, 1));
        v_t_2434 = v_s_2433;
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24v1_244_24PatRune, TAG_CInf, 1, (V[]){v_c_241}), v_t_2434});
      V v_sp_2436 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_n_2429}), heff_dup(v_sp_2436)});
      V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2437}), v_sp_2436});
      V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
      V v_t_2440 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2430), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2439})));
      V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2431, v_t_2440}), v_sp_2430});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2441, v_rest_243, heff_get_n(v_k_240, 6, 7)));
    }
    case TAG_PatRecord: {
      heff_take_n(v_v1_244, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatWord: {
      heff_take_n(v_v1_244, 0ULL, 1);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    case TAG_PatAs: {
      heff_take_n(v_v1_244, 0ULL, 3);
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24v_242_24At, 2);
      return v_rest_243;
    }
    default: return heff_nomatch(v_v1_244);
    }
  }
  default: return heff_nomatch(v_v_242);
  }
}
V g_heff_2eelab_2eclauses_2ecodeTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecodeTest(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinTestGo_str0, 5, "intEq");
Clo g_heff_2eelab_2eclauses_2ebinTestGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebinTestGo_entry, 6, 0};

V g_heff_2eelab_2eclauses_2ebinTestGo(V v_t_240, V v_k_241, V v_env_242, V v_i_243, V v_off_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop(v_env_242);
    heff_drop(v_i_243);
    V v_t_246 = (g_heff_2eelab_2eclauses_2eoffC(v_off_244, heff_dup(heff_rfield(v_k_241, 6))));
    V v_sp_247 = heff_dup(heff_rfield(v_k_241, 6));
    V v_t_248 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_241, 2)});
    V v_t_249 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, heff_dup(v_sp_247)})});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_247}), NTAG(TAG_Nil)});
    V v_args_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2410});
    V v_sp_2412 = heff_get_n(v_k_241, 6, 7);
    V v_t_2413 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2412), v_args_2411));
    V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinTestGo_str0)}), heff_dup(v_sp_2412)});
    V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2414, v_t_2413}), heff_dup(v_sp_2412)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2415}), v_sp_2412});
  }
  case TAG_Cons: {
    V v_s_2416 = heff_field(v_x6_245, 0);
    V v_rest_2417 = heff_field(v_x6_245, 1);
    V v_t_2418 = (g_heff_2eelab_2eclauses_2ewidthBy(v_env_242, heff_dup(heff_rfield(v_s_2416, 4)), heff_dup(heff_rfield(v_s_2416, 1)), heff_rfield(v_s_2416, 2), heff_rfield(v_s_2416, 0)));
    return (g_heff_2eelab_2eclauses_2esegTest(v_t_240, v_k_241, v_env_242, v_i_243, v_off_244, heff_dup(v_s_2416), heff_dup(v_rest_2417), v_t_2418, heff_dup(heff_rfield(v_s_2416, 1))));
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eelab_2eclauses_2ebinTestGo_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2eelab_2eclauses_2ebinTestGo(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erestC_str0, 10, "bitsLength");
HEFF_LIT(g_heff_2eelab_2eclauses_2erestC_str1, 6, "intSub");
Clo g_heff_2eelab_2eclauses_2erestC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erestC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erestC(V v_k_240, V v_off_241) {
top: ;
  V v_sp_242 = heff_dup(heff_rfield(v_k_240, 6));
  V v_sp_243 = heff_dup(heff_rfield(v_k_240, 6));
  V v_t_244 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_240, 0)});
  V v_t_245 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_243)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_243}), NTAG(TAG_Nil)});
  V v_t_247 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_t_246));
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erestC_str0)}), heff_dup(v_sp_242)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_247}), heff_dup(v_sp_242)});
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), v_sp_242});
  V v_t_2411 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_args_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2412});
  V v_sp_2414 = heff_get_n(v_k_240, 6, 7);
  V v_t_2415 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2414), v_args_2413));
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erestC_str1)}), heff_dup(v_sp_2414)});
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2415}), heff_dup(v_sp_2414)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), v_sp_2414});
}
V g_heff_2eelab_2eclauses_2erestC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erestC(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2easBitsC_str0, 11, "bitsOfBytes");
Clo g_heff_2eelab_2eclauses_2easBitsC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2easBitsC_entry, 5, 0};

V g_heff_2eelab_2eclauses_2easBitsC(V v_x1_240, V v_v_241, V v_x_242, V v_sp_243, V v_body_244) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2easBitsC_str0)}), heff_dup(v_sp_243)});
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_v_241}), heff_dup(v_sp_243)});
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_246}), heff_dup(v_sp_243)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_t_248));
    V v_rhs_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_245, v_t_249}), heff_dup(v_sp_243)});
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_242}), heff_dup(v_sp_243)});
    V v_t_2414;
    switch (heff_tag_of(v_body_244)) {
    case TAG_At: {
      V v_s_2413 = heff_dup(heff_field(v_body_244, 1));
      v_t_2414 = v_s_2413;
      break;
    }
    default: heff_nomatch(v_body_244);
    }
    V v_t_2415 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_243, 0)); V rr_ = heff_rec_reuse_nf(v_t_2414, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2411, v_body_244}), v_t_2415});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2410, v_t_2416}), v_sp_243});
  } else {
    heff_drop(v_v_241);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    return v_body_244;
  }
}
V g_heff_2eelab_2eclauses_2easBitsC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2easBitsC(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epeelCols_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epeelCols_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epeelCols(V v_x1_240, V v_x2_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2eelab_2eclauses_2epeelCols_24cpr(v_x1_240, v_x2_241, v_e_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epeelCols(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2ecolFrom_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ecolFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecolFrom_entry, 4, 0};

V g_heff_2eelab_2eclauses_2ecolFrom(V v_used_240, V v_taken_241, V v_rows_242, V v_i_243) {
top: ;
  V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ecolFrom_lam0, 1, 1, (V[]){heff_dup(v_i_243)}), heff_dup(v_rows_242)));
  V v_t_2422 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2421));
  V v_t_2423 = (g_heff_2eelab_2eclauses_2enubStr(v_t_2422));
  return ({ V a_0 = v_used_240; V a_1 = v_taken_241; V a_2 = v_rows_242; V a_3 = v_i_243; V a_4 = v_t_2423; V r_ = (g_heff_2eelab_2eclauses_2ecolPick(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rows_242); heff_drop(v_t_2423); r_; });
}
V g_heff_2eelab_2eclauses_2ecolFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2ecolFrom(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2ecolFrom_lam0(V self, V *args) {
  V v_r_244 = args[0];
  V v_i_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_245 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_r_244, 0, 2), v_i_243));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_p_249 = v_field_247;
      switch (heff_tag_of(v_p_249)) {
      case TAG_PVar: {
        V v_x_2410 = heff_field(v_p_249, 0);
        V v_ru_24p_249_24PVar = heff_take_reuse_n(v_p_249, 1ULL, 1);
        return heff_tag_at_n(v_ru_24p_249_24PVar, TAG_Just, 1, (V[]){v_x_2410});
      }
      case TAG_PTag: {
        heff_take_n(v_p_249, 0ULL, 3);
        return NTAG(TAG_Nothing);
      }
      case TAG_PLit: {
        heff_take_n(v_p_249, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_PRec: {
        heff_take_n(v_p_249, 0ULL, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_PAs: {
        V v_x_2417 = heff_field(v_p_249, 0);
        heff_take_n(v_p_249, 1ULL, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){v_x_2417});
      }
      case TAG_PBin: {
        heff_take_n(v_p_249, 0ULL, 2);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_p_249);
      }
    } else {
      heff_drop(v_field_247);
      return NTAG(TAG_Nothing);
    }
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str4, 12, "builtin.Bool");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str5, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str6, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str7, 5, "False");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str8, 5, "False");
V g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_segs_246, V v_bsp_247, V v_xs_248, V v_ys_249, V v_k_2410, V v_made_2411) {
top: ;
  HeffT2 v_t_2412 = (g_heff_2eelab_2eclauses_2ebinChecks_24cpr(v_rows_244, heff_dup(v_c_245), heff_dup(v_bsp_247)));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      heff_drop(v_segs_246);
      heff_drop_rec(v_bsp_247, 2);
      heff_drop(v_xs_248);
      heff_drop(v_ys_249);
      heff_drop_rec(v_k_2410, 7);
      V v_e_2416 = v_field_2414;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2416}});
    } else {
      V v_x_2417 = v_field_2414;
      heff_drop(v_x_2417);
      V v_bound_2418 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ys_249), heff_dup(v_bound_241)));
      V v_vars_2419 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_vars_243), heff_dup(v_ys_249)));
      V v_rows_2433 = (g_heff_2eelab_2eclauses_2emapWithIndexC(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam0, 2, 3, (V[]){heff_dup(v_c_245), v_xs_248, heff_dup(v_ys_249)}), heff_dup(v_rows_244)));
      V v_t_2435 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam1, 1, 1, (V[]){heff_dup(v_vars_2419)}), v_rows_2433));
      HeffT2 v_t_2436 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(heff_dup(v_used_240), v_bound_2418, heff_dup(v_sp_242), v_vars_2419, v_t_2435));
      {
        V v_field_2438 = v_t_2436.f[1];
        int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
        if ((v_tag_2437 == ((int64_t)0ULL))) {
          heff_drop(v_used_240);
          heff_drop(v_bound_241);
          heff_drop(v_sp_242);
          heff_drop(v_vars_243);
          heff_drop(v_rows_244);
          heff_drop(v_c_245);
          heff_drop(v_segs_246);
          heff_drop_rec(v_bsp_247, 2);
          heff_drop(v_ys_249);
          heff_drop_rec(v_k_2410, 7);
          V v_e_2440 = v_field_2438;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2440}});
        } else {
          V v_x_2441 = v_field_2438;
          V v_rows_2442 = (g_heff_2eelab_2eclauses_2edropC(MK_INT(1LL), v_rows_244));
          V v_t_2444 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam2, 1, 1, (V[]){heff_dup(v_vars_243)}), v_rows_2442));
          HeffT2 v_t_2445 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(v_used_240, v_bound_241, v_sp_242, heff_dup(v_vars_243), v_t_2444));
          {
            V v_field_2447 = v_t_2445.f[1];
            int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
            if ((v_tag_2446 == ((int64_t)0ULL))) {
              heff_drop(v_vars_243);
              heff_drop(v_c_245);
              heff_drop(v_segs_246);
              heff_drop_rec(v_bsp_247, 2);
              heff_drop(v_ys_249);
              heff_drop_rec(v_k_2410, 7);
              heff_drop(v_x_2441);
              V v_e_2449 = v_field_2447;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2449}});
            } else {
              V v_x_2450 = v_field_2447;
              HeffT2 v_t_2451 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, v_c_245));
              V v_t_2456;
              {
                V v_field_2453 = v_t_2451.f[1];
                int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
                if ((v_tag_2452 == ((int64_t)0ULL))) {
                  V v_v_2455 = v_field_2453;
                  v_t_2456 = v_v_2455;
                } else {
                  heff_drop(v_field_2453);
                  v_t_2456 = ((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str2);
                }
              }
              V v_t_2457 = heff_dup(heff_rfield(v_k_2410, 1));
              V v_t_2458;
              if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
                heff_drop(v_t_2457);
                v_t_2458 = NTAG(TAG_Nothing);
              } else {
                heff_drop(v_t_2457);
                v_t_2458 = (g_heff_2eelab_2eclauses_2ewholeBin(v_segs_246, ((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str3)));
              }
              V v_t_2459 = (g_heff_2eelab_2eclauses_2ebinTestOf(heff_dup(v_k_2410), heff_dup(v_segs_246), v_t_2458));
              V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str4)}), heff_dup(v_bsp_247)});
              V v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_t_2460}), heff_dup(v_bsp_247)});
              V v_t_2462 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_2459, v_t_2461}), heff_dup(v_bsp_247)});
              V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str5)}), heff_dup(v_bsp_247)});
              V v_x1_2464 = ({ V a_0 = v_t_2463; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
              V v_t_2467;
              switch (heff_tag_of(v_x1_2464)) {
              case TAG_At: {
                V v_s_2466 = heff_field(v_x1_2464, 1);
                heff_take_n(v_x1_2464, 2ULL, 2);
                v_t_2467 = v_s_2466;
                break;
              }
              default: heff_nomatch(v_x1_2464);
              }
              V v_t_2468 = ({ V rv_0 = heff_dup(heff_rfield(v_bsp_247, 0)); V rr_ = heff_rec_reuse_nf(v_t_2467, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              V v_t_2469 = (g_heff_2eelab_2eclauses_2ebinBind(heff_dup(v_k_2410)));
              V v_t_2470 = heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
              V v_e_2471 = heff_tr(heff_call(heff_get_n(v_t_2469, 0, 1), 6, (V[]){NTAG(TAG_Nil), MK_INT(0LL), v_ys_249, v_t_2470, v_segs_246, v_x_2441}));
              V v_t_2472 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str6), heff_dup(v_bsp_247), NTAG(TAG_Nil)});
              V v_t_2473 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2472, heff_dup(v_t_2468)}), heff_dup(v_e_2471)});
              V v_t_2476;
              switch (heff_tag_of(v_e_2471)) {
              case TAG_At: {
                V v_s_2475 = heff_field(v_e_2471, 1);
                heff_take_n(v_e_2471, 2ULL, 2);
                v_t_2476 = v_s_2475;
                break;
              }
              default: heff_nomatch(v_e_2471);
              }
              V v_t_2477 = ({ V rv_1 = heff_get_n(v_t_2476, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2468, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2478 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str7)}), heff_dup(v_bsp_247)});
              V v_x1_2479 = ({ V a_0 = v_t_2478; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
              V v_t_2482;
              switch (heff_tag_of(v_x1_2479)) {
              case TAG_At: {
                V v_s_2481 = heff_field(v_x1_2479, 1);
                heff_take_n(v_x1_2479, 2ULL, 2);
                v_t_2482 = v_s_2481;
                break;
              }
              default: heff_nomatch(v_x1_2479);
              }
              V v_t_2483 = ({ V rv_0 = heff_dup(heff_rfield(v_bsp_247, 0)); V rr_ = heff_rec_reuse_nf(v_t_2482, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              V v_t_2484 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str8), heff_dup(v_bsp_247), NTAG(TAG_Nil)});
              V v_t_2485 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2484, heff_dup(v_t_2483)}), heff_dup(v_x_2450)});
              V v_t_2488;
              switch (heff_tag_of(v_x_2450)) {
              case TAG_At: {
                V v_s_2487 = heff_field(v_x_2450, 1);
                heff_take_n(v_x_2450, 2ULL, 2);
                v_t_2488 = v_s_2487;
                break;
              }
              default: heff_nomatch(v_x_2450);
              }
              V v_t_2489 = ({ V rv_1 = heff_get_n(v_t_2488, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2483, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2485, v_t_2489}), NTAG(TAG_Nil)});
              V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2473, v_t_2477}), v_t_2490});
              V v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_2462, v_t_2491}), heff_dup(v_bsp_247)});
              V v_f_2493 = (g_heff_2eelab_2eclauses_2easBitsC(v_made_2411, v_t_2456, heff_get_n(v_k_2410, 0, 7), v_bsp_247, v_t_2492));
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2493}});
            }
          }
        }
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam0(V self, V *args) {
  V v_i_2420 = args[0];
  V v_row_2421 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_248 = heff_env(self)[1];
  V v_ys_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_intEq_c(v_i_2420, MK_INT(0LL))) {
    heff_drop(v_ys_249);
    V v_xs_2423 = heff_take_field(v_row_2421, 0);
    V v_t_2424 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_245), heff_dup(v_xs_2423)));
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str0)}), NTAG(TAG_Nil)});
    V v_t_2426 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_245, MK_INT(1LL)), v_xs_2423));
    V v_t_2427 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2425, v_t_2426));
    V v_t_2428 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2424, v_t_2427));
    V v_t_2429 = (g_list_2emap_24s796727596x829078925(v_xs_248));
    V v_pats_2430 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2428, v_t_2429));
    return ({ V rv_0 = v_pats_2430; V rr_ = heff_rec_reuse_nf(v_row_2421, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  } else {
    heff_drop(v_c_245);
    heff_drop(v_xs_248);
    V v_t_2431 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_str1), v_ys_249));
    V v_pats_2432 = (g_heff_2eelab_2eclauses_2eappendC(heff_take_field(v_row_2421, 0), v_t_2431));
    return ({ V rv_0 = v_pats_2432; V rr_ = heff_rec_reuse_nf(v_row_2421, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
}
V g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam1(V self, V *args) {
  V v_row_2434 = args[0];
  V v_vars_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2419, heff_dup(heff_rfield(v_row_2434, 0)), heff_get_n(v_row_2434, 1, 2)));
}
V g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr_lam2(V self, V *args) {
  V v_row_2443 = args[0];
  V v_vars_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_243, heff_dup(heff_rfield(v_row_2443, 0)), heff_get_n(v_row_2443, 1, 2)));
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr(V v_sp_240, V v_rows_241, V v_used_242, V v_x_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_248 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr_lam0, 1, 1, (V[]){heff_dup(v_x_243)}), v_rows_241));
  HeffT2 v_t_249 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), v_used_242}), v_t_244, v_sp_240, v_t_245, v_t_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop(v_x_243);
      V v_e_2413 = v_field_2411;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2413}});
    } else {
      V v_x_2414 = v_field_2411;
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(2, shape_scrutinee__tree, (V[]){v_x_243, v_x_2414})}});
    }
  }
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr_lam0(V self, V *args) {
  V v_row_246 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
  return (g_heff_2eelab_2eclauses_2epeelCols(v_t_247, heff_dup(heff_rfield(v_row_246, 0)), heff_get_n(v_row_246, 1, 2)));
}
Clo g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      V v_x_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_ys_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps(a[0], a[1], a[2]);
}