// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_bad 306815
#define LBL_closed 589621399
#define LBL_cmt 308164
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_comments 142722952
#define LBL_end 310101
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_i 323
#define LBL_isFloat 143306131
#define LBL_kind 9787483
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_msg 317947
#define LBL_ok 10307
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
static uint32_t shape_end__isFloat[] = {LBL_end, LBL_isFloat};
static uint32_t shape_i__line__lineStart__first__closed[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_closed};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_i__text__closed__bad[] = {LBL_i, LBL_text, LBL_closed, LBL_bad};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_ok__end__code[] = {LBL_ok, LBL_end, LBL_code};
static uint32_t shape_start__end__msg[] = {LBL_start, LBL_end, LBL_msg};
static uint32_t shape_start__end__text[] = {LBL_start, LBL_end, LBL_text};
static uint32_t shape_tokens__errors__comments[] = {LBL_tokens, LBL_errors, LBL_comments};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2efmt_2elex_2ebadEsc(V, V, V);
V g_heff_2esyntax_2efmt_2elex_2ebadEsc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2ebadEsc_clo;
V g_heff_2esyntax_2efmt_2elex_2eblockCmtStep(V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_clo;
V g_heff_2esyntax_2efmt_2elex_2eblockScan(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eblockScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eblockScan_clo;
V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_clo;
V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2eescAt(V, V);
V g_heff_2esyntax_2efmt_2elex_2eescAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eescAt_clo;
V g_heff_2esyntax_2efmt_2elex_2efieldBefore(V, V);
V g_heff_2esyntax_2efmt_2elex_2efieldBefore_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2efieldBefore_clo;
V g_heff_2esyntax_2efmt_2elex_2ehexDigitValue(V);
V g_heff_2esyntax_2efmt_2elex_2ehexDigitValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2ehexDigitValue_clo;
V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2ehexValue(V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2ehexValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2ehexValue_clo;
V g_heff_2esyntax_2efmt_2elex_2eisHexC(V);
V g_heff_2esyntax_2efmt_2elex_2eisHexC_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eisHexC_clo;
V g_heff_2esyntax_2efmt_2elex_2eisLetterC(V);
V g_heff_2esyntax_2efmt_2elex_2eisLetterC_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eisLetterC_clo;
V g_heff_2esyntax_2efmt_2elex_2ekeywords_get(void);
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2enameEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2enameEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enameEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2enameStep(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2enameStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enameStep_clo;
V g_heff_2esyntax_2efmt_2elex_2enoCode_get(void);
V g_heff_2esyntax_2efmt_2elex_2enumExp(V, V);
V g_heff_2esyntax_2efmt_2elex_2enumExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enumExp_clo;
V g_heff_2esyntax_2efmt_2elex_2enumFrac(V, V);
V g_heff_2esyntax_2efmt_2elex_2enumFrac_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enumFrac_clo;
V g_heff_2esyntax_2efmt_2elex_2enumFrom(V, V);
V g_heff_2esyntax_2efmt_2elex_2enumFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enumFrom_clo;
V g_heff_2esyntax_2efmt_2elex_2eoperandBefore(V, V);
V g_heff_2esyntax_2efmt_2elex_2eoperandBefore_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eoperandBefore_clo;
V g_heff_2esyntax_2efmt_2elex_2eplainEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eplainEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eplainEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2equoteStep(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2equoteStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2equoteStep_clo;
V g_heff_2esyntax_2efmt_2elex_2eruneScan(V, V);
V g_heff_2esyntax_2efmt_2elex_2eruneScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eruneScan_clo;
V g_heff_2esyntax_2efmt_2elex_2eruneStep(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eruneStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eruneStep_clo;
V g_heff_2esyntax_2efmt_2elex_2estepAt(V, V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2estepAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2estepAt_clo;
V g_heff_2esyntax_2efmt_2elex_2estrScan(V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2estrScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2estrScan_clo;
V g_heff_2esyntax_2efmt_2elex_2estrStep(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2estrStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2estrStep_clo;
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void);
V g_heff_2esyntax_2efmt_2elex_2esymEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2esymEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2esymEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2euniEsc(V, V, V);
V g_heff_2esyntax_2efmt_2elex_2euniEsc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2euniEsc_clo;
V g_heff_2eutil_2erune_2ehexWith(V, V);
V g_heff_2eutil_2erune_2ehexWith_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ehexWith_clo;
V g_heff_2eutil_2erune_2epadTo4(V);
V g_heff_2eutil_2erune_2epadTo4_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2epadTo4_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str0, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str1, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str2, 6, "infixr");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str3, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str4, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str5, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str6, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str7, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str8, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str9, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str10, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str11, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str12, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str13, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str14, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str15, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str16, 6, "String");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str17, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str18, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str19, 5, "catch");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str20, 4, "test");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str21, 6, "return");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str22, 3, "try");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str23, 5, "break");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str24, 8, "continue");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str25, 5, "while");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str26, 3, "for");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str27, 2, "in");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str28, 3, "mut");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str29, 5, "where");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str30, 3, "let");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str31, 4, "else");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str32, 2, "do");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str33, 2, "if");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str34, 4, "then");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str35, 4, "case");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str36, 2, "of");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str37, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str38, 6, "import");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str39, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str40, 9, "primitive");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str41, 4, "data");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str42, 4, "type");

static V g_heff_2esyntax_2efmt_2elex_2ekeywords_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elex_2ekeywords_st;
static V g_heff_2esyntax_2efmt_2elex_2ekeywords_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str10), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str12), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str14), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str16), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str18), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str20), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str22), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str23), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str24), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str25), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str26), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str27), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str28), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str29), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str30), v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str31), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str32), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str33), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str34), v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str35), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str36), v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str37), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str38), v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str39), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str40), v_t_2419})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str41), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str42), v_t_2420})});
}
V g_heff_2esyntax_2efmt_2elex_2ekeywords_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elex_2ekeywords_st)) return g_heff_2esyntax_2efmt_2elex_2ekeywords_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elex_2ekeywords_val, &g_heff_2esyntax_2efmt_2elex_2ekeywords_st, g_heff_2esyntax_2efmt_2elex_2ekeywords_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2esymChars_str0, 20, "!#$%&*+./<=>\?@\\^|-~:");

static V g_heff_2esyntax_2efmt_2elex_2esymChars_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elex_2esymChars_st;
static V g_heff_2esyntax_2efmt_2elex_2esymChars_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elex_2esymChars_str0);
}
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elex_2esymChars_st)) return g_heff_2esyntax_2efmt_2elex_2esymChars_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elex_2esymChars_val, &g_heff_2esyntax_2efmt_2elex_2esymChars_st, g_heff_2esyntax_2efmt_2elex_2esymChars_init);
}
Clo g_heff_2esyntax_2efmt_2elex_2eisLetterC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eisLetterC_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elex_2eisLetterC(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_ret_24bool = heff_bool(((((int64_t)97ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)122ULL)) || ((v_c_240 == ((int64_t)95ULL)) || ((((int64_t)65ULL) <= v_c_240) && (v_c_240 <= ((int64_t)90ULL))))) : ((v_c_240 == ((int64_t)95ULL)) || ((((int64_t)65ULL) <= v_c_240) && (v_c_240 <= ((int64_t)90ULL))))));
  return v_ret_24bool;
}
V g_heff_2esyntax_2efmt_2elex_2eisLetterC_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eisLetterC(a[0]);
}
Clo g_heff_2esyntax_2efmt_2elex_2enameEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enameEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enameEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  V v_t_243 = (g_heff_2esyntax_2efmt_2elex_2eisLetterC(heff_dup(v_c_242)));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_c_242);
    heff_drop(v_t_243);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_t_243);
    if ((((int64_t)48ULL) <= heff_peek_word(v_c_242))) {
      if ((heff_peek_word(v_c_242) <= ((int64_t)57ULL))) {
        heff_drop(v_c_242);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        if ((heff_unbox_word(v_c_242) == ((int64_t)39ULL))) {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          v_s_240 = t_0;
          v_j_241 = t_1;
          goto top;
        } else {
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)47ULL))) {
            V v_t_248 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
            V v_t_249 = (g_heff_2esyntax_2efmt_2elex_2eisLetterC(v_t_248));
            if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
              heff_drop(v_t_249);
              V t_0 = v_s_240;
              V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
              v_s_240 = t_0;
              v_j_241 = t_1;
              goto top;
            } else {
              heff_drop(v_t_249);
              return v_j_241;
            }
          } else {
            return v_j_241;
          }
        }
      }
    } else {
      if ((heff_unbox_word(v_c_242) == ((int64_t)39ULL))) {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)47ULL))) {
          V v_t_2412 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
          V v_t_2413 = (g_heff_2esyntax_2efmt_2elex_2eisLetterC(v_t_2412));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_t_2413);
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
            v_s_240 = t_0;
            v_j_241 = t_1;
            goto top;
          } else {
            heff_drop(v_t_2413);
            return v_j_241;
          }
        } else {
          return v_j_241;
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2enameEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2enameEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2eplainEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eplainEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eplainEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  V v_t_243 = (g_heff_2esyntax_2efmt_2elex_2eisLetterC(heff_dup(v_c_242)));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_c_242);
    heff_drop(v_t_243);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_t_243);
    if ((((int64_t)48ULL) <= heff_peek_word(v_c_242))) {
      if ((heff_peek_word(v_c_242) <= ((int64_t)57ULL))) {
        heff_drop(v_c_242);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        if ((heff_unbox_word(v_c_242) == ((int64_t)39ULL))) {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          v_s_240 = t_0;
          v_j_241 = t_1;
          goto top;
        } else {
          return v_j_241;
        }
      }
    } else {
      if ((heff_unbox_word(v_c_242) == ((int64_t)39ULL))) {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        return v_j_241;
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2eplainEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eplainEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if ((((int64_t)48ULL) <= heff_peek_word(v_c_242))) {
    if ((heff_unbox_word(v_c_242) <= ((int64_t)57ULL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_j_241 = t_1;
      goto top;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)95ULL))) {
        V v_c_246 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
        if ((((int64_t)48ULL) <= heff_peek_word(v_c_246))) {
          if ((heff_unbox_word(v_c_246) <= ((int64_t)57ULL))) {
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
            v_s_240 = t_0;
            v_j_241 = t_1;
            goto top;
          } else {
            return v_j_241;
          }
        } else {
          heff_drop(v_c_246);
          return v_j_241;
        }
      } else {
        return v_j_241;
      }
    }
  } else {
    heff_drop(v_c_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)95ULL))) {
      V v_c_2410 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      if ((((int64_t)48ULL) <= heff_peek_word(v_c_2410))) {
        if ((heff_unbox_word(v_c_2410) <= ((int64_t)57ULL))) {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
          v_s_240 = t_0;
          v_j_241 = t_1;
          goto top;
        } else {
          return v_j_241;
        }
      } else {
        heff_drop(v_c_2410);
        return v_j_241;
      }
    } else {
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2eisHexC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eisHexC_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elex_2eisHexC(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_ret_24bool = heff_bool(((((int64_t)48ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)57ULL)) || ((((int64_t)97ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)102ULL)) || ((((int64_t)65ULL) <= v_c_240) && (v_c_240 <= ((int64_t)70ULL)))) : ((((int64_t)65ULL) <= v_c_240) && (v_c_240 <= ((int64_t)70ULL))))) : ((((int64_t)97ULL) <= v_c_240) ? (heff_intLe_c(heff_box_word(v_c_240), MK_INT(102LL)) || (heff_intLe_c(MK_INT(65LL), heff_box_word(v_c_240)) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(70LL)))) : ((((int64_t)65ULL) <= v_c_240) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(70LL))))));
  return v_ret_24bool;
}
V g_heff_2esyntax_2efmt_2elex_2eisHexC_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eisHexC(a[0]);
}
Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V v_s_240, V v_j_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)45ULL))) {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edashesEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V v_s_240, V v_j_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_j_241), heff_strLength_lent(v_s_240, 0))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL))) {
      return v_j_241;
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_j_241 = t_1;
      goto top;
    }
  } else {
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eeolEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2esymEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2esymEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2esymEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if ((((int64_t)0ULL) <= heff_peek_word(v_c_242))) {
    V v_t_244 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_c_242)));
    if (heff_intLe_c(MK_INT(0LL), heff_strFind(v_t_244, heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)45ULL))) {
        V v_t_247 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
        if ((heff_unbox_word(v_t_247) == ((int64_t)45ULL))) {
          return v_j_241;
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          v_s_240 = t_0;
          v_j_241 = t_1;
          goto top;
        }
      } else {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      }
    } else {
      return v_j_241;
    }
  } else {
    heff_drop(v_c_242);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2esymEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2esymEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2enumExp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enumExp_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enumExp(V v_s_240, V v_b_241) {
top: ;
  V v_t_243 = heff_bool(((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_b_241, 0)) == ((int64_t)101ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_b_241, 0)) == ((int64_t)69ULL))));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_c_244 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(1LL)));
    V v_t_246 = heff_bool(((((int64_t)48ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)57ULL))));
    heff_drop(v_c_244);
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_b_241, MK_INT(2LL))));
      return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_247, NTAG(TAG_True)});
    } else {
      heff_drop(v_t_246);
      V v_t_248 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(1LL)));
      if ((heff_unbox_word(v_t_248) == ((int64_t)43ULL))) {
        V v_c_2410 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(2LL)));
        if ((((int64_t)48ULL) <= heff_peek_word(v_c_2410))) {
          if ((heff_unbox_word(v_c_2410) <= ((int64_t)57ULL))) {
            V v_t_2413 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_b_241, MK_INT(2LL))));
            return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_2413, NTAG(TAG_True)});
          } else {
            return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_241, NTAG(TAG_True)});
          }
        } else {
          heff_drop(v_c_2410);
          return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_241, NTAG(TAG_True)});
        }
      } else {
        V v_t_2414 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(1LL)));
        if ((heff_unbox_word(v_t_2414) == ((int64_t)45ULL))) {
          V v_c_2416 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(2LL)));
          if ((((int64_t)48ULL) <= heff_peek_word(v_c_2416))) {
            if ((heff_unbox_word(v_c_2416) <= ((int64_t)57ULL))) {
              V v_t_2419 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_b_241, MK_INT(2LL))));
              return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_2419, NTAG(TAG_True)});
            } else {
              return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_241, NTAG(TAG_True)});
            }
          } else {
            heff_drop(v_c_2416);
            return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_241, NTAG(TAG_True)});
          }
        } else {
          return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_241, NTAG(TAG_True)});
        }
      }
    }
  } else {
    heff_drop(v_t_243);
    return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_241, NTAG(TAG_True)});
  }
}
V g_heff_2esyntax_2efmt_2elex_2enumExp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2enumExp(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2enumFrac_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enumFrac_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enumFrac(V v_s_240, V v_a_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_a_241, 0)) == ((int64_t)46ULL))) {
    V v_c_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_a_241), MK_INT(1LL)));
    if ((((int64_t)48ULL) <= heff_peek_word(v_c_243))) {
      if ((heff_unbox_word(v_c_243) <= ((int64_t)57ULL))) {
        V v_t_246 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_a_241, MK_INT(2LL))));
        HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumExp(v_s_240, v_t_246);
      } else {
        return heff_rec_n(2, shape_end__isFloat, (V[]){v_a_241, NTAG(TAG_False)});
      }
    } else {
      heff_drop(v_c_243);
      return heff_rec_n(2, shape_end__isFloat, (V[]){v_a_241, NTAG(TAG_False)});
    }
  } else {
    return heff_rec_n(2, shape_end__isFloat, (V[]){v_a_241, NTAG(TAG_False)});
  }
}
V g_heff_2esyntax_2efmt_2elex_2enumFrac_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2enumFrac(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(V v_s_240, V v_j_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(heff_strByteAt_lent(v_s_240, v_j_241, 0)));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_t_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)95ULL))) {
      V v_t_244 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      V v_t_245 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(v_t_244));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_245);
        return v_j_241;
      }
    } else {
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if ((heff_peek_word(v_c_242) == ((int64_t)48ULL))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    if ((heff_unbox_word(v_c_242) == ((int64_t)49ULL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_j_241 = t_1;
      goto top;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)95ULL))) {
        V v_c_246 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
        if ((heff_peek_word(v_c_246) == ((int64_t)48ULL))) {
          heff_drop(v_c_246);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
          v_s_240 = t_0;
          v_j_241 = t_1;
          goto top;
        } else {
          if ((heff_unbox_word(v_c_246) == ((int64_t)49ULL))) {
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
            v_s_240 = t_0;
            v_j_241 = t_1;
            goto top;
          } else {
            return v_j_241;
          }
        }
      } else {
        return v_j_241;
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2enumFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enumFrom_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enumFrom(V v_s_240, V v_j_241) {
top: ;
  V v_t_249;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)48ULL))) {
    V v_t_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
    if ((heff_unbox_word(v_t_243) == ((int64_t)120ULL))) {
      V v_t_245 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)));
      v_t_249 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(v_t_245));
    } else {
      V v_t_246 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      if ((heff_unbox_word(v_t_246) == ((int64_t)88ULL))) {
        V v_t_248 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)));
        v_t_249 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(v_t_248));
      } else {
        v_t_249 = NTAG(TAG_False);
      }
    }
  } else {
    v_t_249 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    V v_t_2410 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(v_s_240, heff_intAdd(v_j_241, MK_INT(2LL))));
    return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_2410, NTAG(TAG_False)});
  } else {
    heff_drop(v_t_249);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)48ULL))) {
      V v_t_2412 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      if ((heff_unbox_word(v_t_2412) == ((int64_t)98ULL))) {
        V v_c_2414 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)));
        if ((heff_peek_word(v_c_2414) == ((int64_t)48ULL))) {
          heff_drop(v_c_2414);
          V v_t_2416 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(v_s_240, heff_intAdd(v_j_241, MK_INT(2LL))));
          return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_2416, NTAG(TAG_False)});
        } else {
          if ((heff_unbox_word(v_c_2414) == ((int64_t)49ULL))) {
            V v_t_2418 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(v_s_240, heff_intAdd(v_j_241, MK_INT(2LL))));
            return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_2418, NTAG(TAG_False)});
          } else {
            V v_t_2419 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_j_241, MK_INT(1LL))));
            HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumFrac(v_s_240, v_t_2419);
          }
        }
      } else {
        V v_t_2420 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
        if ((heff_unbox_word(v_t_2420) == ((int64_t)66ULL))) {
          V v_c_2422 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)));
          if ((heff_peek_word(v_c_2422) == ((int64_t)48ULL))) {
            heff_drop(v_c_2422);
            V v_t_2424 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(v_s_240, heff_intAdd(v_j_241, MK_INT(2LL))));
            return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_2424, NTAG(TAG_False)});
          } else {
            if ((heff_unbox_word(v_c_2422) == ((int64_t)49ULL))) {
              V v_t_2426 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(v_s_240, heff_intAdd(v_j_241, MK_INT(2LL))));
              return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_2426, NTAG(TAG_False)});
            } else {
              V v_t_2427 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_j_241, MK_INT(1LL))));
              HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumFrac(v_s_240, v_t_2427);
            }
          }
        } else {
          V v_t_2428 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_j_241, MK_INT(1LL))));
          HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumFrac(v_s_240, v_t_2428);
        }
      }
    } else {
      V v_t_2429 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_j_241, MK_INT(1LL))));
      HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumFrac(v_s_240, v_t_2429);
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2enumFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2enumFrom(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2esyntax_2efmt_2elex_2enoCode_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elex_2enoCode_st;
static V g_heff_2esyntax_2efmt_2elex_2enoCode_init(void) {
  return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2esyntax_2efmt_2elex_2enoCode_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elex_2enoCode_st)) return g_heff_2esyntax_2efmt_2elex_2enoCode_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elex_2enoCode_val, &g_heff_2esyntax_2efmt_2elex_2enoCode_st, g_heff_2esyntax_2efmt_2elex_2enoCode_init);
}
Clo g_heff_2esyntax_2efmt_2elex_2ehexDigitValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2ehexDigitValue_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elex_2ehexDigitValue(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  if ((((int64_t)48ULL) <= v_c_240)) {
    if ((v_c_240 <= ((int64_t)57ULL))) {
      return heff_box_word((v_c_240 - ((int64_t)48ULL)));
    } else {
      if ((((int64_t)97ULL) <= v_c_240)) {
        return heff_box_word((v_c_240 - ((int64_t)87ULL)));
      } else {
        return heff_box_word((v_c_240 - ((int64_t)55ULL)));
      }
    }
  } else {
    if ((((int64_t)97ULL) <= v_c_240)) {
      return heff_intSub(heff_box_word(v_c_240), MK_INT(87LL));
    } else {
      return heff_box_word((v_c_240 - ((int64_t)55ULL)));
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2ehexDigitValue_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2ehexDigitValue(a[0]);
}
Clo g_heff_2esyntax_2efmt_2elex_2ehexValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2ehexValue_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elex_2ehexValue(V v_s_240, V v_j_241, V v_e_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(v_e_242, v_j_241, 0)) {
    heff_drop(v_j_241);
    heff_drop(v_e_242);
    return v_acc_243;
  } else {
    V v_t_245 = (g_heff_2esyntax_2efmt_2elex_2ehexDigitValue(heff_strByteAt_lent(v_s_240, v_j_241, 0)));
    V v_t_246 = heff_intAdd(heff_intMul(v_acc_243, MK_INT(16LL)), v_t_245);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    V t_2 = v_e_242;
    V t_3 = v_t_246;
    v_s_240 = t_0;
    v_j_241 = t_1;
    v_e_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
}
V g_heff_2esyntax_2efmt_2elex_2ehexValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2ehexValue(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(V v_s_240, V v_j_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(heff_strByteAt_lent(v_s_240, v_j_241, 0)));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_t_242);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2euniEsc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2euniEsc_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elex_2euniEsc(V v_s_240, V v_j_241, V v_e_242) {
top: ;
  if (heff_intLt_c(heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)), heff_dup(v_e_242))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_e_242, 0)) == ((int64_t)125ULL))) {
      V v_t_245 = (g_heff_2esyntax_2efmt_2elex_2ehexValue(v_s_240, heff_intAdd(v_j_241, MK_INT(2LL)), heff_dup(v_e_242), MK_INT(0LL)));
      return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_e_242, MK_INT(1LL)), v_t_245});
    } else {
      heff_drop(v_e_242);
      return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_j_241, MK_INT(1LL)), MK_INT(117LL)});
    }
  } else {
    heff_drop(v_e_242);
    return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_j_241, MK_INT(1LL)), MK_INT(117LL)});
  }
}
V g_heff_2esyntax_2efmt_2elex_2euniEsc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2euniEsc(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2eescAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eescAt_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eescAt(V v_s_240, V v_j_241) {
top: ;
  V v_t_244 = heff_bool(((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)117ULL)) && ({ V v_t_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL))); int c_ = (heff_peek_word(v_t_243) == ((int64_t)123ULL)); heff_drop(v_t_243); c_; })));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(v_s_240, heff_intAdd(heff_dup(v_j_241), MK_INT(2LL))));
    return (g_heff_2esyntax_2efmt_2elex_2euniEsc(v_s_240, v_j_241, v_t_245));
  } else {
    heff_drop(v_t_244);
    if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_j_241))) {
      heff_drop(v_j_241);
      return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL))) {
        heff_drop(v_j_241);
        return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
      } else {
        V v_t_248 = heff_intAdd(heff_dup(v_j_241), heff_strRuneWidth_lent(v_s_240, v_j_241, 0));
        V v_c_249 = heff_runeToInt(heff_strRuneAt_lent(v_s_240, v_j_241, 2));
        V v_t_2413;
        if (heff_intEq_c_lent(v_c_249, MK_INT(110LL), 2)) {
          heff_drop(v_c_249);
          v_t_2413 = MK_INT(10LL);
        } else {
          if (heff_intEq_c_lent(v_c_249, MK_INT(116LL), 2)) {
            heff_drop(v_c_249);
            v_t_2413 = MK_INT(9LL);
          } else {
            if (heff_intEq_c_lent(v_c_249, MK_INT(114LL), 2)) {
              heff_drop(v_c_249);
              v_t_2413 = MK_INT(13LL);
            } else {
              v_t_2413 = v_c_249;
            }
          }
        }
        return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), v_t_248, v_t_2413});
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2eescAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eescAt(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str0, 16, "0123456789ABCDEF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str1, 19, " is beyond U+10FFFF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str2, 15, " is a surrogate");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str3, 2, "U+");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str4, 11, "a `\\u{...}`");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str5, 28, " is a Unicode scalar value: ");
Clo g_heff_2esyntax_2efmt_2elex_2ebadEsc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2ebadEsc_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elex_2ebadEsc(V v_x1_240, V v_j_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    V v_c_243 = heff_dup(heff_rfield(v_e_242, 2));
    V v_t_248 = heff_bool((heff_intLe_c_lent(MK_INT(0LL), v_c_243, 1) && (heff_intLe_c_lent(v_c_243, MK_INT(1114111LL), 2) && ((((int64_t)55296ULL) <= heff_peek_word(v_c_243)) ? !(heff_peek_word(v_c_243) <= ((int64_t)57343ULL)) : 1))));
    heff_drop(v_c_243);
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_j_241);
      heff_drop_rec(v_e_242, 3);
      heff_drop(v_t_248);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_248);
      V v_c_249 = heff_take_field(v_e_242, 2);
      V v_t_2410 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str0); V a_1 = heff_dup(v_c_249); V r_ = (g_heff_2eutil_2erune_2ehexWith(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2411 = (g_heff_2eutil_2erune_2epadTo4(v_t_2410));
      V v_t_2413;
      if (heff_intLt_c(MK_INT(1114111LL), v_c_249)) {
        v_t_2413 = ((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str1);
      } else {
        v_t_2413 = ((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str2);
      }
      V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str3), v_t_2411), v_t_2413);
      V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str4), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str5), v_t_2414));
      V v_t_2416 = heff_rec_n(3, shape_start__end__msg, (V[]){v_j_241, heff_get_n(v_e_242, 1, 3), v_t_2415});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
    }
  }
  case TAG_Just: {
    V v_b_2417 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    heff_drop(v_j_241);
    heff_drop_rec(v_e_242, 3);
    return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_b_2417});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elex_2ebadEsc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2ebadEsc(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2efmt_2elex_2estrScan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2estrScan_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elex_2estrScan(V v_s_240, V v_j_241, V v_acc_242, V v_bad_243) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_j_241))) {
    return heff_rec_n(4, shape_i__text__closed__bad, (V[]){v_j_241, v_acc_242, NTAG(TAG_False), v_bad_243});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL))) {
      return heff_rec_n(4, shape_i__text__closed__bad, (V[]){v_j_241, v_acc_242, NTAG(TAG_False), v_bad_243});
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)34ULL))) {
        return heff_rec_n(4, shape_i__text__closed__bad, (V[]){v_j_241, v_acc_242, NTAG(TAG_True), v_bad_243});
      } else {
        V v_t_2413;
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)92ULL))) {
          V v_j_248 = heff_intAdd(heff_dup(v_j_241), MK_INT(1LL));
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_248, 0)) == ((int64_t)120ULL))) {
            V v_t_2410 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_248), MK_INT(1LL)));
            V v_t_2411 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(v_t_2410));
            if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
              heff_drop(v_t_2411);
              V v_t_2412 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(v_j_248, MK_INT(2LL)));
              v_t_2413 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(v_t_2412));
            } else {
              heff_drop(v_j_248);
              heff_drop(v_t_2411);
              v_t_2413 = NTAG(TAG_False);
            }
          } else {
            heff_drop(v_j_248);
            v_t_2413 = NTAG(TAG_False);
          }
        } else {
          v_t_2413 = NTAG(TAG_False);
        }
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_t_2413);
          V v_t_2414 = (g_heff_2esyntax_2efmt_2elex_2ehexValue(v_s_240, heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)), heff_intAdd(heff_dup(v_j_241), MK_INT(4LL)), MK_INT(0LL)));
          V v_t_2415 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_t_2414)));
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(4LL));
          V t_2 = heff_strAppend(v_acc_242, v_t_2415);
          V t_3 = v_bad_243;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_acc_242 = t_2;
          v_bad_243 = t_3;
          goto top;
        } else {
          heff_drop(v_t_2413);
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)92ULL))) {
            if (heff_intLt_c(heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)), heff_strLength_lent(v_s_240, 0))) {
              V v_k_2418 = heff_intAdd(heff_dup(v_j_241), MK_INT(1LL));
              V v_e_2419 = (g_heff_2esyntax_2efmt_2elex_2eescAt(v_s_240, heff_intAdd(heff_dup(v_j_241), MK_INT(1LL))));
              V v_t_2420 = heff_dup(heff_rfield(v_e_2419, 0));
              V v_e_2421;
              if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
                heff_drop(v_k_2418);
                heff_drop(v_t_2420);
                v_e_2421 = v_e_2419;
              } else {
                heff_drop_rec(v_e_2419, 3);
                heff_drop(v_t_2420);
                v_e_2421 = heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(heff_dup(v_k_2418), MK_INT(1LL)), heff_strByteAt_lent(v_s_240, v_k_2418, 2)});
              }
              V v_c_2422 = heff_dup(heff_rfield(v_e_2421, 2));
              V v_t_2427;
              if (heff_intLe_c_lent(MK_INT(0LL), v_c_2422, 1)) {
                if (heff_intLe_c_lent(v_c_2422, MK_INT(1114111LL), 2)) {
                  if ((((int64_t)55296ULL) <= heff_peek_word(v_c_2422))) {
                    if ((heff_peek_word(v_c_2422) <= ((int64_t)57343ULL))) {
                      heff_drop(v_c_2422);
                      v_t_2427 = MK_INT(65533LL);
                    } else {
                      v_t_2427 = v_c_2422;
                    }
                  } else {
                    v_t_2427 = v_c_2422;
                  }
                } else {
                  heff_drop(v_c_2422);
                  v_t_2427 = MK_INT(65533LL);
                }
              } else {
                heff_drop(v_c_2422);
                v_t_2427 = MK_INT(65533LL);
              }
              V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_t_2427), NTAG(TAG_Nil)});
              V v_t_2429 = heff_strAppend(v_acc_242, heff_strOfRunes(v_t_2428));
              V v_t_2430 = (g_heff_2esyntax_2efmt_2elex_2ebadEsc(v_bad_243, v_j_241, heff_dup(v_e_2421)));
              V t_0 = v_s_240;
              V t_1 = heff_get_n(v_e_2421, 1, 3);
              V t_2 = v_t_2429;
              V t_3 = v_t_2430;
              v_s_240 = t_0;
              v_j_241 = t_1;
              v_acc_242 = t_2;
              v_bad_243 = t_3;
              goto top;
            } else {
              V v_t_2431 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_j_241), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
              V t_0 = v_s_240;
              V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
              V t_2 = heff_strAppend(v_acc_242, v_t_2431);
              V t_3 = v_bad_243;
              v_s_240 = t_0;
              v_j_241 = t_1;
              v_acc_242 = t_2;
              v_bad_243 = t_3;
              goto top;
            }
          } else {
            V v_t_2432 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_j_241), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
            V t_2 = heff_strAppend(v_acc_242, v_t_2432);
            V t_3 = v_bad_243;
            v_s_240 = t_0;
            v_j_241 = t_1;
            v_acc_242 = t_2;
            v_bad_243 = t_3;
            goto top;
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2estrScan_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2estrScan(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2eruneScan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eruneScan_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eruneScan(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
  if ((heff_unbox_word(v_t_242) == ((int64_t)92ULL))) {
    V v_e_244 = (g_heff_2esyntax_2efmt_2elex_2eescAt(v_s_240, heff_intAdd(v_i_241, MK_INT(2LL))));
    V v_t_245 = heff_take_field(v_e_244, 0);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_j_246 = heff_take_field(v_e_244, 1);
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_246, 0)) == ((int64_t)39ULL))) {
        return ({ V rv_0 = NTAG(TAG_True); V rv_1 = heff_intAdd(v_j_246, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_e_244, 4ULL, 3, shape_ok__end__code, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      } else {
        heff_drop_rec(v_e_244, 3);
        heff_drop(v_j_246);
        return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
      }
    } else {
      heff_drop_rec(v_e_244, 3);
      heff_drop(v_t_245);
      return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
    }
  } else {
    if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) {
      heff_drop(v_i_241);
      return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
    } else {
      V v_t_249 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
      if ((heff_unbox_word(v_t_249) == ((int64_t)39ULL))) {
        heff_drop(v_i_241);
        return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
      } else {
        V v_t_2411 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
        if ((heff_unbox_word(v_t_2411) == ((int64_t)10ULL))) {
          heff_drop(v_i_241);
          return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
        } else {
          V v_t_2413 = heff_strRuneWidth(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
          V v_j_2414 = heff_intAdd(heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), v_t_2413);
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_2414, 0)) == ((int64_t)39ULL))) {
            V v_t_2416 = heff_strRuneAt(heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(1LL)));
            return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_j_2414, MK_INT(1LL)), heff_runeToInt(v_t_2416)});
          } else {
            heff_drop(v_i_241);
            heff_drop(v_j_2414);
            return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2eruneScan_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eruneScan(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2eblockScan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eblockScan_entry, 6, 0};

V g_heff_2esyntax_2efmt_2elex_2eblockScan(V v_s_240, V v_j_241, V v_depth_242, V v_line_243, V v_lineStart_244, V v_first_245) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_j_241))) {
    heff_drop(v_depth_242);
    return heff_rec_n(5, shape_i__line__lineStart__first__closed, (V[]){v_j_241, v_line_243, v_lineStart_244, v_first_245, NTAG(TAG_False)});
  } else {
    V v_t_249 = heff_bool(((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)123ULL)) && ({ V v_t_248 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL))); int c_ = (heff_peek_word(v_t_248) == ((int64_t)45ULL)); heff_drop(v_t_248); c_; })));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
      V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
      V t_3 = v_line_243;
      V t_4 = v_lineStart_244;
      V t_5 = v_first_245;
      v_s_240 = t_0;
      v_j_241 = t_1;
      v_depth_242 = t_2;
      v_line_243 = t_3;
      v_lineStart_244 = t_4;
      v_first_245 = t_5;
      goto top;
    } else {
      heff_drop(v_t_249);
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)45ULL))) {
        V v_t_2411 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
        if ((heff_unbox_word(v_t_2411) == ((int64_t)125ULL))) {
          if (heff_intEq_c_lent(v_depth_242, MK_INT(1LL), 2)) {
            heff_drop(v_depth_242);
            return heff_rec_n(5, shape_i__line__lineStart__first__closed, (V[]){heff_intAdd(v_j_241, MK_INT(2LL)), v_line_243, v_lineStart_244, v_first_245, NTAG(TAG_True)});
          } else {
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
            V t_2 = heff_intSub(v_depth_242, MK_INT(1LL));
            V t_3 = v_line_243;
            V t_4 = v_lineStart_244;
            V t_5 = v_first_245;
            v_s_240 = t_0;
            v_j_241 = t_1;
            v_depth_242 = t_2;
            v_line_243 = t_3;
            v_lineStart_244 = t_4;
            v_first_245 = t_5;
            goto top;
          }
        } else {
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL))) {
            heff_drop(v_lineStart_244);
            heff_drop(v_first_245);
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(heff_dup(v_j_241), MK_INT(1LL));
            V t_2 = v_depth_242;
            V t_3 = heff_intAdd(v_line_243, MK_INT(1LL));
            V t_4 = heff_intAdd(v_j_241, MK_INT(1LL));
            V t_5 = NTAG(TAG_True);
            v_s_240 = t_0;
            v_j_241 = t_1;
            v_depth_242 = t_2;
            v_line_243 = t_3;
            v_lineStart_244 = t_4;
            v_first_245 = t_5;
            goto top;
          } else {
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
            V t_2 = v_depth_242;
            V t_3 = v_line_243;
            V t_4 = v_lineStart_244;
            V t_5 = v_first_245;
            v_s_240 = t_0;
            v_j_241 = t_1;
            v_depth_242 = t_2;
            v_line_243 = t_3;
            v_lineStart_244 = t_4;
            v_first_245 = t_5;
            goto top;
          }
        }
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL))) {
          heff_drop(v_lineStart_244);
          heff_drop(v_first_245);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(heff_dup(v_j_241), MK_INT(1LL));
          V t_2 = v_depth_242;
          V t_3 = heff_intAdd(v_line_243, MK_INT(1LL));
          V t_4 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_5 = NTAG(TAG_True);
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_2 = v_depth_242;
          V t_3 = v_line_243;
          V t_4 = v_lineStart_244;
          V t_5 = v_first_245;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2eblockScan_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eblockScan(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str0, 5, "field");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str1, 3, "str");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str2, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str3, 3, "int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str4, 5, "float");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str5, 3, "var");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str6, 3, "con");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str7, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str8, 1, "}");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str10, 1, "]");
Clo g_heff_2esyntax_2efmt_2elex_2eoperandBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eoperandBefore_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eoperandBefore(V v_x1_240, V v_start_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_start_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 3)), v_start_241)) {
      V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_242, 0))}));
      V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str0), NTAG(TAG_Nil)});
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str2), v_t_246})});
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str4), v_t_247})});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str6), v_t_248})});
      V v_t_2410 = ({ V a_0 = v_t_245; V a_1 = v_t_249; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_249, 2); r_; });
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_t_242, 7);
        heff_drop(v_t_2410);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2410);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str7))) {
          V v_t_2412 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_t_242, 1, 7)}));
          V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str8), NTAG(TAG_Nil)});
          V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str10), v_t_2413})});
          return ({ V a_0 = v_t_2412; V a_1 = v_t_2414; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2414, 2); r_; });
        } else {
          heff_drop_rec(v_t_242, 7);
          return NTAG(TAG_False);
        }
      }
    } else {
      heff_drop_rec(v_t_242, 7);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elex_2eoperandBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eoperandBefore(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2efieldBefore_str0, 2, "kw");
Clo g_heff_2esyntax_2efmt_2elex_2efieldBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2efieldBefore_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2efieldBefore(V v_x1_240, V v_start_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_start_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_t_242), v_rest_243}), heff_dup(v_start_241)));
    V v_ret_24bool = heff_bool(((heff_dup(v_t_244) == NTAG(TAG_True)) || (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 3)), heff_dup(v_start_241)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2esyntax_2efmt_2elex_2efieldBefore_str0)) && ({ V v_c_247 = heff_strByteAt(heff_dup(heff_rfield(v_t_242, 1)), MK_INT(0LL)); int c_ = ((((int64_t)65ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)90ULL))); heff_drop(v_c_247); c_; })))));
    heff_drop(v_start_241);
    heff_drop_rec(v_t_242, 7);
    heff_drop(v_t_244);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elex_2efieldBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2efieldBefore(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2enameStep_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2enameStep_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2enameStep_str2, 3, "var");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2enameStep_str3, 3, "var");
Clo g_heff_2esyntax_2efmt_2elex_2enameStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enameStep_entry, 6, 0};

V g_heff_2esyntax_2efmt_2elex_2enameStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_j_245) {
top: ;
  V v_c_246 = heff_strByteAt_lent(v_src_240, v_i_241, 0);
  V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_strSlice_lent(v_src_240, v_i_241, v_j_245, 0)}));
  V v_t_248 = ({ V a_0 = v_t_247; V b_1 = heff_dup(g_heff_2esyntax_2efmt_2elex_2ekeywords_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_kind_2411;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_c_246);
    heff_drop(v_t_248);
    v_kind_2411 = ((V)&g_heff_2esyntax_2efmt_2elex_2enameStep_str0);
  } else {
    heff_drop(v_t_248);
    if ((((int64_t)65ULL) <= heff_peek_word(v_c_246))) {
      if ((heff_unbox_word(v_c_246) <= ((int64_t)90ULL))) {
        v_kind_2411 = ((V)&g_heff_2esyntax_2efmt_2elex_2enameStep_str1);
      } else {
        v_kind_2411 = ((V)&g_heff_2esyntax_2efmt_2elex_2enameStep_str2);
      }
    } else {
      heff_drop(v_c_246);
      v_kind_2411 = ((V)&g_heff_2esyntax_2efmt_2elex_2enameStep_str3);
    }
  }
  V v_t_2412 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){v_kind_2411, heff_strSlice_lent(v_src_240, v_i_241, v_j_245, 0), heff_dup(v_i_241), heff_dup(v_j_245), heff_dup(v_line_242), heff_intSub(v_i_241, heff_dup(v_lineStart_243)), v_first_244});
  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_j_245, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2412}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2efmt_2elex_2enameStep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2enameStep(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estrStep_str0, 3, "str");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estrStep_str1, 24, "a string is never closed");
Clo g_heff_2esyntax_2efmt_2elex_2estrStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2estrStep_entry, 6, 0};

V g_heff_2esyntax_2efmt_2elex_2estrStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_r_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_r_245, 2));
  V v_t_247;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_r_245, 0)), MK_INT(1LL));
  } else {
    heff_drop(v_t_246);
    v_t_247 = heff_dup(heff_rfield(v_r_245, 0));
  }
  V v_t_248 = heff_dup(heff_rfield(v_r_245, 2));
  V v_j_249;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    v_j_249 = heff_intAdd(heff_dup(heff_rfield(v_r_245, 0)), MK_INT(1LL));
  } else {
    heff_drop(v_t_248);
    v_j_249 = heff_dup(heff_rfield(v_r_245, 0));
  }
  V v_t_2410 = heff_intAdd(heff_dup(v_lineStart_243), heff_intSub(heff_dup(v_j_249), heff_dup(v_i_241)));
  V v_t_2411 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, heff_dup(v_i_241), v_j_249, MK_INT(0LL)));
  V v_t_2412 = heff_dup(heff_rfield(v_r_245, 2));
  V v_t_2413;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    v_t_2413 = heff_intAdd(heff_dup(heff_rfield(v_r_245, 0)), MK_INT(1LL));
  } else {
    heff_drop(v_t_2412);
    v_t_2413 = heff_dup(heff_rfield(v_r_245, 0));
  }
  V v_t_2414 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estrStep_str0), heff_take_field(v_r_245, 1), heff_dup(v_i_241), v_t_2413, heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), v_lineStart_243), v_first_244});
  V v_t_2415 = heff_take_field(v_r_245, 2);
  V v_t_2417;
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_i_241);
    heff_drop(v_t_2415);
    v_t_2417 = heff_get_n(v_r_245, 3, 4);
  } else {
    heff_drop(v_t_2415);
    V v_t_2416 = heff_rec_n(3, shape_start__end__msg, (V[]){v_i_241, heff_get_n(v_r_245, 0, 4), ((V)&g_heff_2esyntax_2efmt_2elex_2estrStep_str1)});
    v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
  }
  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_t_247, v_line_242, heff_intSub(v_t_2410, v_t_2411), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2414}), v_t_2417, NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2efmt_2elex_2estrStep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2estrStep(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str0, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str1, 16, "0123456789ABCDEF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str2, 19, " is beyond U+10FFFF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str3, 15, " is a surrogate");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str4, 2, "U+");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str5, 14, "a rune literal");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str6, 28, " is a Unicode scalar value: ");
Clo g_heff_2esyntax_2efmt_2elex_2eruneStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eruneStep_entry, 6, 0};

V g_heff_2esyntax_2efmt_2elex_2eruneStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_r_245) {
top: ;
  V v_j_246 = heff_dup(heff_rfield(v_r_245, 1));
  V v_t_247 = heff_intAdd(heff_dup(v_lineStart_243), heff_intSub(heff_dup(v_j_246), heff_dup(v_i_241)));
  V v_t_248 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, heff_dup(v_i_241), v_j_246, MK_INT(0LL)));
  V v_c_249 = heff_dup(heff_rfield(v_r_245, 2));
  V v_t_2414;
  if (heff_intLe_c_lent(MK_INT(0LL), v_c_249, 1)) {
    if (heff_intLe_c_lent(v_c_249, MK_INT(1114111LL), 2)) {
      if ((((int64_t)55296ULL) <= heff_peek_word(v_c_249))) {
        if ((heff_peek_word(v_c_249) <= ((int64_t)57343ULL))) {
          heff_drop(v_c_249);
          v_t_2414 = MK_INT(65533LL);
        } else {
          v_t_2414 = v_c_249;
        }
      } else {
        v_t_2414 = v_c_249;
      }
    } else {
      heff_drop(v_c_249);
      v_t_2414 = MK_INT(65533LL);
    }
  } else {
    heff_drop(v_c_249);
    v_t_2414 = MK_INT(65533LL);
  }
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_t_2414), NTAG(TAG_Nil)});
  V v_t_2416 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str0), heff_strOfRunes(v_t_2415), heff_dup(v_i_241), heff_dup(heff_rfield(v_r_245, 1)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), v_lineStart_243), v_first_244});
  V v_c_2417 = heff_dup(heff_rfield(v_r_245, 2));
  V v_t_2422 = heff_bool((heff_intLe_c_lent(MK_INT(0LL), v_c_2417, 1) && (heff_intLe_c_lent(v_c_2417, MK_INT(1114111LL), 2) && ((((int64_t)55296ULL) <= heff_peek_word(v_c_2417)) ? !(heff_peek_word(v_c_2417) <= ((int64_t)57343ULL)) : 1))));
  heff_drop(v_c_2417);
  V v_t_2431;
  if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
    heff_drop(v_i_241);
    heff_drop(v_t_2422);
    v_t_2431 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2422);
    V v_c_2423 = heff_dup(heff_rfield(v_r_245, 2));
    V v_t_2424 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str1); V a_1 = heff_dup(v_c_2423); V r_ = (g_heff_2eutil_2erune_2ehexWith(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2425 = (g_heff_2eutil_2erune_2epadTo4(v_t_2424));
    V v_t_2427;
    if (heff_intLt_c(MK_INT(1114111LL), v_c_2423)) {
      v_t_2427 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str2);
    } else {
      v_t_2427 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str3);
    }
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str4), v_t_2425), v_t_2427);
    V v_t_2429 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str5), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str6), v_t_2428));
    V v_t_2430 = heff_rec_n(3, shape_start__end__msg, (V[]){v_i_241, heff_dup(heff_rfield(v_r_245, 1)), v_t_2429});
    v_t_2431 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2430});
  }
  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_get_n(v_r_245, 1, 3), v_line_242, heff_intSub(v_t_247, v_t_248), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2416}), v_t_2431, NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2efmt_2elex_2eruneStep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eruneStep(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2equoteStep_str0, 21, "unexpected character ");
Clo g_heff_2esyntax_2efmt_2elex_2equoteStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2equoteStep_entry, 6, 0};

V g_heff_2esyntax_2efmt_2elex_2equoteStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_r_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_r_245, 0));
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2eruneStep(v_src_240, v_i_241, v_line_242, v_lineStart_243, v_first_244, v_r_245);
  } else {
    heff_drop_rec(v_r_245, 3);
    heff_drop(v_t_246);
    V v_w_247 = heff_strRuneWidth_lent(v_src_240, v_i_241, 0);
    V v_t_248 = heff_intSub(heff_intAdd(v_lineStart_243, heff_dup(v_w_247)), MK_INT(1LL));
    V v_t_249 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_247)));
    V v_t_2410 = heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_247)), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2equoteStep_str0), v_t_249)});
    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, v_w_247), v_line_242, v_t_248, v_first_244, NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_2410}), NTAG(TAG_Nothing)});
  }
}
V g_heff_2esyntax_2efmt_2elex_2equoteStep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2equoteStep(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_str0, 30, "a `{-` comment is never closed");
Clo g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elex_2eblockCmtStep(V v_src_240, V v_i_241, V v_lineStart_242, V v_r_243) {
top: ;
  V v_t_2412;
  if (heff_intEq_c(heff_dup(heff_rfield(v_r_243, 2)), heff_dup(v_lineStart_242))) {
    V v_j_245 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_246 = heff_intAdd(v_lineStart_242, heff_intSub(heff_dup(v_j_245), heff_dup(v_i_241)));
    V v_t_247 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, heff_dup(v_i_241), v_j_245, MK_INT(0LL)));
    v_t_2412 = heff_intSub(v_t_246, v_t_247);
  } else {
    heff_drop(v_lineStart_242);
    V v_i_248 = heff_dup(heff_rfield(v_r_243, 2));
    V v_j_249 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_r_243, 2)), heff_intSub(heff_dup(v_j_249), heff_dup(v_i_248)));
    V v_t_2411 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, v_i_248, v_j_249, MK_INT(0LL)));
    v_t_2412 = heff_intSub(v_t_2410, v_t_2411);
  }
  V v_t_2413 = heff_take_field(v_r_243, 4);
  V v_t_2415;
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_t_2413);
    v_t_2415 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2413);
    V v_t_2414 = heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_241), heff_dup(heff_rfield(v_r_243, 0)), ((V)&g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_str0)});
    v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
  }
  V v_t_2416 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_dup(heff_rfield(v_r_243, 0)));
  V v_t_2417 = heff_rec_n(3, shape_start__end__text, (V[]){v_i_241, heff_dup(heff_rfield(v_r_243, 0)), v_t_2416});
  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_dup(heff_rfield(v_r_243, 0)), heff_dup(heff_rfield(v_r_243, 1)), v_t_2412, heff_get_n(v_r_243, 3, 5), NTAG(TAG_Nothing), v_t_2415, heff_tag_n(TAG_Just, 1, (V[]){v_t_2417})});
}
V g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eblockCmtStep(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str0, 6, "-- >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str1, 5, "watch");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str2, 6, "-- >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str3, 8, "-- | >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str4, 7, "doctest");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str5, 8, "-- | >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str6, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str7, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str8, 5, "field");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str9, 5, "float");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str10, 3, "int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str11, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str12, 1, "-");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str14, 7, "()[]{},");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str15, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str16, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str17, 21, "unexpected character ");
Clo g_heff_2esyntax_2efmt_2elex_2estepAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2estepAt_entry, 7, 0};

V g_heff_2esyntax_2efmt_2elex_2estepAt(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_toks_245, V v_box_24c_246) {
  int64_t v_c_246 = heff_unbox_word(v_box_24c_246);
top: ;
  if ((v_c_246 == ((int64_t)10ULL))) {
    heff_drop(v_lineStart_243);
    heff_drop(v_first_244);
    heff_drop(v_toks_245);
    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_intAdd(v_line_242, MK_INT(1LL)), heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  } else {
    if ((v_c_246 == ((int64_t)32ULL))) {
      heff_drop(v_toks_245);
      return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    } else {
      if ((v_c_246 == ((int64_t)9ULL))) {
        heff_drop(v_toks_245);
        return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      } else {
        if ((v_c_246 == ((int64_t)13ULL))) {
          heff_drop(v_toks_245);
          return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        } else {
          V v_t_2413 = heff_bool(((v_c_246 == ((int64_t)45ULL)) && ({ V v_t_2412 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(6LL))); int c_ = heff_strEq_c_lent(v_t_2412, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str0), 2); heff_drop(v_t_2412); c_; })));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_toks_245);
            heff_drop(v_t_2413);
            V v_t_2414 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str1), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str2), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
            return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(6LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2414}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
          } else {
            heff_drop(v_t_2413);
            V v_t_2417 = heff_bool(((v_c_246 == ((int64_t)45ULL)) && ({ V v_t_2416 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(8LL))); int c_ = heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str3), 2); heff_drop(v_t_2416); c_; })));
            if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
              heff_drop(v_toks_245);
              heff_drop(v_t_2417);
              V v_t_2418 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str4), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str5), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(8LL)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
              return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(8LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2418}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
            } else {
              heff_drop(v_t_2417);
              V v_t_2428 = heff_bool(((v_c_246 == ((int64_t)45ULL)) && ({ V v_t_2420 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(v_src_240, heff_dup(v_i_241))); int c_ = ({ V v_x_2421 = heff_intSub(heff_dup(v_t_2420), heff_dup(v_i_241)); int c_ = (heff_intLe_c_lent(MK_INT(2LL), v_x_2421, 1) && ({ V v_t_2423 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(v_src_240, heff_dup(v_i_241))); int c_ = ({ V v_c_2424 = heff_strByteAt_lent(v_src_240, v_t_2423, 0); int c_ = ((((int64_t)0ULL) <= heff_peek_word(v_c_2424)) ? ({ V v_t_2426 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_dup(v_c_2424)))); int c_ = !heff_intLe_c(MK_INT(0LL), heff_strFind(heff_dup(v_t_2426), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL))); heff_drop(v_t_2426); c_; }) : 1); heff_drop(v_c_2424); c_; }); heff_drop(v_t_2423); c_; })); heff_drop(v_x_2421); c_; }); heff_drop(v_t_2420); c_; })));
              if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
                heff_drop(v_toks_245);
                heff_drop(v_t_2428);
                V v_e_2429 = (g_heff_2esyntax_2efmt_2elex_2eeolEnd(v_src_240, heff_dup(v_i_241)));
                V v_t_2430 = heff_rec_n(3, shape_start__end__text, (V[]){heff_dup(v_i_241), heff_dup(v_e_2429), heff_strSlice_lent(v_src_240, v_i_241, v_e_2429, 2)});
                return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_e_2429, v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_2430})});
              } else {
                heff_drop(v_t_2428);
                V v_t_2433 = heff_bool(((v_c_246 == ((int64_t)123ULL)) && ({ V v_t_2432 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))); int c_ = (heff_peek_word(v_t_2432) == ((int64_t)45ULL)); heff_drop(v_t_2432); c_; })));
                if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
                  heff_drop(v_toks_245);
                  heff_drop(v_t_2433);
                  V v_t_2434 = (g_heff_2esyntax_2efmt_2elex_2eblockScan(v_src_240, heff_dup(v_i_241), MK_INT(0LL), v_line_242, heff_dup(v_lineStart_243), v_first_244));
                  return (g_heff_2esyntax_2efmt_2elex_2eblockCmtStep(v_src_240, v_i_241, v_lineStart_243, v_t_2434));
                } else {
                  heff_drop(v_t_2433);
                  V v_t_2437 = heff_bool(((v_c_246 == ((int64_t)98ULL)) && ({ V v_t_2436 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))); int c_ = (heff_peek_word(v_t_2436) == ((int64_t)91ULL)); heff_drop(v_t_2436); c_; })));
                  if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
                    heff_drop(v_toks_245);
                    heff_drop(v_t_2437);
                    V v_t_2438 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str6), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str7), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
                    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(2LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2438}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                  } else {
                    heff_drop(v_t_2437);
                    V v_t_2439 = (g_heff_2esyntax_2efmt_2elex_2eisLetterC(heff_box_word(v_c_246)));
                    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
                      heff_drop(v_toks_245);
                      heff_drop(v_t_2439);
                      V v_t_2440 = (g_heff_2esyntax_2efmt_2elex_2enameEnd(v_src_240, heff_dup(v_i_241)));
                      return (g_heff_2esyntax_2efmt_2elex_2enameStep(v_src_240, v_i_241, v_line_242, v_lineStart_243, v_first_244, v_t_2440));
                    } else {
                      heff_drop(v_t_2439);
                      V v_t_2444;
                      if ((v_c_246 == ((int64_t)46ULL))) {
                        V v_t_2442 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                        V v_t_2443 = (g_heff_2esyntax_2efmt_2elex_2eisLetterC(v_t_2442));
                        if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
                          heff_drop(v_t_2443);
                          v_t_2444 = (g_heff_2esyntax_2efmt_2elex_2efieldBefore(heff_dup(v_toks_245), heff_dup(v_i_241)));
                        } else {
                          heff_drop(v_t_2443);
                          v_t_2444 = NTAG(TAG_False);
                        }
                      } else {
                        v_t_2444 = NTAG(TAG_False);
                      }
                      if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
                        heff_drop(v_toks_245);
                        heff_drop(v_t_2444);
                        V v_j_2445 = (g_heff_2esyntax_2efmt_2elex_2eplainEnd(v_src_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
                        V v_t_2446 = heff_strSlice(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_j_2445));
                        V v_t_2447 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str8), v_t_2446, heff_dup(v_i_241), heff_dup(v_j_2445), heff_dup(v_line_242), heff_intSub(v_i_241, heff_dup(v_lineStart_243)), v_first_244});
                        return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_j_2445, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2447}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                      } else {
                        heff_drop(v_t_2444);
                        V v_t_2460 = heff_bool(((((int64_t)48ULL) <= v_c_246) ? ((v_c_246 <= ((int64_t)57ULL)) || ((v_c_246 == ((int64_t)45ULL)) && ({ V v_c_2451 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))); int c_ = ((((int64_t)48ULL) <= heff_peek_word(v_c_2451)) && ((heff_peek_word(v_c_2451) <= ((int64_t)57ULL)) && ({ V v_x1_2454 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(heff_dup(v_toks_245), heff_dup(v_i_241))); int c_ = !(heff_dup(v_x1_2454) == NTAG(TAG_True)); heff_drop(v_x1_2454); c_; }))); heff_drop(v_c_2451); c_; }))) : ((v_c_246 == ((int64_t)45ULL)) && ({ V v_c_2456 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))); int c_ = ((((int64_t)48ULL) <= heff_peek_word(v_c_2456)) && ((heff_peek_word(v_c_2456) <= ((int64_t)57ULL)) && ({ V v_x1_2459 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(heff_dup(v_toks_245), heff_dup(v_i_241))); int c_ = !(heff_dup(v_x1_2459) == NTAG(TAG_True)); heff_drop(v_x1_2459); c_; }))); heff_drop(v_c_2456); c_; }))));
                        if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
                          heff_drop(v_toks_245);
                          heff_drop(v_t_2460);
                          V v_r_2462;
                          if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)45ULL))) {
                            v_r_2462 = (g_heff_2esyntax_2efmt_2elex_2enumFrom(v_src_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
                          } else {
                            v_r_2462 = (g_heff_2esyntax_2efmt_2elex_2enumFrom(v_src_240, heff_dup(v_i_241)));
                          }
                          V v_t_2463 = heff_take_field(v_r_2462, 1);
                          V v_t_2464;
                          if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
                            heff_drop(v_t_2463);
                            v_t_2464 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str9);
                          } else {
                            heff_drop(v_t_2463);
                            v_t_2464 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str10);
                          }
                          V v_t_2465 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_dup(heff_rfield(v_r_2462, 0)));
                          V v_t_2466 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){v_t_2464, v_t_2465, heff_dup(v_i_241), heff_dup(heff_rfield(v_r_2462, 0)), heff_dup(v_line_242), heff_intSub(v_i_241, heff_dup(v_lineStart_243)), v_first_244});
                          return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_get_n(v_r_2462, 0, 2), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2466}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                        } else {
                          heff_drop(v_t_2460);
                          V v_t_2473 = heff_bool(((v_c_246 == ((int64_t)45ULL)) && ({ V v_c_2468 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))); int c_ = ({ V v_t_2469 = (g_heff_2esyntax_2efmt_2elex_2eisLetterC(heff_dup(v_c_2468))); int c_ = ((heff_dup(v_t_2469) == NTAG(TAG_True)) ? ({ V v_x1_2470 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(heff_dup(v_toks_245), heff_dup(v_i_241))); int c_ = !(heff_dup(v_x1_2470) == NTAG(TAG_True)); heff_drop(v_x1_2470); c_; }) : ((heff_peek_word(v_c_2468) == ((int64_t)40ULL)) && ({ V v_x1_2472 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(heff_dup(v_toks_245), heff_dup(v_i_241))); int c_ = !(heff_dup(v_x1_2472) == NTAG(TAG_True)); heff_drop(v_x1_2472); c_; }))); heff_drop(v_t_2469); c_; }); heff_drop(v_c_2468); c_; })));
                          heff_drop(v_toks_245);
                          if ((heff_dup(v_t_2473) == NTAG(TAG_True))) {
                            heff_drop(v_t_2473);
                            V v_t_2474 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str11), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str12), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
                            return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2474}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                          } else {
                            heff_drop(v_t_2473);
                            if ((v_c_246 == ((int64_t)34ULL))) {
                              V v_t_2476 = (g_heff_2esyntax_2efmt_2elex_2estrScan(v_src_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str13), NTAG(TAG_Nothing)));
                              return (g_heff_2esyntax_2efmt_2elex_2estrStep(v_src_240, v_i_241, v_line_242, v_lineStart_243, v_first_244, v_t_2476));
                            } else {
                              V v_t_2479 = heff_bool(((((int64_t)0ULL) <= v_c_246) && ({ V v_t_2478 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_c_246)))); int c_ = heff_intLe_c(MK_INT(0LL), heff_strFind_lent(v_t_2478, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str14), MK_INT(0LL), 6)); heff_drop(v_t_2478); c_; })));
                              if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
                                heff_drop(v_t_2479);
                                V v_t_2480 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                                V v_t_2481 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str15), v_t_2480, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
                                return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2481}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                              } else {
                                heff_drop(v_t_2479);
                                V v_t_2484 = heff_bool(((((int64_t)0ULL) <= v_c_246) && ({ V v_t_2483 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_c_246)))); int c_ = heff_intLe_c(MK_INT(0LL), heff_strFind(heff_dup(v_t_2483), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL))); heff_drop(v_t_2483); c_; })));
                                if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
                                  heff_drop(v_t_2484);
                                  V v_j_2485 = (g_heff_2esyntax_2efmt_2elex_2esymEnd(v_src_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
                                  V v_t_2486 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str16), heff_strSlice_lent(v_src_240, v_i_241, v_j_2485, 0), heff_dup(v_i_241), heff_dup(v_j_2485), heff_dup(v_line_242), heff_intSub(v_i_241, heff_dup(v_lineStart_243)), v_first_244});
                                  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_j_2485, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2486}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                                } else {
                                  heff_drop(v_t_2484);
                                  if ((v_c_246 == ((int64_t)39ULL))) {
                                    V v_t_2488 = (g_heff_2esyntax_2efmt_2elex_2eruneScan(v_src_240, heff_dup(v_i_241)));
                                    return (g_heff_2esyntax_2efmt_2elex_2equoteStep(v_src_240, v_i_241, v_line_242, v_lineStart_243, v_first_244, v_t_2488));
                                  } else {
                                    V v_w_2489 = heff_strRuneWidth_lent(v_src_240, v_i_241, 0);
                                    V v_t_2490 = heff_intSub(heff_intAdd(v_lineStart_243, heff_dup(v_w_2489)), MK_INT(1LL));
                                    V v_t_2491 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_2489)));
                                    V v_t_2492 = heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_2489)), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str17), v_t_2491)});
                                    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, v_w_2489), v_line_242, v_t_2490, v_first_244, NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_2492}), NTAG(TAG_Nothing)});
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2estepAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2estepAt(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr_str1, 0, "");

HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V v_src_240, V v_st_241, V v_toks_242, V v_errs_243, V v_cmts_244) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(heff_rfield(v_st_241, 0)))) {
    V v_t_246 = heff_intAdd(heff_take_field(v_st_241, 1), MK_INT(1LL));
    V v_t_247 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr_str0), ((V)&g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr_str1), heff_strLength_lent(v_src_240, 0), heff_strLength_lent(v_src_240, 0), v_t_246, MK_INT(0LL), NTAG(TAG_True)});
    V v_t_248 = heff_take_field(v_st_241, 4);
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      v_t_2410 = v_toks_242;
      break;
    }
    case TAG_Just: {
      V v_x_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_toks_242});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_f_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2410})));
    V v_t_2412 = heff_take_field(v_st_241, 5);
    V v_t_2414;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      v_t_2414 = v_errs_243;
      break;
    }
    case TAG_Just: {
      V v_x_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_errs_243});
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_f_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2414));
    V v_t_2416 = heff_get_n(v_st_241, 6, 7);
    V v_t_2418;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      v_t_2418 = v_cmts_244;
      break;
    }
    case TAG_Just: {
      V v_x_2417 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2417, v_cmts_244});
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_f_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2418));
    return ((HeffT3){{v_f_2411, v_f_2415, v_f_2419}});
  } else {
    V v_i_2420 = heff_take_field(v_st_241, 0);
    V v_t_2421 = heff_dup(heff_rfield(v_st_241, 4));
    V v_t_2423;
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Nothing: {
      v_t_2423 = heff_dup(v_toks_242);
      break;
    }
    case TAG_Just: {
      V v_x_2422 = heff_field(v_t_2421, 0);
      heff_take_n(v_t_2421, 1ULL, 1);
      v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2422, heff_dup(v_toks_242)});
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    V v_t_2424 = (g_heff_2esyntax_2efmt_2elex_2estepAt(v_src_240, heff_dup(v_i_2420), heff_take_field(v_st_241, 1), heff_take_field(v_st_241, 2), heff_take_field(v_st_241, 3), v_t_2423, heff_strByteAt_lent(v_src_240, v_i_2420, 2)));
    V v_t_2425 = heff_take_field(v_st_241, 4);
    V v_t_2427;
    switch (heff_tag_of(v_t_2425)) {
    case TAG_Nothing: {
      v_t_2427 = v_toks_242;
      break;
    }
    case TAG_Just: {
      V v_x_2426 = heff_field(v_t_2425, 0);
      heff_take_n(v_t_2425, 1ULL, 1);
      v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2426, v_toks_242});
      break;
    }
    default: heff_nomatch(v_t_2425);
    }
    V v_t_2428 = heff_take_field(v_st_241, 5);
    V v_t_2430;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Nothing: {
      v_t_2430 = v_errs_243;
      break;
    }
    case TAG_Just: {
      V v_x_2429 = heff_field(v_t_2428, 0);
      heff_take_n(v_t_2428, 1ULL, 1);
      v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2429, v_errs_243});
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    V v_t_2431 = heff_get_n(v_st_241, 6, 7);
    V v_t_2433;
    switch (heff_tag_of(v_t_2431)) {
    case TAG_Nothing: {
      v_t_2433 = v_cmts_244;
      break;
    }
    case TAG_Just: {
      V v_x_2432 = heff_field(v_t_2431, 0);
      heff_take_n(v_t_2431, 1ULL, 1);
      v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2432, v_cmts_244});
      break;
    }
    default: heff_nomatch(v_t_2431);
    }
    V t_0 = v_src_240;
    V t_1 = v_t_2424;
    V t_2 = v_t_2427;
    V t_3 = v_t_2430;
    V t_4 = v_t_2433;
    v_src_240 = t_0;
    v_st_241 = t_1;
    v_toks_242 = t_2;
    v_errs_243 = t_3;
    v_cmts_244 = t_4;
    goto top;
  }
}
Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2elexGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elex_2elexGo(V v_src_240, V v_st_241, V v_toks_242, V v_errs_243, V v_cmts_244) {
top: ;
  HeffT3 v_t_245 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_st_241, v_toks_242, v_errs_243, v_cmts_244));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_field_248 = v_t_245.f[2];
    return heff_rec_n(3, shape_tokens__errors__comments, (V[]){v_field_246, v_field_247, v_field_248});
  }
}
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2elexGo(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}