// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_closed 589621399
#define LBL_cmt 308164
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_comments 142722952
#define LBL_end 310101
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_i 323
#define LBL_isFloat 143306131
#define LBL_kind 9787483
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_msg 317947
#define LBL_ok 10307
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
static uint32_t shape_end__isFloat[] = {LBL_end, LBL_isFloat};
static uint32_t shape_i__line__lineStart__first__closed[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_closed};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_ok__end__code[] = {LBL_ok, LBL_end, LBL_code};
static uint32_t shape_start__end__msg[] = {LBL_start, LBL_end, LBL_msg};
static uint32_t shape_start__end__text[] = {LBL_start, LBL_end, LBL_text};
static uint32_t shape_tokens__errors__comments[] = {LBL_tokens, LBL_errors, LBL_comments};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2efmt_2elex_2eblockScan(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eblockScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eblockScan_clo;
V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_clo;
V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2eescAt(V, V);
V g_heff_2esyntax_2efmt_2elex_2eescAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eescAt_clo;
V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2ehexValue(V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2ehexValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2ehexValue_clo;
V g_heff_2esyntax_2efmt_2elex_2ekeywords_get(void);
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2enameEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2enameEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enameEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2enoCode_get(void);
V g_heff_2esyntax_2efmt_2elex_2enumFrac(V, V);
V g_heff_2esyntax_2efmt_2elex_2enumFrac_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enumFrac_clo;
V g_heff_2esyntax_2efmt_2elex_2enumFrom(V, V);
V g_heff_2esyntax_2efmt_2elex_2enumFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enumFrom_clo;
V g_heff_2esyntax_2efmt_2elex_2eoperandBefore(V, V);
V g_heff_2esyntax_2efmt_2elex_2eoperandBefore_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eoperandBefore_clo;
V g_heff_2esyntax_2efmt_2elex_2eplainEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eplainEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eplainEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2eruneScan(V, V);
V g_heff_2esyntax_2efmt_2elex_2eruneScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eruneScan_clo;
V g_heff_2esyntax_2efmt_2elex_2eruneStep(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eruneStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eruneStep_clo;
V g_heff_2esyntax_2efmt_2elex_2estartsDelayed(V, V);
V g_heff_2esyntax_2efmt_2elex_2estartsDelayed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2estartsDelayed_clo;
V g_heff_2esyntax_2efmt_2elex_2estepAt(V, V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2estepAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2estepAt_clo;
HeffT4 g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr(V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void);
V g_heff_2esyntax_2efmt_2elex_2esymEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2esymEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2esymEnd_clo;
V g_heff_2eutil_2erune_2ehexWith(V, V);
V g_heff_2eutil_2erune_2ehexWith_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ehexWith_clo;
V g_heff_2eutil_2erune_2epadTo4(V);
V g_heff_2eutil_2erune_2epadTo4_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2epadTo4_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str0, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str1, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str2, 6, "infixr");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str3, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str4, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str5, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str6, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str7, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str8, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str9, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str10, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str11, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str12, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str13, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str14, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str15, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str16, 6, "String");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str17, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str18, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str19, 4, "with");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str20, 4, "test");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str21, 3, "try");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str22, 5, "catch");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str23, 8, "continue");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str24, 6, "return");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str25, 3, "for");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str26, 5, "break");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str27, 3, "mut");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str28, 5, "while");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str29, 3, "let");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str30, 2, "in");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str31, 2, "do");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str32, 5, "where");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str33, 4, "then");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str34, 4, "else");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str35, 2, "of");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str36, 2, "if");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str37, 2, "as");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str38, 4, "case");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str39, 6, "mutual");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str40, 6, "import");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str41, 9, "primitive");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str42, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str43, 4, "type");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str44, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str45, 4, "data");

static V g_heff_2esyntax_2efmt_2elex_2ekeywords_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elex_2ekeywords_st;
static V g_heff_2esyntax_2efmt_2elex_2ekeywords_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str10), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str12), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str14), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str16), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str18), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str20), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str22), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str23), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str24), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str25), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str26), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str27), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str28), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str29), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str30), v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str31), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str32), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str33), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str34), v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str35), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str36), v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str37), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str38), v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str39), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str40), v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str41), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str42), v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str43), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str44), v_t_2421})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str45), v_t_2422});
}
V g_heff_2esyntax_2efmt_2elex_2ekeywords_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elex_2ekeywords_st)) return g_heff_2esyntax_2efmt_2elex_2ekeywords_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elex_2ekeywords_val, &g_heff_2esyntax_2efmt_2elex_2ekeywords_st, g_heff_2esyntax_2efmt_2elex_2ekeywords_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2esymChars_str0, 20, "!#$%&*+./<=>\?@\\^|-~:");

static V g_heff_2esyntax_2efmt_2elex_2esymChars_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elex_2esymChars_st;
static V g_heff_2esyntax_2efmt_2elex_2esymChars_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elex_2esymChars_str0);
}
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elex_2esymChars_st)) return g_heff_2esyntax_2efmt_2elex_2esymChars_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elex_2esymChars_val, &g_heff_2esyntax_2efmt_2elex_2esymChars_st, g_heff_2esyntax_2efmt_2elex_2esymChars_init);
}
Clo g_heff_2esyntax_2efmt_2elex_2enameEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enameEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enameEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if ((((((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (heff_peek_word(v_c_242) == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL)))) || (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || (heff_peek_word(v_c_242) == ((int64_t)39ULL))))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)47ULL))) {
      V v_c_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      if (((((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)122ULL))) || (heff_peek_word(v_c_243) == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)90ULL))))) {
        heff_drop(v_c_243);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        heff_drop(v_c_243);
        return v_j_241;
      }
    } else {
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2enameEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2enameEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2eplainEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eplainEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eplainEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if ((((((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (heff_peek_word(v_c_242) == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL)))) || (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || (heff_peek_word(v_c_242) == ((int64_t)39ULL))))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2eplainEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eplainEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL)))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)95ULL))) {
      V v_c_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      if (((((int64_t)48ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)57ULL)))) {
        heff_drop(v_c_243);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        heff_drop(v_c_243);
        return v_j_241;
      }
    } else {
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V v_s_240, V v_j_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)45ULL))) {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edashesEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V v_s_240, V v_j_241) {
top: ;
  if ((heff_intLt_c(heff_dup(v_j_241), heff_strLength_lent(v_s_240, 0)) && !(heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL)))) {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eeolEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2esymEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2esymEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2esymEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  V v_t_244 = heff_bool(((((int64_t)0ULL) <= heff_peek_word(v_c_242)) && ({ V v_t_243 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_dup(v_c_242)))); int c_ = ({ V v_t_245 = heff_strFind(heff_dup(v_t_243), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)); int c_ = heff_intLe_c_lent(MK_INT(0LL), v_t_245, 1); heff_drop(v_t_245); c_; }); heff_drop(v_t_243); c_; })));
  heff_drop(v_c_242);
  if (((heff_dup(v_t_244) == NTAG(TAG_True)) && ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)45ULL)) ? !(heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)))) == ((int64_t)45ULL)) : 1))) {
    heff_drop(v_t_244);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_t_244);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2esymEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2esymEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2enumFrac_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enumFrac_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enumFrac(V v_s_240, V v_a_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_a_241, 0)) == ((int64_t)46ULL))) {
    V v_c_242 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_a_241), MK_INT(1LL)));
    if (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL)))) {
      heff_drop(v_c_242);
      V v_s_243 = heff_dup(v_s_240);
      V v_b_244 = ({ V a_0 = v_s_240; V a_1 = heff_intAdd(v_a_241, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(a_0, a_1)); heff_drop(v_s_240); r_; });
      if (((heff_unbox_word(heff_strByteAt_lent(v_s_243, v_b_244, 0)) == ((int64_t)101ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_243, v_b_244, 0)) == ((int64_t)69ULL)))) {
        V v_c_245 = heff_strByteAt(heff_dup(v_s_243), heff_intAdd(heff_dup(v_b_244), MK_INT(1LL)));
        if (((((int64_t)48ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)57ULL)))) {
          heff_drop(v_c_245);
          V v_t_246 = ({ V a_0 = v_s_243; V a_1 = heff_intAdd(v_b_244, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(a_0, a_1)); heff_drop(v_s_243); r_; });
          return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_246, NTAG(TAG_True)});
        } else {
          heff_drop(v_c_245);
          V v_t_247 = heff_strByteAt(heff_dup(v_s_243), heff_intAdd(heff_dup(v_b_244), MK_INT(1LL)));
          if (((heff_peek_word(v_t_247) == ((int64_t)43ULL)) || (heff_unbox_word(heff_strByteAt(heff_dup(v_s_243), heff_intAdd(heff_dup(v_b_244), MK_INT(1LL)))) == ((int64_t)45ULL)))) {
            heff_drop(v_t_247);
            V v_c_248 = heff_strByteAt(heff_dup(v_s_243), heff_intAdd(heff_dup(v_b_244), MK_INT(2LL)));
            if (((((int64_t)48ULL) <= heff_peek_word(v_c_248)) && (heff_peek_word(v_c_248) <= ((int64_t)57ULL)))) {
              heff_drop(v_c_248);
              V v_t_249 = ({ V a_0 = v_s_243; V a_1 = heff_intAdd(v_b_244, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(a_0, a_1)); heff_drop(v_s_243); r_; });
              return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_249, NTAG(TAG_True)});
            } else {
              heff_drop(v_s_243);
              heff_drop(v_c_248);
              return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_244, NTAG(TAG_True)});
            }
          } else {
            heff_drop(v_s_243);
            heff_drop(v_t_247);
            return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_244, NTAG(TAG_True)});
          }
        }
      } else {
        heff_drop(v_s_243);
        return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_244, NTAG(TAG_True)});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_c_242);
      return heff_rec_n(2, shape_end__isFloat, (V[]){v_a_241, NTAG(TAG_False)});
    }
  } else {
    heff_drop(v_s_240);
    return heff_rec_n(2, shape_end__isFloat, (V[]){v_a_241, NTAG(TAG_False)});
  }
}
V g_heff_2esyntax_2efmt_2elex_2enumFrac_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2enumFrac(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if ((((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)102ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)70ULL)))))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)95ULL))) {
      V v_c_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      if ((((((int64_t)48ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)57ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)102ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)70ULL)))))) {
        heff_drop(v_c_243);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        heff_drop(v_c_243);
        return v_j_241;
      }
    } else {
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if (((heff_peek_word(v_c_242) == ((int64_t)48ULL)) || (heff_peek_word(v_c_242) == ((int64_t)49ULL)))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)95ULL))) {
      V v_c_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      if (((heff_peek_word(v_c_243) == ((int64_t)48ULL)) || (heff_peek_word(v_c_243) == ((int64_t)49ULL)))) {
        heff_drop(v_c_243);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        heff_drop(v_c_243);
        return v_j_241;
      }
    } else {
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2enumFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enumFrom_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enumFrom(V v_s_240, V v_j_241) {
top: ;
  V v_t_244;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)48ULL))) {
    V v_t_242 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
    if (((heff_peek_word(v_t_242) == ((int64_t)120ULL)) || (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)))) == ((int64_t)88ULL)))) {
      heff_drop(v_t_242);
      V v_c_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)));
      v_t_244 = heff_bool((((((int64_t)48ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)57ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)102ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)70ULL))))));
      heff_drop(v_c_243);
    } else {
      heff_drop(v_t_242);
      v_t_244 = NTAG(TAG_False);
    }
  } else {
    v_t_244 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = ({ V a_0 = v_s_240; V a_1 = heff_intAdd(v_j_241, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(a_0, a_1)); heff_drop(v_s_240); r_; });
    return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_245, NTAG(TAG_False)});
  } else {
    heff_drop(v_t_244);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)48ULL))) {
      V v_t_246 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      if (((heff_peek_word(v_t_246) == ((int64_t)98ULL)) || (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)))) == ((int64_t)66ULL)))) {
        heff_drop(v_t_246);
        V v_c_247 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)));
        if (((heff_peek_word(v_c_247) == ((int64_t)48ULL)) || (heff_peek_word(v_c_247) == ((int64_t)49ULL)))) {
          heff_drop(v_c_247);
          V v_t_248 = ({ V a_0 = v_s_240; V a_1 = heff_intAdd(v_j_241, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(a_0, a_1)); heff_drop(v_s_240); r_; });
          return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_248, NTAG(TAG_False)});
        } else {
          heff_drop(v_c_247);
          V v_t_249 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_j_241, MK_INT(1LL))));
          HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumFrac(v_s_240, v_t_249);
        }
      } else {
        heff_drop(v_t_246);
        V v_t_2410 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_j_241, MK_INT(1LL))));
        HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumFrac(v_s_240, v_t_2410);
      }
    } else {
      V v_t_2411 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_j_241, MK_INT(1LL))));
      HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumFrac(v_s_240, v_t_2411);
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2enumFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2enumFrom(a[0], a[1]);
}

static V g_heff_2esyntax_2efmt_2elex_2enoCode_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elex_2enoCode_st;
static V g_heff_2esyntax_2efmt_2elex_2enoCode_init(void) {
  return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2esyntax_2efmt_2elex_2enoCode_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elex_2enoCode_st)) return g_heff_2esyntax_2efmt_2elex_2enoCode_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elex_2enoCode_val, &g_heff_2esyntax_2efmt_2elex_2enoCode_st, g_heff_2esyntax_2efmt_2elex_2enoCode_init);
}
Clo g_heff_2esyntax_2efmt_2elex_2ehexValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2ehexValue_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elex_2ehexValue(V v_s_240, V v_j_241, V v_e_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(v_e_242, v_j_241, 0)) {
    heff_drop(v_j_241);
    heff_drop(v_e_242);
    return v_acc_243;
  } else {
    V v_c_244 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
    int64_t v_t_245;
    if (((((int64_t)48ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)57ULL)))) {
      v_t_245 = (heff_unbox_word(v_c_244) - ((int64_t)48ULL));
    } else {
      if ((((int64_t)97ULL) <= heff_peek_word(v_c_244))) {
        v_t_245 = (heff_unbox_word(v_c_244) - ((int64_t)87ULL));
      } else {
        v_t_245 = (heff_unbox_word(v_c_244) - ((int64_t)55ULL));
      }
    }
    V v_t_246 = heff_intAdd(heff_intMul(v_acc_243, MK_INT(16LL)), heff_box_word(v_t_245));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    V t_2 = v_e_242;
    V t_3 = v_t_246;
    v_s_240 = t_0;
    v_j_241 = t_1;
    v_e_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
}
V g_heff_2esyntax_2efmt_2elex_2ehexValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2ehexValue(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if ((((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)102ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)70ULL)))))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2eescAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eescAt_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eescAt(V v_s_240, V v_j_241) {
top: ;
  if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)117ULL)) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)))) == ((int64_t)123ULL)))) {
    V v_s_242 = heff_dup(v_s_240);
    V v_j_243 = heff_dup(v_j_241);
    V v_e_244 = ({ V a_0 = v_s_240; V a_1 = heff_intAdd(v_j_241, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(a_0, a_1)); heff_drop(v_s_240); r_; });
    if ((heff_intLt_c(heff_intAdd(heff_dup(v_j_243), MK_INT(2LL)), heff_dup(v_e_244)) && (heff_unbox_word(heff_strByteAt_lent(v_s_242, v_e_244, 0)) == ((int64_t)125ULL)))) {
      V v_t_245 = ({ V a_0 = v_s_242; V a_1 = heff_intAdd(v_j_243, MK_INT(2LL)); V a_2 = heff_dup(v_e_244); V a_3 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elex_2ehexValue(a_0, a_1, a_2, a_3)); heff_drop(v_s_242); r_; });
      return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_e_244, MK_INT(1LL)), v_t_245});
    } else {
      heff_drop(v_s_242);
      heff_drop(v_e_244);
      return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_j_243, MK_INT(1LL)), MK_INT(117LL)});
    }
  } else {
    if ((heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_j_241)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL)))) {
      heff_drop(v_s_240);
      heff_drop(v_j_241);
      return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
    } else {
      HeffT2 v_t_246 = heff_strRuneDecode_lent(v_s_240, v_j_241, 1);
      {
        V v_rune_247 = v_t_246.f[0];
        V v_width_248 = v_t_246.f[1];
        V v_t_249 = heff_intAdd(v_j_241, v_width_248);
        V v_c_2410 = heff_runeToInt(v_rune_247);
        V v_t_2411;
        if (heff_intEq_c_lent(v_c_2410, MK_INT(110LL), 2)) {
          heff_drop(v_c_2410);
          v_t_2411 = MK_INT(10LL);
        } else {
          if (heff_intEq_c_lent(v_c_2410, MK_INT(116LL), 2)) {
            heff_drop(v_c_2410);
            v_t_2411 = MK_INT(9LL);
          } else {
            if (heff_intEq_c_lent(v_c_2410, MK_INT(114LL), 2)) {
              heff_drop(v_c_2410);
              v_t_2411 = MK_INT(13LL);
            } else {
              v_t_2411 = v_c_2410;
            }
          }
        }
        return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), v_t_249, v_t_2411});
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2eescAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eescAt(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str0, 16, "0123456789ABCDEF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str1, 39, "a `\\u{...}` is a Unicode scalar value: ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str2, 2, "U+");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str3, 19, " is beyond U+10FFFF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str4, 15, " is a surrogate");

HeffT4 g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr(V v_s_240, V v_j_241, V v_acc_242, V v_bad_243) {
top: ;
  if ((heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_j_241)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL)))) {
    heff_drop(v_s_240);
    return ((HeffT4){{v_j_241, v_acc_242, NTAG(TAG_False), v_bad_243}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)34ULL))) {
      heff_drop(v_s_240);
      return ((HeffT4){{v_j_241, v_acc_242, NTAG(TAG_True), v_bad_243}});
    } else {
      V v_t_248;
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)92ULL))) {
        V v_s_244 = heff_dup(v_s_240);
        V v_j_245 = heff_intAdd(heff_dup(v_j_241), MK_INT(1LL));
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_244, v_j_245, 0)) == ((int64_t)120ULL))) {
          V v_c_246 = heff_strByteAt(heff_dup(v_s_244), heff_intAdd(heff_dup(v_j_245), MK_INT(1LL)));
          if ((((((int64_t)48ULL) <= heff_peek_word(v_c_246)) && (heff_peek_word(v_c_246) <= ((int64_t)57ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_c_246)) && (heff_peek_word(v_c_246) <= ((int64_t)102ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_246)) && (heff_peek_word(v_c_246) <= ((int64_t)70ULL)))))) {
            heff_drop(v_c_246);
            V v_c_247 = heff_strByteAt(v_s_244, heff_intAdd(v_j_245, MK_INT(2LL)));
            v_t_248 = heff_bool((((((int64_t)48ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)57ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)102ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)70ULL))))));
            heff_drop(v_c_247);
          } else {
            heff_drop(v_s_244);
            heff_drop(v_j_245);
            heff_drop(v_c_246);
            v_t_248 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_s_244);
          heff_drop(v_j_245);
          v_t_248 = NTAG(TAG_False);
        }
      } else {
        v_t_248 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_t_249 = (g_heff_2esyntax_2efmt_2elex_2ehexValue(v_s_240, heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)), heff_intAdd(heff_dup(v_j_241), MK_INT(4LL)), MK_INT(0LL)));
        V v_t_2410 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_t_249)));
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(4LL));
        V t_2 = heff_strAppend(v_acc_242, v_t_2410);
        V t_3 = v_bad_243;
        v_s_240 = t_0;
        v_j_241 = t_1;
        v_acc_242 = t_2;
        v_bad_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_248);
        if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)92ULL)) && heff_intLt_c(heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)), heff_strLength_lent(v_s_240, 0)))) {
          V v_k_2411 = heff_intAdd(heff_dup(v_j_241), MK_INT(1LL));
          V v_e_2412 = (g_heff_2esyntax_2efmt_2elex_2eescAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL))));
          V v_t_2413 = heff_dup(heff_rfield(v_e_2412, 0));
          V v_e_2414;
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_k_2411);
            heff_drop(v_t_2413);
            v_e_2414 = v_e_2412;
          } else {
            heff_drop_rec(v_e_2412, 3);
            heff_drop(v_t_2413);
            v_e_2414 = heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(heff_dup(v_k_2411), MK_INT(1LL)), heff_strByteAt_lent(v_s_240, v_k_2411, 2)});
          }
          V v_c_2415 = heff_dup(heff_rfield(v_e_2414, 2));
          V v_t_2416;
          if ((heff_intLe_c_lent(MK_INT(0LL), v_c_2415, 1) && (heff_intLe_c_lent(v_c_2415, MK_INT(1114111LL), 2) && ((((int64_t)55296ULL) <= heff_peek_word(v_c_2415)) ? !(heff_peek_word(v_c_2415) <= ((int64_t)57343ULL)) : 1)))) {
            v_t_2416 = v_c_2415;
          } else {
            heff_drop(v_c_2415);
            v_t_2416 = MK_INT(65533LL);
          }
          V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_t_2416), NTAG(TAG_Nil)});
          V v_t_2418 = heff_strAppend(v_acc_242, heff_strOfRunes(v_t_2417));
          V v_x1_2419 = v_bad_243;
          V v_j_2420 = v_j_241;
          V v_e_2421 = heff_dup(v_e_2414);
          V v_code_2422 = heff_take_field(v_e_2421, 2);
          V v_end_2423 = heff_get_n(v_e_2421, 1, 3);
          V v_t_2432;
          switch (heff_tag_of(v_x1_2419)) {
          case TAG_Nothing: {
            V v_c_2424 = heff_dup(v_code_2422);
            if ((heff_intLe_c_lent(MK_INT(0LL), v_c_2424, 1) && (heff_intLe_c_lent(v_c_2424, MK_INT(1114111LL), 2) && ((((int64_t)55296ULL) <= heff_peek_word(v_c_2424)) ? !(heff_peek_word(v_c_2424) <= ((int64_t)57343ULL)) : 1)))) {
              heff_drop(v_j_2420);
              heff_drop(v_code_2422);
              heff_drop(v_end_2423);
              heff_drop(v_c_2424);
              v_t_2432 = NTAG(TAG_Nothing);
            } else {
              heff_drop(v_c_2424);
              V v_c_2425 = v_code_2422;
              V v_t_2426 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str0); V a_1 = heff_dup(v_c_2425); V r_ = (g_heff_2eutil_2erune_2ehexWith(b_0, a_1)); heff_drop(b_0); r_; });
              V v_t_2427 = (g_heff_2eutil_2erune_2epadTo4(v_t_2426));
              V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str1), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str2), v_t_2427));
              V v_t_2429;
              if (heff_intLt_c(MK_INT(1114111LL), v_c_2425)) {
                v_t_2429 = ((V)&g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str3);
              } else {
                v_t_2429 = ((V)&g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str4);
              }
              V v_t_2430 = heff_rec_n(3, shape_start__end__msg, (V[]){v_j_2420, v_end_2423, heff_strAppend(v_t_2428, v_t_2429)});
              v_t_2432 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2430});
            }
            break;
          }
          case TAG_Just: {
            V v_b_2431 = heff_field(v_x1_2419, 0);
            V v_ru_24x1_2419_24Just = heff_take_reuse_n(v_x1_2419, 1ULL, 1);
            heff_drop(v_j_2420);
            heff_drop(v_code_2422);
            heff_drop(v_end_2423);
            v_t_2432 = heff_tag_at_n(v_ru_24x1_2419_24Just, TAG_Just, 1, (V[]){v_b_2431});
            break;
          }
          default: heff_nomatch(v_x1_2419);
          }
          V t_0 = v_s_240;
          V t_1 = heff_get_n(v_e_2414, 1, 3);
          V t_2 = v_t_2418;
          V t_3 = v_t_2432;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_acc_242 = t_2;
          v_bad_243 = t_3;
          goto top;
        } else {
          V v_t_2433 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_j_241), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_2 = heff_strAppend(v_acc_242, v_t_2433);
          V t_3 = v_bad_243;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_acc_242 = t_2;
          v_bad_243 = t_3;
          goto top;
        }
      }
    }
  }
}
Clo g_heff_2esyntax_2efmt_2elex_2eruneScan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eruneScan_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eruneScan(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
  if ((heff_unbox_word(v_t_242) == ((int64_t)92ULL))) {
    V v_e_243 = (g_heff_2esyntax_2efmt_2elex_2eescAt(heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(2LL))));
    V v_t_244 = heff_take_field(v_e_243, 0);
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_j_245 = heff_take_field(v_e_243, 1);
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_245, 1)) == ((int64_t)39ULL))) {
        return ({ V rv_0 = NTAG(TAG_True); V rv_1 = heff_intAdd(v_j_245, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_e_243, 4ULL, 3, shape_ok__end__code, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      } else {
        heff_drop_rec(v_e_243, 3);
        heff_drop(v_j_245);
        return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
      }
    } else {
      heff_drop(v_s_240);
      heff_drop_rec(v_e_243, 3);
      heff_drop(v_t_244);
      return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
    }
  } else {
    if ((heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))) || ((heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) == ((int64_t)39ULL)) || (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) == ((int64_t)10ULL))))) {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
    } else {
      HeffT2 v_t_246 = heff_strRuneDecode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
      {
        V v_rune_247 = v_t_246.f[0];
        V v_width_248 = v_t_246.f[1];
        V v_j_249 = heff_intAdd(heff_intAdd(v_i_241, MK_INT(1LL)), v_width_248);
        V v_c_2410 = heff_runeToInt(v_rune_247);
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_249, 1)) == ((int64_t)39ULL))) {
          return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_j_249, MK_INT(1LL)), v_c_2410});
        } else {
          heff_drop(v_j_249);
          heff_drop(v_c_2410);
          return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2eruneScan_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eruneScan(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2eblockScan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eblockScan_entry, 6, 0};

V g_heff_2esyntax_2efmt_2elex_2eblockScan(V v_s_240, V v_j_241, V v_depth_242, V v_line_243, V v_lineStart_244, V v_first_245) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_j_241))) {
    heff_drop(v_depth_242);
    return heff_rec_n(5, shape_i__line__lineStart__first__closed, (V[]){v_j_241, v_line_243, v_lineStart_244, v_first_245, NTAG(TAG_False)});
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)123ULL)) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)))) == ((int64_t)45ULL)))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
      V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
      V t_3 = v_line_243;
      V t_4 = v_lineStart_244;
      V t_5 = v_first_245;
      v_s_240 = t_0;
      v_j_241 = t_1;
      v_depth_242 = t_2;
      v_line_243 = t_3;
      v_lineStart_244 = t_4;
      v_first_245 = t_5;
      goto top;
    } else {
      if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)45ULL)) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)))) == ((int64_t)125ULL)))) {
        if (heff_intEq_c_lent(v_depth_242, MK_INT(1LL), 2)) {
          heff_drop(v_depth_242);
          return heff_rec_n(5, shape_i__line__lineStart__first__closed, (V[]){heff_intAdd(v_j_241, MK_INT(2LL)), v_line_243, v_lineStart_244, v_first_245, NTAG(TAG_True)});
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
          V t_2 = heff_intSub(v_depth_242, MK_INT(1LL));
          V t_3 = v_line_243;
          V t_4 = v_lineStart_244;
          V t_5 = v_first_245;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        }
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL))) {
          heff_drop(v_lineStart_244);
          heff_drop(v_first_245);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(heff_dup(v_j_241), MK_INT(1LL));
          V t_2 = v_depth_242;
          V t_3 = heff_intAdd(v_line_243, MK_INT(1LL));
          V t_4 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_5 = NTAG(TAG_True);
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_2 = v_depth_242;
          V t_3 = v_line_243;
          V t_4 = v_lineStart_244;
          V t_5 = v_first_245;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2eblockScan_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eblockScan(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str2, 3, "int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str3, 5, "float");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str4, 3, "str");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str5, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str6, 5, "field");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str7, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str8, 1, "}");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str10, 1, "]");
Clo g_heff_2esyntax_2efmt_2elex_2eoperandBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eoperandBefore_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eoperandBefore(V v_x1_240, V v_start_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_start_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    V v_end_244 = heff_take_field(v_t_242, 3);
    V v_kind_245 = heff_take_field(v_t_242, 0);
    V v_text_246 = heff_get_n(v_t_242, 1, 7);
    if (heff_intEq_c(v_end_244, v_start_241)) {
      V v_p_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_kind_245)}));
      V v_t_248 = heff_tr(heff_call(heff_dup(v_p_247), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str0)}));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_kind_245);
        heff_drop(v_text_246);
        heff_drop(v_p_247);
        heff_drop(v_t_248);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_248);
        V v_t_249 = heff_tr(heff_call(heff_dup(v_p_247), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str1)}));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_kind_245);
          heff_drop(v_text_246);
          heff_drop(v_p_247);
          heff_drop(v_t_249);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_249);
          V v_t_2410 = heff_tr(heff_call(heff_dup(v_p_247), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str2)}));
          if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_kind_245);
            heff_drop(v_text_246);
            heff_drop(v_p_247);
            heff_drop(v_t_2410);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_2410);
            V v_t_2411 = heff_tr(heff_call(heff_dup(v_p_247), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str3)}));
            if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
              heff_drop_cell(v_ru_24x1_240_24Cons, 2);
              heff_drop(v_kind_245);
              heff_drop(v_text_246);
              heff_drop(v_p_247);
              heff_drop(v_t_2411);
              return NTAG(TAG_True);
            } else {
              heff_drop(v_t_2411);
              V v_t_2412 = heff_tr(heff_call(heff_dup(v_p_247), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str4)}));
              if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
                heff_drop_cell(v_ru_24x1_240_24Cons, 2);
                heff_drop(v_kind_245);
                heff_drop(v_text_246);
                heff_drop(v_p_247);
                heff_drop(v_t_2412);
                return NTAG(TAG_True);
              } else {
                heff_drop(v_t_2412);
                V v_t_2413 = heff_tr(heff_call(heff_dup(v_p_247), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str5)}));
                if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24x1_240_24Cons, 2);
                  heff_drop(v_kind_245);
                  heff_drop(v_text_246);
                  heff_drop(v_p_247);
                  heff_drop(v_t_2413);
                  return NTAG(TAG_True);
                } else {
                  heff_drop(v_t_2413);
                  V v_t_2414 = heff_tr(heff_call(v_p_247, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str6)}));
                  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
                    heff_drop_cell(v_ru_24x1_240_24Cons, 2);
                    heff_drop(v_kind_245);
                    heff_drop(v_text_246);
                    heff_drop(v_t_2414);
                    return NTAG(TAG_True);
                  } else {
                    heff_drop(v_t_2414);
                    if (heff_strEq_c(v_kind_245, ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str7))) {
                      V v_t_2415 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_text_246}));
                      V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str8), NTAG(TAG_Nil)});
                      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str10), v_t_2416})});
                      return ({ V a_0 = v_t_2415; V a_1 = v_t_2417; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2417, 2); r_; });
                    } else {
                      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
                      heff_drop(v_text_246);
                      return NTAG(TAG_False);
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_kind_245);
      heff_drop(v_text_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elex_2eoperandBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eoperandBefore(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2estartsDelayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2estartsDelayed_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2estartsDelayed(V v_src_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_src_240, v_j_241, 0);
  if ((((((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (heff_peek_word(v_c_242) == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL)))) || (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || ((heff_peek_word(v_c_242) == ((int64_t)40ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)91ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)34ULL)) || (heff_peek_word(v_c_242) == ((int64_t)39ULL)))))))) {
    heff_drop(v_j_241);
    heff_drop(v_c_242);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_c_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_j_241, 0)) == ((int64_t)126ULL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_j_241 = t_1;
      goto top;
    } else {
      heff_drop(v_j_241);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2estartsDelayed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2estartsDelayed(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str0, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str1, 16, "0123456789ABCDEF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str2, 42, "a rune literal is a Unicode scalar value: ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str3, 2, "U+");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str4, 19, " is beyond U+10FFFF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str5, 15, " is a surrogate");
Clo g_heff_2esyntax_2efmt_2elex_2eruneStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eruneStep_entry, 6, 0};

V g_heff_2esyntax_2efmt_2elex_2eruneStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_r_245) {
top: ;
  V v_end_246 = heff_take_field(v_r_245, 1);
  V v_code_247 = heff_get_n(v_r_245, 2, 3);
  V v_j_248 = heff_dup(v_end_246);
  V v_t_249 = heff_intAdd(heff_dup(v_lineStart_243), heff_intSub(heff_dup(v_j_248), heff_dup(v_i_241)));
  V v_t_2410 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, heff_dup(v_i_241), v_j_248, MK_INT(0LL)));
  V v_c_2411 = heff_dup(v_code_247);
  V v_col_2412 = heff_intSub(heff_dup(v_i_241), v_lineStart_243);
  V v_t_2413;
  if ((heff_intLe_c_lent(MK_INT(0LL), v_c_2411, 1) && (heff_intLe_c_lent(v_c_2411, MK_INT(1114111LL), 2) && ((((int64_t)55296ULL) <= heff_peek_word(v_c_2411)) ? !(heff_peek_word(v_c_2411) <= ((int64_t)57343ULL)) : 1)))) {
    v_t_2413 = v_c_2411;
  } else {
    heff_drop(v_c_2411);
    v_t_2413 = MK_INT(65533LL);
  }
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_t_2413), NTAG(TAG_Nil)});
  V v_t_2415 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str0), heff_strOfRunes(v_t_2414), heff_dup(v_i_241), heff_dup(v_end_246), heff_dup(v_line_242), v_col_2412, v_first_244});
  V v_c_2416 = heff_dup(v_code_247);
  V v_t_2423;
  if ((heff_intLe_c_lent(MK_INT(0LL), v_c_2416, 1) && (heff_intLe_c_lent(v_c_2416, MK_INT(1114111LL), 2) && ((((int64_t)55296ULL) <= heff_peek_word(v_c_2416)) ? !(heff_peek_word(v_c_2416) <= ((int64_t)57343ULL)) : 1)))) {
    heff_drop(v_i_241);
    heff_drop(v_code_247);
    heff_drop(v_c_2416);
    v_t_2423 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_c_2416);
    V v_c_2417 = v_code_247;
    V v_t_2418 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str1); V a_1 = heff_dup(v_c_2417); V r_ = (g_heff_2eutil_2erune_2ehexWith(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2419 = (g_heff_2eutil_2erune_2epadTo4(v_t_2418));
    V v_t_2420 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str2), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str3), v_t_2419));
    V v_t_2421;
    if (heff_intLt_c(MK_INT(1114111LL), v_c_2417)) {
      v_t_2421 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str4);
    } else {
      v_t_2421 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str5);
    }
    V v_t_2422 = heff_rec_n(3, shape_start__end__msg, (V[]){v_i_241, heff_dup(v_end_246), heff_strAppend(v_t_2420, v_t_2421)});
    v_t_2423 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2422});
  }
  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_end_246, v_line_242, heff_intSub(v_t_249, v_t_2410), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2415}), v_t_2423, NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2efmt_2elex_2eruneStep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eruneStep(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str0, 6, "-- >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str1, 5, "watch");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str2, 6, "-- >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str3, 8, "-- | >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str4, 7, "doctest");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str5, 8, "-- | >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str6, 30, "a `{-` comment is never closed");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str7, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str8, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str9, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str10, 3, "con");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str11, 3, "var");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str12, 3, "var");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str13, 3, "con");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str14, 3, "int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str15, 5, "float");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str16, 3, "str");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str17, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str18, 5, "field");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str19, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str20, 1, ")");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str21, 1, "]");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str22, 1, "}");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str23, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str24, 5, "field");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str25, 5, "float");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str26, 3, "int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str27, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str28, 1, "-");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str29, 4, "lazy");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str30, 1, "~");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str31, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str32, 3, "str");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str33, 24, "a string is never closed");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str34, 7, "()[]{},");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str35, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str36, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str37, 21, "unexpected character ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str38, 21, "unexpected character ");
Clo g_heff_2esyntax_2efmt_2elex_2estepAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2estepAt_entry, 7, 0};

V g_heff_2esyntax_2efmt_2elex_2estepAt(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_toks_245, V v_box_24c_246) {
  int64_t v_c_246 = heff_unbox_word(v_box_24c_246);
top: ;
  if ((v_c_246 == ((int64_t)10ULL))) {
    heff_drop(v_src_240);
    heff_drop(v_lineStart_243);
    heff_drop(v_first_244);
    heff_drop(v_toks_245);
    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_intAdd(v_line_242, MK_INT(1LL)), heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  } else {
    if (((v_c_246 == ((int64_t)32ULL)) || ((v_c_246 == ((int64_t)9ULL)) || (v_c_246 == ((int64_t)13ULL))))) {
      heff_drop(v_src_240);
      heff_drop(v_toks_245);
      return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    } else {
      if (((v_c_246 == ((int64_t)45ULL)) && heff_strEq_c(heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(6LL))), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str0)))) {
        heff_drop(v_src_240);
        heff_drop(v_toks_245);
        V v_end_247 = heff_intAdd(heff_dup(v_i_241), MK_INT(6LL));
        V v_col_248 = heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243));
        V v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str1), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str2), heff_dup(v_i_241), v_end_247, heff_dup(v_line_242), v_col_248, v_first_244})});
        return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(6LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), v_t_249, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      } else {
        if (((v_c_246 == ((int64_t)45ULL)) && heff_strEq_c(heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(8LL))), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str3)))) {
          heff_drop(v_src_240);
          heff_drop(v_toks_245);
          V v_end_2410 = heff_intAdd(heff_dup(v_i_241), MK_INT(8LL));
          V v_col_2411 = heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243));
          V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str4), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str5), heff_dup(v_i_241), v_end_2410, heff_dup(v_line_242), v_col_2411, v_first_244})});
          return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(8LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), v_t_2412, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        } else {
          V v_t_2418;
          if ((v_c_246 == ((int64_t)45ULL))) {
            V v_t_2413 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(v_src_240, heff_dup(v_i_241)));
            V v_x_2414 = heff_intSub(v_t_2413, heff_dup(v_i_241));
            if (heff_intLe_c(MK_INT(2LL), v_x_2414)) {
              V v_t_2415 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(v_src_240, heff_dup(v_i_241)));
              V v_c_2416 = heff_strByteAt_lent(v_src_240, v_t_2415, 2);
              v_t_2418 = heff_bool(((((int64_t)0ULL) <= heff_peek_word(v_c_2416)) ? ({ V v_t_2417 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_dup(v_c_2416)))); int c_ = ({ V v_t_24150 = heff_strFind(heff_dup(v_t_2417), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)); int c_ = !heff_intLe_c_lent(MK_INT(0LL), v_t_24150, 1); heff_drop(v_t_24150); c_; }); heff_drop(v_t_2417); c_; }) : 1));
              heff_drop(v_c_2416);
            } else {
              v_t_2418 = NTAG(TAG_False);
            }
          } else {
            v_t_2418 = NTAG(TAG_False);
          }
          if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
            heff_drop(v_toks_245);
            heff_drop(v_t_2418);
            V v_e_2419 = (g_heff_2esyntax_2efmt_2elex_2eeolEnd(v_src_240, heff_dup(v_i_241)));
            V v_t_2420 = heff_rec_n(3, shape_start__end__text, (V[]){heff_dup(v_i_241), heff_dup(v_e_2419), heff_strSlice_lent(v_src_240, v_i_241, v_e_2419, 3)});
            return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_e_2419, v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_2420})});
          } else {
            heff_drop(v_t_2418);
            if (((v_c_246 == ((int64_t)123ULL)) && (heff_unbox_word(heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) == ((int64_t)45ULL)))) {
              heff_drop(v_toks_245);
              V v_src_2421 = heff_dup(v_src_240);
              V v_i_2422 = heff_dup(v_i_241);
              V v_lineStart_2423 = heff_dup(v_lineStart_243);
              V v_r_2424 = ({ V a_0 = v_src_240; V a_1 = v_i_241; V a_2 = MK_INT(0LL); V a_3 = v_line_242; V a_4 = v_lineStart_243; V a_5 = v_first_244; V r_ = (g_heff_2esyntax_2efmt_2elex_2eblockScan(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_src_240); r_; });
              V v_i_2425 = heff_take_field(v_r_2424, 0);
              V v_line_2426 = heff_take_field(v_r_2424, 1);
              V v_lineStart_2427 = heff_take_field(v_r_2424, 2);
              V v_first_2428 = heff_take_field(v_r_2424, 3);
              V v_closed_2429 = heff_get_n(v_r_2424, 4, 5);
              V v_t_2437;
              if (heff_intEq_c_lent(v_lineStart_2427, v_lineStart_2423, 0)) {
                heff_drop(v_lineStart_2427);
                V v_j_2430 = heff_dup(v_i_2425);
                V v_t_2431 = heff_intAdd(v_lineStart_2423, heff_intSub(heff_dup(v_j_2430), heff_dup(v_i_2422)));
                V v_t_2432 = (g_heff_2eutil_2erune_2erunesGo(v_src_2421, heff_dup(v_i_2422), v_j_2430, MK_INT(0LL)));
                v_t_2437 = heff_intSub(v_t_2431, v_t_2432);
              } else {
                heff_drop(v_lineStart_2423);
                V v_i_2433 = heff_dup(v_lineStart_2427);
                V v_j_2434 = heff_dup(v_i_2425);
                V v_t_2435 = heff_intAdd(v_lineStart_2427, heff_intSub(heff_dup(v_j_2434), heff_dup(v_i_2433)));
                V v_t_2436 = (g_heff_2eutil_2erune_2erunesGo(v_src_2421, v_i_2433, v_j_2434, MK_INT(0LL)));
                v_t_2437 = heff_intSub(v_t_2435, v_t_2436);
              }
              V v_t_2438;
              if ((heff_dup(v_closed_2429) == NTAG(TAG_True))) {
                heff_drop(v_closed_2429);
                v_t_2438 = NTAG(TAG_Nothing);
              } else {
                heff_drop(v_closed_2429);
                v_t_2438 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_2422), heff_dup(v_i_2425), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str6)})});
              }
              V v_t_2439 = heff_rec_n(3, shape_start__end__text, (V[]){heff_dup(v_i_2422), heff_dup(v_i_2425), heff_strSlice_lent(v_src_2421, v_i_2422, v_i_2425, 3)});
              return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_i_2425, v_line_2426, v_t_2437, v_first_2428, NTAG(TAG_Nothing), v_t_2438, heff_tag_n(TAG_Just, 1, (V[]){v_t_2439})});
            } else {
              if (((v_c_246 == ((int64_t)98ULL)) && (heff_unbox_word(heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) == ((int64_t)91ULL)))) {
                heff_drop(v_src_240);
                heff_drop(v_toks_245);
                V v_end_2440 = heff_intAdd(heff_dup(v_i_241), MK_INT(2LL));
                V v_col_2441 = heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243));
                V v_t_2442 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str7), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str8), heff_dup(v_i_241), v_end_2440, heff_dup(v_line_242), v_col_2441, v_first_244})});
                return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(2LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), v_t_2442, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
              } else {
                if (((((((int64_t)97ULL) <= v_c_246) && (v_c_246 <= ((int64_t)122ULL))) || (v_c_246 == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= v_c_246) && (v_c_246 <= ((int64_t)90ULL))))) {
                  heff_drop(v_toks_245);
                  V v_src_2443 = heff_dup(v_src_240);
                  V v_i_2444 = heff_dup(v_i_241);
                  V v_line_2445 = v_line_242;
                  V v_lineStart_2446 = v_lineStart_243;
                  V v_first_2447 = v_first_244;
                  V v_j_2448 = ({ V a_0 = v_src_240; V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2efmt_2elex_2enameEnd(a_0, a_1)); heff_drop(v_src_240); r_; });
                  V v_c_2449 = heff_strByteAt_lent(v_src_2443, v_i_2444, 0);
                  V v_t_2450 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_strSlice_lent(v_src_2443, v_i_2444, v_j_2448, 0)}));
                  V v_t_2451 = ({ V a_0 = v_t_2450; V b_1 = heff_dup(g_heff_2esyntax_2efmt_2elex_2ekeywords_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
                  V v_kind_2452;
                  if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
                    heff_drop(v_c_2449);
                    heff_drop(v_t_2451);
                    v_kind_2452 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str9);
                  } else {
                    heff_drop(v_t_2451);
                    if (((((int64_t)65ULL) <= heff_peek_word(v_c_2449)) && (heff_peek_word(v_c_2449) <= ((int64_t)90ULL)))) {
                      heff_drop(v_c_2449);
                      v_kind_2452 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str10);
                    } else {
                      heff_drop(v_c_2449);
                      v_kind_2452 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str11);
                    }
                  }
                  V v_col_2453 = heff_intSub(heff_dup(v_i_2444), heff_dup(v_lineStart_2446));
                  V v_t_2454 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){v_kind_2452, heff_strSlice_lent(v_src_2443, v_i_2444, v_j_2448, 1), v_i_2444, heff_dup(v_j_2448), heff_dup(v_line_2445), v_col_2453, v_first_2447});
                  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_j_2448, v_line_2445, v_lineStart_2446, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2454}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                } else {
                  V v_t_2479;
                  if ((v_c_246 == ((int64_t)46ULL))) {
                    V v_c_2455 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                    if (((((((int64_t)97ULL) <= heff_peek_word(v_c_2455)) && (heff_peek_word(v_c_2455) <= ((int64_t)122ULL))) || (heff_peek_word(v_c_2455) == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_2455)) && (heff_peek_word(v_c_2455) <= ((int64_t)90ULL))))) {
                      heff_drop(v_c_2455);
                      V v_x1_2456 = heff_dup(v_toks_245);
                      V v_start_2457 = heff_dup(v_i_241);
                      switch (heff_tag_of(v_x1_2456)) {
                      case TAG_Nil: {
                        heff_drop(v_start_2457);
                        v_t_2479 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_Cons: {
                        V v_t_2458 = heff_field(v_x1_2456, 0);
                        V v_rest_2459 = heff_field(v_x1_2456, 1);
                        heff_take_n(v_x1_2456, 3ULL, 2);
                        V v_lit_2460 = heff_dup(v_t_2458);
                        V v_end_2461 = heff_take_field(v_lit_2460, 3);
                        V v_kind_2462 = heff_take_field(v_lit_2460, 0);
                        V v_text_2463 = heff_get_n(v_lit_2460, 1, 7);
                        V v_lit_2464 = v_rest_2459;
                        heff_drop(v_lit_2464);
                        V v_start_2465 = heff_dup(v_start_2457);
                        V v_t_2477;
                        if (heff_intEq_c(v_end_2461, v_start_2465)) {
                          V v_p_2466 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_kind_2462)}));
                          V v_t_2467 = heff_tr(heff_call(heff_dup(v_p_2466), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str12)}));
                          if ((heff_dup(v_t_2467) == NTAG(TAG_True))) {
                            heff_drop(v_kind_2462);
                            heff_drop(v_text_2463);
                            heff_drop(v_p_2466);
                            heff_drop(v_t_2467);
                            v_t_2477 = NTAG(TAG_True);
                          } else {
                            heff_drop(v_t_2467);
                            V v_t_2468 = heff_tr(heff_call(heff_dup(v_p_2466), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str13)}));
                            if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
                              heff_drop(v_kind_2462);
                              heff_drop(v_text_2463);
                              heff_drop(v_p_2466);
                              heff_drop(v_t_2468);
                              v_t_2477 = NTAG(TAG_True);
                            } else {
                              heff_drop(v_t_2468);
                              V v_t_2469 = heff_tr(heff_call(heff_dup(v_p_2466), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str14)}));
                              if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
                                heff_drop(v_kind_2462);
                                heff_drop(v_text_2463);
                                heff_drop(v_p_2466);
                                heff_drop(v_t_2469);
                                v_t_2477 = NTAG(TAG_True);
                              } else {
                                heff_drop(v_t_2469);
                                V v_t_2470 = heff_tr(heff_call(heff_dup(v_p_2466), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str15)}));
                                if ((heff_dup(v_t_2470) == NTAG(TAG_True))) {
                                  heff_drop(v_kind_2462);
                                  heff_drop(v_text_2463);
                                  heff_drop(v_p_2466);
                                  heff_drop(v_t_2470);
                                  v_t_2477 = NTAG(TAG_True);
                                } else {
                                  heff_drop(v_t_2470);
                                  V v_t_2471 = heff_tr(heff_call(heff_dup(v_p_2466), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str16)}));
                                  if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
                                    heff_drop(v_kind_2462);
                                    heff_drop(v_text_2463);
                                    heff_drop(v_p_2466);
                                    heff_drop(v_t_2471);
                                    v_t_2477 = NTAG(TAG_True);
                                  } else {
                                    heff_drop(v_t_2471);
                                    V v_t_2472 = heff_tr(heff_call(heff_dup(v_p_2466), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str17)}));
                                    if ((heff_dup(v_t_2472) == NTAG(TAG_True))) {
                                      heff_drop(v_kind_2462);
                                      heff_drop(v_text_2463);
                                      heff_drop(v_p_2466);
                                      heff_drop(v_t_2472);
                                      v_t_2477 = NTAG(TAG_True);
                                    } else {
                                      heff_drop(v_t_2472);
                                      V v_t_2473 = heff_tr(heff_call(v_p_2466, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str18)}));
                                      if ((heff_dup(v_t_2473) == NTAG(TAG_True))) {
                                        heff_drop(v_kind_2462);
                                        heff_drop(v_text_2463);
                                        heff_drop(v_t_2473);
                                        v_t_2477 = NTAG(TAG_True);
                                      } else {
                                        heff_drop(v_t_2473);
                                        if (heff_strEq_c(v_kind_2462, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str19))) {
                                          V v_p_2474 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_text_2463}));
                                          V v_t_2475 = heff_tr(heff_call(heff_dup(v_p_2474), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str20)}));
                                          if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
                                            heff_drop(v_p_2474);
                                            heff_drop(v_t_2475);
                                            v_t_2477 = NTAG(TAG_True);
                                          } else {
                                            heff_drop(v_t_2475);
                                            V v_t_2476 = heff_tr(heff_call(heff_dup(v_p_2474), 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str21)}));
                                            if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
                                              heff_drop(v_p_2474);
                                              heff_drop(v_t_2476);
                                              v_t_2477 = NTAG(TAG_True);
                                            } else {
                                              heff_drop(v_t_2476);
                                              v_t_2477 = heff_tr(heff_call(v_p_2474, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str22)}));
                                            }
                                          }
                                        } else {
                                          heff_drop(v_text_2463);
                                          v_t_2477 = NTAG(TAG_False);
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        } else {
                          heff_drop(v_kind_2462);
                          heff_drop(v_text_2463);
                          v_t_2477 = NTAG(TAG_False);
                        }
                        if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
                          heff_drop(v_start_2457);
                          heff_drop_rec(v_t_2458, 7);
                          heff_drop(v_t_2477);
                          v_t_2479 = NTAG(TAG_True);
                        } else {
                          heff_drop(v_t_2477);
                          if (heff_intEq_c(heff_dup(heff_rfield(v_t_2458, 3)), v_start_2457)) {
                            if (heff_strEq_c(heff_dup(heff_rfield(v_t_2458, 0)), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str23))) {
                              V v_c_2478 = heff_strByteAt(heff_get_n(v_t_2458, 1, 7), MK_INT(0LL));
                              v_t_2479 = heff_bool(((((int64_t)65ULL) <= heff_peek_word(v_c_2478)) && (heff_peek_word(v_c_2478) <= ((int64_t)90ULL))));
                              heff_drop(v_c_2478);
                            } else {
                              heff_drop_rec(v_t_2458, 7);
                              v_t_2479 = NTAG(TAG_False);
                            }
                          } else {
                            heff_drop_rec(v_t_2458, 7);
                            v_t_2479 = NTAG(TAG_False);
                          }
                        }
                        break;
                      }
                      default: heff_nomatch(v_x1_2456);
                      }
                    } else {
                      heff_drop(v_c_2455);
                      v_t_2479 = NTAG(TAG_False);
                    }
                  } else {
                    v_t_2479 = NTAG(TAG_False);
                  }
                  if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
                    heff_drop(v_toks_245);
                    heff_drop(v_t_2479);
                    V v_j_2480 = (g_heff_2esyntax_2efmt_2elex_2eplainEnd(v_src_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
                    V v_col_2481 = heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243));
                    V v_t_2482 = heff_strSlice(v_src_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_j_2480));
                    V v_t_2483 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str24), v_t_2482, v_i_241, heff_dup(v_j_2480), heff_dup(v_line_242), v_col_2481, v_first_244});
                    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_j_2480, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2483}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                  } else {
                    heff_drop(v_t_2479);
                    V v_t_2486;
                    if (((((int64_t)48ULL) <= v_c_246) && (v_c_246 <= ((int64_t)57ULL)))) {
                      v_t_2486 = NTAG(TAG_True);
                    } else {
                      if ((v_c_246 == ((int64_t)45ULL))) {
                        V v_c_2484 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                        if (((((int64_t)48ULL) <= heff_peek_word(v_c_2484)) && (heff_peek_word(v_c_2484) <= ((int64_t)57ULL)))) {
                          heff_drop(v_c_2484);
                          V v_x1_2485 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(heff_dup(v_toks_245), heff_dup(v_i_241)));
                          v_t_2486 = heff_bool(!(heff_dup(v_x1_2485) == NTAG(TAG_True)));
                          heff_drop(v_x1_2485);
                        } else {
                          heff_drop(v_c_2484);
                          v_t_2486 = NTAG(TAG_False);
                        }
                      } else {
                        v_t_2486 = NTAG(TAG_False);
                      }
                    }
                    if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
                      heff_drop(v_toks_245);
                      heff_drop(v_t_2486);
                      V v_src_2487 = heff_dup(v_src_240);
                      V v_i_2488 = heff_dup(v_i_241);
                      V v_line_2489 = v_line_242;
                      V v_lineStart_2490 = v_lineStart_243;
                      V v_first_2491 = v_first_244;
                      V v_r_2492;
                      if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)45ULL))) {
                        v_r_2492 = (g_heff_2esyntax_2efmt_2elex_2enumFrom(v_src_240, heff_intAdd(v_i_241, MK_INT(1LL))));
                      } else {
                        v_r_2492 = (g_heff_2esyntax_2efmt_2elex_2enumFrom(v_src_240, v_i_241));
                      }
                      V v_isFloat_2493 = heff_take_field(v_r_2492, 1);
                      V v_end_2494 = heff_get_n(v_r_2492, 0, 2);
                      V v_col_2495 = heff_intSub(heff_dup(v_i_2488), heff_dup(v_lineStart_2490));
                      V v_t_2496;
                      if ((heff_dup(v_isFloat_2493) == NTAG(TAG_True))) {
                        heff_drop(v_isFloat_2493);
                        v_t_2496 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str25);
                      } else {
                        heff_drop(v_isFloat_2493);
                        v_t_2496 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str26);
                      }
                      V v_t_2497 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){v_t_2496, heff_strSlice_lent(v_src_2487, v_i_2488, v_end_2494, 1), v_i_2488, heff_dup(v_end_2494), heff_dup(v_line_2489), v_col_2495, v_first_2491});
                      return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_end_2494, v_line_2489, v_lineStart_2490, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2497}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                    } else {
                      heff_drop(v_t_2486);
                      V v_t_24100;
                      if ((v_c_246 == ((int64_t)45ULL))) {
                        V v_c_2498 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                        if ((((((((int64_t)97ULL) <= heff_peek_word(v_c_2498)) && (heff_peek_word(v_c_2498) <= ((int64_t)122ULL))) || (heff_peek_word(v_c_2498) == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_2498)) && (heff_peek_word(v_c_2498) <= ((int64_t)90ULL)))) || (heff_peek_word(v_c_2498) == ((int64_t)40ULL)))) {
                          heff_drop(v_c_2498);
                          V v_x1_2499 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(heff_dup(v_toks_245), heff_dup(v_i_241)));
                          v_t_24100 = heff_bool(!(heff_dup(v_x1_2499) == NTAG(TAG_True)));
                          heff_drop(v_x1_2499);
                        } else {
                          heff_drop(v_c_2498);
                          v_t_24100 = NTAG(TAG_False);
                        }
                      } else {
                        v_t_24100 = NTAG(TAG_False);
                      }
                      if ((heff_dup(v_t_24100) == NTAG(TAG_True))) {
                        heff_drop(v_src_240);
                        heff_drop(v_toks_245);
                        heff_drop(v_t_24100);
                        V v_end_24101 = heff_intAdd(heff_dup(v_i_241), MK_INT(1LL));
                        V v_col_24102 = heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243));
                        V v_t_24103 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str27), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str28), heff_dup(v_i_241), v_end_24101, heff_dup(v_line_242), v_col_24102, v_first_244})});
                        return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), v_t_24103, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                      } else {
                        heff_drop(v_t_24100);
                        V v_t_24106;
                        if ((v_c_246 == ((int64_t)126ULL))) {
                          V v_t_24104 = (g_heff_2esyntax_2efmt_2elex_2estartsDelayed(v_src_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
                          if ((heff_dup(v_t_24104) == NTAG(TAG_True))) {
                            heff_drop(v_t_24104);
                            V v_x1_24105 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(v_toks_245, heff_dup(v_i_241)));
                            v_t_24106 = heff_bool(!(heff_dup(v_x1_24105) == NTAG(TAG_True)));
                            heff_drop(v_x1_24105);
                          } else {
                            heff_drop(v_toks_245);
                            heff_drop(v_t_24104);
                            v_t_24106 = NTAG(TAG_False);
                          }
                        } else {
                          heff_drop(v_toks_245);
                          v_t_24106 = NTAG(TAG_False);
                        }
                        if ((heff_dup(v_t_24106) == NTAG(TAG_True))) {
                          heff_drop(v_src_240);
                          heff_drop(v_t_24106);
                          V v_end_24107 = heff_intAdd(heff_dup(v_i_241), MK_INT(1LL));
                          V v_col_24108 = heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243));
                          V v_t_24109 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str29), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str30), heff_dup(v_i_241), v_end_24107, heff_dup(v_line_242), v_col_24108, v_first_244})});
                          return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), v_t_24109, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                        } else {
                          heff_drop(v_t_24106);
                          if ((v_c_246 == ((int64_t)34ULL))) {
                            V v_src_24110 = heff_dup(v_src_240);
                            V v_i_24111 = heff_dup(v_i_241);
                            V v_line_24112 = v_line_242;
                            V v_lineStart_24113 = v_lineStart_243;
                            V v_first_24114 = v_first_244;
                            HeffT4 v_t_24115 = (g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr(v_src_240, heff_intAdd(v_i_241, MK_INT(1LL)), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str31), NTAG(TAG_Nothing)));
                            {
                              V v_field_24116 = v_t_24115.f[0];
                              V v_field_24117 = v_t_24115.f[1];
                              V v_field_24118 = v_t_24115.f[2];
                              V v_field_24119 = v_t_24115.f[3];
                              V v_t_24120;
                              if ((heff_dup(v_field_24118) == NTAG(TAG_True))) {
                                v_t_24120 = heff_intAdd(heff_dup(v_field_24116), MK_INT(1LL));
                              } else {
                                v_t_24120 = heff_dup(v_field_24116);
                              }
                              V v_j_24121;
                              if ((heff_dup(v_field_24118) == NTAG(TAG_True))) {
                                v_j_24121 = heff_intAdd(heff_dup(v_field_24116), MK_INT(1LL));
                              } else {
                                v_j_24121 = heff_dup(v_field_24116);
                              }
                              V v_t_24122 = heff_intAdd(heff_dup(v_lineStart_24113), heff_intSub(heff_dup(v_j_24121), heff_dup(v_i_24111)));
                              V v_t_24123 = ({ V a_0 = v_src_24110; V a_1 = heff_dup(v_i_24111); V a_2 = v_j_24121; V a_3 = MK_INT(0LL); V r_ = (g_heff_2eutil_2erune_2erunesGo(a_0, a_1, a_2, a_3)); heff_drop(v_src_24110); r_; });
                              V v_end_24124;
                              if ((heff_dup(v_field_24118) == NTAG(TAG_True))) {
                                v_end_24124 = heff_intAdd(heff_dup(v_field_24116), MK_INT(1LL));
                              } else {
                                v_end_24124 = heff_dup(v_field_24116);
                              }
                              V v_col_24125 = heff_intSub(heff_dup(v_i_24111), v_lineStart_24113);
                              V v_t_24126 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str32), v_field_24117, heff_dup(v_i_24111), v_end_24124, heff_dup(v_line_24112), v_col_24125, v_first_24114})});
                              V v_t_24127;
                              if ((heff_dup(v_field_24118) == NTAG(TAG_True))) {
                                heff_drop(v_i_24111);
                                heff_drop(v_field_24116);
                                heff_drop(v_field_24118);
                                v_t_24127 = v_field_24119;
                              } else {
                                heff_drop(v_field_24118);
                                heff_drop(v_field_24119);
                                v_t_24127 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_start__end__msg, (V[]){v_i_24111, v_field_24116, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str33)})});
                              }
                              return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_t_24120, v_line_24112, heff_intSub(v_t_24122, v_t_24123), NTAG(TAG_False), v_t_24126, v_t_24127, NTAG(TAG_Nothing)});
                            }
                          } else {
                            if (((((int64_t)0ULL) <= v_c_246) && ({ V v_t_24128 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_c_246)))); int c_ = ({ V v_t_24151 = heff_strFind_lent(v_t_24128, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str34), MK_INT(0LL), 6); int c_ = heff_intLe_c_lent(MK_INT(0LL), v_t_24151, 1); heff_drop(v_t_24151); c_; }); heff_drop(v_t_24128); c_; }))) {
                              V v_t_24129 = heff_strSlice(v_src_240, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                              V v_t_24130 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str35), v_t_24129, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
                              return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_24130}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                            } else {
                              if (((((int64_t)0ULL) <= v_c_246) && ({ V v_t_24131 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_c_246)))); int c_ = ({ V v_t_24152 = heff_strFind(heff_dup(v_t_24131), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)); int c_ = heff_intLe_c_lent(MK_INT(0LL), v_t_24152, 1); heff_drop(v_t_24152); c_; }); heff_drop(v_t_24131); c_; }))) {
                                V v_j_24132 = (g_heff_2esyntax_2efmt_2elex_2esymEnd(v_src_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
                                V v_col_24133 = heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243));
                                V v_t_24134 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str36), heff_strSlice_lent(v_src_240, v_i_241, v_j_24132, 1), v_i_241, heff_dup(v_j_24132), heff_dup(v_line_242), v_col_24133, v_first_244});
                                return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_j_24132, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_24134}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                              } else {
                                if ((v_c_246 == ((int64_t)39ULL))) {
                                  V v_src_24135 = heff_dup(v_src_240);
                                  V v_i_24136 = heff_dup(v_i_241);
                                  V v_line_24137 = v_line_242;
                                  V v_lineStart_24138 = v_lineStart_243;
                                  V v_first_24139 = v_first_244;
                                  V v_r_24140 = (g_heff_2esyntax_2efmt_2elex_2eruneScan(v_src_240, v_i_241));
                                  V v_t_24141 = heff_dup(heff_rfield(v_r_24140, 0));
                                  if ((heff_dup(v_t_24141) == NTAG(TAG_True))) {
                                    heff_drop(v_t_24141);
                                    return ({ V a_0 = v_src_24135; V a_1 = v_i_24136; V a_2 = v_line_24137; V a_3 = v_lineStart_24138; V a_4 = v_first_24139; V a_5 = v_r_24140; V r_ = (g_heff_2esyntax_2efmt_2elex_2eruneStep(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_src_24135); r_; });
                                  } else {
                                    heff_drop_rec(v_r_24140, 3);
                                    heff_drop(v_t_24141);
                                    V v_w_24142 = heff_strRuneWidth_lent(v_src_24135, v_i_24136, 0);
                                    V v_t_24143 = heff_intSub(heff_intAdd(v_lineStart_24138, heff_dup(v_w_24142)), MK_INT(1LL));
                                    V v_t_24144 = heff_strSlice(v_src_24135, heff_dup(v_i_24136), heff_intAdd(heff_dup(v_i_24136), heff_dup(v_w_24142)));
                                    V v_t_24145 = heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_24136), heff_intAdd(heff_dup(v_i_24136), heff_dup(v_w_24142)), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str37), v_t_24144)});
                                    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_24136, v_w_24142), v_line_24137, v_t_24143, v_first_24139, NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_24145}), NTAG(TAG_Nothing)});
                                  }
                                } else {
                                  V v_w_24146 = heff_strRuneWidth_lent(v_src_240, v_i_241, 0);
                                  V v_t_24147 = heff_intSub(heff_intAdd(v_lineStart_243, heff_dup(v_w_24146)), MK_INT(1LL));
                                  V v_t_24148 = heff_strSlice(v_src_240, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_24146)));
                                  V v_t_24149 = heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_24146)), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str38), v_t_24148)});
                                  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, v_w_24146), v_line_242, v_t_24147, v_first_244, NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_24149}), NTAG(TAG_Nothing)});
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2estepAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2estepAt(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr_str1, 0, "");

HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V v_src_240, V v_st_241, V v_toks_242, V v_errs_243, V v_cmts_244) {
top: ;
  V v_i_245 = heff_take_field(v_st_241, 0);
  V v_line_246 = heff_take_field(v_st_241, 1);
  V v_tok_247 = heff_take_field(v_st_241, 4);
  V v_err_248 = heff_take_field(v_st_241, 5);
  V v_cmt_249 = heff_take_field(v_st_241, 6);
  V v_lineStart_2410 = heff_take_field(v_st_241, 2);
  V v_first_2411 = heff_get_n(v_st_241, 3, 7);
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_245))) {
    heff_drop(v_i_245);
    heff_drop(v_lineStart_2410);
    heff_drop(v_first_2411);
    V v_end_2412 = heff_strLength_lent(v_src_240, 0);
    V v_t_2413 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr_str0), ((V)&g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr_str1), heff_strLength(v_src_240), v_end_2412, heff_intAdd(v_line_246, MK_INT(1LL)), MK_INT(0LL), NTAG(TAG_True)});
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    V v_t_2416;
    switch (heff_tag_of(v_tok_247)) {
    case TAG_Nothing: {
      v_t_2416 = v_toks_242;
      break;
    }
    case TAG_Just: {
      V v_x_2415 = heff_field(v_tok_247, 0);
      heff_take_n(v_tok_247, 1ULL, 1);
      v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_toks_242});
      break;
    }
    default: heff_nomatch(v_tok_247);
    }
    V v_f_2417 = (g_list_2efoldl_24s1370882877x364361272(v_t_2414, v_t_2416));
    V v_t_2419;
    switch (heff_tag_of(v_err_248)) {
    case TAG_Nothing: {
      v_t_2419 = v_errs_243;
      break;
    }
    case TAG_Just: {
      V v_x_2418 = heff_field(v_err_248, 0);
      heff_take_n(v_err_248, 1ULL, 1);
      v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2418, v_errs_243});
      break;
    }
    default: heff_nomatch(v_err_248);
    }
    V v_f_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2419));
    V v_t_2422;
    switch (heff_tag_of(v_cmt_249)) {
    case TAG_Nothing: {
      v_t_2422 = v_cmts_244;
      break;
    }
    case TAG_Just: {
      V v_x_2421 = heff_field(v_cmt_249, 0);
      heff_take_n(v_cmt_249, 1ULL, 1);
      v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2421, v_cmts_244});
      break;
    }
    default: heff_nomatch(v_cmt_249);
    }
    V v_f_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2422));
    return ((HeffT3){{v_f_2417, v_f_2420, v_f_2423}});
  } else {
    V v_i_2424 = v_i_245;
    V v_lineStart_2425 = v_lineStart_2410;
    V v_first_2426 = v_first_2411;
    V v_toks_2428;
    switch (heff_tag_of(v_tok_247)) {
    case TAG_Nothing: {
      v_toks_2428 = heff_dup(v_toks_242);
      break;
    }
    case TAG_Just: {
      V v_x_2427 = heff_dup(heff_field(v_tok_247, 0));
      v_toks_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2427, heff_dup(v_toks_242)});
      break;
    }
    default: heff_nomatch(v_tok_247);
    }
    V v_t_2429 = (g_heff_2esyntax_2efmt_2elex_2estepAt(heff_dup(v_src_240), heff_dup(v_i_2424), v_line_246, v_lineStart_2425, v_first_2426, v_toks_2428, heff_strByteAt_lent(v_src_240, v_i_2424, 2)));
    V v_t_2431;
    switch (heff_tag_of(v_tok_247)) {
    case TAG_Nothing: {
      v_t_2431 = v_toks_242;
      break;
    }
    case TAG_Just: {
      V v_x_2430 = heff_field(v_tok_247, 0);
      heff_take_n(v_tok_247, 1ULL, 1);
      v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2430, v_toks_242});
      break;
    }
    default: heff_nomatch(v_tok_247);
    }
    V v_t_2433;
    switch (heff_tag_of(v_err_248)) {
    case TAG_Nothing: {
      v_t_2433 = v_errs_243;
      break;
    }
    case TAG_Just: {
      V v_x_2432 = heff_field(v_err_248, 0);
      heff_take_n(v_err_248, 1ULL, 1);
      v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2432, v_errs_243});
      break;
    }
    default: heff_nomatch(v_err_248);
    }
    V v_t_2435;
    switch (heff_tag_of(v_cmt_249)) {
    case TAG_Nothing: {
      v_t_2435 = v_cmts_244;
      break;
    }
    case TAG_Just: {
      V v_x_2434 = heff_field(v_cmt_249, 0);
      heff_take_n(v_cmt_249, 1ULL, 1);
      v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2434, v_cmts_244});
      break;
    }
    default: heff_nomatch(v_cmt_249);
    }
    V t_0 = v_src_240;
    V t_1 = v_t_2429;
    V t_2 = v_t_2431;
    V t_3 = v_t_2433;
    V t_4 = v_t_2435;
    v_src_240 = t_0;
    v_st_241 = t_1;
    v_toks_242 = t_2;
    v_errs_243 = t_3;
    v_cmts_244 = t_4;
    goto top;
  }
}
Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2elexGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elex_2elexGo(V v_src_240, V v_st_241, V v_toks_242, V v_errs_243, V v_cmts_244) {
top: ;
  HeffT3 v_t_245 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_st_241, v_toks_242, v_errs_243, v_cmts_244));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_field_248 = v_t_245.f[2];
    return heff_rec_n(3, shape_tokens__errors__comments, (V[]){v_field_246, v_field_247, v_field_248});
  }
}
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2elexGo(a[0], a[1], a[2], a[3], a[4]);
}