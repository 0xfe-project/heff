// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_bad 306815
#define LBL_closed 589621399
#define LBL_cmt 308164
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_comments 142722952
#define LBL_end 310101
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_i 323
#define LBL_isFloat 143306131
#define LBL_kind 9787483
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_msg 317947
#define LBL_ok 10307
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
static uint32_t shape_end__isFloat[] = {LBL_end, LBL_isFloat};
static uint32_t shape_i__line__lineStart__first__closed[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_closed};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_i__text__closed__bad[] = {LBL_i, LBL_text, LBL_closed, LBL_bad};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_ok__end__code[] = {LBL_ok, LBL_end, LBL_code};
static uint32_t shape_start__end__msg[] = {LBL_start, LBL_end, LBL_msg};
static uint32_t shape_start__end__text[] = {LBL_start, LBL_end, LBL_text};
static uint32_t shape_tokens__errors__comments[] = {LBL_tokens, LBL_errors, LBL_comments};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2efmt_2elex_2ebadEsc(V, V, V);
V g_heff_2esyntax_2efmt_2elex_2ebadEsc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2ebadEsc_clo;
V g_heff_2esyntax_2efmt_2elex_2eblockCmtStep(V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_clo;
V g_heff_2esyntax_2efmt_2elex_2eblockScan(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eblockScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eblockScan_clo;
V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_clo;
V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2eescAt(V, V);
V g_heff_2esyntax_2efmt_2elex_2eescAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eescAt_clo;
V g_heff_2esyntax_2efmt_2elex_2efieldBefore(V, V);
V g_heff_2esyntax_2efmt_2elex_2efieldBefore_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2efieldBefore_clo;
V g_heff_2esyntax_2efmt_2elex_2ehexDigitValue(V);
V g_heff_2esyntax_2efmt_2elex_2ehexDigitValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2ehexDigitValue_clo;
V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2ehexValue(V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2ehexValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2ehexValue_clo;
V g_heff_2esyntax_2efmt_2elex_2eisHexC(V);
V g_heff_2esyntax_2efmt_2elex_2eisHexC_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eisHexC_clo;
V g_heff_2esyntax_2efmt_2elex_2eisNameC(V);
V g_heff_2esyntax_2efmt_2elex_2eisNameC_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eisNameC_clo;
V g_heff_2esyntax_2efmt_2elex_2ekeywords_get(void);
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2efmt_2elex_2enameEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2enameEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enameEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2enameStep(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2enameStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enameStep_clo;
V g_heff_2esyntax_2efmt_2elex_2enoCode_get(void);
V g_heff_2esyntax_2efmt_2elex_2enumExp(V, V);
V g_heff_2esyntax_2efmt_2elex_2enumExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enumExp_clo;
V g_heff_2esyntax_2efmt_2elex_2enumFrac(V, V);
V g_heff_2esyntax_2efmt_2elex_2enumFrac_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enumFrac_clo;
V g_heff_2esyntax_2efmt_2elex_2enumFrom(V, V);
V g_heff_2esyntax_2efmt_2elex_2enumFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enumFrom_clo;
V g_heff_2esyntax_2efmt_2elex_2eoperandBefore(V, V);
V g_heff_2esyntax_2efmt_2elex_2eoperandBefore_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eoperandBefore_clo;
V g_heff_2esyntax_2efmt_2elex_2eplainEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eplainEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eplainEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2equoteStep(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2equoteStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2equoteStep_clo;
V g_heff_2esyntax_2efmt_2elex_2equotedStep(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2equotedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2equotedStep_clo;
V g_heff_2esyntax_2efmt_2elex_2eruneScan(V, V);
V g_heff_2esyntax_2efmt_2elex_2eruneScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eruneScan_clo;
V g_heff_2esyntax_2efmt_2elex_2eruneStep(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eruneStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eruneStep_clo;
V g_heff_2esyntax_2efmt_2elex_2estartsNegated(V);
V g_heff_2esyntax_2efmt_2elex_2estartsNegated_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2estartsNegated_clo;
V g_heff_2esyntax_2efmt_2elex_2estepAt(V, V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2estepAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2estepAt_clo;
V g_heff_2esyntax_2efmt_2elex_2estrScan(V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2estrScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2estrScan_clo;
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void);
V g_heff_2esyntax_2efmt_2elex_2esymEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2esymEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2esymEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2euniEsc(V, V, V);
V g_heff_2esyntax_2efmt_2elex_2euniEsc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2euniEsc_clo;
V g_heff_2eutil_2erune_2eencode(V);
V g_heff_2eutil_2erune_2eencode_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2eencode_clo;
V g_heff_2eutil_2erune_2ehexWith(V, V);
V g_heff_2eutil_2erune_2ehexWith_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ehexWith_clo;
V g_heff_2eutil_2erune_2epadTo4(V);
V g_heff_2eutil_2erune_2epadTo4_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2epadTo4_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str0, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str1, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str2, 6, "infixr");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str3, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str4, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str5, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str6, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str7, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str8, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str9, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str10, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str11, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str12, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str13, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str14, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str15, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str16, 6, "String");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str17, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str18, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str19, 2, "in");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str20, 4, "test");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str21, 5, "where");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str22, 3, "let");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str23, 4, "else");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str24, 2, "do");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str25, 2, "if");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str26, 4, "then");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str27, 4, "case");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str28, 2, "of");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str29, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str30, 6, "import");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str31, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str32, 9, "primitive");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str33, 4, "data");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str34, 4, "type");

static V g_heff_2esyntax_2efmt_2elex_2ekeywords_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elex_2ekeywords_st;
static V g_heff_2esyntax_2efmt_2elex_2ekeywords_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str10), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str12), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str14), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str16), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str18), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str20), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str22), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str23), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str24), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str25), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str26), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str27), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str28), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str29), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str30), v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str31), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str32), v_t_2415})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str33), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str34), v_t_2416})});
}
V g_heff_2esyntax_2efmt_2elex_2ekeywords_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elex_2ekeywords_st)) return g_heff_2esyntax_2efmt_2elex_2ekeywords_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elex_2ekeywords_val, &g_heff_2esyntax_2efmt_2elex_2ekeywords_st, g_heff_2esyntax_2efmt_2elex_2ekeywords_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2esymChars_str0, 20, "!#$%&*+./<=>\?@\\^|-~:");

static V g_heff_2esyntax_2efmt_2elex_2esymChars_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elex_2esymChars_st;
static V g_heff_2esyntax_2efmt_2elex_2esymChars_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elex_2esymChars_str0);
}
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elex_2esymChars_st)) return g_heff_2esyntax_2efmt_2elex_2esymChars_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elex_2esymChars_val, &g_heff_2esyntax_2efmt_2elex_2esymChars_st, g_heff_2esyntax_2efmt_2elex_2esymChars_init);
}
Clo g_heff_2esyntax_2efmt_2elex_2eisNameC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eisNameC_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elex_2eisNameC(V v_c_240) {
top: ;
  V v_t_243 = heff_bool((heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(122LL)) || heff_intEq_c(heff_dup(v_c_240), MK_INT(95LL))) : heff_intEq_c(heff_dup(v_c_240), MK_INT(95LL))));
  V v_ret_24bool = heff_bool(((heff_dup(v_t_243) == NTAG(TAG_True)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)) || heff_intEq_c(heff_dup(v_c_240), MK_INT(39LL))) : heff_intEq_c(heff_dup(v_c_240), MK_INT(39LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)) || heff_intEq_c(heff_dup(v_c_240), MK_INT(39LL))) : heff_intEq_c(heff_dup(v_c_240), MK_INT(39LL))))));
  heff_drop(v_c_240);
  heff_drop(v_t_243);
  return v_ret_24bool;
}
V g_heff_2esyntax_2efmt_2elex_2eisNameC_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eisNameC(a[0]);
}
Clo g_heff_2esyntax_2efmt_2elex_2enameEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enameEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enameEnd(V v_s_240, V v_j_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2efmt_2elex_2eisNameC(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241))));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_t_242);
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(47LL))) {
      V v_c_244 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      V v_t_247 = heff_bool((heff_intLe_c(MK_INT(97LL), heff_dup(v_c_244)) ? (heff_intLe_c(heff_dup(v_c_244), MK_INT(122LL)) || heff_intEq_c(heff_dup(v_c_244), MK_INT(95LL))) : heff_intEq_c(heff_dup(v_c_244), MK_INT(95LL))));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_c_244);
        heff_drop(v_t_247);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_247);
        if (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_244))) {
          if (heff_intLe_c(v_c_244, MK_INT(90LL))) {
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
            v_s_240 = t_0;
            v_j_241 = t_1;
            goto top;
          } else {
            heff_drop(v_s_240);
            return v_j_241;
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_c_244);
          return v_j_241;
        }
      }
    } else {
      heff_drop(v_s_240);
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2enameEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2enameEnd(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2eplainEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eplainEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eplainEnd(V v_s_240, V v_j_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2efmt_2elex_2eisNameC(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241))));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_s_240);
    heff_drop(v_t_242);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2eplainEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eplainEnd(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241));
  if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_242))) {
    if (heff_intLe_c(v_c_242, MK_INT(57LL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_j_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(95LL))) {
        V v_c_246 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
        if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_246))) {
          if (heff_intLe_c(v_c_246, MK_INT(57LL))) {
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
            v_s_240 = t_0;
            v_j_241 = t_1;
            goto top;
          } else {
            heff_drop(v_s_240);
            return v_j_241;
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_c_246);
          return v_j_241;
        }
      } else {
        heff_drop(v_s_240);
        return v_j_241;
      }
    }
  } else {
    heff_drop(v_c_242);
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(95LL))) {
      V v_c_2410 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_2410))) {
        if (heff_intLe_c(v_c_2410, MK_INT(57LL))) {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
          v_s_240 = t_0;
          v_j_241 = t_1;
          goto top;
        } else {
          heff_drop(v_s_240);
          return v_j_241;
        }
      } else {
        heff_drop(v_s_240);
        heff_drop(v_c_2410);
        return v_j_241;
      }
    } else {
      heff_drop(v_s_240);
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2eisHexC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eisHexC_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elex_2eisHexC(V v_c_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)) || (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(102LL)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(70LL)))) : (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(70LL))))) : (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(102LL)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(70LL)))) : (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(70LL))))));
  heff_drop(v_c_240);
  return v_ret_24bool;
}
V g_heff_2esyntax_2efmt_2elex_2eisHexC_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eisHexC(a[0]);
}
Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V v_s_240, V v_j_241) {
top: ;
  if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(45LL))) {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_s_240);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2edashesEnd(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V v_s_240, V v_j_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_j_241), heff_strLength(heff_dup(v_s_240)))) {
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(10LL))) {
      heff_drop(v_s_240);
      return v_j_241;
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_j_241 = t_1;
      goto top;
    }
  } else {
    heff_drop(v_s_240);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eeolEnd(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2esymEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2esymEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2esymEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241));
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_242))) {
    V v_t_244 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_c_242)));
    V v_x3_245 = (g_prelude_2eindexFrom(v_t_244, heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_s_240);
      return v_j_241;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      V v_x1_249 = heff_bool((heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(45LL)) && ({ V v_t_248 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL))); int c_ = heff_intEq_c(heff_dup(v_t_248), MK_INT(45LL)); heff_drop(v_t_248); c_; })));
      if ((heff_dup(v_x1_249) == NTAG(TAG_True))) {
        heff_drop(v_s_240);
        heff_drop(v_x1_249);
        return v_j_241;
      } else {
        heff_drop(v_x1_249);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_245);
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_c_242);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2esymEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2esymEnd(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2enumExp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enumExp_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enumExp(V v_s_240, V v_b_241) {
top: ;
  V v_t_243 = heff_bool((heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_b_241)), MK_INT(101LL)) || heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_b_241)), MK_INT(69LL))));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_c_244 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(1LL)));
    V v_t_246 = heff_bool((heff_intLe_c(MK_INT(48LL), heff_dup(v_c_244)) && heff_intLe_c(heff_dup(v_c_244), MK_INT(57LL))));
    heff_drop(v_c_244);
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_b_241, MK_INT(2LL))));
      return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_247, NTAG(TAG_True)});
    } else {
      heff_drop(v_t_246);
      V v_t_248 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(1LL)));
      V v_t_2416 = heff_bool((heff_intEq_c(heff_dup(v_t_248), MK_INT(43LL)) ? ({ V v_c_2410 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(2LL))); int c_ = (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_2410)) && heff_intLe_c(heff_dup(v_c_2410), MK_INT(57LL))); heff_drop(v_c_2410); c_; }) : ({ V v_t_2412 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(1LL))); int c_ = (heff_intEq_c(heff_dup(v_t_2412), MK_INT(45LL)) && ({ V v_c_2414 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(2LL))); int c_ = (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_2414)) && heff_intLe_c(heff_dup(v_c_2414), MK_INT(57LL))); heff_drop(v_c_2414); c_; })); heff_drop(v_t_2412); c_; })));
      heff_drop(v_t_248);
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        V v_t_2417 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_b_241, MK_INT(2LL))));
        return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_2417, NTAG(TAG_True)});
      } else {
        heff_drop(v_s_240);
        heff_drop(v_t_2416);
        return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_241, NTAG(TAG_True)});
      }
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_t_243);
    return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_241, NTAG(TAG_True)});
  }
}
V g_heff_2esyntax_2efmt_2elex_2enumExp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2enumExp(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2enumFrac_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enumFrac_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enumFrac(V v_s_240, V v_a_241) {
top: ;
  if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_a_241)), MK_INT(46LL))) {
    V v_c_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_a_241), MK_INT(1LL)));
    if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_243))) {
      if (heff_intLe_c(v_c_243, MK_INT(57LL))) {
        V v_t_246 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(heff_dup(v_s_240), heff_intAdd(v_a_241, MK_INT(2LL))));
        HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumExp(v_s_240, v_t_246);
      } else {
        heff_drop(v_s_240);
        return heff_rec_n(2, shape_end__isFloat, (V[]){v_a_241, NTAG(TAG_False)});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_c_243);
      return heff_rec_n(2, shape_end__isFloat, (V[]){v_a_241, NTAG(TAG_False)});
    }
  } else {
    heff_drop(v_s_240);
    return heff_rec_n(2, shape_end__isFloat, (V[]){v_a_241, NTAG(TAG_False)});
  }
}
V g_heff_2esyntax_2efmt_2elex_2enumFrac_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2enumFrac(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(V v_s_240, V v_j_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241))));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_t_242);
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(95LL))) {
      V v_t_244 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      V v_t_245 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(v_t_244));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        heff_drop(v_s_240);
        heff_drop(v_t_245);
        return v_j_241;
      }
    } else {
      heff_drop(v_s_240);
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241));
  V v_t_244 = heff_bool((heff_intEq_c(heff_dup(v_c_242), MK_INT(48LL)) || heff_intEq_c(heff_dup(v_c_242), MK_INT(49LL))));
  heff_drop(v_c_242);
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_t_244);
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(95LL))) {
      V v_c_246 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      if (heff_intEq_c(heff_dup(v_c_246), MK_INT(48LL))) {
        heff_drop(v_c_246);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        if (heff_intEq_c(v_c_246, MK_INT(49LL))) {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
          v_s_240 = t_0;
          v_j_241 = t_1;
          goto top;
        } else {
          heff_drop(v_s_240);
          return v_j_241;
        }
      }
    } else {
      heff_drop(v_s_240);
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2enumFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enumFrom_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enumFrom(V v_s_240, V v_j_241) {
top: ;
  V v_t_249;
  if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(48LL))) {
    V v_t_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
    if (heff_intEq_c(v_t_243, MK_INT(120LL))) {
      V v_t_245 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)));
      v_t_249 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(v_t_245));
    } else {
      V v_t_246 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      if (heff_intEq_c(v_t_246, MK_INT(88LL))) {
        V v_t_248 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)));
        v_t_249 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(v_t_248));
      } else {
        v_t_249 = NTAG(TAG_False);
      }
    }
  } else {
    v_t_249 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    V v_t_2410 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(v_s_240, heff_intAdd(v_j_241, MK_INT(2LL))));
    return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_2410, NTAG(TAG_False)});
  } else {
    heff_drop(v_t_249);
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(48LL))) {
      V v_t_2412 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      V v_t_2420 = heff_bool((heff_intEq_c(heff_dup(v_t_2412), MK_INT(98LL)) ? ({ V v_c_2414 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL))); int c_ = (heff_intEq_c(heff_dup(v_c_2414), MK_INT(48LL)) || heff_intEq_c(heff_dup(v_c_2414), MK_INT(49LL))); heff_drop(v_c_2414); c_; }) : ({ V v_t_2416 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL))); int c_ = (heff_intEq_c(heff_dup(v_t_2416), MK_INT(66LL)) && ({ V v_c_2418 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL))); int c_ = (heff_intEq_c(heff_dup(v_c_2418), MK_INT(48LL)) || heff_intEq_c(heff_dup(v_c_2418), MK_INT(49LL))); heff_drop(v_c_2418); c_; })); heff_drop(v_t_2416); c_; })));
      heff_drop(v_t_2412);
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_t_2420);
        V v_t_2421 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(v_s_240, heff_intAdd(v_j_241, MK_INT(2LL))));
        return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_2421, NTAG(TAG_False)});
      } else {
        heff_drop(v_t_2420);
        V v_t_2422 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(heff_dup(v_s_240), heff_intAdd(v_j_241, MK_INT(1LL))));
        HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumFrac(v_s_240, v_t_2422);
      }
    } else {
      V v_t_2423 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(heff_dup(v_s_240), heff_intAdd(v_j_241, MK_INT(1LL))));
      HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumFrac(v_s_240, v_t_2423);
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2enumFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2enumFrom(a[0], a[1]);
}

static V g_heff_2esyntax_2efmt_2elex_2enoCode_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elex_2enoCode_st;
static V g_heff_2esyntax_2efmt_2elex_2enoCode_init(void) {
  return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2esyntax_2efmt_2elex_2enoCode_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elex_2enoCode_st)) return g_heff_2esyntax_2efmt_2elex_2enoCode_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elex_2enoCode_val, &g_heff_2esyntax_2efmt_2elex_2enoCode_st, g_heff_2esyntax_2efmt_2elex_2enoCode_init);
}
Clo g_heff_2esyntax_2efmt_2elex_2ehexDigitValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2ehexDigitValue_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elex_2ehexDigitValue(V v_c_240) {
top: ;
  if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240))) {
    if (heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL))) {
      return heff_intSub(v_c_240, MK_INT(48LL));
    } else {
      if (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240))) {
        return heff_intSub(v_c_240, MK_INT(87LL));
      } else {
        return heff_intSub(v_c_240, MK_INT(55LL));
      }
    }
  } else {
    if (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240))) {
      return heff_intSub(v_c_240, MK_INT(87LL));
    } else {
      return heff_intSub(v_c_240, MK_INT(55LL));
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2ehexDigitValue_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2ehexDigitValue(a[0]);
}
Clo g_heff_2esyntax_2efmt_2elex_2ehexValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2ehexValue_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elex_2ehexValue(V v_s_240, V v_j_241, V v_e_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_e_242), heff_dup(v_j_241))) {
    heff_drop(v_s_240);
    heff_drop(v_j_241);
    heff_drop(v_e_242);
    return v_acc_243;
  } else {
    V v_t_245 = (g_heff_2esyntax_2efmt_2elex_2ehexDigitValue(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241))));
    V v_t_246 = heff_intAdd(heff_intMul(v_acc_243, MK_INT(16LL)), v_t_245);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    V t_2 = v_e_242;
    V t_3 = v_t_246;
    v_s_240 = t_0;
    v_j_241 = t_1;
    v_e_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
}
V g_heff_2esyntax_2efmt_2elex_2ehexValue_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2ehexValue(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(V v_s_240, V v_j_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241))));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_s_240);
    heff_drop(v_t_242);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2euniEsc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2euniEsc_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elex_2euniEsc(V v_s_240, V v_j_241, V v_e_242) {
top: ;
  if (heff_intLt_c(heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)), heff_dup(v_e_242))) {
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_e_242)), MK_INT(125LL))) {
      V v_t_245 = (g_heff_2esyntax_2efmt_2elex_2ehexValue(v_s_240, heff_intAdd(v_j_241, MK_INT(2LL)), heff_dup(v_e_242), MK_INT(0LL)));
      return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_e_242, MK_INT(1LL)), v_t_245});
    } else {
      heff_drop(v_s_240);
      heff_drop(v_e_242);
      return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_j_241, MK_INT(1LL)), MK_INT(117LL)});
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_e_242);
    return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_j_241, MK_INT(1LL)), MK_INT(117LL)});
  }
}
V g_heff_2esyntax_2efmt_2elex_2euniEsc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2euniEsc(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2efmt_2elex_2eescAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eescAt_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eescAt(V v_s_240, V v_j_241) {
top: ;
  V v_t_244 = heff_bool((heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(117LL)) && ({ V v_t_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL))); int c_ = heff_intEq_c(heff_dup(v_t_243), MK_INT(123LL)); heff_drop(v_t_243); c_; })));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL))));
    return (g_heff_2esyntax_2efmt_2elex_2euniEsc(v_s_240, v_j_241, v_t_245));
  } else {
    heff_drop(v_t_244);
    if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_j_241))) {
      heff_drop(v_s_240);
      heff_drop(v_j_241);
      return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
    } else {
      if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(10LL))) {
        heff_drop(v_s_240);
        heff_drop(v_j_241);
        return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
      } else {
        V v_t_248 = heff_intAdd(heff_dup(v_j_241), heff_strRuneWidth(heff_dup(v_s_240), heff_dup(v_j_241)));
        V v_c_249 = heff_runeToInt(heff_strRuneAt(v_s_240, v_j_241));
        V v_t_2413;
        if (heff_intEq_c(heff_dup(v_c_249), MK_INT(110LL))) {
          heff_drop(v_c_249);
          v_t_2413 = MK_INT(10LL);
        } else {
          if (heff_intEq_c(heff_dup(v_c_249), MK_INT(116LL))) {
            heff_drop(v_c_249);
            v_t_2413 = MK_INT(9LL);
          } else {
            if (heff_intEq_c(heff_dup(v_c_249), MK_INT(114LL))) {
              heff_drop(v_c_249);
              v_t_2413 = MK_INT(13LL);
            } else {
              v_t_2413 = v_c_249;
            }
          }
        }
        return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), v_t_248, v_t_2413});
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2eescAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eescAt(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str0, 16, "0123456789ABCDEF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str1, 19, " is beyond U+10FFFF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str2, 15, " is a surrogate");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str3, 2, "U+");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str4, 11, "a `\\u{...}`");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str5, 28, " is a Unicode scalar value: ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str6, 16, "0123456789ABCDEF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str7, 19, " is beyond U+10FFFF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str8, 15, " is a surrogate");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str9, 2, "U+");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str10, 11, "a `\\u{...}`");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str11, 28, " is a Unicode scalar value: ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str12, 16, "0123456789ABCDEF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str13, 19, " is beyond U+10FFFF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str14, 15, " is a surrogate");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str15, 2, "U+");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str16, 11, "a `\\u{...}`");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ebadEsc_str17, 28, " is a Unicode scalar value: ");
Clo g_heff_2esyntax_2efmt_2elex_2ebadEsc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2ebadEsc_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elex_2ebadEsc(V v_x1_240, V v_j_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    V v_c_243 = heff_dup(heff_rfield(v_e_242, 2));
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_243))) {
      if (heff_intLe_c(heff_dup(v_c_243), MK_INT(1114111LL))) {
        V v_x1_247 = heff_bool((heff_intLe_c(MK_INT(55296LL), heff_dup(v_c_243)) && heff_intLe_c(heff_dup(v_c_243), MK_INT(57343LL))));
        heff_drop(v_c_243);
        if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
          heff_drop(v_x1_247);
          V v_c_248 = heff_take_field(v_e_242, 2);
          V v_t_249 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str0), heff_dup(v_c_248)));
          V v_t_2410 = (g_heff_2eutil_2erune_2epadTo4(v_t_249));
          V v_t_2412;
          if (heff_intLt_c(MK_INT(1114111LL), v_c_248)) {
            v_t_2412 = ((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str1);
          } else {
            v_t_2412 = ((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str2);
          }
          V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str3), v_t_2410), v_t_2412);
          V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str4), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str5), v_t_2413));
          V v_t_2415 = heff_rec_n(3, shape_start__end__msg, (V[]){v_j_241, heff_get_n(v_e_242, 1, 3), v_t_2414});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
        } else {
          heff_drop(v_j_241);
          heff_drop_rec(v_e_242, 3);
          heff_drop(v_x1_247);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_c_243);
        V v_c_2416 = heff_take_field(v_e_242, 2);
        V v_t_2417 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str6), heff_dup(v_c_2416)));
        V v_t_2418 = (g_heff_2eutil_2erune_2epadTo4(v_t_2417));
        V v_t_2420;
        if (heff_intLt_c(MK_INT(1114111LL), v_c_2416)) {
          v_t_2420 = ((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str7);
        } else {
          v_t_2420 = ((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str8);
        }
        V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str9), v_t_2418), v_t_2420);
        V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str10), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str11), v_t_2421));
        V v_t_2423 = heff_rec_n(3, shape_start__end__msg, (V[]){v_j_241, heff_get_n(v_e_242, 1, 3), v_t_2422});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2423});
      }
    } else {
      heff_drop(v_c_243);
      V v_c_2424 = heff_take_field(v_e_242, 2);
      V v_t_2425 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str12), heff_dup(v_c_2424)));
      V v_t_2426 = (g_heff_2eutil_2erune_2epadTo4(v_t_2425));
      V v_t_2428;
      if (heff_intLt_c(MK_INT(1114111LL), v_c_2424)) {
        v_t_2428 = ((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str13);
      } else {
        v_t_2428 = ((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str14);
      }
      V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str15), v_t_2426), v_t_2428);
      V v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str16), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2ebadEsc_str17), v_t_2429));
      V v_t_2431 = heff_rec_n(3, shape_start__end__msg, (V[]){v_j_241, heff_get_n(v_e_242, 1, 3), v_t_2430});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2431});
    }
  }
  case TAG_Just: {
    V v_b_2432 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    heff_drop(v_j_241);
    heff_drop_rec(v_e_242, 3);
    return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_b_2432});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elex_2ebadEsc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2ebadEsc(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2efmt_2elex_2estrScan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2estrScan_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elex_2estrScan(V v_s_240, V v_j_241, V v_acc_242, V v_bad_243) {
top: ;
  V v_t_245 = heff_bool((heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_j_241)) || heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(10LL))));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_s_240);
    heff_drop(v_t_245);
    return heff_rec_n(4, shape_i__text__closed__bad, (V[]){v_j_241, v_acc_242, NTAG(TAG_False), v_bad_243});
  } else {
    heff_drop(v_t_245);
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(34LL))) {
      heff_drop(v_s_240);
      return heff_rec_n(4, shape_i__text__closed__bad, (V[]){v_j_241, v_acc_242, NTAG(TAG_True), v_bad_243});
    } else {
      V v_t_2413;
      if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(92LL))) {
        V v_j_248 = heff_intAdd(heff_dup(v_j_241), MK_INT(1LL));
        if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_248)), MK_INT(120LL))) {
          V v_t_2410 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_248), MK_INT(1LL)));
          V v_t_2411 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(v_t_2410));
          if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
            heff_drop(v_t_2411);
            V v_t_2412 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(v_j_248, MK_INT(2LL)));
            v_t_2413 = (g_heff_2esyntax_2efmt_2elex_2eisHexC(v_t_2412));
          } else {
            heff_drop(v_j_248);
            heff_drop(v_t_2411);
            v_t_2413 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_j_248);
          v_t_2413 = NTAG(TAG_False);
        }
      } else {
        v_t_2413 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_t_2414 = (g_heff_2esyntax_2efmt_2elex_2ehexValue(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)), heff_intAdd(heff_dup(v_j_241), MK_INT(4LL)), MK_INT(0LL)));
        V v_t_2415 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_t_2414)));
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(4LL));
        V t_2 = heff_strAppend(v_acc_242, v_t_2415);
        V t_3 = v_bad_243;
        v_s_240 = t_0;
        v_j_241 = t_1;
        v_acc_242 = t_2;
        v_bad_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_2413);
        V v_t_2417 = heff_bool((heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(92LL)) && heff_intLt_c(heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)), heff_strLength(heff_dup(v_s_240)))));
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_t_2417);
          V v_k_2418 = heff_intAdd(heff_dup(v_j_241), MK_INT(1LL));
          V v_e_2419 = (g_heff_2esyntax_2efmt_2elex_2eescAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL))));
          V v_t_2420 = heff_dup(heff_rfield(v_e_2419, 0));
          V v_e_2421;
          if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
            heff_drop(v_k_2418);
            heff_drop(v_t_2420);
            v_e_2421 = v_e_2419;
          } else {
            heff_drop_rec(v_e_2419, 3);
            heff_drop(v_t_2420);
            v_e_2421 = heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(heff_dup(v_k_2418), MK_INT(1LL)), heff_strByteAt(heff_dup(v_s_240), v_k_2418)});
          }
          V v_t_2422 = (g_heff_2eutil_2erune_2eencode(heff_dup(heff_rfield(v_e_2421, 2))));
          V v_t_2423 = (g_heff_2esyntax_2efmt_2elex_2ebadEsc(v_bad_243, v_j_241, heff_dup(v_e_2421)));
          V t_0 = v_s_240;
          V t_1 = heff_get_n(v_e_2421, 1, 3);
          V t_2 = heff_strAppend(v_acc_242, v_t_2422);
          V t_3 = v_t_2423;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_acc_242 = t_2;
          v_bad_243 = t_3;
          goto top;
        } else {
          heff_drop(v_t_2417);
          V v_t_2424 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_j_241), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_2 = heff_strAppend(v_acc_242, v_t_2424);
          V t_3 = v_bad_243;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_acc_242 = t_2;
          v_bad_243 = t_3;
          goto top;
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2estrScan_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2estrScan(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2efmt_2elex_2eruneScan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eruneScan_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eruneScan(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
  if (heff_intEq_c(v_t_242, MK_INT(92LL))) {
    V v_e_244 = (g_heff_2esyntax_2efmt_2elex_2eescAt(heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(2LL))));
    V v_t_245 = heff_take_field(v_e_244, 0);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_j_246 = heff_take_field(v_e_244, 1);
      if (heff_intEq_c(heff_strByteAt(v_s_240, heff_dup(v_j_246)), MK_INT(39LL))) {
        return ({ V rv_0 = NTAG(TAG_True); V rv_1 = heff_intAdd(v_j_246, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_e_244, 4ULL, 3, shape_ok__end__code, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      } else {
        heff_drop_rec(v_e_244, 3);
        heff_drop(v_j_246);
        return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
      }
    } else {
      heff_drop(v_s_240);
      heff_drop_rec(v_e_244, 3);
      heff_drop(v_t_245);
      return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
    }
  } else {
    if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
    } else {
      V v_t_249 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
      if (heff_intEq_c(v_t_249, MK_INT(39LL))) {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
      } else {
        V v_t_2411 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
        if (heff_intEq_c(v_t_2411, MK_INT(10LL))) {
          heff_drop(v_s_240);
          heff_drop(v_i_241);
          return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
        } else {
          V v_t_2413 = heff_strRuneWidth(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
          V v_j_2414 = heff_intAdd(heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), v_t_2413);
          if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_2414)), MK_INT(39LL))) {
            V v_t_2416 = heff_strRuneAt(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)));
            return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_j_2414, MK_INT(1LL)), heff_runeToInt(v_t_2416)});
          } else {
            heff_drop(v_s_240);
            heff_drop(v_i_241);
            heff_drop(v_j_2414);
            return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2eruneScan_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eruneScan(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2eblockScan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eblockScan_entry, 6, 0};

V g_heff_2esyntax_2efmt_2elex_2eblockScan(V v_s_240, V v_j_241, V v_depth_242, V v_line_243, V v_lineStart_244, V v_first_245) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_j_241))) {
    heff_drop(v_s_240);
    heff_drop(v_depth_242);
    return heff_rec_n(5, shape_i__line__lineStart__first__closed, (V[]){v_j_241, v_line_243, v_lineStart_244, v_first_245, NTAG(TAG_False)});
  } else {
    V v_t_249 = heff_bool((heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(123LL)) && ({ V v_t_248 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL))); int c_ = heff_intEq_c(heff_dup(v_t_248), MK_INT(45LL)); heff_drop(v_t_248); c_; })));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
      V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
      V t_3 = v_line_243;
      V t_4 = v_lineStart_244;
      V t_5 = v_first_245;
      v_s_240 = t_0;
      v_j_241 = t_1;
      v_depth_242 = t_2;
      v_line_243 = t_3;
      v_lineStart_244 = t_4;
      v_first_245 = t_5;
      goto top;
    } else {
      heff_drop(v_t_249);
      V v_t_2412 = heff_bool((heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(45LL)) && ({ V v_t_2411 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL))); int c_ = heff_intEq_c(heff_dup(v_t_2411), MK_INT(125LL)); heff_drop(v_t_2411); c_; })));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        if (heff_intEq_c(heff_dup(v_depth_242), MK_INT(1LL))) {
          heff_drop(v_s_240);
          heff_drop(v_depth_242);
          return heff_rec_n(5, shape_i__line__lineStart__first__closed, (V[]){heff_intAdd(v_j_241, MK_INT(2LL)), v_line_243, v_lineStart_244, v_first_245, NTAG(TAG_True)});
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
          V t_2 = heff_intSub(v_depth_242, MK_INT(1LL));
          V t_3 = v_line_243;
          V t_4 = v_lineStart_244;
          V t_5 = v_first_245;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        }
      } else {
        heff_drop(v_t_2412);
        if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(10LL))) {
          heff_drop(v_lineStart_244);
          heff_drop(v_first_245);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(heff_dup(v_j_241), MK_INT(1LL));
          V t_2 = v_depth_242;
          V t_3 = heff_intAdd(v_line_243, MK_INT(1LL));
          V t_4 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_5 = NTAG(TAG_True);
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_2 = v_depth_242;
          V t_3 = v_line_243;
          V t_4 = v_lineStart_244;
          V t_5 = v_first_245;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2eblockScan_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eblockScan(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str0, 5, "field");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str1, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str2, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str3, 5, "float");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str4, 3, "str");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str5, 3, "con");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str6, 3, "int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str7, 3, "var");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str8, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str9, 1, "}");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str11, 1, "]");
Clo g_heff_2esyntax_2efmt_2elex_2eoperandBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eoperandBefore_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eoperandBefore(V v_x1_240, V v_start_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_start_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 3)), v_start_241)) {
      V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_242, 0))}));
      V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str0), NTAG(TAG_Nil)});
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str2), v_t_246})});
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str4), v_t_247})});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str6), v_t_248})});
      V v_t_2410 = ({ V a_0 = v_t_245; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str7), v_t_249}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_t_242, 7);
        heff_drop(v_t_2410);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2410);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str8))) {
          V v_t_2412 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_t_242, 1, 7)}));
          V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str9), NTAG(TAG_Nil)});
          V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str11), v_t_2413})});
          return ({ V a_0 = v_t_2412; V a_1 = v_t_2414; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2414, 2); r_; });
        } else {
          heff_drop_rec(v_t_242, 7);
          return NTAG(TAG_False);
        }
      }
    } else {
      heff_drop_rec(v_t_242, 7);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elex_2eoperandBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eoperandBefore(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2estartsNegated_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2estartsNegated_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elex_2estartsNegated(V v_c_240) {
top: ;
  V v_t_243 = heff_bool((heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(122LL)) || heff_intEq_c(heff_dup(v_c_240), MK_INT(95LL))) : heff_intEq_c(heff_dup(v_c_240), MK_INT(95LL))));
  V v_ret_24bool = heff_bool(((heff_dup(v_t_243) == NTAG(TAG_True)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || heff_intEq_c(heff_dup(v_c_240), MK_INT(40LL))) : heff_intEq_c(heff_dup(v_c_240), MK_INT(40LL)))));
  heff_drop(v_c_240);
  heff_drop(v_t_243);
  return v_ret_24bool;
}
V g_heff_2esyntax_2efmt_2elex_2estartsNegated_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2estartsNegated(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2efieldBefore_str0, 2, "kw");
Clo g_heff_2esyntax_2efmt_2elex_2efieldBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2efieldBefore_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2efieldBefore(V v_x1_240, V v_start_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_start_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_t_242), v_rest_243}), heff_dup(v_start_241)));
    V v_ret_24bool = heff_bool(((heff_dup(v_t_244) == NTAG(TAG_True)) || (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 3)), heff_dup(v_start_241)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2esyntax_2efmt_2elex_2efieldBefore_str0)) && ({ V v_c_247 = heff_strByteAt(heff_dup(heff_rfield(v_t_242, 1)), MK_INT(0LL)); int c_ = (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_247)) && heff_intLe_c(heff_dup(v_c_247), MK_INT(90LL))); heff_drop(v_c_247); c_; })))));
    heff_drop(v_start_241);
    heff_drop_rec(v_t_242, 7);
    heff_drop(v_t_244);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elex_2efieldBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2efieldBefore(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2enameStep_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2enameStep_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2enameStep_str2, 3, "var");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2enameStep_str3, 3, "var");
Clo g_heff_2esyntax_2efmt_2elex_2enameStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enameStep_entry, 6, 0};

V g_heff_2esyntax_2efmt_2elex_2enameStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_j_245) {
top: ;
  V v_c_246 = heff_strByteAt(heff_dup(v_src_240), heff_dup(v_i_241));
  V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_dup(v_j_245))}));
  V v_t_248 = ({ V a_0 = v_t_247; V b_1 = heff_dup(g_heff_2esyntax_2efmt_2elex_2ekeywords_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_kind_2411;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_c_246);
    heff_drop(v_t_248);
    v_kind_2411 = ((V)&g_heff_2esyntax_2efmt_2elex_2enameStep_str0);
  } else {
    heff_drop(v_t_248);
    if (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_246))) {
      if (heff_intLe_c(v_c_246, MK_INT(90LL))) {
        v_kind_2411 = ((V)&g_heff_2esyntax_2efmt_2elex_2enameStep_str1);
      } else {
        v_kind_2411 = ((V)&g_heff_2esyntax_2efmt_2elex_2enameStep_str2);
      }
    } else {
      heff_drop(v_c_246);
      v_kind_2411 = ((V)&g_heff_2esyntax_2efmt_2elex_2enameStep_str3);
    }
  }
  V v_t_2412 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){v_kind_2411, heff_strSlice(v_src_240, heff_dup(v_i_241), heff_dup(v_j_245)), heff_dup(v_i_241), heff_dup(v_j_245), heff_dup(v_line_242), heff_intSub(v_i_241, heff_dup(v_lineStart_243)), v_first_244});
  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_j_245, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2412}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2efmt_2elex_2enameStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2enameStep(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2equotedStep_str0, 16, " is never closed");
Clo g_heff_2esyntax_2efmt_2elex_2equotedStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2equotedStep_entry, 8, 0};

V g_heff_2esyntax_2efmt_2elex_2equotedStep(V v_kind_240, V v_what_241, V v_src_242, V v_i_243, V v_line_244, V v_lineStart_245, V v_first_246, V v_r_247) {
top: ;
  V v_t_248 = heff_dup(heff_rfield(v_r_247, 2));
  V v_t_249;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_r_247, 0)), MK_INT(1LL));
  } else {
    heff_drop(v_t_248);
    v_t_249 = heff_dup(heff_rfield(v_r_247, 0));
  }
  V v_t_2410 = heff_dup(heff_rfield(v_r_247, 2));
  V v_j_2411;
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    v_j_2411 = heff_intAdd(heff_dup(heff_rfield(v_r_247, 0)), MK_INT(1LL));
  } else {
    heff_drop(v_t_2410);
    v_j_2411 = heff_dup(heff_rfield(v_r_247, 0));
  }
  V v_t_2412 = heff_intAdd(heff_dup(v_lineStart_245), heff_intSub(heff_dup(v_j_2411), heff_dup(v_i_243)));
  V v_t_2413 = (g_heff_2eutil_2erune_2erunesGo(v_src_242, heff_dup(v_i_243), v_j_2411, MK_INT(0LL)));
  V v_t_2414 = heff_dup(heff_rfield(v_r_247, 2));
  V v_end_2415;
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_t_2414);
    v_end_2415 = heff_intAdd(heff_dup(heff_rfield(v_r_247, 0)), MK_INT(1LL));
  } else {
    heff_drop(v_t_2414);
    v_end_2415 = heff_dup(heff_rfield(v_r_247, 0));
  }
  V v_t_2416 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){v_kind_240, heff_take_field(v_r_247, 1), heff_dup(v_i_243), v_end_2415, heff_dup(v_line_244), heff_intSub(heff_dup(v_i_243), v_lineStart_245), v_first_246});
  V v_t_2417 = heff_take_field(v_r_247, 2);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_what_241);
    heff_drop(v_i_243);
    heff_drop(v_t_2417);
    v_t_2419 = heff_get_n(v_r_247, 3, 4);
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = heff_rec_n(3, shape_start__end__msg, (V[]){v_i_243, heff_get_n(v_r_247, 0, 4), heff_strAppend(v_what_241, ((V)&g_heff_2esyntax_2efmt_2elex_2equotedStep_str0))});
    v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2418});
  }
  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_t_249, v_line_244, heff_intSub(v_t_2412, v_t_2413), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2416}), v_t_2419, NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2efmt_2elex_2equotedStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2equotedStep(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str0, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str1, 16, "0123456789ABCDEF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str2, 19, " is beyond U+10FFFF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str3, 15, " is a surrogate");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str4, 2, "U+");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str5, 14, "a rune literal");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str6, 28, " is a Unicode scalar value: ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str7, 16, "0123456789ABCDEF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str8, 19, " is beyond U+10FFFF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str9, 15, " is a surrogate");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str10, 2, "U+");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str11, 14, "a rune literal");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str12, 28, " is a Unicode scalar value: ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str13, 16, "0123456789ABCDEF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str14, 19, " is beyond U+10FFFF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str15, 15, " is a surrogate");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str16, 2, "U+");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str17, 14, "a rune literal");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str18, 28, " is a Unicode scalar value: ");
Clo g_heff_2esyntax_2efmt_2elex_2eruneStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eruneStep_entry, 6, 0};

V g_heff_2esyntax_2efmt_2elex_2eruneStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_r_245) {
top: ;
  V v_j_246 = heff_dup(heff_rfield(v_r_245, 1));
  V v_t_247 = heff_intAdd(heff_dup(v_lineStart_243), heff_intSub(heff_dup(v_j_246), heff_dup(v_i_241)));
  V v_t_248 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, heff_dup(v_i_241), v_j_246, MK_INT(0LL)));
  V v_text_249 = (g_heff_2eutil_2erune_2eencode(heff_dup(heff_rfield(v_r_245, 2))));
  V v_t_2410 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str0), v_text_249, heff_dup(v_i_241), heff_dup(heff_rfield(v_r_245, 1)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), v_lineStart_243), v_first_244});
  V v_c_2411 = heff_dup(heff_rfield(v_r_245, 2));
  V v_t_2440;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_2411))) {
    if (heff_intLe_c(heff_dup(v_c_2411), MK_INT(1114111LL))) {
      V v_x1_2415 = heff_bool((heff_intLe_c(MK_INT(55296LL), heff_dup(v_c_2411)) && heff_intLe_c(heff_dup(v_c_2411), MK_INT(57343LL))));
      heff_drop(v_c_2411);
      if ((heff_dup(v_x1_2415) == NTAG(TAG_True))) {
        heff_drop(v_x1_2415);
        V v_c_2416 = heff_dup(heff_rfield(v_r_245, 2));
        V v_t_2417 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str1), heff_dup(v_c_2416)));
        V v_t_2418 = (g_heff_2eutil_2erune_2epadTo4(v_t_2417));
        V v_t_2420;
        if (heff_intLt_c(MK_INT(1114111LL), v_c_2416)) {
          v_t_2420 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str2);
        } else {
          v_t_2420 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str3);
        }
        V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str4), v_t_2418), v_t_2420);
        V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str5), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str6), v_t_2421));
        V v_t_2423 = heff_rec_n(3, shape_start__end__msg, (V[]){v_i_241, heff_dup(heff_rfield(v_r_245, 1)), v_t_2422});
        v_t_2440 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2423});
      } else {
        heff_drop(v_i_241);
        heff_drop(v_x1_2415);
        v_t_2440 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_c_2411);
      V v_c_2424 = heff_dup(heff_rfield(v_r_245, 2));
      V v_t_2425 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str7), heff_dup(v_c_2424)));
      V v_t_2426 = (g_heff_2eutil_2erune_2epadTo4(v_t_2425));
      V v_t_2428;
      if (heff_intLt_c(MK_INT(1114111LL), v_c_2424)) {
        v_t_2428 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str8);
      } else {
        v_t_2428 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str9);
      }
      V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str10), v_t_2426), v_t_2428);
      V v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str11), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str12), v_t_2429));
      V v_t_2431 = heff_rec_n(3, shape_start__end__msg, (V[]){v_i_241, heff_dup(heff_rfield(v_r_245, 1)), v_t_2430});
      v_t_2440 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2431});
    }
  } else {
    heff_drop(v_c_2411);
    V v_c_2432 = heff_dup(heff_rfield(v_r_245, 2));
    V v_t_2433 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str13), heff_dup(v_c_2432)));
    V v_t_2434 = (g_heff_2eutil_2erune_2epadTo4(v_t_2433));
    V v_t_2436;
    if (heff_intLt_c(MK_INT(1114111LL), v_c_2432)) {
      v_t_2436 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str14);
    } else {
      v_t_2436 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str15);
    }
    V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str16), v_t_2434), v_t_2436);
    V v_t_2438 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str17), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str18), v_t_2437));
    V v_t_2439 = heff_rec_n(3, shape_start__end__msg, (V[]){v_i_241, heff_dup(heff_rfield(v_r_245, 1)), v_t_2438});
    v_t_2440 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2439});
  }
  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_get_n(v_r_245, 1, 3), v_line_242, heff_intSub(v_t_247, v_t_248), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2410}), v_t_2440, NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2efmt_2elex_2eruneStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eruneStep(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2equoteStep_str0, 21, "unexpected character ");
Clo g_heff_2esyntax_2efmt_2elex_2equoteStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2equoteStep_entry, 6, 0};

V g_heff_2esyntax_2efmt_2elex_2equoteStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_r_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_r_245, 0));
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2eruneStep(v_src_240, v_i_241, v_line_242, v_lineStart_243, v_first_244, v_r_245);
  } else {
    heff_drop_rec(v_r_245, 3);
    heff_drop(v_t_246);
    V v_w_247 = heff_strRuneWidth(heff_dup(v_src_240), heff_dup(v_i_241));
    V v_t_248 = heff_intSub(heff_intAdd(v_lineStart_243, heff_dup(v_w_247)), MK_INT(1LL));
    V v_t_249 = heff_strSlice(v_src_240, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_247)));
    V v_t_2410 = heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_247)), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2equoteStep_str0), v_t_249)});
    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, v_w_247), v_line_242, v_t_248, v_first_244, NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_2410}), NTAG(TAG_Nothing)});
  }
}
V g_heff_2esyntax_2efmt_2elex_2equoteStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2equoteStep(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_str0, 30, "a `{-` comment is never closed");
Clo g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elex_2eblockCmtStep(V v_src_240, V v_i_241, V v_lineStart_242, V v_r_243) {
top: ;
  V v_t_2412;
  if (heff_intEq_c(heff_dup(heff_rfield(v_r_243, 2)), heff_dup(v_lineStart_242))) {
    V v_j_245 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_246 = heff_intAdd(v_lineStart_242, heff_intSub(heff_dup(v_j_245), heff_dup(v_i_241)));
    V v_t_247 = (g_heff_2eutil_2erune_2erunesGo(heff_dup(v_src_240), heff_dup(v_i_241), v_j_245, MK_INT(0LL)));
    v_t_2412 = heff_intSub(v_t_246, v_t_247);
  } else {
    heff_drop(v_lineStart_242);
    V v_i_248 = heff_dup(heff_rfield(v_r_243, 2));
    V v_j_249 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_r_243, 2)), heff_intSub(heff_dup(v_j_249), heff_dup(v_i_248)));
    V v_t_2411 = (g_heff_2eutil_2erune_2erunesGo(heff_dup(v_src_240), v_i_248, v_j_249, MK_INT(0LL)));
    v_t_2412 = heff_intSub(v_t_2410, v_t_2411);
  }
  V v_t_2413 = heff_take_field(v_r_243, 4);
  V v_t_2415;
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_t_2413);
    v_t_2415 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2413);
    V v_t_2414 = heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_241), heff_dup(heff_rfield(v_r_243, 0)), ((V)&g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_str0)});
    v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
  }
  V v_t_2416 = heff_strSlice(v_src_240, heff_dup(v_i_241), heff_dup(heff_rfield(v_r_243, 0)));
  V v_t_2417 = heff_rec_n(3, shape_start__end__text, (V[]){v_i_241, heff_dup(heff_rfield(v_r_243, 0)), v_t_2416});
  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_dup(heff_rfield(v_r_243, 0)), heff_dup(heff_rfield(v_r_243, 1)), v_t_2412, heff_get_n(v_r_243, 3, 5), NTAG(TAG_Nothing), v_t_2415, heff_tag_n(TAG_Just, 1, (V[]){v_t_2417})});
}
V g_heff_2esyntax_2efmt_2elex_2eblockCmtStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eblockCmtStep(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str0, 6, "-- >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str1, 5, "watch");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str2, 6, "-- >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str3, 8, "-- | >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str4, 7, "doctest");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str5, 8, "-- | >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str7, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str8, 15, "a bytes literal");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str9, 5, "field");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str10, 5, "float");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str11, 3, "int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str12, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str13, 1, "-");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str15, 3, "str");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str16, 8, "a string");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str17, 7, "()[]{},");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str18, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str19, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str20, 21, "unexpected character ");
Clo g_heff_2esyntax_2efmt_2elex_2estepAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2estepAt_entry, 7, 0};

V g_heff_2esyntax_2efmt_2elex_2estepAt(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_toks_245, V v_c_246) {
top: ;
  if (heff_intEq_c(heff_dup(v_c_246), MK_INT(10LL))) {
    heff_drop(v_src_240);
    heff_drop(v_lineStart_243);
    heff_drop(v_first_244);
    heff_drop(v_toks_245);
    heff_drop(v_c_246);
    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_intAdd(v_line_242, MK_INT(1LL)), heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  } else {
    V v_t_2410 = heff_bool((heff_intEq_c(heff_dup(v_c_246), MK_INT(32LL)) || (heff_intEq_c(heff_dup(v_c_246), MK_INT(9LL)) || heff_intEq_c(heff_dup(v_c_246), MK_INT(13LL)))));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_src_240);
      heff_drop(v_toks_245);
      heff_drop(v_c_246);
      heff_drop(v_t_2410);
      return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    } else {
      heff_drop(v_t_2410);
      V v_t_2413 = heff_bool((heff_intEq_c(heff_dup(v_c_246), MK_INT(45LL)) && ({ V v_t_2412 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(6LL))); int c_ = heff_strEq_c(heff_dup(v_t_2412), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str0)); heff_drop(v_t_2412); c_; })));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_src_240);
        heff_drop(v_toks_245);
        heff_drop(v_c_246);
        heff_drop(v_t_2413);
        V v_t_2414 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str1), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str2), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
        return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(6LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2414}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      } else {
        heff_drop(v_t_2413);
        V v_t_2417 = heff_bool((heff_intEq_c(heff_dup(v_c_246), MK_INT(45LL)) && ({ V v_t_2416 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(8LL))); int c_ = heff_strEq_c(heff_dup(v_t_2416), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str3)); heff_drop(v_t_2416); c_; })));
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_src_240);
          heff_drop(v_toks_245);
          heff_drop(v_c_246);
          heff_drop(v_t_2417);
          V v_t_2418 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str4), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str5), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(8LL)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
          return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(8LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2418}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        } else {
          heff_drop(v_t_2417);
          V v_t_2430;
          if (heff_intEq_c(heff_dup(v_c_246), MK_INT(45LL))) {
            V v_t_2420 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(heff_dup(v_src_240), heff_dup(v_i_241)));
            V v_x_2421 = heff_intSub(v_t_2420, heff_dup(v_i_241));
            if (heff_intLe_c(MK_INT(2LL), v_x_2421)) {
              V v_t_2423 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(heff_dup(v_src_240), heff_dup(v_i_241)));
              V v_c_2424 = heff_strByteAt(heff_dup(v_src_240), v_t_2423);
              V v_x1_2429;
              if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_2424))) {
                V v_t_2426 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_c_2424)));
                V v_x3_2427 = (g_prelude_2eindexFrom(v_t_2426, heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)));
                switch (heff_tag_of(v_x3_2427)) {
                case TAG_Nothing: {
                  v_x1_2429 = NTAG(TAG_False);
                  break;
                }
                case TAG_Just: {
                  heff_take_n(v_x3_2427, 0ULL, 1);
                  v_x1_2429 = NTAG(TAG_True);
                  break;
                }
                default: heff_nomatch(v_x3_2427);
                }
              } else {
                heff_drop(v_c_2424);
                v_x1_2429 = NTAG(TAG_False);
              }
              v_t_2430 = heff_bool(!(heff_dup(v_x1_2429) == NTAG(TAG_True)));
              heff_drop(v_x1_2429);
            } else {
              v_t_2430 = NTAG(TAG_False);
            }
          } else {
            v_t_2430 = NTAG(TAG_False);
          }
          if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
            heff_drop(v_toks_245);
            heff_drop(v_c_246);
            heff_drop(v_t_2430);
            V v_e_2431 = (g_heff_2esyntax_2efmt_2elex_2eeolEnd(heff_dup(v_src_240), heff_dup(v_i_241)));
            V v_t_2432 = heff_rec_n(3, shape_start__end__text, (V[]){heff_dup(v_i_241), heff_dup(v_e_2431), heff_strSlice(v_src_240, v_i_241, heff_dup(v_e_2431))});
            return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_e_2431, v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_2432})});
          } else {
            heff_drop(v_t_2430);
            V v_t_2435 = heff_bool((heff_intEq_c(heff_dup(v_c_246), MK_INT(123LL)) && ({ V v_t_2434 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))); int c_ = heff_intEq_c(heff_dup(v_t_2434), MK_INT(45LL)); heff_drop(v_t_2434); c_; })));
            if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
              heff_drop(v_toks_245);
              heff_drop(v_c_246);
              heff_drop(v_t_2435);
              V v_t_2436 = (g_heff_2esyntax_2efmt_2elex_2eblockScan(heff_dup(v_src_240), heff_dup(v_i_241), MK_INT(0LL), v_line_242, heff_dup(v_lineStart_243), v_first_244));
              return (g_heff_2esyntax_2efmt_2elex_2eblockCmtStep(v_src_240, v_i_241, v_lineStart_243, v_t_2436));
            } else {
              heff_drop(v_t_2435);
              V v_t_2439 = heff_bool((heff_intEq_c(heff_dup(v_c_246), MK_INT(98LL)) && ({ V v_t_2438 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))); int c_ = heff_intEq_c(heff_dup(v_t_2438), MK_INT(34LL)); heff_drop(v_t_2438); c_; })));
              if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
                heff_drop(v_toks_245);
                heff_drop(v_c_246);
                heff_drop(v_t_2439);
                V v_r_2440 = (g_heff_2esyntax_2efmt_2elex_2estrScan(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str6), NTAG(TAG_Nothing)));
                return (g_heff_2esyntax_2efmt_2elex_2equotedStep(((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str7), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str8), v_src_240, v_i_241, v_line_242, v_lineStart_243, v_first_244, v_r_2440));
              } else {
                heff_drop(v_t_2439);
                V v_t_2443 = heff_bool((heff_intLe_c(MK_INT(97LL), heff_dup(v_c_246)) ? (heff_intLe_c(heff_dup(v_c_246), MK_INT(122LL)) || heff_intEq_c(heff_dup(v_c_246), MK_INT(95LL))) : heff_intEq_c(heff_dup(v_c_246), MK_INT(95LL))));
                V v_t_2445 = heff_bool(((heff_dup(v_t_2443) == NTAG(TAG_True)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_246)) && heff_intLe_c(heff_dup(v_c_246), MK_INT(90LL)))));
                heff_drop(v_t_2443);
                if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
                  heff_drop(v_toks_245);
                  heff_drop(v_c_246);
                  heff_drop(v_t_2445);
                  V v_t_2446 = (g_heff_2esyntax_2efmt_2elex_2enameEnd(heff_dup(v_src_240), heff_dup(v_i_241)));
                  return (g_heff_2esyntax_2efmt_2elex_2enameStep(v_src_240, v_i_241, v_line_242, v_lineStart_243, v_first_244, v_t_2446));
                } else {
                  heff_drop(v_t_2445);
                  V v_t_2454;
                  if (heff_intEq_c(heff_dup(v_c_246), MK_INT(46LL))) {
                    V v_c_2448 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                    V v_t_2451 = heff_bool((heff_intLe_c(MK_INT(97LL), heff_dup(v_c_2448)) ? (heff_intLe_c(heff_dup(v_c_2448), MK_INT(122LL)) || heff_intEq_c(heff_dup(v_c_2448), MK_INT(95LL))) : heff_intEq_c(heff_dup(v_c_2448), MK_INT(95LL))));
                    if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
                      heff_drop(v_c_2448);
                      heff_drop(v_t_2451);
                      v_t_2454 = (g_heff_2esyntax_2efmt_2elex_2efieldBefore(heff_dup(v_toks_245), heff_dup(v_i_241)));
                    } else {
                      heff_drop(v_t_2451);
                      if (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_2448))) {
                        if (heff_intLe_c(v_c_2448, MK_INT(90LL))) {
                          v_t_2454 = (g_heff_2esyntax_2efmt_2elex_2efieldBefore(heff_dup(v_toks_245), heff_dup(v_i_241)));
                        } else {
                          v_t_2454 = NTAG(TAG_False);
                        }
                      } else {
                        heff_drop(v_c_2448);
                        v_t_2454 = NTAG(TAG_False);
                      }
                    }
                  } else {
                    v_t_2454 = NTAG(TAG_False);
                  }
                  if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
                    heff_drop(v_toks_245);
                    heff_drop(v_c_246);
                    heff_drop(v_t_2454);
                    V v_j_2455 = (g_heff_2esyntax_2efmt_2elex_2eplainEnd(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
                    V v_t_2456 = heff_strSlice(v_src_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_j_2455));
                    V v_t_2457 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str9), v_t_2456, heff_dup(v_i_241), heff_dup(v_j_2455), heff_dup(v_line_242), heff_intSub(v_i_241, heff_dup(v_lineStart_243)), v_first_244});
                    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_j_2455, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2457}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                  } else {
                    heff_drop(v_t_2454);
                    V v_t_2470 = heff_bool((heff_intLe_c(MK_INT(48LL), heff_dup(v_c_246)) ? (heff_intLe_c(heff_dup(v_c_246), MK_INT(57LL)) || (heff_intEq_c(heff_dup(v_c_246), MK_INT(45LL)) && ({ V v_c_2461 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))); int c_ = (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_2461)) && (heff_intLe_c(heff_dup(v_c_2461), MK_INT(57LL)) && ({ V v_x1_2464 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(heff_dup(v_toks_245), heff_dup(v_i_241))); int c_ = !(heff_dup(v_x1_2464) == NTAG(TAG_True)); heff_drop(v_x1_2464); c_; }))); heff_drop(v_c_2461); c_; }))) : (heff_intEq_c(heff_dup(v_c_246), MK_INT(45LL)) && ({ V v_c_2466 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))); int c_ = (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_2466)) && (heff_intLe_c(heff_dup(v_c_2466), MK_INT(57LL)) && ({ V v_x1_2469 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(heff_dup(v_toks_245), heff_dup(v_i_241))); int c_ = !(heff_dup(v_x1_2469) == NTAG(TAG_True)); heff_drop(v_x1_2469); c_; }))); heff_drop(v_c_2466); c_; }))));
                    if ((heff_dup(v_t_2470) == NTAG(TAG_True))) {
                      heff_drop(v_toks_245);
                      heff_drop(v_c_246);
                      heff_drop(v_t_2470);
                      V v_r_2472;
                      if (heff_intEq_c(heff_strByteAt(heff_dup(v_src_240), heff_dup(v_i_241)), MK_INT(45LL))) {
                        v_r_2472 = (g_heff_2esyntax_2efmt_2elex_2enumFrom(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
                      } else {
                        v_r_2472 = (g_heff_2esyntax_2efmt_2elex_2enumFrom(heff_dup(v_src_240), heff_dup(v_i_241)));
                      }
                      V v_t_2473 = heff_take_field(v_r_2472, 1);
                      V v_kind_2474;
                      if ((heff_dup(v_t_2473) == NTAG(TAG_True))) {
                        heff_drop(v_t_2473);
                        v_kind_2474 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str10);
                      } else {
                        heff_drop(v_t_2473);
                        v_kind_2474 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str11);
                      }
                      V v_t_2475 = heff_strSlice(v_src_240, heff_dup(v_i_241), heff_dup(heff_rfield(v_r_2472, 0)));
                      V v_t_2476 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){v_kind_2474, v_t_2475, heff_dup(v_i_241), heff_dup(heff_rfield(v_r_2472, 0)), heff_dup(v_line_242), heff_intSub(v_i_241, heff_dup(v_lineStart_243)), v_first_244});
                      return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_get_n(v_r_2472, 0, 2), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2476}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                    } else {
                      heff_drop(v_t_2470);
                      V v_t_2481 = heff_bool((heff_intEq_c(heff_dup(v_c_246), MK_INT(45LL)) && ({ V v_t_2478 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))); int c_ = ({ V v_t_2479 = (g_heff_2esyntax_2efmt_2elex_2estartsNegated(heff_dup(v_t_2478))); int c_ = ((heff_dup(v_t_2479) == NTAG(TAG_True)) && ({ V v_x1_2480 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(heff_dup(v_toks_245), heff_dup(v_i_241))); int c_ = !(heff_dup(v_x1_2480) == NTAG(TAG_True)); heff_drop(v_x1_2480); c_; })); heff_drop(v_t_2479); c_; }); heff_drop(v_t_2478); c_; })));
                      heff_drop(v_toks_245);
                      if ((heff_dup(v_t_2481) == NTAG(TAG_True))) {
                        heff_drop(v_src_240);
                        heff_drop(v_c_246);
                        heff_drop(v_t_2481);
                        V v_t_2482 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str12), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str13), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
                        return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2482}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                      } else {
                        heff_drop(v_t_2481);
                        if (heff_intEq_c(heff_dup(v_c_246), MK_INT(34LL))) {
                          heff_drop(v_c_246);
                          V v_r_2484 = (g_heff_2esyntax_2efmt_2elex_2estrScan(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str14), NTAG(TAG_Nothing)));
                          return (g_heff_2esyntax_2efmt_2elex_2equotedStep(((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str15), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str16), v_src_240, v_i_241, v_line_242, v_lineStart_243, v_first_244, v_r_2484));
                        } else {
                          V v_t_2489;
                          if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_246))) {
                            V v_t_2486 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_dup(v_c_246))));
                            V v_x3_2487 = (g_prelude_2eindexFrom(v_t_2486, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str17), MK_INT(0LL)));
                            switch (heff_tag_of(v_x3_2487)) {
                            case TAG_Nothing: {
                              v_t_2489 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_Just: {
                              heff_take_n(v_x3_2487, 0ULL, 1);
                              v_t_2489 = NTAG(TAG_True);
                              break;
                            }
                            default: heff_nomatch(v_x3_2487);
                            }
                          } else {
                            v_t_2489 = NTAG(TAG_False);
                          }
                          if ((heff_dup(v_t_2489) == NTAG(TAG_True))) {
                            heff_drop(v_c_246);
                            heff_drop(v_t_2489);
                            V v_t_2490 = heff_strSlice(v_src_240, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                            V v_t_2491 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str18), v_t_2490, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
                            return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2491}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                          } else {
                            heff_drop(v_t_2489);
                            V v_t_2496;
                            if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_246))) {
                              V v_t_2493 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_dup(v_c_246))));
                              V v_x3_2494 = (g_prelude_2eindexFrom(v_t_2493, heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)));
                              switch (heff_tag_of(v_x3_2494)) {
                              case TAG_Nothing: {
                                v_t_2496 = NTAG(TAG_False);
                                break;
                              }
                              case TAG_Just: {
                                heff_take_n(v_x3_2494, 0ULL, 1);
                                v_t_2496 = NTAG(TAG_True);
                                break;
                              }
                              default: heff_nomatch(v_x3_2494);
                              }
                            } else {
                              v_t_2496 = NTAG(TAG_False);
                            }
                            if ((heff_dup(v_t_2496) == NTAG(TAG_True))) {
                              heff_drop(v_c_246);
                              heff_drop(v_t_2496);
                              V v_j_2497 = (g_heff_2esyntax_2efmt_2elex_2esymEnd(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
                              V v_t_2498 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str19), heff_strSlice(v_src_240, heff_dup(v_i_241), heff_dup(v_j_2497)), heff_dup(v_i_241), heff_dup(v_j_2497), heff_dup(v_line_242), heff_intSub(v_i_241, heff_dup(v_lineStart_243)), v_first_244});
                              return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_j_2497, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2498}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                            } else {
                              heff_drop(v_t_2496);
                              if (heff_intEq_c(v_c_246, MK_INT(39LL))) {
                                V v_t_24100 = (g_heff_2esyntax_2efmt_2elex_2eruneScan(heff_dup(v_src_240), heff_dup(v_i_241)));
                                return (g_heff_2esyntax_2efmt_2elex_2equoteStep(v_src_240, v_i_241, v_line_242, v_lineStart_243, v_first_244, v_t_24100));
                              } else {
                                V v_w_24101 = heff_strRuneWidth(heff_dup(v_src_240), heff_dup(v_i_241));
                                V v_t_24102 = heff_intSub(heff_intAdd(v_lineStart_243, heff_dup(v_w_24101)), MK_INT(1LL));
                                V v_t_24103 = heff_strSlice(v_src_240, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_24101)));
                                V v_t_24104 = heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_24101)), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str20), v_t_24103)});
                                return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, v_w_24101), v_line_242, v_t_24102, v_first_244, NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_24104}), NTAG(TAG_Nothing)});
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2estepAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2estepAt(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2elexGo_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2elexGo_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2elexGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elex_2elexGo(V v_src_240, V v_st_241, V v_toks_242, V v_errs_243, V v_cmts_244) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_src_240)), heff_dup(heff_rfield(v_st_241, 0)))) {
    V v_t_246 = heff_intAdd(heff_take_field(v_st_241, 1), MK_INT(1LL));
    V v_t_247 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2elexGo_str0), ((V)&g_heff_2esyntax_2efmt_2elex_2elexGo_str1), heff_strLength(heff_dup(v_src_240)), heff_strLength(v_src_240), v_t_246, MK_INT(0LL), NTAG(TAG_True)});
    V v_t_248 = heff_take_field(v_st_241, 4);
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      v_t_2410 = v_toks_242;
      break;
    }
    case TAG_Just: {
      V v_x_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_toks_242});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_xs_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2410});
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2411));
    V v_t_2413 = heff_take_field(v_st_241, 5);
    V v_xs_2415;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      v_xs_2415 = v_errs_243;
      break;
    }
    case TAG_Just: {
      V v_x_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      v_xs_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, v_errs_243});
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
    V v_t_2417 = heff_get_n(v_st_241, 6, 7);
    V v_xs_2419;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nothing: {
      v_xs_2419 = v_cmts_244;
      break;
    }
    case TAG_Just: {
      V v_x_2418 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      v_xs_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2418, v_cmts_244});
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
    return heff_rec_n(3, shape_tokens__errors__comments, (V[]){v_t_2412, v_t_2416, v_t_2420});
  } else {
    V v_i_2421 = heff_take_field(v_st_241, 0);
    V v_t_2422 = heff_dup(heff_rfield(v_st_241, 4));
    V v_toks_2424;
    switch (heff_tag_of(v_t_2422)) {
    case TAG_Nothing: {
      v_toks_2424 = heff_dup(v_toks_242);
      break;
    }
    case TAG_Just: {
      V v_x_2423 = heff_field(v_t_2422, 0);
      heff_take_n(v_t_2422, 1ULL, 1);
      v_toks_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2423, heff_dup(v_toks_242)});
      break;
    }
    default: heff_nomatch(v_t_2422);
    }
    V v_t_2425 = (g_heff_2esyntax_2efmt_2elex_2estepAt(heff_dup(v_src_240), heff_dup(v_i_2421), heff_take_field(v_st_241, 1), heff_take_field(v_st_241, 2), heff_take_field(v_st_241, 3), v_toks_2424, heff_strByteAt(heff_dup(v_src_240), v_i_2421)));
    V v_t_2426 = heff_take_field(v_st_241, 4);
    V v_t_2428;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      v_t_2428 = v_toks_242;
      break;
    }
    case TAG_Just: {
      V v_x_2427 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 1);
      v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2427, v_toks_242});
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2429 = heff_take_field(v_st_241, 5);
    V v_t_2431;
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      v_t_2431 = v_errs_243;
      break;
    }
    case TAG_Just: {
      V v_x_2430 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2430, v_errs_243});
      break;
    }
    default: heff_nomatch(v_t_2429);
    }
    V v_t_2432 = heff_get_n(v_st_241, 6, 7);
    V v_t_2434;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nothing: {
      v_t_2434 = v_cmts_244;
      break;
    }
    case TAG_Just: {
      V v_x_2433 = heff_field(v_t_2432, 0);
      heff_take_n(v_t_2432, 1ULL, 1);
      v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2433, v_cmts_244});
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    V t_0 = v_src_240;
    V t_1 = v_t_2425;
    V t_2 = v_t_2428;
    V t_3 = v_t_2431;
    V t_4 = v_t_2434;
    v_src_240 = t_0;
    v_st_241 = t_1;
    v_toks_242 = t_2;
    v_errs_243 = t_3;
    v_cmts_244 = t_4;
    goto top;
  }
}
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2elexGo(a[0], a[1], a[2], a[3], a[4]);
}