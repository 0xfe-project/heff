// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_cmt 308164
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_comments 142722952
#define LBL_end 310101
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_i 323
#define LBL_isFloat 143306131
#define LBL_kind 9787483
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_msg 317947
#define LBL_ok 10307
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
static uint32_t shape_end__isFloat[] = {LBL_end, LBL_isFloat};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_ok__end__code[] = {LBL_ok, LBL_end, LBL_code};
static uint32_t shape_start__end__msg[] = {LBL_start, LBL_end, LBL_msg};
static uint32_t shape_start__end__text[] = {LBL_start, LBL_end, LBL_text};
static uint32_t shape_tokens__errors__comments[] = {LBL_tokens, LBL_errors, LBL_comments};
HeffT5 g_heff_2esyntax_2efmt_2elex_2eblockScan_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s1528547454x853005061(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s1528547454x853005061_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s1528547454x853005061_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_clo;
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(V, V);
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_clo;
V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2eescAt(V, V);
V g_heff_2esyntax_2efmt_2elex_2eescAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eescAt_clo;
V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2ehexValue(V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2ehexValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2ehexValue_clo;
V g_heff_2esyntax_2efmt_2elex_2ekeywords_get(void);
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2enameEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2enameEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enameEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2enoCode_get(void);
V g_heff_2esyntax_2efmt_2elex_2enumFrac(V, V);
V g_heff_2esyntax_2efmt_2elex_2enumFrac_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enumFrac_clo;
V g_heff_2esyntax_2efmt_2elex_2enumFrom(V, V);
V g_heff_2esyntax_2efmt_2elex_2enumFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2enumFrom_clo;
V g_heff_2esyntax_2efmt_2elex_2eoperandBefore(V, V);
V g_heff_2esyntax_2efmt_2elex_2eoperandBefore_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eoperandBefore_clo;
V g_heff_2esyntax_2efmt_2elex_2eplainEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eplainEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eplainEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2eruneScan(V, V);
V g_heff_2esyntax_2efmt_2elex_2eruneScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eruneScan_clo;
V g_heff_2esyntax_2efmt_2elex_2eruneStep(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eruneStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eruneStep_clo;
V g_heff_2esyntax_2efmt_2elex_2estartsDelayed(V, V);
V g_heff_2esyntax_2efmt_2elex_2estartsDelayed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2estartsDelayed_clo;
V g_heff_2esyntax_2efmt_2elex_2estepAt(V, V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2estepAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2estepAt_clo;
HeffT4 g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr(V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void);
V g_heff_2esyntax_2efmt_2elex_2esymEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2esymEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2esymEnd_clo;
V g_heff_2eutil_2erune_2ehexWith(V, V);
V g_heff_2eutil_2erune_2ehexWith_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ehexWith_clo;
V g_heff_2eutil_2erune_2epadTo4(V);
V g_heff_2eutil_2erune_2epadTo4_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2epadTo4_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str0, 4, "data");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str1, 4, "type");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str2, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str3, 9, "primitive");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str4, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str5, 6, "mutual");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str6, 6, "import");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str7, 2, "as");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str8, 4, "case");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str9, 2, "of");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str10, 2, "if");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str11, 4, "then");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str12, 4, "else");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str13, 2, "do");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str14, 5, "where");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str15, 3, "let");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str16, 2, "in");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str17, 3, "mut");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str18, 5, "while");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str19, 3, "for");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str20, 5, "break");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str21, 8, "continue");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str22, 6, "return");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str23, 3, "try");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str24, 5, "catch");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str25, 4, "with");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str26, 4, "test");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str27, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str28, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str29, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str30, 6, "String");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str31, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str32, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str33, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str34, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str35, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str36, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str37, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str38, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str39, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str40, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str41, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str42, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str43, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str44, 6, "infixr");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_str45, 5, "infix");
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit46, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str45), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit47, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str44), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit46));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit48, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str43), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit47));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit49, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str42), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit48));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit50, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str41), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit49));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit51, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str40), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit50));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit52, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str39), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit51));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit53, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str38), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit52));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit54, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str37), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit53));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit55, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str36), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit54));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit56, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str35), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit55));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit57, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str34), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit56));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit58, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str33), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit57));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit59, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str32), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit58));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit60, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str31), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit59));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit61, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str30), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit60));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit62, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str29), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit61));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit63, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str28), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit62));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit64, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str27), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit63));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit65, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str26), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit64));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit66, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str25), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit65));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit67, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str24), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit66));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit68, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str23), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit67));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit69, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str22), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit68));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit70, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str21), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit69));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit71, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str20), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit70));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit72, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str19), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit71));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit73, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str18), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit72));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit74, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str17), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit73));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit75, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str16), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit74));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit76, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str15), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit75));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit77, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str14), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit76));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit78, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str13), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit77));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit79, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str12), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit78));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit80, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str11), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit79));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit81, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str10), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit80));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit82, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str9), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit81));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit83, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str8), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit82));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit84, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str7), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit83));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit85, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str6), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit84));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit86, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str5), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit85));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit87, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str4), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit86));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit88, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str3), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit87));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit89, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str2), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit88));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit90, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str1), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit89));
HEFF_TAG_LIT(g_heff_2esyntax_2efmt_2elex_2ekeywords_lit91, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_str0), ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit90));

static V g_heff_2esyntax_2efmt_2elex_2ekeywords_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elex_2ekeywords_st;
static V g_heff_2esyntax_2efmt_2elex_2ekeywords_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elex_2ekeywords_lit91);
}
V g_heff_2esyntax_2efmt_2elex_2ekeywords_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elex_2ekeywords_st)) return g_heff_2esyntax_2efmt_2elex_2ekeywords_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elex_2ekeywords_val, &g_heff_2esyntax_2efmt_2elex_2ekeywords_st, g_heff_2esyntax_2efmt_2elex_2ekeywords_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2esymChars_str0, 20, "!#$%&*+./<=>\?@\\^|-~:");

static V g_heff_2esyntax_2efmt_2elex_2esymChars_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elex_2esymChars_st;
static V g_heff_2esyntax_2efmt_2elex_2esymChars_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elex_2esymChars_str0);
}
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elex_2esymChars_st)) return g_heff_2esyntax_2efmt_2elex_2esymChars_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elex_2esymChars_val, &g_heff_2esyntax_2efmt_2elex_2esymChars_st, g_heff_2esyntax_2efmt_2elex_2esymChars_init);
}
Clo g_heff_2esyntax_2efmt_2elex_2enameEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enameEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enameEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if ((((((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (heff_peek_word(v_c_242) == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL)))) || (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || (heff_peek_word(v_c_242) == ((int64_t)39ULL))))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)47ULL))) {
      V v_c_243 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2);
      if (((((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)122ULL))) || (heff_peek_word(v_c_243) == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)90ULL))))) {
        heff_drop(v_c_243);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        heff_drop(v_c_243);
        return v_j_241;
      }
    } else {
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2enameEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2enameEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2eplainEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eplainEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eplainEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if ((((((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (heff_peek_word(v_c_242) == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL)))) || (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || (heff_peek_word(v_c_242) == ((int64_t)39ULL))))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2eplainEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eplainEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL)))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)95ULL))) {
      V v_c_243 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2);
      if (((((int64_t)48ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)57ULL)))) {
        heff_drop(v_c_243);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        heff_drop(v_c_243);
        return v_j_241;
      }
    } else {
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V v_s_240, V v_j_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)45ULL))) {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edashesEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V v_s_240, V v_j_241) {
top: ;
  if ((heff_intLt_c_lent(v_j_241, heff_strLength_lent(v_s_240, 0), 2) && !(heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL)))) {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eeolEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2esymEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2esymEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2esymEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  V v_t_244 = heff_bool(((((int64_t)0ULL) <= heff_peek_word(v_c_242)) && ({ V v_t_243 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_dup(v_c_242)))); int c_ = ({ V v_t_245 = heff_strFind(heff_dup(v_t_243), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)); int c_ = heff_intLe_c_lent(MK_INT(0LL), v_t_245, 1); heff_drop(v_t_245); c_; }); heff_drop(v_t_243); c_; })));
  heff_drop(v_c_242);
  if (((heff_dup(v_t_244) == NTAG(TAG_True)) && ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)45ULL)) ? !(heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2)) == ((int64_t)45ULL)) : 1))) {
    heff_drop(v_t_244);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_t_244);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2esymEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2esymEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2enumFrac_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enumFrac_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enumFrac(V v_s_240, V v_a_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_a_241, 0)) == ((int64_t)46ULL))) {
    V v_c_242 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_a_241, MK_INT(1LL), 2), 2);
    if (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL)))) {
      heff_drop(v_c_242);
      V v_s_243 = heff_dup(v_s_240);
      V v_b_244 = ({ V a_0 = v_s_240; V a_1 = heff_intAdd(v_a_241, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(a_0, a_1)); heff_drop(v_s_240); r_; });
      if (((heff_unbox_word(heff_strByteAt_lent(v_s_243, v_b_244, 0)) == ((int64_t)101ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_243, v_b_244, 0)) == ((int64_t)69ULL)))) {
        V v_c_245 = heff_strByteAt_lent(v_s_243, heff_intAdd_lent(v_b_244, MK_INT(1LL), 2), 2);
        if (((((int64_t)48ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)57ULL)))) {
          heff_drop(v_c_245);
          V v_t_246 = ({ V a_0 = v_s_243; V a_1 = heff_intAdd(v_b_244, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(a_0, a_1)); heff_drop(v_s_243); r_; });
          return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_246, NTAG(TAG_True)});
        } else {
          heff_drop(v_c_245);
          V v_t_247 = heff_strByteAt_lent(v_s_243, heff_intAdd_lent(v_b_244, MK_INT(1LL), 2), 2);
          if (((heff_peek_word(v_t_247) == ((int64_t)43ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_243, heff_intAdd_lent(v_b_244, MK_INT(1LL), 2), 2)) == ((int64_t)45ULL)))) {
            heff_drop(v_t_247);
            V v_c_248 = heff_strByteAt_lent(v_s_243, heff_intAdd_lent(v_b_244, MK_INT(2LL), 2), 2);
            if (((((int64_t)48ULL) <= heff_peek_word(v_c_248)) && (heff_peek_word(v_c_248) <= ((int64_t)57ULL)))) {
              heff_drop(v_c_248);
              V v_t_249 = ({ V a_0 = v_s_243; V a_1 = heff_intAdd(v_b_244, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(a_0, a_1)); heff_drop(v_s_243); r_; });
              return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_249, NTAG(TAG_True)});
            } else {
              heff_drop(v_s_243);
              heff_drop(v_c_248);
              return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_244, NTAG(TAG_True)});
            }
          } else {
            heff_drop(v_s_243);
            heff_drop(v_t_247);
            return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_244, NTAG(TAG_True)});
          }
        }
      } else {
        heff_drop(v_s_243);
        return heff_rec_n(2, shape_end__isFloat, (V[]){v_b_244, NTAG(TAG_True)});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_c_242);
      return heff_rec_n(2, shape_end__isFloat, (V[]){v_a_241, NTAG(TAG_False)});
    }
  } else {
    heff_drop(v_s_240);
    return heff_rec_n(2, shape_end__isFloat, (V[]){v_a_241, NTAG(TAG_False)});
  }
}
V g_heff_2esyntax_2efmt_2elex_2enumFrac_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2enumFrac(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if ((((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)102ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)70ULL)))))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)95ULL))) {
      V v_c_243 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2);
      if ((((((int64_t)48ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)57ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)102ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)70ULL)))))) {
        heff_drop(v_c_243);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        heff_drop(v_c_243);
        return v_j_241;
      }
    } else {
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s1528547454x853005061_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s1528547454x853005061_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s1528547454x853005061(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)55ULL)))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)95ULL))) {
      V v_c_243 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2);
      if (((((int64_t)48ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)55ULL)))) {
        heff_drop(v_c_243);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        heff_drop(v_c_243);
        return v_j_241;
      }
    } else {
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s1528547454x853005061_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s1528547454x853005061(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if (((heff_peek_word(v_c_242) == ((int64_t)48ULL)) || (heff_peek_word(v_c_242) == ((int64_t)49ULL)))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)95ULL))) {
      V v_c_243 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2);
      if (((heff_peek_word(v_c_243) == ((int64_t)48ULL)) || (heff_peek_word(v_c_243) == ((int64_t)49ULL)))) {
        heff_drop(v_c_243);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      } else {
        heff_drop(v_c_243);
        return v_j_241;
      }
    } else {
      return v_j_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2enumFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2enumFrom_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2enumFrom(V v_s_240, V v_j_241) {
top: ;
  V v_t_244;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)48ULL))) {
    V v_t_242 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2);
    if (((heff_peek_word(v_t_242) == ((int64_t)120ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2)) == ((int64_t)88ULL)))) {
      heff_drop(v_t_242);
      V v_c_243 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(2LL), 2), 2);
      v_t_244 = heff_bool((((((int64_t)48ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)57ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)102ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)70ULL))))));
      heff_drop(v_c_243);
    } else {
      heff_drop(v_t_242);
      v_t_244 = NTAG(TAG_False);
    }
  } else {
    v_t_244 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = ({ V a_0 = v_s_240; V a_1 = heff_intAdd(v_j_241, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s220248506x548376025(a_0, a_1)); heff_drop(v_s_240); r_; });
    return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_245, NTAG(TAG_False)});
  } else {
    heff_drop(v_t_244);
    V v_t_248;
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)48ULL))) {
      V v_t_246 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2);
      if (((heff_peek_word(v_t_246) == ((int64_t)111ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2)) == ((int64_t)79ULL)))) {
        heff_drop(v_t_246);
        V v_c_247 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(2LL), 2), 2);
        v_t_248 = heff_bool(((((int64_t)48ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)55ULL))));
        heff_drop(v_c_247);
      } else {
        heff_drop(v_t_246);
        v_t_248 = NTAG(TAG_False);
      }
    } else {
      v_t_248 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = ({ V a_0 = v_s_240; V a_1 = heff_intAdd(v_j_241, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s1528547454x853005061(a_0, a_1)); heff_drop(v_s_240); r_; });
      return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_249, NTAG(TAG_False)});
    } else {
      heff_drop(v_t_248);
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)48ULL))) {
        V v_t_2410 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2);
        if (((heff_peek_word(v_t_2410) == ((int64_t)98ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2)) == ((int64_t)66ULL)))) {
          heff_drop(v_t_2410);
          V v_c_2411 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(2LL), 2), 2);
          if (((heff_peek_word(v_c_2411) == ((int64_t)48ULL)) || (heff_peek_word(v_c_2411) == ((int64_t)49ULL)))) {
            heff_drop(v_c_2411);
            V v_t_2412 = ({ V a_0 = v_s_240; V a_1 = heff_intAdd(v_j_241, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s326261749x1133775504(a_0, a_1)); heff_drop(v_s_240); r_; });
            return heff_rec_n(2, shape_end__isFloat, (V[]){v_t_2412, NTAG(TAG_False)});
          } else {
            heff_drop(v_c_2411);
            V v_t_2413 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_j_241, MK_INT(1LL))));
            HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumFrac(v_s_240, v_t_2413);
          }
        } else {
          heff_drop(v_t_2410);
          V v_t_2414 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_j_241, MK_INT(1LL))));
          HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumFrac(v_s_240, v_t_2414);
        }
      } else {
        V v_t_2415 = (g_heff_2esyntax_2efmt_2elex_2edigitsBy_24s336139560x479052132(v_s_240, heff_intAdd(v_j_241, MK_INT(1LL))));
        HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2enumFrac(v_s_240, v_t_2415);
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2enumFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2enumFrom(a[0], a[1]);
}
HEFF_REC_LIT(g_heff_2esyntax_2efmt_2elex_2enoCode_lit0, 3, shape_ok__end__code, NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL));

static V g_heff_2esyntax_2efmt_2elex_2enoCode_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elex_2enoCode_st;
static V g_heff_2esyntax_2efmt_2elex_2enoCode_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elex_2enoCode_lit0);
}
V g_heff_2esyntax_2efmt_2elex_2enoCode_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elex_2enoCode_st)) return g_heff_2esyntax_2efmt_2elex_2enoCode_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elex_2enoCode_val, &g_heff_2esyntax_2efmt_2elex_2enoCode_st, g_heff_2esyntax_2efmt_2elex_2enoCode_init);
}
Clo g_heff_2esyntax_2efmt_2elex_2ehexValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2ehexValue_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elex_2ehexValue(V v_s_240, V v_j_241, V v_e_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(v_e_242, v_j_241, 0)) {
    heff_drop(v_j_241);
    heff_drop(v_e_242);
    return v_acc_243;
  } else {
    V v_c_244 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
    int64_t v_t_245;
    if (((((int64_t)48ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)57ULL)))) {
      v_t_245 = (heff_unbox_word(v_c_244) - ((int64_t)48ULL));
    } else {
      if ((((int64_t)97ULL) <= heff_peek_word(v_c_244))) {
        v_t_245 = (heff_unbox_word(v_c_244) - ((int64_t)87ULL));
      } else {
        v_t_245 = (heff_unbox_word(v_c_244) - ((int64_t)55ULL));
      }
    }
    V v_t_246 = heff_intAdd(heff_intMul(v_acc_243, MK_INT(16LL)), heff_box_word(v_t_245));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    V t_2 = v_e_242;
    V t_3 = v_t_246;
    v_s_240 = t_0;
    v_j_241 = t_1;
    v_e_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
}
V g_heff_2esyntax_2efmt_2elex_2ehexValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2ehexValue(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_j_241, 0);
  if ((((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)102ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)70ULL)))))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    return v_j_241;
  }
}
V g_heff_2esyntax_2efmt_2elex_2ehexRunEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2eescAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eescAt_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eescAt(V v_s_240, V v_j_241) {
top: ;
  if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)117ULL)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2)) == ((int64_t)123ULL)))) {
    V v_s_242 = heff_dup(v_s_240);
    V v_j_243 = heff_dup(v_j_241);
    V v_e_244 = ({ V a_0 = v_s_240; V a_1 = heff_intAdd(v_j_241, MK_INT(2LL)); V r_ = (g_heff_2esyntax_2efmt_2elex_2ehexRunEnd(a_0, a_1)); heff_drop(v_s_240); r_; });
    if ((heff_intLt_c_lent(heff_intAdd_lent(v_j_243, MK_INT(2LL), 2), v_e_244, 1) && (heff_unbox_word(heff_strByteAt_lent(v_s_242, v_e_244, 0)) == ((int64_t)125ULL)))) {
      V v_t_245 = ({ V a_0 = v_s_242; V a_1 = heff_intAdd(v_j_243, MK_INT(2LL)); V a_2 = heff_dup(v_e_244); V a_3 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elex_2ehexValue(a_0, a_1, a_2, a_3)); heff_drop(v_s_242); r_; });
      return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_e_244, MK_INT(1LL)), v_t_245});
    } else {
      heff_drop(v_s_242);
      heff_drop(v_e_244);
      return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_j_243, MK_INT(1LL)), MK_INT(117LL)});
    }
  } else {
    if ((heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_j_241, 1) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL)))) {
      heff_drop(v_s_240);
      heff_drop(v_j_241);
      return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
    } else {
      HeffT2 v_t_246 = heff_strRuneDecode_lent(v_s_240, v_j_241, 1);
      {
        V v_rune_247 = v_t_246.f[0];
        V v_width_248 = v_t_246.f[1];
        V v_c_249 = heff_runeToInt(v_rune_247);
        V v_t_2410;
        if (heff_intEq_c_lent(v_c_249, MK_INT(110LL), 2)) {
          heff_drop(v_c_249);
          v_t_2410 = MK_INT(10LL);
        } else {
          if (heff_intEq_c_lent(v_c_249, MK_INT(116LL), 2)) {
            heff_drop(v_c_249);
            v_t_2410 = MK_INT(9LL);
          } else {
            if (heff_intEq_c_lent(v_c_249, MK_INT(114LL), 2)) {
              heff_drop(v_c_249);
              v_t_2410 = MK_INT(13LL);
            } else {
              v_t_2410 = v_c_249;
            }
          }
        }
        V v_t_2411 = heff_intAdd(v_j_241, v_width_248);
        return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), v_t_2411, v_t_2410});
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2eescAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eescAt(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str0, 16, "0123456789ABCDEF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str1, 19, " is beyond U+10FFFF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str2, 15, " is a surrogate");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str3, 39, "a `\\u{...}` is a Unicode scalar value: ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str4, 2, "U+");

HeffT4 g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr(V v_s_240, V v_j_241, V v_acc_242, V v_bad_243) {
top: ;
  if ((heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_j_241, 1) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL)))) {
    heff_drop(v_s_240);
    return ((HeffT4){{v_j_241, v_acc_242, NTAG(TAG_False), v_bad_243}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)34ULL))) {
      heff_drop(v_s_240);
      return ((HeffT4){{v_j_241, v_acc_242, NTAG(TAG_True), v_bad_243}});
    } else {
      V v_t_248;
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)92ULL))) {
        V v_s_244 = heff_dup(v_s_240);
        V v_j_245 = heff_intAdd_lent(v_j_241, MK_INT(1LL), 2);
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_244, v_j_245, 0)) == ((int64_t)120ULL))) {
          V v_c_246 = heff_strByteAt_lent(v_s_244, heff_intAdd_lent(v_j_245, MK_INT(1LL), 2), 2);
          if ((((((int64_t)48ULL) <= heff_peek_word(v_c_246)) && (heff_peek_word(v_c_246) <= ((int64_t)57ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_c_246)) && (heff_peek_word(v_c_246) <= ((int64_t)102ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_246)) && (heff_peek_word(v_c_246) <= ((int64_t)70ULL)))))) {
            heff_drop(v_c_246);
            V v_c_247 = heff_strByteAt(v_s_244, heff_intAdd(v_j_245, MK_INT(2LL)));
            v_t_248 = heff_bool((((((int64_t)48ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)57ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)102ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)70ULL))))));
            heff_drop(v_c_247);
          } else {
            heff_drop(v_s_244);
            heff_drop(v_j_245);
            heff_drop(v_c_246);
            v_t_248 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_s_244);
          heff_drop(v_j_245);
          v_t_248 = NTAG(TAG_False);
        }
      } else {
        v_t_248 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_t_249 = (g_heff_2esyntax_2efmt_2elex_2ehexValue(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(2LL), 2), heff_intAdd_lent(v_j_241, MK_INT(4LL), 2), MK_INT(0LL)));
        V v_t_2410 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_t_249)));
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(4LL));
        V t_2 = heff_strAppend(v_acc_242, v_t_2410);
        V t_3 = v_bad_243;
        v_s_240 = t_0;
        v_j_241 = t_1;
        v_acc_242 = t_2;
        v_bad_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_248);
        if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)92ULL)) && heff_intLt_c(heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), heff_strLength_lent(v_s_240, 0)))) {
          V v_k_2411 = heff_intAdd_lent(v_j_241, MK_INT(1LL), 2);
          V v_e_2412 = (g_heff_2esyntax_2efmt_2elex_2eescAt(heff_dup(v_s_240), heff_intAdd_lent(v_j_241, MK_INT(1LL), 2)));
          V v_t_2413 = heff_dup(heff_rfield(v_e_2412, 0));
          V v_e_2414;
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_k_2411);
            heff_drop(v_t_2413);
            v_e_2414 = v_e_2412;
          } else {
            heff_drop(v_t_2413);
            v_e_2414 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = heff_intAdd_lent(v_k_2411, MK_INT(1LL), 2); V rv_2 = heff_strByteAt_lent(v_s_240, v_k_2411, 2); V rr_ = heff_rec_reuse_nf(v_e_2412, 0ULL, 3, shape_ok__end__code, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          }
          V v_c_2415 = heff_dup(heff_rfield(v_e_2414, 2));
          V v_t_2416;
          if ((heff_intLe_c_lent(MK_INT(0LL), v_c_2415, 1) && (heff_intLe_c_lent(v_c_2415, MK_INT(1114111LL), 2) && ((((int64_t)55296ULL) <= heff_peek_word(v_c_2415)) ? !(heff_peek_word(v_c_2415) <= ((int64_t)57343ULL)) : 1)))) {
            v_t_2416 = v_c_2415;
          } else {
            heff_drop(v_c_2415);
            v_t_2416 = MK_INT(65533LL);
          }
          V v_x1_2417 = v_bad_243;
          V v_j_2418 = v_j_241;
          V v_e_2419 = heff_dup(v_e_2414);
          V v_code_2420 = heff_take_field(v_e_2419, 2);
          V v_end_2421 = heff_get_n(v_e_2419, 1, 3);
          V v_t_2430;
          switch (heff_tag_of(v_x1_2417)) {
          case TAG_Nothing: {
            V v_c_2422 = heff_dup(v_code_2420);
            if ((heff_intLe_c_lent(MK_INT(0LL), v_c_2422, 1) && (heff_intLe_c_lent(v_c_2422, MK_INT(1114111LL), 2) && ((((int64_t)55296ULL) <= heff_peek_word(v_c_2422)) ? !(heff_peek_word(v_c_2422) <= ((int64_t)57343ULL)) : 1)))) {
              heff_drop(v_j_2418);
              heff_drop(v_code_2420);
              heff_drop(v_end_2421);
              heff_drop(v_c_2422);
              v_t_2430 = NTAG(TAG_Nothing);
            } else {
              heff_drop(v_c_2422);
              V v_c_2423 = v_code_2420;
              V v_t_2424 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str0); V a_1 = heff_dup(v_c_2423); V r_ = (g_heff_2eutil_2erune_2ehexWith(b_0, a_1)); heff_drop(b_0); r_; });
              V v_t_2425 = (g_heff_2eutil_2erune_2epadTo4(v_t_2424));
              V v_t_2426;
              if (heff_intLt_c(MK_INT(1114111LL), v_c_2423)) {
                v_t_2426 = ((V)&g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str1);
              } else {
                v_t_2426 = ((V)&g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str2);
              }
              V v_t_2427 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str3), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr_str4), v_t_2425));
              V v_t_2428 = heff_rec_n(3, shape_start__end__msg, (V[]){v_j_2418, v_end_2421, heff_strAppend(v_t_2427, v_t_2426)});
              v_t_2430 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2428});
            }
            break;
          }
          case TAG_Just: {
            V v_b_2429 = heff_field(v_x1_2417, 0);
            V v_ru_24x1_2417_24Just = heff_take_reuse_n(v_x1_2417, 1ULL, 1);
            heff_drop(v_j_2418);
            heff_drop(v_code_2420);
            heff_drop(v_end_2421);
            v_t_2430 = heff_tag_re_n(v_ru_24x1_2417_24Just, TAG_Just, 1, 1ULL, (V[]){v_b_2429});
            break;
          }
          default: heff_nomatch(v_x1_2417);
          }
          V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_t_2416), NTAG(TAG_Nil)});
          V v_t_2432 = heff_strAppend(v_acc_242, heff_strOfRunes(v_t_2431));
          V t_0 = v_s_240;
          V t_1 = heff_get_n(v_e_2414, 1, 3);
          V t_2 = v_t_2432;
          V t_3 = v_t_2430;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_acc_242 = t_2;
          v_bad_243 = t_3;
          goto top;
        } else {
          V v_t_2433 = heff_strSlice_lent(v_s_240, v_j_241, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 4);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_2 = heff_strAppend(v_acc_242, v_t_2433);
          V t_3 = v_bad_243;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_acc_242 = t_2;
          v_bad_243 = t_3;
          goto top;
        }
      }
    }
  }
}
Clo g_heff_2esyntax_2efmt_2elex_2eruneScan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eruneScan_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eruneScan(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2);
  if ((heff_unbox_word(v_t_242) == ((int64_t)92ULL))) {
    V v_e_243 = (g_heff_2esyntax_2efmt_2elex_2eescAt(heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(2LL))));
    V v_t_244 = heff_take_field(v_e_243, 0);
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_j_245 = heff_take_field(v_e_243, 1);
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_245, 1)) == ((int64_t)39ULL))) {
        return ({ V rv_0 = NTAG(TAG_True); V rv_1 = heff_intAdd(v_j_245, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_e_243, 4ULL, 3, shape_ok__end__code, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      } else {
        heff_drop_rec(v_e_243, 3);
        heff_drop(v_j_245);
        return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
      }
    } else {
      heff_drop(v_s_240);
      heff_drop_rec(v_e_243, 3);
      heff_drop(v_t_244);
      return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
    }
  } else {
    if ((heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd_lent(v_i_241, MK_INT(1LL), 2)) || ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2)) == ((int64_t)39ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2)) == ((int64_t)10ULL))))) {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
    } else {
      HeffT2 v_t_246 = heff_strRuneDecode_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2);
      {
        V v_rune_247 = v_t_246.f[0];
        V v_width_248 = v_t_246.f[1];
        V v_j_249 = heff_intAdd(heff_intAdd(v_i_241, MK_INT(1LL)), v_width_248);
        V v_c_2410 = heff_runeToInt(v_rune_247);
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_249, 1)) == ((int64_t)39ULL))) {
          return heff_rec_n(3, shape_ok__end__code, (V[]){NTAG(TAG_True), heff_intAdd(v_j_249, MK_INT(1LL)), v_c_2410});
        } else {
          heff_drop(v_j_249);
          heff_drop(v_c_2410);
          return heff_dup(g_heff_2esyntax_2efmt_2elex_2enoCode_get());
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2eruneScan_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2eruneScan(a[0], a[1]);
}

HeffT5 g_heff_2esyntax_2efmt_2elex_2eblockScan_24cpr(V v_s_240, V v_j_241, V v_depth_242, V v_line_243, V v_lineStart_244, V v_first_245) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_j_241, 1)) {
    heff_drop(v_depth_242);
    return ((HeffT5){{v_j_241, v_line_243, v_lineStart_244, v_first_245, NTAG(TAG_False)}});
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)123ULL)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2)) == ((int64_t)45ULL)))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
      V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
      V t_3 = v_line_243;
      V t_4 = v_lineStart_244;
      V t_5 = v_first_245;
      v_s_240 = t_0;
      v_j_241 = t_1;
      v_depth_242 = t_2;
      v_line_243 = t_3;
      v_lineStart_244 = t_4;
      v_first_245 = t_5;
      goto top;
    } else {
      if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)45ULL)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_241, MK_INT(1LL), 2), 2)) == ((int64_t)125ULL)))) {
        if (heff_intEq_c_lent(v_depth_242, MK_INT(1LL), 2)) {
          heff_drop(v_depth_242);
          V v_f_246 = heff_intAdd(v_j_241, MK_INT(2LL));
          return ((HeffT5){{v_f_246, v_line_243, v_lineStart_244, v_first_245, NTAG(TAG_True)}});
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
          V t_2 = heff_intSub(v_depth_242, MK_INT(1LL));
          V t_3 = v_line_243;
          V t_4 = v_lineStart_244;
          V t_5 = v_first_245;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        }
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)10ULL))) {
          heff_drop(v_lineStart_244);
          heff_drop(v_first_245);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd_lent(v_j_241, MK_INT(1LL), 2);
          V t_2 = v_depth_242;
          V t_3 = heff_intAdd(v_line_243, MK_INT(1LL));
          V t_4 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_5 = NTAG(TAG_True);
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_2 = v_depth_242;
          V t_3 = v_line_243;
          V t_4 = v_lineStart_244;
          V t_5 = v_first_245;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str2, 3, "int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str3, 5, "float");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str4, 3, "str");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str5, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str6, 5, "field");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str7, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str9, 1, "]");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str10, 1, "}");
Clo g_heff_2esyntax_2efmt_2elex_2eoperandBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eoperandBefore_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2eoperandBefore(V v_x1_240, V v_start_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_start_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_end_244 = heff_dup(heff_rfield(v_t_242, 3));
    V v_kind_245 = heff_dup(heff_rfield(v_t_242, 0));
    V v_text_246 = heff_dup(heff_rfield(v_t_242, 1));
    V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_end_244, v_start_241, 0) && ((heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str0), 2) || (heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str1), 2) || (heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str2), 2) || (heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str3), 2) || (heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str4), 2) || (heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str5), 2) || heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str6), 2))))))) || (heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str7), 2) && (heff_strEq_c_lent(v_text_246, ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str8), 2) || (heff_strEq_c_lent(v_text_246, ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str9), 2) || heff_strEq_c_lent(v_text_246, ((V)&g_heff_2esyntax_2efmt_2elex_2eoperandBefore_str10), 2)))))));
    heff_drop(v_start_241);
    heff_drop(v_end_244);
    heff_drop(v_kind_245);
    heff_drop(v_text_246);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elex_2eoperandBefore_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eoperandBefore(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elex_2estartsDelayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2estartsDelayed_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elex_2estartsDelayed(V v_src_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_src_240, v_j_241, 0);
  if ((((((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (heff_peek_word(v_c_242) == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL)))) || (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || ((heff_peek_word(v_c_242) == ((int64_t)40ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)91ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)34ULL)) || (heff_peek_word(v_c_242) == ((int64_t)39ULL)))))))) {
    heff_drop(v_j_241);
    heff_drop(v_c_242);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_c_242);
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_j_241, 0)) == ((int64_t)126ULL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_j_241 = t_1;
      goto top;
    } else {
      heff_drop(v_j_241);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2estartsDelayed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2estartsDelayed(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str0, 16, "0123456789ABCDEF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str1, 19, " is beyond U+10FFFF");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str2, 15, " is a surrogate");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str3, 42, "a rune literal is a Unicode scalar value: ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str4, 2, "U+");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2eruneStep_str5, 4, "rune");
Clo g_heff_2esyntax_2efmt_2elex_2eruneStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2eruneStep_entry, 6, 0};

V g_heff_2esyntax_2efmt_2elex_2eruneStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_r_245) {
top: ;
  V v_end_246 = heff_take_field(v_r_245, 1);
  V v_code_247 = heff_get_n(v_r_245, 2, 3);
  V v_j_248 = heff_dup(v_end_246);
  V v_t_249 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, heff_dup(v_i_241), heff_dup(v_j_248), MK_INT(0LL)));
  V v_c_2410 = heff_dup(v_code_247);
  V v_col_2411 = heff_intSub_lent(v_i_241, v_lineStart_243, 0);
  V v_t_2412;
  if ((heff_intLe_c_lent(MK_INT(0LL), v_c_2410, 1) && (heff_intLe_c_lent(v_c_2410, MK_INT(1114111LL), 2) && ((((int64_t)55296ULL) <= heff_peek_word(v_c_2410)) ? !(heff_peek_word(v_c_2410) <= ((int64_t)57343ULL)) : 1)))) {
    v_t_2412 = v_c_2410;
  } else {
    heff_drop(v_c_2410);
    v_t_2412 = MK_INT(65533LL);
  }
  V v_c_2413 = heff_dup(v_code_247);
  V v_t_2420;
  if ((heff_intLe_c_lent(MK_INT(0LL), v_c_2413, 1) && (heff_intLe_c_lent(v_c_2413, MK_INT(1114111LL), 2) && ((((int64_t)55296ULL) <= heff_peek_word(v_c_2413)) ? !(heff_peek_word(v_c_2413) <= ((int64_t)57343ULL)) : 1)))) {
    heff_drop(v_code_247);
    heff_drop(v_c_2413);
    v_t_2420 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_c_2413);
    V v_c_2414 = v_code_247;
    V v_t_2415 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str0); V a_1 = heff_dup(v_c_2414); V r_ = (g_heff_2eutil_2erune_2ehexWith(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2416 = (g_heff_2eutil_2erune_2epadTo4(v_t_2415));
    V v_t_2417;
    if (heff_intLt_c(MK_INT(1114111LL), v_c_2414)) {
      v_t_2417 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str1);
    } else {
      v_t_2417 = ((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str2);
    }
    V v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str3), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str4), v_t_2416));
    V v_t_2419 = heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_241), heff_dup(v_end_246), heff_strAppend(v_t_2418, v_t_2417)});
    v_t_2420 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
  }
  V v_t_2421 = heff_intAdd(v_lineStart_243, heff_intSub_lent(v_j_248, v_i_241, 1));
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_t_2412), NTAG(TAG_Nil)});
  V v_t_2423 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2eruneStep_str5), heff_strOfRunes(v_t_2422), v_i_241, heff_dup(v_end_246), heff_dup(v_line_242), v_col_2411, v_first_244});
  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_end_246, v_line_242, heff_intSub(v_t_2421, v_t_249), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2423}), v_t_2420, NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2efmt_2elex_2eruneStep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elex_2eruneStep(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str0, 6, "-- >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str1, 5, "watch");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str2, 6, "-- >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str3, 8, "-- | >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str4, 7, "doctest");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str5, 8, "-- | >>>");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str6, 30, "a `{-` comment is never closed");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str7, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str8, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str9, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str10, 3, "con");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str11, 3, "var");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str12, 3, "var");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str13, 3, "con");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str14, 3, "int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str15, 5, "float");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str16, 3, "str");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str17, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str18, 5, "field");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str19, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str20, 1, ")");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str21, 1, "]");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str22, 1, "}");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str23, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str24, 5, "field");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str25, 5, "float");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str26, 3, "int");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str27, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str28, 1, "-");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str29, 4, "lazy");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str30, 1, "~");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str31, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str32, 24, "a string is never closed");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str33, 3, "str");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str34, 7, "()[]{},");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str35, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str36, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str37, 21, "unexpected character ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2estepAt_str38, 21, "unexpected character ");
Clo g_heff_2esyntax_2efmt_2elex_2estepAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2estepAt_entry, 7, 0};

V g_heff_2esyntax_2efmt_2elex_2estepAt(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_toks_245, V v_box_24c_246) {
  int64_t v_c_246 = heff_unbox_word(v_box_24c_246);
top: ;
  if ((v_c_246 == ((int64_t)10ULL))) {
    heff_drop(v_src_240);
    heff_drop(v_lineStart_243);
    heff_drop(v_first_244);
    heff_drop(v_toks_245);
    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), heff_intAdd(v_line_242, MK_INT(1LL)), heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  } else {
    if (((v_c_246 == ((int64_t)32ULL)) || ((v_c_246 == ((int64_t)9ULL)) || (v_c_246 == ((int64_t)13ULL))))) {
      heff_drop(v_src_240);
      heff_drop(v_toks_245);
      return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    } else {
      if (((v_c_246 == ((int64_t)45ULL)) && heff_strEq_c(heff_strSlice_lent(v_src_240, v_i_241, heff_intAdd_lent(v_i_241, MK_INT(6LL), 2), 4), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str0)))) {
        heff_drop(v_src_240);
        heff_drop(v_toks_245);
        V v_end_247 = heff_intAdd_lent(v_i_241, MK_INT(6LL), 2);
        V v_col_248 = heff_intSub_lent(v_i_241, v_lineStart_243, 0);
        V v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str1), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str2), heff_dup(v_i_241), v_end_247, heff_dup(v_line_242), v_col_248, v_first_244})});
        return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(6LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), v_t_249, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      } else {
        if (((v_c_246 == ((int64_t)45ULL)) && heff_strEq_c(heff_strSlice_lent(v_src_240, v_i_241, heff_intAdd_lent(v_i_241, MK_INT(8LL), 2), 4), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str3)))) {
          heff_drop(v_src_240);
          heff_drop(v_toks_245);
          V v_end_2410 = heff_intAdd_lent(v_i_241, MK_INT(8LL), 2);
          V v_col_2411 = heff_intSub_lent(v_i_241, v_lineStart_243, 0);
          V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str4), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str5), heff_dup(v_i_241), v_end_2410, heff_dup(v_line_242), v_col_2411, v_first_244})});
          return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(8LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), v_t_2412, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        } else {
          V v_t_2418;
          if ((v_c_246 == ((int64_t)45ULL))) {
            V v_t_2413 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(v_src_240, heff_dup(v_i_241)));
            V v_x_2414 = heff_intSub_lent(v_t_2413, v_i_241, 1);
            if (heff_intLe_c(MK_INT(2LL), v_x_2414)) {
              V v_t_2415 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(v_src_240, heff_dup(v_i_241)));
              V v_c_2416 = heff_strByteAt_lent(v_src_240, v_t_2415, 2);
              v_t_2418 = heff_bool(((((int64_t)0ULL) <= heff_peek_word(v_c_2416)) ? ({ V v_t_2417 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_dup(v_c_2416)))); int c_ = ({ V v_t_24142 = heff_strFind(heff_dup(v_t_2417), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)); int c_ = !heff_intLe_c_lent(MK_INT(0LL), v_t_24142, 1); heff_drop(v_t_24142); c_; }); heff_drop(v_t_2417); c_; }) : 1));
              heff_drop(v_c_2416);
            } else {
              v_t_2418 = NTAG(TAG_False);
            }
          } else {
            v_t_2418 = NTAG(TAG_False);
          }
          if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
            heff_drop(v_toks_245);
            heff_drop(v_t_2418);
            V v_e_2419 = (g_heff_2esyntax_2efmt_2elex_2eeolEnd(v_src_240, heff_dup(v_i_241)));
            V v_t_2420 = heff_rec_n(3, shape_start__end__text, (V[]){heff_dup(v_i_241), heff_dup(v_e_2419), heff_strSlice_lent(v_src_240, v_i_241, v_e_2419, 3)});
            return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_e_2419, v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_2420})});
          } else {
            heff_drop(v_t_2418);
            if (((v_c_246 == ((int64_t)123ULL)) && (heff_unbox_word(heff_strByteAt_lent(v_src_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2)) == ((int64_t)45ULL)))) {
              heff_drop(v_toks_245);
              V v_src_2421 = heff_dup(v_src_240);
              V v_i_2422 = heff_dup(v_i_241);
              V v_lineStart_2423 = heff_dup(v_lineStart_243);
              HeffT5 v_t_2424 = ({ V a_0 = v_src_240; V a_1 = v_i_241; V a_2 = MK_INT(0LL); V a_3 = v_line_242; V a_4 = v_lineStart_243; V a_5 = v_first_244; HeffT5 r_ = (g_heff_2esyntax_2efmt_2elex_2eblockScan_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_src_240); r_; });
              {
                V v_field_2425 = v_t_2424.f[0];
                V v_field_2426 = v_t_2424.f[1];
                V v_field_2427 = v_t_2424.f[2];
                V v_field_2428 = v_t_2424.f[3];
                V v_field_2429 = v_t_2424.f[4];
                V v_t_2437;
                if (heff_intEq_c_lent(v_field_2427, v_lineStart_2423, 0)) {
                  heff_drop(v_field_2427);
                  V v_j_2430 = heff_dup(v_field_2425);
                  V v_t_2431 = (g_heff_2eutil_2erune_2erunesGo(v_src_2421, heff_dup(v_i_2422), heff_dup(v_j_2430), MK_INT(0LL)));
                  V v_t_2432 = heff_intAdd(v_lineStart_2423, heff_intSub_lent(v_j_2430, v_i_2422, 1));
                  v_t_2437 = heff_intSub(v_t_2432, v_t_2431);
                } else {
                  heff_drop(v_lineStart_2423);
                  V v_i_2433 = heff_dup(v_field_2427);
                  V v_j_2434 = heff_dup(v_field_2425);
                  V v_t_2435 = (g_heff_2eutil_2erune_2erunesGo(v_src_2421, heff_dup(v_i_2433), heff_dup(v_j_2434), MK_INT(0LL)));
                  V v_t_2436 = heff_intAdd(v_field_2427, heff_intSub(v_j_2434, v_i_2433));
                  v_t_2437 = heff_intSub(v_t_2436, v_t_2435);
                }
                V v_t_2438 = v_field_2429;
                V v_t_2439;
                if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
                  heff_drop(v_t_2438);
                  v_t_2439 = NTAG(TAG_Nothing);
                } else {
                  heff_drop(v_t_2438);
                  v_t_2439 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_2422), heff_dup(v_field_2425), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str6)})});
                }
                V v_t_2440 = heff_rec_n(3, shape_start__end__text, (V[]){heff_dup(v_i_2422), heff_dup(v_field_2425), heff_strSlice_lent(v_src_2421, v_i_2422, v_field_2425, 3)});
                return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_field_2425, v_field_2426, v_t_2437, v_field_2428, NTAG(TAG_Nothing), v_t_2439, heff_tag_n(TAG_Just, 1, (V[]){v_t_2440})});
              }
            } else {
              if (((v_c_246 == ((int64_t)98ULL)) && (heff_unbox_word(heff_strByteAt_lent(v_src_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2)) == ((int64_t)91ULL)))) {
                heff_drop(v_src_240);
                heff_drop(v_toks_245);
                V v_end_2441 = heff_intAdd_lent(v_i_241, MK_INT(2LL), 2);
                V v_col_2442 = heff_intSub_lent(v_i_241, v_lineStart_243, 0);
                V v_t_2443 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str7), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str8), heff_dup(v_i_241), v_end_2441, heff_dup(v_line_242), v_col_2442, v_first_244})});
                return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(2LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), v_t_2443, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
              } else {
                if (((((((int64_t)97ULL) <= v_c_246) && (v_c_246 <= ((int64_t)122ULL))) || (v_c_246 == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= v_c_246) && (v_c_246 <= ((int64_t)90ULL))))) {
                  heff_drop(v_toks_245);
                  V v_src_2444 = heff_dup(v_src_240);
                  V v_i_2445 = heff_dup(v_i_241);
                  V v_line_2446 = v_line_242;
                  V v_lineStart_2447 = v_lineStart_243;
                  V v_first_2448 = v_first_244;
                  V v_j_2449 = ({ V a_0 = v_src_240; V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2efmt_2elex_2enameEnd(a_0, a_1)); heff_drop(v_src_240); r_; });
                  V v_c_2450 = heff_strByteAt_lent(v_src_2444, v_i_2445, 0);
                  V v_t_2451 = ({ V b_0 = heff_strSlice_lent(v_src_2444, v_i_2445, v_j_2449, 0); V b_1 = heff_dup(g_heff_2esyntax_2efmt_2elex_2ekeywords_get()); V r_ = (g_list_2eany_24s1006624359x760861690(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
                  V v_kind_2452;
                  if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
                    heff_drop(v_c_2450);
                    heff_drop(v_t_2451);
                    v_kind_2452 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str9);
                  } else {
                    heff_drop(v_t_2451);
                    if (((((int64_t)65ULL) <= heff_peek_word(v_c_2450)) && (heff_peek_word(v_c_2450) <= ((int64_t)90ULL)))) {
                      heff_drop(v_c_2450);
                      v_kind_2452 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str10);
                    } else {
                      heff_drop(v_c_2450);
                      v_kind_2452 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str11);
                    }
                  }
                  V v_col_2453 = heff_intSub_lent(v_i_2445, v_lineStart_2447, 0);
                  V v_t_2454 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){v_kind_2452, heff_strSlice_lent(v_src_2444, v_i_2445, v_j_2449, 1), v_i_2445, heff_dup(v_j_2449), heff_dup(v_line_2446), v_col_2453, v_first_2448});
                  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_j_2449, v_line_2446, v_lineStart_2447, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2454}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                } else {
                  V v_t_2466;
                  if ((v_c_246 == ((int64_t)46ULL))) {
                    V v_c_2455 = heff_strByteAt_lent(v_src_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2);
                    if (((((((int64_t)97ULL) <= heff_peek_word(v_c_2455)) && (heff_peek_word(v_c_2455) <= ((int64_t)122ULL))) || (heff_peek_word(v_c_2455) == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_2455)) && (heff_peek_word(v_c_2455) <= ((int64_t)90ULL))))) {
                      heff_drop(v_c_2455);
                      V v_x1_2456 = heff_dup(v_toks_245);
                      V v_start_2457 = heff_dup(v_i_241);
                      switch (heff_tag_of(v_x1_2456)) {
                      case TAG_Nil: {
                        heff_drop(v_start_2457);
                        v_t_2466 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_Cons: {
                        V v_t_2458 = heff_field(v_x1_2456, 0);
                        heff_take_n(v_x1_2456, 1ULL, 2);
                        V v_lit_2460 = heff_dup(v_t_2458);
                        V v_end_2461 = heff_take_field(v_lit_2460, 3);
                        V v_kind_2462 = heff_take_field(v_lit_2460, 0);
                        V v_text_2463 = heff_get_n(v_lit_2460, 1, 7);
                        V v_start_2464 = heff_dup(v_start_2457);
                        if ((heff_intEq_c_lent(v_end_2461, v_start_2464, 0) && ((heff_strEq_c_lent(v_kind_2462, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str12), 2) || (heff_strEq_c_lent(v_kind_2462, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str13), 2) || (heff_strEq_c_lent(v_kind_2462, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str14), 2) || (heff_strEq_c_lent(v_kind_2462, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str15), 2) || (heff_strEq_c_lent(v_kind_2462, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str16), 2) || (heff_strEq_c_lent(v_kind_2462, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str17), 2) || heff_strEq_c_lent(v_kind_2462, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str18), 2))))))) || (heff_strEq_c_lent(v_kind_2462, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str19), 2) && (heff_strEq_c_lent(v_text_2463, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str20), 2) || (heff_strEq_c_lent(v_text_2463, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str21), 2) || heff_strEq_c_lent(v_text_2463, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str22), 2))))))) {
                          heff_drop(v_start_2457);
                          heff_drop_rec(v_t_2458, 7);
                          heff_drop(v_end_2461);
                          heff_drop(v_kind_2462);
                          heff_drop(v_text_2463);
                          heff_drop(v_start_2464);
                          v_t_2466 = NTAG(TAG_True);
                        } else {
                          heff_drop(v_end_2461);
                          heff_drop(v_kind_2462);
                          heff_drop(v_text_2463);
                          heff_drop(v_start_2464);
                          if (heff_intEq_c(heff_dup(heff_rfield(v_t_2458, 3)), v_start_2457)) {
                            if (heff_strEq_c(heff_dup(heff_rfield(v_t_2458, 0)), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str23))) {
                              V v_c_2465 = heff_strByteAt(heff_get_n(v_t_2458, 1, 7), MK_INT(0LL));
                              v_t_2466 = heff_bool(((((int64_t)65ULL) <= heff_peek_word(v_c_2465)) && (heff_peek_word(v_c_2465) <= ((int64_t)90ULL))));
                              heff_drop(v_c_2465);
                            } else {
                              heff_drop_rec(v_t_2458, 7);
                              v_t_2466 = NTAG(TAG_False);
                            }
                          } else {
                            heff_drop_rec(v_t_2458, 7);
                            v_t_2466 = NTAG(TAG_False);
                          }
                        }
                        break;
                      }
                      default: heff_nomatch(v_x1_2456);
                      }
                    } else {
                      heff_drop(v_c_2455);
                      v_t_2466 = NTAG(TAG_False);
                    }
                  } else {
                    v_t_2466 = NTAG(TAG_False);
                  }
                  if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
                    heff_drop(v_toks_245);
                    heff_drop(v_t_2466);
                    V v_j_2467 = (g_heff_2esyntax_2efmt_2elex_2eplainEnd(v_src_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2)));
                    V v_col_2468 = heff_intSub_lent(v_i_241, v_lineStart_243, 0);
                    V v_t_2469 = heff_strSlice_lent(v_src_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), v_j_2467, 3);
                    V v_t_2470 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str24), v_t_2469, v_i_241, heff_dup(v_j_2467), heff_dup(v_line_242), v_col_2468, v_first_244});
                    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_j_2467, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2470}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                  } else {
                    heff_drop(v_t_2466);
                    V v_t_2473;
                    if (((((int64_t)48ULL) <= v_c_246) && (v_c_246 <= ((int64_t)57ULL)))) {
                      v_t_2473 = NTAG(TAG_True);
                    } else {
                      if ((v_c_246 == ((int64_t)45ULL))) {
                        V v_c_2471 = heff_strByteAt_lent(v_src_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2);
                        if (((((int64_t)48ULL) <= heff_peek_word(v_c_2471)) && (heff_peek_word(v_c_2471) <= ((int64_t)57ULL)))) {
                          heff_drop(v_c_2471);
                          V v_x1_2472 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(v_toks_245, heff_dup(v_i_241)));
                          v_t_2473 = heff_bool(!(heff_dup(v_x1_2472) == NTAG(TAG_True)));
                          heff_drop(v_x1_2472);
                        } else {
                          heff_drop(v_c_2471);
                          v_t_2473 = NTAG(TAG_False);
                        }
                      } else {
                        v_t_2473 = NTAG(TAG_False);
                      }
                    }
                    if ((heff_dup(v_t_2473) == NTAG(TAG_True))) {
                      heff_drop(v_toks_245);
                      heff_drop(v_t_2473);
                      V v_src_2474 = heff_dup(v_src_240);
                      V v_i_2475 = heff_dup(v_i_241);
                      V v_line_2476 = v_line_242;
                      V v_lineStart_2477 = v_lineStart_243;
                      V v_first_2478 = v_first_244;
                      V v_r_2479;
                      if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)45ULL))) {
                        v_r_2479 = (g_heff_2esyntax_2efmt_2elex_2enumFrom(v_src_240, heff_intAdd(v_i_241, MK_INT(1LL))));
                      } else {
                        v_r_2479 = (g_heff_2esyntax_2efmt_2elex_2enumFrom(v_src_240, v_i_241));
                      }
                      V v_isFloat_2480 = heff_take_field(v_r_2479, 1);
                      V v_end_2481 = heff_get_n(v_r_2479, 0, 2);
                      V v_col_2482 = heff_intSub_lent(v_i_2475, v_lineStart_2477, 0);
                      V v_t_2483 = v_isFloat_2480;
                      V v_t_2484;
                      if ((heff_dup(v_t_2483) == NTAG(TAG_True))) {
                        heff_drop(v_t_2483);
                        v_t_2484 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str25);
                      } else {
                        heff_drop(v_t_2483);
                        v_t_2484 = ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str26);
                      }
                      V v_t_2485 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){v_t_2484, heff_strSlice_lent(v_src_2474, v_i_2475, v_end_2481, 1), v_i_2475, heff_dup(v_end_2481), heff_dup(v_line_2476), v_col_2482, v_first_2478});
                      return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_end_2481, v_line_2476, v_lineStart_2477, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_2485}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                    } else {
                      heff_drop(v_t_2473);
                      V v_t_2488;
                      if ((v_c_246 == ((int64_t)45ULL))) {
                        V v_c_2486 = heff_strByteAt_lent(v_src_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2);
                        if ((((((((int64_t)97ULL) <= heff_peek_word(v_c_2486)) && (heff_peek_word(v_c_2486) <= ((int64_t)122ULL))) || (heff_peek_word(v_c_2486) == ((int64_t)95ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_2486)) && (heff_peek_word(v_c_2486) <= ((int64_t)90ULL)))) || (heff_peek_word(v_c_2486) == ((int64_t)40ULL)))) {
                          heff_drop(v_c_2486);
                          V v_x1_2487 = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(v_toks_245, heff_dup(v_i_241)));
                          v_t_2488 = heff_bool(!(heff_dup(v_x1_2487) == NTAG(TAG_True)));
                          heff_drop(v_x1_2487);
                        } else {
                          heff_drop(v_c_2486);
                          v_t_2488 = NTAG(TAG_False);
                        }
                      } else {
                        v_t_2488 = NTAG(TAG_False);
                      }
                      if ((heff_dup(v_t_2488) == NTAG(TAG_True))) {
                        heff_drop(v_src_240);
                        heff_drop(v_toks_245);
                        heff_drop(v_t_2488);
                        V v_end_2489 = heff_intAdd_lent(v_i_241, MK_INT(1LL), 2);
                        V v_col_2490 = heff_intSub_lent(v_i_241, v_lineStart_243, 0);
                        V v_t_2491 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str27), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str28), heff_dup(v_i_241), v_end_2489, heff_dup(v_line_242), v_col_2490, v_first_244})});
                        return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), v_t_2491, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                      } else {
                        heff_drop(v_t_2488);
                        V v_t_2494;
                        if ((v_c_246 == ((int64_t)126ULL))) {
                          V v_t_2492 = (g_heff_2esyntax_2efmt_2elex_2estartsDelayed(v_src_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2)));
                          if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
                            heff_drop(v_t_2492);
                            V v_x1_2493 = ({ V a_0 = v_toks_245; V a_1 = heff_dup(v_i_241); V r_ = (g_heff_2esyntax_2efmt_2elex_2eoperandBefore(a_0, a_1)); heff_drop(v_toks_245); r_; });
                            v_t_2494 = heff_bool(!(heff_dup(v_x1_2493) == NTAG(TAG_True)));
                            heff_drop(v_x1_2493);
                          } else {
                            heff_drop(v_toks_245);
                            heff_drop(v_t_2492);
                            v_t_2494 = NTAG(TAG_False);
                          }
                        } else {
                          heff_drop(v_toks_245);
                          v_t_2494 = NTAG(TAG_False);
                        }
                        if ((heff_dup(v_t_2494) == NTAG(TAG_True))) {
                          heff_drop(v_src_240);
                          heff_drop(v_t_2494);
                          V v_end_2495 = heff_intAdd_lent(v_i_241, MK_INT(1LL), 2);
                          V v_col_2496 = heff_intSub_lent(v_i_241, v_lineStart_243, 0);
                          V v_t_2497 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str29), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str30), heff_dup(v_i_241), v_end_2495, heff_dup(v_line_242), v_col_2496, v_first_244})});
                          return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), v_t_2497, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                        } else {
                          heff_drop(v_t_2494);
                          if ((v_c_246 == ((int64_t)34ULL))) {
                            V v_src_2498 = heff_dup(v_src_240);
                            V v_i_2499 = heff_dup(v_i_241);
                            V v_line_24100 = v_line_242;
                            V v_lineStart_24101 = v_lineStart_243;
                            V v_first_24102 = v_first_244;
                            HeffT4 v_t_24103 = (g_heff_2esyntax_2efmt_2elex_2estrScan_24cpr(v_src_240, heff_intAdd(v_i_241, MK_INT(1LL)), ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str31), NTAG(TAG_Nothing)));
                            {
                              V v_field_24104 = v_t_24103.f[0];
                              V v_field_24105 = v_t_24103.f[1];
                              V v_field_24106 = v_t_24103.f[2];
                              V v_field_24107 = v_t_24103.f[3];
                              V v_t_24108 = heff_dup(v_field_24106);
                              V v_t_24109;
                              if ((heff_dup(v_t_24108) == NTAG(TAG_True))) {
                                heff_drop(v_t_24108);
                                v_t_24109 = heff_intAdd_lent(v_field_24104, MK_INT(1LL), 2);
                              } else {
                                heff_drop(v_t_24108);
                                v_t_24109 = heff_dup(v_field_24104);
                              }
                              V v_t_24110 = heff_dup(v_field_24106);
                              V v_j_24111;
                              if ((heff_dup(v_t_24110) == NTAG(TAG_True))) {
                                heff_drop(v_t_24110);
                                v_j_24111 = heff_intAdd_lent(v_field_24104, MK_INT(1LL), 2);
                              } else {
                                heff_drop(v_t_24110);
                                v_j_24111 = heff_dup(v_field_24104);
                              }
                              V v_t_24112 = ({ V a_0 = v_src_2498; V a_1 = heff_dup(v_i_2499); V a_2 = heff_dup(v_j_24111); V a_3 = MK_INT(0LL); V r_ = (g_heff_2eutil_2erune_2erunesGo(a_0, a_1, a_2, a_3)); heff_drop(v_src_2498); r_; });
                              V v_t_24113 = heff_dup(v_field_24106);
                              V v_end_24114;
                              if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
                                heff_drop(v_t_24113);
                                v_end_24114 = heff_intAdd_lent(v_field_24104, MK_INT(1LL), 2);
                              } else {
                                heff_drop(v_t_24113);
                                v_end_24114 = heff_dup(v_field_24104);
                              }
                              V v_col_24115 = heff_intSub_lent(v_i_2499, v_lineStart_24101, 0);
                              V v_t_24116 = v_field_24106;
                              V v_t_24117;
                              if ((heff_dup(v_t_24116) == NTAG(TAG_True))) {
                                heff_drop(v_field_24104);
                                heff_drop(v_t_24116);
                                v_t_24117 = v_field_24107;
                              } else {
                                heff_drop(v_field_24107);
                                heff_drop(v_t_24116);
                                v_t_24117 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_2499), v_field_24104, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str32)})});
                              }
                              V v_t_24118 = heff_intAdd(v_lineStart_24101, heff_intSub_lent(v_j_24111, v_i_2499, 1));
                              V v_t_24119 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str33), v_field_24105, v_i_2499, v_end_24114, heff_dup(v_line_24100), v_col_24115, v_first_24102})});
                              return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_t_24109, v_line_24100, heff_intSub(v_t_24118, v_t_24112), NTAG(TAG_False), v_t_24119, v_t_24117, NTAG(TAG_Nothing)});
                            }
                          } else {
                            if (((((int64_t)0ULL) <= v_c_246) && ({ V v_t_24120 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_c_246)))); int c_ = ({ V v_t_24143 = heff_strFind_lent(v_t_24120, ((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str34), MK_INT(0LL), 6); int c_ = heff_intLe_c_lent(MK_INT(0LL), v_t_24143, 1); heff_drop(v_t_24143); c_; }); heff_drop(v_t_24120); c_; }))) {
                              V v_t_24121 = heff_strSlice_lent(v_src_240, v_i_241, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 5);
                              V v_t_24122 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str35), v_t_24121, heff_dup(v_i_241), heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), heff_dup(v_line_242), heff_intSub_lent(v_i_241, v_lineStart_243, 0), v_first_244});
                              return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_24122}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                            } else {
                              if (((((int64_t)0ULL) <= v_c_246) && ({ V v_t_24123 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_c_246)))); int c_ = ({ V v_t_24144 = heff_strFind(heff_dup(v_t_24123), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)); int c_ = heff_intLe_c_lent(MK_INT(0LL), v_t_24144, 1); heff_drop(v_t_24144); c_; }); heff_drop(v_t_24123); c_; }))) {
                                V v_j_24124 = (g_heff_2esyntax_2efmt_2elex_2esymEnd(v_src_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2)));
                                V v_col_24125 = heff_intSub_lent(v_i_241, v_lineStart_243, 0);
                                V v_t_24126 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str36), heff_strSlice_lent(v_src_240, v_i_241, v_j_24124, 1), v_i_241, heff_dup(v_j_24124), heff_dup(v_line_242), v_col_24125, v_first_244});
                                return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){v_j_24124, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_t_24126}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                              } else {
                                if ((v_c_246 == ((int64_t)39ULL))) {
                                  V v_src_24127 = heff_dup(v_src_240);
                                  V v_i_24128 = heff_dup(v_i_241);
                                  V v_line_24129 = v_line_242;
                                  V v_lineStart_24130 = v_lineStart_243;
                                  V v_first_24131 = v_first_244;
                                  V v_r_24132 = (g_heff_2esyntax_2efmt_2elex_2eruneScan(v_src_240, v_i_241));
                                  V v_t_24133 = heff_dup(heff_rfield(v_r_24132, 0));
                                  if ((heff_dup(v_t_24133) == NTAG(TAG_True))) {
                                    heff_drop(v_t_24133);
                                    return ({ V a_0 = v_src_24127; V a_1 = v_i_24128; V a_2 = v_line_24129; V a_3 = v_lineStart_24130; V a_4 = v_first_24131; V a_5 = v_r_24132; V r_ = (g_heff_2esyntax_2efmt_2elex_2eruneStep(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_src_24127); r_; });
                                  } else {
                                    heff_drop_rec(v_r_24132, 3);
                                    heff_drop(v_t_24133);
                                    V v_w_24134 = heff_strRuneWidth_lent(v_src_24127, v_i_24128, 0);
                                    V v_t_24135 = heff_intSub(heff_intAdd_lent(v_lineStart_24130, v_w_24134, 1), MK_INT(1LL));
                                    V v_t_24136 = heff_strSlice_lent(v_src_24127, v_i_24128, heff_intAdd_lent(v_i_24128, v_w_24134, 0), 5);
                                    V v_t_24137 = heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_24128), heff_intAdd_lent(v_i_24128, v_w_24134, 0), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str37), v_t_24136)});
                                    return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_24128, v_w_24134), v_line_24129, v_t_24135, v_first_24131, NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_24137}), NTAG(TAG_Nothing)});
                                  }
                                } else {
                                  V v_w_24138 = heff_strRuneWidth_lent(v_src_240, v_i_241, 0);
                                  V v_t_24139 = heff_intSub(heff_intAdd_lent(v_lineStart_243, v_w_24138, 1), MK_INT(1LL));
                                  V v_t_24140 = heff_strSlice_lent(v_src_240, v_i_241, heff_intAdd_lent(v_i_241, v_w_24138, 0), 5);
                                  V v_t_24141 = heff_rec_n(3, shape_start__end__msg, (V[]){heff_dup(v_i_241), heff_intAdd_lent(v_i_241, v_w_24138, 0), heff_strAppend(((V)&g_heff_2esyntax_2efmt_2elex_2estepAt_str38), v_t_24140)});
                                  return heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){heff_intAdd(v_i_241, v_w_24138), v_line_242, v_t_24139, v_first_244, NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_t_24141}), NTAG(TAG_Nothing)});
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2efmt_2elex_2estepAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2estepAt(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr_str1, 0, "");

HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V v_src_240, V v_st_241, V v_toks_242, V v_errs_243, V v_cmts_244) {
top: ;
  V v_i_245 = heff_take_field(v_st_241, 0);
  V v_line_246 = heff_take_field(v_st_241, 1);
  V v_tok_247 = heff_take_field(v_st_241, 4);
  V v_err_248 = heff_take_field(v_st_241, 5);
  V v_cmt_249 = heff_take_field(v_st_241, 6);
  V v_lineStart_2410 = heff_take_field(v_st_241, 2);
  V v_first_2411 = heff_get_n(v_st_241, 3, 7);
  if (heff_intLe_c_lent(heff_strLength_lent(v_src_240, 0), v_i_245, 1)) {
    heff_drop(v_i_245);
    heff_drop(v_lineStart_2410);
    heff_drop(v_first_2411);
    V v_end_2412 = heff_strLength_lent(v_src_240, 0);
    V v_t_2413 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr_str0), ((V)&g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr_str1), heff_strLength(v_src_240), v_end_2412, heff_intAdd(v_line_246, MK_INT(1LL)), MK_INT(0LL), NTAG(TAG_True)});
    V v_t_2414 = v_tok_247;
    V v_t_2416;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nothing: {
      v_t_2416 = v_toks_242;
      break;
    }
    case TAG_Just: {
      V v_x_2415 = heff_field(v_t_2414, 0);
      heff_take_n(v_t_2414, 1ULL, 1);
      v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_toks_242});
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(v_t_2417, v_t_2416));
    V v_t_2419 = v_err_248;
    V v_t_2421;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_Nothing: {
      v_t_2421 = v_errs_243;
      break;
    }
    case TAG_Just: {
      V v_x_2420 = heff_field(v_t_2419, 0);
      heff_take_n(v_t_2419, 1ULL, 1);
      v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2420, v_errs_243});
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2421));
    V v_t_2423 = v_cmt_249;
    V v_t_2425;
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Nothing: {
      v_t_2425 = v_cmts_244;
      break;
    }
    case TAG_Just: {
      V v_x_2424 = heff_field(v_t_2423, 0);
      heff_take_n(v_t_2423, 1ULL, 1);
      v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2424, v_cmts_244});
      break;
    }
    default: heff_nomatch(v_t_2423);
    }
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2425));
    return ((HeffT3){{v_t_2418, v_t_2422, v_t_2426}});
  } else {
    V v_i_2427 = v_i_245;
    V v_lineStart_2428 = v_lineStart_2410;
    V v_first_2429 = v_first_2411;
    V v_t_2430 = heff_dup(v_tok_247);
    V v_toks_2432;
    switch (heff_tag_of(v_t_2430)) {
    case TAG_Nothing: {
      v_toks_2432 = heff_dup(v_toks_242);
      break;
    }
    case TAG_Just: {
      V v_x_2431 = heff_field(v_t_2430, 0);
      heff_take_n(v_t_2430, 1ULL, 1);
      v_toks_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2431, heff_dup(v_toks_242)});
      break;
    }
    default: heff_nomatch(v_t_2430);
    }
    V v_t_2433 = (g_heff_2esyntax_2efmt_2elex_2estepAt(heff_dup(v_src_240), heff_dup(v_i_2427), v_line_246, v_lineStart_2428, v_first_2429, v_toks_2432, heff_strByteAt_lent(v_src_240, v_i_2427, 2)));
    V v_t_2434 = v_tok_247;
    V v_t_2436;
    switch (heff_tag_of(v_t_2434)) {
    case TAG_Nothing: {
      v_t_2436 = v_toks_242;
      break;
    }
    case TAG_Just: {
      V v_x_2435 = heff_field(v_t_2434, 0);
      heff_take_n(v_t_2434, 1ULL, 1);
      v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2435, v_toks_242});
      break;
    }
    default: heff_nomatch(v_t_2434);
    }
    V v_t_2437 = v_err_248;
    V v_t_2439;
    switch (heff_tag_of(v_t_2437)) {
    case TAG_Nothing: {
      v_t_2439 = v_errs_243;
      break;
    }
    case TAG_Just: {
      V v_x_2438 = heff_field(v_t_2437, 0);
      heff_take_n(v_t_2437, 1ULL, 1);
      v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2438, v_errs_243});
      break;
    }
    default: heff_nomatch(v_t_2437);
    }
    V v_t_2440 = v_cmt_249;
    V v_t_2442;
    switch (heff_tag_of(v_t_2440)) {
    case TAG_Nothing: {
      v_t_2442 = v_cmts_244;
      break;
    }
    case TAG_Just: {
      V v_x_2441 = heff_field(v_t_2440, 0);
      heff_take_n(v_t_2440, 1ULL, 1);
      v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2441, v_cmts_244});
      break;
    }
    default: heff_nomatch(v_t_2440);
    }
    V t_0 = v_src_240;
    V t_1 = v_t_2433;
    V t_2 = v_t_2436;
    V t_3 = v_t_2439;
    V t_4 = v_t_2442;
    v_src_240 = t_0;
    v_st_241 = t_1;
    v_toks_242 = t_2;
    v_errs_243 = t_3;
    v_cmts_244 = t_4;
    goto top;
  }
}
Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elex_2elexGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elex_2elexGo(V v_src_240, V v_st_241, V v_toks_242, V v_errs_243, V v_cmts_244) {
top: ;
  HeffT3 v_t_245 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_st_241, v_toks_242, v_errs_243, v_cmts_244));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_field_248 = v_t_245.f[2];
    return heff_rec_n(3, shape_tokens__errors__comments, (V[]){v_field_246, v_field_247, v_field_248});
  }
}
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elex_2elexGo(a[0], a[1], a[2], a[3], a[4]);
}