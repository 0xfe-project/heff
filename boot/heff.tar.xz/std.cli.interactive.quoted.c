// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_list_2eany_24s781693278x668067139(V, V);
V g_list_2eany_24s781693278x668067139_entry(V self, V *a);
extern Clo g_list_2eany_24s781693278x668067139_clo;
V g_std_2ecli_2einteractive_2equoted_2eplainFrom_240(V, V);
V g_std_2ecli_2einteractive_2equoted_2eplainFrom_240_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2equoted_2eplainFrom_240_clo;
Clo g_std_2ecli_2einteractive_2equoted_2eplainFrom_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2equoted_2eplainFrom_240_entry, 2, 0};

V g_std_2ecli_2einteractive_2equoted_2eplainFrom_240(V v_w_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_w_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_b_242 = heff_strByteAt_lent(v_w_240, heff_box_word(v_i_241), 2);
    V v_t_244;
    if (((((int64_t)48ULL) <= heff_peek_word(v_b_242)) && (heff_peek_word(v_b_242) <= ((int64_t)57ULL)))) {
      heff_drop(v_b_242);
      v_t_244 = NTAG(TAG_True);
    } else {
      if (((((int64_t)65ULL) <= heff_peek_word(v_b_242)) && (heff_peek_word(v_b_242) <= ((int64_t)90ULL)))) {
        heff_drop(v_b_242);
        v_t_244 = NTAG(TAG_True);
      } else {
        if (((((int64_t)97ULL) <= heff_peek_word(v_b_242)) && (heff_peek_word(v_b_242) <= ((int64_t)122ULL)))) {
          heff_drop(v_b_242);
          v_t_244 = NTAG(TAG_True);
        } else {
          if ((heff_peek_word(v_b_242) == ((int64_t)45ULL))) {
            heff_drop(v_b_242);
            v_t_244 = NTAG(TAG_True);
          } else {
            if ((heff_peek_word(v_b_242) == ((int64_t)95ULL))) {
              heff_drop(v_b_242);
              v_t_244 = NTAG(TAG_True);
            } else {
              if ((heff_peek_word(v_b_242) == ((int64_t)46ULL))) {
                heff_drop(v_b_242);
                v_t_244 = NTAG(TAG_True);
              } else {
                if ((heff_peek_word(v_b_242) == ((int64_t)47ULL))) {
                  heff_drop(v_b_242);
                  v_t_244 = NTAG(TAG_True);
                } else {
                  if ((heff_peek_word(v_b_242) == ((int64_t)61ULL))) {
                    heff_drop(v_b_242);
                    v_t_244 = NTAG(TAG_True);
                  } else {
                    if ((heff_peek_word(v_b_242) == ((int64_t)58ULL))) {
                      heff_drop(v_b_242);
                      v_t_244 = NTAG(TAG_True);
                    } else {
                      if ((heff_peek_word(v_b_242) == ((int64_t)44ULL))) {
                        heff_drop(v_b_242);
                        v_t_244 = NTAG(TAG_True);
                      } else {
                        if ((heff_peek_word(v_b_242) == ((int64_t)64ULL))) {
                          heff_drop(v_b_242);
                          v_t_244 = NTAG(TAG_True);
                        } else {
                          V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(43LL), NTAG(TAG_Nil)});
                          v_t_244 = ({ V a_0 = v_b_242; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(37LL), v_t_243}); V r_ = (g_list_2eany_24s781693278x668067139(a_0, b_1)); heff_drop(b_1); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_w_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_w_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
}
V g_std_2ecli_2einteractive_2equoted_2eplainFrom_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2equoted_2eplainFrom_240(a0, a[1]); heff_drop(a0); return r;
}