// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_ctx 308385
#define LBL_def 308863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_inner 301714032
#define LBL_keys 9783995
#define LBL_large 304101205
#define LBL_n 328
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_params 951713969
#define LBL_rest 9992347
#define LBL_values 1123329101
static uint32_t shape_im__indent[] = {LBL_im, LBL_indent};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
static uint32_t shape_names__rest__ctx[] = {LBL_names, LBL_rest, LBL_ctx};
static uint32_t shape_params__names__def__large[] = {LBL_params, LBL_names, LBL_def, LBL_large};
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo;
V g_heff_2esyntax_2esurfaceprint_2eformerAt(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerAt_clo;
V g_heff_2esyntax_2esurfaceprint_2eformerOf(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerOf_clo;
V g_heff_2esyntax_2esurfaceprint_2eformerParam(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerParam_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerParam_clo;
V g_heff_2esyntax_2esurfaceprint_2eimplicitGroup(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eimplicitGroup_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eimplicitGroup_clo;
V g_heff_2esyntax_2esurfaceprint_2eimplicitName(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eimplicitName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eimplicitName_clo;
V g_heff_2esyntax_2esurfaceprint_2enth(V, V);
V g_heff_2esyntax_2esurfaceprint_2enth_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enth_clo;
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo;
V g_heff_2esyntax_2esurfaceprint_2estripIs(V);
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_heff_2esyntax_2esurfaceprint_2etypeFormer(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etypeFormer_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etypeFormer_clo;
V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo;
Clo g_heff_2esyntax_2esurfaceprint_2enth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2enth_entry, 2, 0};

V g_heff_2esyntax_2esurfaceprint_2enth(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2enth_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurfaceprint_2enth(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str0, 5, ") -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str1, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str3, 6, "}} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str4, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str5, 2, "{{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str6, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str7, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str8, 6, "}} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str9, 6, "{{_ : ");
Clo g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry, 6, 0};

V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(V v_c_240, V v_xs_241, V v_level_242, V v_dom_243, V v_x6_244, V v_implicit_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkAbs: {
    V v_x_246 = heff_field(v_x6_244, 0);
    V v_b_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24MkAbs = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_implicit_245)) {
    case TAG_Expl: {
      V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_249 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), v_xs_241}); V a_3 = v_b_247; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_b_247); r_; });
      V v_t_2410 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str0), v_t_249));
      V v_t_2411 = heff_strAppend(v_x_246, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str1), v_t_2410));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str2), v_t_2411);
    }
    case TAG_Impl: {
      V v_t_2438;
      switch (heff_tag_of(v_dom_243)) {
      case TAG_SU: {
        V v_u_2412 = heff_field(v_dom_243, 0);
        V v_t_2413 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = (g_heff_2esyntax_2esurfaceprint_2eimplicitGroup(v_t_2413, v_u_2412, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})));
        break;
      }
      case TAG_SDecode: {
        V v_t_2415 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2415, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SFunction: {
        V v_t_2421 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2421, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SRecord: {
        V v_t_2425 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2425, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SSum: {
        V v_t_2427 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2427, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SIsTy: {
        V v_t_2429 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2429, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimInt: {
        V v_t_2430 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2430, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimFloat: {
        V v_t_2431 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2431, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimString: {
        V v_t_2432 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2432, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimRune: {
        V v_t_2433 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2433, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimArray: {
        V v_t_2435 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2435, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SFixed: {
        V v_t_2437 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2437, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      default: heff_nomatch(v_dom_243);
      }
      return (g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994(v_c_240, v_xs_241, v_dom_243, v_t_2438));
    }
    case TAG_Inst: {
      V v_t_2439 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2440 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), v_xs_241}); V a_3 = v_b_247; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_b_247); r_; });
      V v_t_2441 = heff_strAppend(v_t_2439, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str3), v_t_2440));
      V v_t_2442 = heff_strAppend(v_x_246, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str4), v_t_2441));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str5), v_t_2442);
    }
    default: return heff_nomatch(v_implicit_245);
    }
  }
  case TAG_AbsConst: {
    V v_b_2443 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    switch (heff_tag_of(v_implicit_245)) {
    case TAG_Expl: {
      V v_t_2444 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2445 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2443; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_b_2443); r_; });
      return heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str6), v_t_2445));
    }
    case TAG_Impl: {
      V v_t_2446 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2447 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2443; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_b_2443); r_; });
      return heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str7), v_t_2447));
    }
    case TAG_Inst: {
      V v_t_2448 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2449 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2443; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_b_2443); r_; });
      V v_t_2450 = heff_strAppend(v_t_2448, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str8), v_t_2449));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str9), v_t_2450);
    }
    default: return heff_nomatch(v_implicit_245);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V a5 = a[5]; V r = g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(a[0], a[1], a2, a3, a[4], a5); heff_drop(a2); heff_drop(a3); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str0, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str2, 1, "(");
Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_entry, 6, 0};

V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(V v_c_240, V v_xs_241, V v_names_242, V v_i_243, V v_x6_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_xs_241);
    heff_drop(v_names_242);
    heff_drop(v_i_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x6_244, 0);
    V v_rest_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2eimplicitName(heff_dup(v_names_242), heff_dup(v_i_243), heff_dup(v_a_246)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_241), v_a_246));
      V v_cell_2410 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_c_240;
      V t_1 = v_xs_241;
      V t_2 = v_names_242;
      V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
      V t_4 = v_rest_247;
      V t_5 = v_cell_2410;
      v_c_240 = t_0;
      v_xs_241 = t_1;
      v_names_242 = t_2;
      v_i_243 = t_3;
      v_x6_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    case TAG_Just: {
      V v_imp_2412 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      heff_drop(v_a_246);
      V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 1, 2);
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x6_244_24Cons, 2);
        heff_drop_rec(v_imp_2412, 2);
        heff_drop(v_t_2413);
        V t_0 = v_c_240;
        V t_1 = v_xs_241;
        V t_2 = v_names_242;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        V t_4 = v_rest_247;
        V t_5 = v_d_245;
        v_c_240 = t_0;
        v_xs_241 = t_1;
        v_names_242 = t_2;
        v_i_243 = t_3;
        v_x6_244 = t_4;
        v_d_245 = t_5;
        goto top;
      } else {
        heff_drop(v_t_2413);
        V v_t_2414 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), heff_take_field(v_imp_2412, 1)));
        V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str0), heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str1)));
        V v_t_2416 = heff_strAppend(heff_get_n(v_imp_2412, 0, 2), v_t_2415);
        V v_cell_2417 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str2), v_t_2416), heff_hole()});
        V v_u_2418 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2417));
        heff_drop(v_u_2418);
        V t_0 = v_c_240;
        V t_1 = v_xs_241;
        V t_2 = v_names_242;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        V t_4 = v_rest_247;
        V t_5 = v_cell_2417;
        v_c_240 = t_0;
        v_xs_241 = t_1;
        v_names_242 = t_2;
        v_i_243 = t_3;
        v_x6_244 = t_4;
        v_d_245 = t_5;
        goto top;
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_SU: {
    return v_d_240;
  }
  case TAG_SDecode: {
    return v_d_240;
  }
  case TAG_SFunction: {
    return v_d_240;
  }
  case TAG_SRecord: {
    return v_d_240;
  }
  case TAG_SSum: {
    return v_d_240;
  }
  case TAG_SIsTy: {
    V v_d1_2412 = heff_field(v_d_240, 0);
    heff_take_n(v_d_240, 1ULL, 1);
    V t_0 = v_d1_2412;
    v_d_240 = t_0;
    goto top;
  }
  case TAG_SPrimInt: {
    return v_d_240;
  }
  case TAG_SPrimFloat: {
    return v_d_240;
  }
  case TAG_SPrimString: {
    return v_d_240;
  }
  case TAG_SPrimRune: {
    return v_d_240;
  }
  case TAG_SPrimArray: {
    return v_d_240;
  }
  case TAG_SFixed: {
    return v_d_240;
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eunIsTy(a[0]);
}
Clo g_heff_2esyntax_2esurfaceprint_2eformerAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eformerAt_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eformerAt(V v_params_240, V v_ns_241, V v_b_242, V v_large_243) {
top: ;
  switch (heff_tag_of(v_b_242)) {
  case TAG_SLocal: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SGlobal: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SCode: {
    V v_d_246 = heff_field(v_b_242, 0);
    heff_take_n(v_b_242, 1ULL, 1);
    V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(v_d_246));
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, v_t_247, v_large_243});
  }
  case TAG_SApp: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLam: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SCons: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SProj: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_STag: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SMatch: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SSpecialize: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SIs: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SOpaque: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SAbandon: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SRec: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SFix: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SImplicit: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SPrim: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SMetaApp: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitInt: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFloat: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitString: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitBytes: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitRune: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFixed: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFloat32: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  default: return heff_nomatch(v_b_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eformerAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eformerAt(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2esurfaceprint_2etypeFormer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etypeFormer_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2etypeFormer(V v_t_240, V v_body_241, V v_ns_242, V v_params_243) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_t_240, 0);
    V v_ru_24t_240_24SU = heff_take_reuse_n(v_t_240, 1ULL, 1);
    V v_t_245 = (g_heff_2esyntax_2esurfaceprint_2estripIs(v_body_241));
    V v_t_246;
    switch (heff_tag_of(v_u_244)) {
    case TAG_SmallU: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_LargeU: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_u_244);
    }
    V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2eformerAt(v_params_243, v_ns_242, v_t_245, v_t_246));
    return heff_tag_at_n(v_ru_24t_240_24SU, TAG_Just, 1, (V[]){v_t_247});
  }
  case TAG_SDecode: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_2426 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_2426;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SFunction: {
    V v_dom_2445 = heff_dup(heff_field(v_t_240, 1));
    V v_t3_2446 = heff_dup(heff_field(v_t_240, 2));
    V v_t4_2447 = heff_dup(heff_field(v_t_240, 3));
    switch (heff_tag_of(v_t3_2446)) {
    case TAG_MkAbs: {
      V v_cod_2450 = heff_field(v_t3_2446, 1);
      V v_ru_24t3_2446_24MkAbs = heff_take_reuse_n(v_t3_2446, 2ULL, 2);
      switch (heff_tag_of(v_t4_2447)) {
      case TAG_Expl: {
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          V v_it2_2457 = heff_field(v_body_241, 1);
          V v_ru_24body_241_24SLam = heff_take_reuse_n(v_body_241, 2ULL, 2);
          heff_drop_tag(v_t_240, 5);
          switch (heff_tag_of(v_it2_2457)) {
          case TAG_MkAbs: {
            V v_x_2458 = heff_field(v_it2_2457, 0);
            V v_b_2459 = heff_field(v_it2_2457, 1);
            heff_take_n(v_it2_2457, 3ULL, 2);
            V v_t_2460 = ({ V a_0 = heff_dup(v_ns_242); V a_1 = heff_dup(v_x_2458); V a_2 = v_dom_2445; V r_ = (g_heff_2esyntax_2esurfaceprint_2eformerParam(a_0, a_1, a_2)); heff_drop(v_dom_2445); r_; });
            V v_t_2461 = heff_tag_at_n(v_ru_24t3_2446_24MkAbs, TAG_Cons, 2, (V[]){v_t_2460, NTAG(TAG_Nil)});
            V v_t_2462 = (g_prelude_2e_2b_2b(v_params_243, v_t_2461));
            V t_0 = v_cod_2450;
            V t_1 = v_b_2459;
            V t_2 = heff_tag_at_n(v_ru_24body_241_24SLam, TAG_Cons, 2, (V[]){v_x_2458, v_ns_242});
            V t_3 = v_t_2462;
            v_t_240 = t_0;
            v_body_241 = t_1;
            v_ns_242 = t_2;
            v_params_243 = t_3;
            goto top;
          }
          case TAG_AbsConst: {
            heff_take_n(v_it2_2457, 0ULL, 1);
            heff_drop(v_ns_242);
            heff_drop(v_params_243);
            heff_drop(v_dom_2445);
            heff_drop(v_cod_2450);
            heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
            heff_drop_cell(v_ru_24body_241_24SLam, 2);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_it2_2457);
          }
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          V v_b_2474 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          V t_0 = v_t_240;
          V t_1 = v_b_2474;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_na(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitBytes: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitRune: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_na(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_body_241);
        }
      }
      case TAG_Impl: {
        heff_drop(v_dom_2445);
        heff_drop(v_cod_2450);
        heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          V v_b_24109 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          V t_0 = v_t_240;
          V t_1 = v_b_24109;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_na(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitBytes: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitRune: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_na(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_body_241);
        }
      }
      case TAG_Inst: {
        heff_drop(v_dom_2445);
        heff_drop(v_cod_2450);
        heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          V v_b_24144 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          V t_0 = v_t_240;
          V t_1 = v_b_24144;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_na(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitBytes: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitRune: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_na(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_body_241);
        }
      }
      default: return heff_nomatch(v_t4_2447);
      }
    }
    case TAG_AbsConst: {
      heff_take_n(v_t3_2446, 0ULL, 1);
      heff_drop(v_dom_2445);
      heff_drop(v_t4_2447);
      switch (heff_tag_of(v_body_241)) {
      case TAG_SLocal: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SGlobal: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCode: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SApp: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLam: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCons: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SProj: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_STag: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMatch: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_body_241, 0ULL, 3);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SIs: {
        V v_b_24180 = heff_field(v_body_241, 0);
        heff_take_n(v_body_241, 1ULL, 1);
        V t_0 = v_t_240;
        V t_1 = v_b_24180;
        V t_2 = v_ns_242;
        V t_3 = v_params_243;
        v_t_240 = t_0;
        v_body_241 = t_1;
        v_ns_242 = t_2;
        v_params_243 = t_3;
        goto top;
      }
      case TAG_SOpaque: {
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SAbandon: {
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SRec: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SFix: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SImplicit: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrim: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_body_241, 0ULL, 3);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitInt: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitString: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitRune: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_body_241);
      }
    }
    default: return heff_nomatch(v_t3_2446);
    }
  }
  case TAG_SRecord: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24218 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24218;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SSum: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24254 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24254;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SIsTy: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24290 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24290;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimInt: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24325 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24325;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimFloat: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24360 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24360;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimString: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24395 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24395;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimRune: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24430 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24430;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimArray: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24466 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24466;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SFixed: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24502 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24502;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etypeFormer_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2etypeFormer(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str1, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str2, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str3, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str5, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str6, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str7, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str9, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str10, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str11, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str13, 2, "  ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str15, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str16, 7, " where\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str17, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str18, 7, "theory ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str20, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str21, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str22, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str24, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str27, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str28, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str29, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str30, 5, "data ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str32, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str33, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str34, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str36, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str37, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str38, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str40, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str41, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str42, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str44, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str45, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str46, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str48, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str49, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str50, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str52, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str53, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str54, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str56, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str57, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_str58, 5, "type ");
V g_heff_2esyntax_2esurfaceprint_2eformerOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eformerOf_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eformerOf_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2eformerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eformerOf_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2eformerOf(V v_c_240, V v_name_241, V v_tf_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_tf_242, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    V v_ru_24t_243_24SU = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_245 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SU, 1);
      heff_drop(v_t_245);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_245);
      V v_t_246 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str0), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_247 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str1), heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str2)));
      V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str3), heff_strAppend(v_t_246, v_t_248));
      return heff_tag_at_n(v_ru_24t_243_24SU, TAG_Just, 1, (V[]){v_t_249});
    }
  }
  case TAG_SDecode: {
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2411 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SDecode, 1);
      heff_drop(v_t_2411);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2411);
      V v_t_2412 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str4), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2413 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str5), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str6)));
      V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str7), heff_strAppend(v_t_2412, v_t_2414));
      return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_Just, 1, (V[]){v_t_2415});
    }
  }
  case TAG_SFunction: {
    heff_take_n(v_t_243, 0ULL, 5);
    V v_t_2421 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2421);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2421);
      V v_t_2422 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str8), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2423 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2424 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str9), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str10)));
      V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str11), heff_strAppend(v_t_2422, v_t_2424));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2425});
    }
  }
  case TAG_SRecord: {
    V v_fs_2427 = heff_field(v_t_243, 1);
    V v_ds_2428 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 6ULL, 3);
    V v_t_2429 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_t_2429);
      V v_t_2430 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str12), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2431 = heff_arrayToList(heff_take_field(v_fs_2427, 0));
      V v_t_2432 = heff_arrayToList(heff_get_n(v_fs_2427, 2, 3));
      V v_fs_2433 = (g_heff_2eutil_2edict_2ezipKV(v_t_2431, v_t_2432));
      V v_t_2434 = heff_rec_n(2, shape_names__out, (V[]){heff_get_n(v_tf_242, 1, 4), NTAG(TAG_Nil)});
      V v_acc_2437 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eformerOf_lam0, 2, 2, (V[]){v_c_240, v_ds_2428}); V a_1 = v_t_2434; V a_2 = v_fs_2433; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2433); r_; });
      V v_x2_2438 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str13), heff_get_n(v_acc_2437, 1, 2)));
      V v_t_2441;
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_Nil: {
        v_t_2441 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str14);
        break;
      }
      case TAG_Cons: {
        V v_x_2439 = heff_field(v_x2_2438, 0);
        V v_xs_2440 = heff_field(v_x2_2438, 1);
        heff_take_n(v_x2_2438, 3ULL, 2);
        v_t_2441 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str15); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2438);
      }
      V v_t_2442 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str16), heff_strAppend(v_t_2441, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str17)));
      V v_t_2443 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str18), heff_strAppend(v_t_2430, v_t_2442));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2443});
    } else {
      heff_drop_rec(v_fs_2427, 3);
      heff_drop(v_ds_2428);
      heff_drop(v_t_2429);
      V v_t_2444 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str19), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2445 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2446 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str20), heff_strAppend(v_t_2445, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str21)));
      V v_t_2447 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str22), heff_strAppend(v_t_2444, v_t_2446));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2447});
    }
  }
  case TAG_SSum: {
    V v_vs_2448 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2449 = heff_dup(heff_rfield(v_tf_242, 3));
    if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_rec(v_vs_2448, 3);
      heff_drop_cell(v_ru_24t_243_24SSum, 1);
      heff_drop(v_t_2449);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2449);
      V v_t_2450 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str23), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2451 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2448, 0)));
      V v_t_2452 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2448, 2)));
      V v_x1_2453 = (g_heff_2eutil_2edict_2ezipKV(v_t_2451, v_t_2452));
      V v_t_2456;
      switch (heff_tag_of(v_x1_2453)) {
      case TAG_Nil: {
        v_t_2456 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x1_2453, 0ULL, 2);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x1_2453);
      }
      V v_t_2468;
      if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
        heff_drop(v_c_240);
        heff_drop_rec(v_tf_242, 4);
        heff_drop_rec(v_vs_2448, 3);
        heff_drop(v_t_2456);
        v_t_2468 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str24);
      } else {
        heff_drop(v_t_2456);
        V v_t_2457 = heff_arrayToList(heff_take_field(v_vs_2448, 0));
        V v_t_2458 = heff_arrayToList(heff_get_n(v_vs_2448, 2, 3));
        V v_t_2459 = (g_heff_2eutil_2edict_2ezipKV(v_t_2457, v_t_2458));
        V v_x2_2464 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eformerOf_lam1, 1, 2, (V[]){v_c_240, v_tf_242}), v_t_2459));
        V v_t_2467;
        switch (heff_tag_of(v_x2_2464)) {
        case TAG_Nil: {
          v_t_2467 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str26);
          break;
        }
        case TAG_Cons: {
          V v_x_2465 = heff_field(v_x2_2464, 0);
          V v_xs_2466 = heff_field(v_x2_2464, 1);
          heff_take_n(v_x2_2464, 3ULL, 2);
          v_t_2467 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str27); V a_1 = v_x_2465; V a_2 = v_xs_2466; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2466); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2464);
        }
        v_t_2468 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str28), v_t_2467);
      }
      V v_t_2469 = heff_strAppend(v_t_2450, heff_strAppend(v_t_2468, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str29)));
      return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str30), v_t_2469)});
    }
  }
  case TAG_SIsTy: {
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2471 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SIsTy, 1);
      heff_drop(v_t_2471);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2471);
      V v_t_2472 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str31), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2473 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2474 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str32), heff_strAppend(v_t_2473, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str33)));
      V v_t_2475 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str34), heff_strAppend(v_t_2472, v_t_2474));
      return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_Just, 1, (V[]){v_t_2475});
    }
  }
  case TAG_SPrimInt: {
    V v_t_2476 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2476);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2476);
      V v_t_2477 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str35), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2478 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2479 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str36), heff_strAppend(v_t_2478, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str37)));
      V v_t_2480 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str38), heff_strAppend(v_t_2477, v_t_2479));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2480});
    }
  }
  case TAG_SPrimFloat: {
    V v_t_2481 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2481) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2481);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2481);
      V v_t_2482 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str39), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2483 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2484 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str40), heff_strAppend(v_t_2483, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str41)));
      V v_t_2485 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str42), heff_strAppend(v_t_2482, v_t_2484));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2485});
    }
  }
  case TAG_SPrimString: {
    V v_t_2486 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2486);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2486);
      V v_t_2487 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str43), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2488 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2489 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str44), heff_strAppend(v_t_2488, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str45)));
      V v_t_2490 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str46), heff_strAppend(v_t_2487, v_t_2489));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2490});
    }
  }
  case TAG_SPrimRune: {
    V v_t_2491 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2491) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2491);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2491);
      V v_t_2492 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str47), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2493 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2494 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str48), heff_strAppend(v_t_2493, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str49)));
      V v_t_2495 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str50), heff_strAppend(v_t_2492, v_t_2494));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2495});
    }
  }
  case TAG_SPrimArray: {
    V v_ru_24t_243_24SPrimArray = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2497 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2497) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SPrimArray, 1);
      heff_drop(v_t_2497);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2497);
      V v_t_2498 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str51), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2499 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_24100 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str52), heff_strAppend(v_t_2499, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str53)));
      V v_t_24101 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str54), heff_strAppend(v_t_2498, v_t_24100));
      return heff_tag_at_n(v_ru_24t_243_24SPrimArray, TAG_Just, 1, (V[]){v_t_24101});
    }
  }
  case TAG_SFixed: {
    V v_ru_24t_243_24SFixed = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_24103 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_24103) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SFixed, 1);
      heff_drop(v_t_24103);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_24103);
      V v_t_24104 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str55), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_24105 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_24106 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str56), heff_strAppend(v_t_24105, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str57)));
      V v_t_24107 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str58), heff_strAppend(v_t_24104, v_t_24106));
      return heff_tag_at_n(v_ru_24t_243_24SFixed, TAG_Just, 1, (V[]){v_t_24107});
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eformerOf(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_lam0(V self, V *args) {
  V v_acc_2435 = args[0];
  V v_f_2436 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_ds_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(v_c_240, v_ds_2428, v_acc_2435, v_f_2436));
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_lam2(V self, V *args) {
  V v_t2_2463 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_tf_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_c_240; V a_1 = MK_INT(2LL); V a_2 = heff_get_n(v_tf_242, 1, 4); V a_3 = v_t2_2463; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2463); r_; });
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_lam1(V self, V *args) {
  V v_v_2460 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_tf_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2460)) {
  case TAG_MkPair: {
    V v_t_2461 = heff_field(v_v_2460, 0);
    V v_ts_2462 = heff_field(v_v_2460, 1);
    heff_take_n(v_v_2460, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_str25); V a_1 = v_t_2461; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eformerOf_lam2, 1, 2, (V[]){v_c_240, v_tf_242}); V b_3 = heff_arrayToList(v_ts_2462); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2460);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str10, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str11, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str12, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str14, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str15, 6, "String");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str16, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str17, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str18, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str20, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str21, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str22, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str23, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str24, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str25, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str26, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str27, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str28, 7, "Float32");
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_x5_243, 0);
    V v_dom_247 = heff_field(v_x5_243, 1);
    V v_cod_248 = heff_field(v_x5_243, 2);
    V v_implicit_249 = heff_field(v_x5_243, 3);
    V v_dflt_2410 = heff_field(v_x5_243, 4);
    V v_s_2412;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      v_s_2412 = (g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_xs_242, v_level_246, v_dom_247, heff_dup(v_cod_248), v_implicit_249));
      break;
    }
    case TAG_Just: {
      V v_d_2411 = heff_field(v_dflt_2410, 0);
      v_s_2412 = (g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_xs_242, v_dom_247, heff_dup(v_cod_248), heff_dup(v_d_2411)));
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str2), heff_strAppend(v_s_2412, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str3)));
    } else {
      return v_s_2412;
    }
  }
  case TAG_SRecord: {
    V v_fs_2415 = heff_field(v_x5_243, 1);
    V v_ds_2416 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_t_2417 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2415, 0)));
    V v_t_2418 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2415, 2)));
    V v_fs_2419 = (g_heff_2eutil_2edict_2ezipKV(v_t_2417, v_t_2418));
    V v_t_2420 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2423 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_lam0, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2416)}); V a_1 = v_t_2420; V a_2 = v_fs_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2419); r_; });
    V v_t_2424 = heff_get_n(v_acc_2423, 1, 2);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_t_2424, 0);
      V v_xs_2426 = heff_field(v_t_2424, 1);
      heff_take_n(v_t_2424, 3ULL, 2);
      v_t_2427 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str5); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str6), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str7)));
  }
  case TAG_SSum: {
    V v_vs_2428 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_t_2429 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2428, 0)));
    V v_t_2430 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2428, 2)));
    V v_t_2431 = (g_heff_2eutil_2edict_2ezipKV(v_t_2429, v_t_2430));
    V v_x2_2436 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2431));
    V v_t_2439;
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_Nil: {
      v_t_2439 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_xs_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      v_t_2439 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str10); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2436);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str11), heff_strAppend(v_t_2439, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str12)));
  }
  case TAG_SIsTy: {
    V v_t2_2440 = heff_field(v_x5_243, 0);
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_t2_2440);
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str13);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str14);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str15);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str16);
  }
  case TAG_SPrimArray: {
    V v_a_2441 = heff_field(v_x5_243, 0);
    V v_t_2442 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2441));
    V v_s_2443 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str17), v_t_2442);
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str18), heff_strAppend(v_s_2443, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str19)));
    } else {
      return v_s_2443;
    }
  }
  case TAG_SFixed: {
    V v_w_2445 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2445)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str20);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str21);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str22);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str23);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str24);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str25);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str26);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str27);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str28);
    }
    default: return heff_nomatch(v_w_2445);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_lam0(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_f_2422 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_ds_2416, v_acc_2421, v_f_2422));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_lam2(V self, V *args) {
  V v_t2_2435 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(2LL); V a_2 = v_xs_242; V a_3 = v_t2_2435; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2435); r_; });
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_lam1(V self, V *args) {
  V v_v_2432 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2432)) {
  case TAG_MkPair: {
    V v_t_2433 = heff_field(v_v_2432, 0);
    V v_ts_2434 = heff_field(v_v_2432, 1);
    heff_take_n(v_v_2432, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_str8); V a_1 = v_t_2433; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2434); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2432);
  }
}