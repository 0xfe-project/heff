// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_ctx 308385
#define LBL_def 308863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_inner 301714032
#define LBL_keys 9783995
#define LBL_large 304101205
#define LBL_n 328
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_params 951713969
#define LBL_rest 9992347
#define LBL_typed 312202372
#define LBL_values 1123329101
static uint32_t shape_im__indent__typed[] = {LBL_im, LBL_indent, LBL_typed};
static uint32_t shape_names__hide[] = {LBL_names, LBL_hide};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
static uint32_t shape_names__rest__ctx[] = {LBL_names, LBL_rest, LBL_ctx};
static uint32_t shape_params__names__def__large[] = {LBL_params, LBL_names, LBL_def, LBL_large};
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_clo;
V g_heff_2esyntax_2esurfaceprint_2earrayNone_get(void);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo;
V g_heff_2esyntax_2esurfaceprint_2eformerAt(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerAt_clo;
V g_heff_2esyntax_2esurfaceprint_2eimplicitGroup(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eimplicitGroup_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eimplicitGroup_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eimplicitName_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_heff_2esyntax_2esurfaceprint_2etypeFormer(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etypeFormer_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etypeFormer_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr(V);
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo;
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str0, 4, "plus");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str1, 5, "minus");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str2, 5, "times");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str3, 5, "slash");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str4, 7, "percent");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str5, 2, "eq");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str6, 2, "lt");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str7, 2, "gt");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str8, 3, "amp");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str9, 3, "bar");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str10, 4, "bang");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str11, 5, "caret");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str12, 1, "q");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str13, 2, "at");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str14, 4, "hash");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str15, 6, "dollar");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str16, 5, "tilde");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str17, 5, "colon");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str18, 3, "dot");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str19, 9, "backslash");

HeffT2 g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  if ((v_c_240 == ((int64_t)43ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str0)}});
  } else {
    if ((v_c_240 == ((int64_t)45ULL))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str1)}});
    } else {
      if ((v_c_240 == ((int64_t)42ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str2)}});
      } else {
        if ((v_c_240 == ((int64_t)47ULL))) {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str3)}});
        } else {
          if ((v_c_240 == ((int64_t)37ULL))) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str4)}});
          } else {
            if ((v_c_240 == ((int64_t)61ULL))) {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str5)}});
            } else {
              if ((v_c_240 == ((int64_t)60ULL))) {
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str6)}});
              } else {
                if ((v_c_240 == ((int64_t)62ULL))) {
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str7)}});
                } else {
                  if ((v_c_240 == ((int64_t)38ULL))) {
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str8)}});
                  } else {
                    if ((v_c_240 == ((int64_t)124ULL))) {
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str9)}});
                    } else {
                      if ((v_c_240 == ((int64_t)33ULL))) {
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str10)}});
                      } else {
                        if ((v_c_240 == ((int64_t)94ULL))) {
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str11)}});
                        } else {
                          if ((v_c_240 == ((int64_t)63ULL))) {
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str12)}});
                          } else {
                            if ((v_c_240 == ((int64_t)64ULL))) {
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str13)}});
                            } else {
                              if ((v_c_240 == ((int64_t)35ULL))) {
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str14)}});
                              } else {
                                if ((v_c_240 == ((int64_t)36ULL))) {
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str15)}});
                                } else {
                                  if ((v_c_240 == ((int64_t)126ULL))) {
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str16)}});
                                  } else {
                                    if ((v_c_240 == ((int64_t)58ULL))) {
                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str17)}});
                                    } else {
                                      if ((v_c_240 == ((int64_t)46ULL))) {
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str18)}});
                                      } else {
                                        if ((v_c_240 == ((int64_t)92ULL))) {
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr_str19)}});
                                        } else {
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str0, 5, ") -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str1, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str3, 6, "}} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str4, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str5, 2, "{{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str6, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str7, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str8, 6, "}} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str9, 6, "{{_ : ");
Clo g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry, 6, 0};

V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(V v_c_240, V v_xs_241, V v_level_242, V v_dom_243, V v_x6_244, V v_implicit_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkAbs: {
    V v_x_246 = heff_field(v_x6_244, 0);
    V v_b_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24MkAbs = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_implicit_245)) {
    case TAG_Expl: {
      V v_t_248 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
      V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_248, MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2410 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2410, MK_INT(0LL), heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), v_xs_241}), v_b_247));
      V v_t_2412 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str0), v_t_2411));
      V v_t_2413 = heff_strAppend(v_x_246, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str1), v_t_2412));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str2), v_t_2413);
    }
    case TAG_Impl: {
      V v_t_2440;
      switch (heff_tag_of(v_dom_243)) {
      case TAG_SU: {
        V v_u_2414 = heff_dup(heff_field(v_dom_243, 0));
        V v_t_2415 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2440 = ({ V a_0 = v_t_2415; V a_1 = v_u_2414; V a_2 = v_b_247; V a_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)}); V r_ = (g_heff_2esyntax_2esurfaceprint_2eimplicitGroup(a_0, a_1, a_2, a_3)); heff_drop(v_u_2414); r_; });
        break;
      }
      case TAG_SDecode: {
        V v_t_2417 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2440 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2417, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SFunction: {
        V v_t_2423 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2440 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2423, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SRecord: {
        V v_t_2427 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2440 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2427, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SSum: {
        V v_t_2429 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2440 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2429, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SIsTy: {
        V v_t_2431 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2440 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2431, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimInt: {
        V v_t_2432 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2440 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2432, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimFloat: {
        V v_t_2433 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2440 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2433, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimString: {
        V v_t_2434 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2440 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2434, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimRune: {
        V v_t_2435 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2440 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2435, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimArray: {
        V v_t_2437 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2440 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2437, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SFixed: {
        V v_t_2439 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2440 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2439, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      default: heff_nomatch(v_dom_243);
      }
      return (g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994(v_c_240, v_xs_241, v_dom_243, v_t_2440));
    }
    case TAG_Inst: {
      V v_t_2441 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
      V v_t_2442 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2441, MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2443 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2444 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2443, MK_INT(0LL), heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), v_xs_241}), v_b_247));
      V v_t_2445 = heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str3), v_t_2444));
      V v_t_2446 = heff_strAppend(v_x_246, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str4), v_t_2445));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str5), v_t_2446);
    }
    default: return heff_nomatch(v_implicit_245);
    }
  }
  case TAG_AbsConst: {
    V v_b_2447 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    switch (heff_tag_of(v_implicit_245)) {
    case TAG_Expl: {
      V v_t_2448 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
      V v_t_2449 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2448, MK_INT(1LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2450 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2451 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2450, MK_INT(0LL), v_xs_241, v_b_2447));
      return heff_strAppend(v_t_2449, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str6), v_t_2451));
    }
    case TAG_Impl: {
      V v_t_2452 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
      V v_t_2453 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2452, MK_INT(1LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2454 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2455 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2454, MK_INT(0LL), v_xs_241, v_b_2447));
      return heff_strAppend(v_t_2453, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str7), v_t_2455));
    }
    case TAG_Inst: {
      V v_t_2456 = heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_dup(heff_rfield(v_c_240, 1)), NTAG(TAG_True)});
      V v_t_2457 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2456, MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2458 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2459 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2458, MK_INT(0LL), v_xs_241, v_b_2447));
      V v_t_2460 = heff_strAppend(v_t_2457, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str8), v_t_2459));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_str9), v_t_2460);
    }
    default: return heff_nomatch(v_implicit_245);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a5 = a[5]; V r = g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(a[0], a[1], a2, a[3], a[4], a5); heff_drop(a2); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str0, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str2, 1, "(");
Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_entry, 6, 0};

V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(V v_c_240, V v_xs_241, V v_names_242, V v_i_243, V v_x6_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_xs_241);
    heff_drop(v_names_242);
    heff_drop(v_i_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x6_244, 0);
    V v_rest_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    HeffT2 v_t_248 = (g_heff_2esyntax_2esurfaceprint_2eimplicitName_24cpr(heff_dup(v_names_242), heff_dup(v_i_243), heff_dup(v_a_246)));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        heff_drop(v_a_246);
        V v_imp_2411 = v_field_2410;
        V v_n_2412 = heff_take_field(v_imp_2411, 0);
        V v_inner_2413 = heff_get_n(v_imp_2411, 1, 2);
        V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 1, 2);
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x6_244_24Cons, 2);
          heff_drop(v_n_2412);
          heff_drop(v_inner_2413);
          heff_drop(v_t_2414);
          V t_0 = v_c_240;
          V t_1 = v_xs_241;
          V t_2 = v_names_242;
          V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
          V t_4 = v_rest_247;
          V t_5 = v_d_245;
          v_c_240 = t_0;
          v_xs_241 = t_1;
          v_names_242 = t_2;
          v_i_243 = t_3;
          v_x6_244 = t_4;
          v_d_245 = t_5;
          goto top;
        } else {
          heff_drop(v_t_2414);
          V v_t_2415 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_inner_2413));
          V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str0), heff_strAppend(v_t_2415, ((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str1)));
          V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_str2), heff_strAppend(v_n_2412, v_t_2416));
          V v_cell_2418 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
          V v_u_2419 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2418));
          heff_drop(v_u_2419);
          V t_0 = v_c_240;
          V t_1 = v_xs_241;
          V t_2 = v_names_242;
          V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
          V t_4 = v_rest_247;
          V t_5 = v_cell_2418;
          v_c_240 = t_0;
          v_xs_241 = t_1;
          v_names_242 = t_2;
          v_i_243 = t_3;
          v_x6_244 = t_4;
          v_d_245 = t_5;
          goto top;
        }
      } else {
        heff_drop(v_field_2410);
        V v_t_2420 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_241), v_a_246));
        V v_cell_2421 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2420, heff_hole()});
        V v_u_2422 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2421));
        heff_drop(v_u_2422);
        V t_0 = v_c_240;
        V t_1 = v_xs_241;
        V t_2 = v_names_242;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        V t_4 = v_rest_247;
        V t_5 = v_cell_2421;
        v_c_240 = t_0;
        v_xs_241 = t_1;
        v_names_242 = t_2;
        v_i_243 = t_3;
        v_x6_244 = t_4;
        v_d_245 = t_5;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SU: {
    return v_x1_240;
  }
  case TAG_SDecode: {
    return v_x1_240;
  }
  case TAG_SFunction: {
    return v_x1_240;
  }
  case TAG_SRecord: {
    return v_x1_240;
  }
  case TAG_SSum: {
    return v_x1_240;
  }
  case TAG_SIsTy: {
    V v_d_2412 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_d_2412;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SPrimInt: {
    return v_x1_240;
  }
  case TAG_SPrimFloat: {
    return v_x1_240;
  }
  case TAG_SPrimString: {
    return v_x1_240;
  }
  case TAG_SPrimRune: {
    return v_x1_240;
  }
  case TAG_SPrimArray: {
    return v_x1_240;
  }
  case TAG_SFixed: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eunIsTy(a[0]);
}
Clo g_heff_2esyntax_2esurfaceprint_2eformerAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eformerAt_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eformerAt(V v_params_240, V v_ns_241, V v_b_242, V v_large_243) {
top: ;
  switch (heff_tag_of(v_b_242)) {
  case TAG_SLocal: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SGlobal: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SCode: {
    V v_d_246 = heff_field(v_b_242, 0);
    heff_take_n(v_b_242, 1ULL, 1);
    V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(v_d_246));
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, v_t_247, v_large_243});
  }
  case TAG_SApp: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLam: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SCons: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SProj: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_STag: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SMatch: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SSpecialize: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SIs: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SOpaque: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SAbandon: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SRec: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SFix: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SImplicit: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SPrim: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SMetaApp: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitInt: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFloat: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitString: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitBytes: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitRune: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFixed: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFloat32: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  default: return heff_nomatch(v_b_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eformerAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eformerAt(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str10, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str11, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str12, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str14, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str15, 6, "String");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str16, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str17, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str18, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str20, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str21, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str22, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str23, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str24, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str25, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str26, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str27, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str28, 7, "Float32");
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam0, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam1, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam2, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam4(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam4, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam3(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam7(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam7, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam6(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam5(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam8(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam8, 2, 0};
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam9(V self, V *args); static Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam9, 2, 0};
Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    V v_t_248 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam0_clo), NTAG(TAG_False)});
    V v_t_249 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_248, v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_t_249, v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_2410 = heff_field(v_x5_243, 0);
    V v_dom_2411 = heff_field(v_x5_243, 1);
    V v_cod_2412 = heff_field(v_x5_243, 2);
    V v_implicit_2413 = heff_field(v_x5_243, 3);
    V v_dflt_2414 = heff_field(v_x5_243, 4);
    V v_s_2424;
    switch (heff_tag_of(v_dflt_2414)) {
    case TAG_Nothing: {
      V v_t_2417 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam1_clo), NTAG(TAG_False)});
      V v_t_2418 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_2417, v_lit_240, NTAG(TAG_True)});
      v_s_2424 = (g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(v_t_2418, v_xs_242, v_level_2410, heff_dup(v_dom_2411), heff_dup(v_cod_2412), v_implicit_2413));
      break;
    }
    case TAG_Just: {
      V v_d_2419 = heff_field(v_dflt_2414, 0);
      V v_t_2422 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam2_clo), NTAG(TAG_False)});
      V v_t_2423 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_2422, v_lit_240, NTAG(TAG_True)});
      v_s_2424 = (g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(v_t_2423, v_xs_242, heff_dup(v_dom_2411), heff_dup(v_cod_2412), heff_dup(v_d_2419)));
      break;
    }
    default: heff_nomatch(v_dflt_2414);
    }
    if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str2), heff_strAppend(v_s_2424, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str3)));
    } else {
      return v_s_2424;
    }
  }
  case TAG_SRecord: {
    V v_fs_2426 = heff_field(v_x5_243, 1);
    V v_ds_2427 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_keys_2428 = heff_dup(heff_rfield(v_fs_2426, 0));
    V v_values_2429 = heff_dup(heff_rfield(v_fs_2426, 2));
    V v_fs_2430 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2428), heff_arrayToList(v_values_2429)));
    V v_t_2431 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2438 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam3, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2427)}); V a_1 = v_t_2431; V a_2 = v_fs_2430; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2430); r_; });
    V v_t_2439 = heff_get_n(v_acc_2438, 1, 2);
    V v_t_2442;
    switch (heff_tag_of(v_t_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_t_2439, 0);
      V v_xs_2441 = heff_field(v_t_2439, 1);
      heff_take_n(v_t_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str5); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_t_2439);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str6), heff_strAppend(v_t_2442, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str7)));
  }
  case TAG_SSum: {
    V v_vs_2443 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_keys_2444 = heff_dup(heff_rfield(v_vs_2443, 0));
    V v_values_2445 = heff_dup(heff_rfield(v_vs_2443, 2));
    V v_t_2446 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2444), heff_arrayToList(v_values_2445)));
    V v_x2_2455 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam5, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2446));
    V v_t_2458;
    switch (heff_tag_of(v_x2_2455)) {
    case TAG_Nil: {
      v_t_2458 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2456 = heff_field(v_x2_2455, 0);
      V v_xs_2457 = heff_field(v_x2_2455, 1);
      heff_take_n(v_x2_2455, 3ULL, 2);
      v_t_2458 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str10); V a_1 = v_x_2456; V a_2 = v_xs_2457; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2457); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2455);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str11), heff_strAppend(v_t_2458, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str12)));
  }
  case TAG_SIsTy: {
    V v_t2_2459 = heff_field(v_x5_243, 0);
    V v_t_2462 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam8_clo), NTAG(TAG_False)});
    V v_t_2463 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_2462, v_lit_240, NTAG(TAG_True)});
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2463, v_p_241, v_xs_242, heff_dup(v_t2_2459));
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str13);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str14);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str15);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str16);
  }
  case TAG_SPrimArray: {
    V v_a_2464 = heff_field(v_x5_243, 0);
    V v_t_2467 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam9_clo), NTAG(TAG_False)});
    V v_t_2468 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_2467, v_lit_240, NTAG(TAG_True)});
    V v_t_2469 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2468, MK_INT(2LL), v_xs_242, heff_dup(v_a_2464)));
    V v_s_2470 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str17), v_t_2469);
    if ((((int64_t)2ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str18), heff_strAppend(v_s_2470, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str19)));
    } else {
      return v_s_2470;
    }
  }
  case TAG_SFixed: {
    V v_w_2471 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2471)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str20);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str21);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str22);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str23);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str24);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str25);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str26);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str27);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str28);
    }
    default: return heff_nomatch(v_w_2471);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  heff_drop(v_a_246);
  heff_drop(v_a_247);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam1(V self, V *args) {
  V v_a_2415 = args[0];
  V v_a_2416 = args[1];
  heff_drop(v_a_2415);
  heff_drop(v_a_2416);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam2(V self, V *args) {
  V v_a_2420 = args[0];
  V v_a_2421 = args[1];
  heff_drop(v_a_2420);
  heff_drop(v_a_2421);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam4(V self, V *args) {
  V v_a_2434 = args[0];
  V v_a_2435 = args[1];
  heff_drop(v_a_2434);
  heff_drop(v_a_2435);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam3(V self, V *args) {
  V v_acc_2432 = args[0];
  V v_f_2433 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam4_clo), NTAG(TAG_False)});
  V v_t_2437 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_2436, v_lit_240, NTAG(TAG_True)});
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(v_t_2437, v_ds_2427, v_acc_2432, v_f_2433));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam7(V self, V *args) {
  V v_a_2451 = args[0];
  V v_a_2452 = args[1];
  heff_drop(v_a_2451);
  heff_drop(v_a_2452);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam6(V self, V *args) {
  V v_t2_2450 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam7_clo), NTAG(TAG_False)});
  V v_t_2454 = heff_rec_n(3, shape_im__indent__typed, (V[]){v_t_2453, v_lit_240, NTAG(TAG_True)});
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2454, MK_INT(2LL), v_xs_242, v_t2_2450));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam5(V self, V *args) {
  V v_v_2447 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2447)) {
  case TAG_MkPair: {
    V v_t_2448 = heff_field(v_v_2447, 0);
    V v_ts_2449 = heff_field(v_v_2447, 1);
    heff_take_n(v_v_2447, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_str8); V a_1 = v_t_2448; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam6, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2449); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2447);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam8(V self, V *args) {
  V v_a_2460 = args[0];
  V v_a_2461 = args[1];
  heff_drop(v_a_2460);
  heff_drop(v_a_2461);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s327686394x2051645827_lam9(V self, V *args) {
  V v_a_2465 = args[0];
  V v_a_2466 = args[1];
  heff_drop(v_a_2465);
  heff_drop(v_a_2466);
  return heff_dup(g_heff_2esyntax_2esurfaceprint_2earrayNone_get());
}
Clo g_heff_2esyntax_2esurfaceprint_2etypeFormer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etypeFormer_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2etypeFormer(V v_t_240, V v_body_241, V v_ns_242, V v_params_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(v_t_240, v_body_241, v_ns_242, v_params_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2etypeFormer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurfaceprint_2etypeFormer(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}