// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_ReadDirectory 46629
#define TAG_Right 62770
#define LBL_dir 308999
#define LBL_heff 9694020
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_src 323678
#define LBL_top 324559
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_heff_2ebuild_2eload_2ecycleAmong(V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecycleAmong_clo;
V g_heff_2ebuild_2eload_2enamedGo(V, V);
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374(V, V, V);
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1(V, V, V, V);
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1462590149x1582455373(V);
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_clo;
V g_list_2emap_24s18996220x10511024(V);
V g_list_2emap_24s18996220x10511024_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str3, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str4, 30, "packages require one another: ");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str6, 0, "");
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0(V v_ps_240, V v_hd_241, V v_root_242, V v_x_243, V v_x_244, V v_k_245, V v_x_246) {
top: ;
  V v_require_247 = heff_take_field(v_root_242, 2);
  V v_module_248 = heff_take_field(v_root_242, 0);
  V v_heff_249 = heff_get_n(v_root_242, 1, 4);
  V v_lib_2410 = heff_take_field(v_ps_240, 2);
  V v_root_2411 = heff_take_field(v_ps_240, 0);
  V v_src_2412 = heff_get_n(v_ps_240, 1, 6);
  V v_t_2415;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Left: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_2414 = heff_field(v_x_246, 0);
    v_t_2415 = heff_dup(v_y_2414);
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V v_x_2416 = (g_list_2emap_24s1462590149x1582455373(v_t_2415));
  V v_t_2417 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_lib_2410));
  return (g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374(v_t_2417, v_hd_241, heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_lam0, 1, 9, (V[]){v_require_247, v_x_2416, v_x_243, heff_dup(v_x_244), v_module_248, v_root_2411, v_src_2412, v_heff_249, v_k_245})));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V r = g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0(a[0], a[1], a[2], a[3], a4, a[5], a6); heff_drop(a4); heff_drop(a6); return r;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_require_247 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_module_248 = heff_env(self)[4];
  V v_root_2411 = heff_env(self)[5];
  V v_src_2412 = heff_env(self)[6];
  V v_heff_249 = heff_env(self)[7];
  V v_k_245 = heff_env(self)[8];
  V v_t_2420;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    v_t_2420 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_x_2421 = (g_list_2emap_24s1462590149x1582455373(v_t_2420));
  V v_t_2422 = (g_list_2emap_24s18996220x10511024(heff_dup(v_require_247)));
  heff_clo_take(self, 9);
  V v_t_2423 = (g_prelude_2e_2b_2b(v_x_2416, v_x_2421));
  V v_t_2424 = (g_prelude_2e_2b_2b(v_x_243, v_t_2423));
  V v_t_2427;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_dup(heff_field(v_x_244, 0));
    v_t_2427 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_t_2428 = (g_heff_2ebuild_2eload_2enamedGo(v_t_2424, v_t_2427));
  V v_t_2431;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkPair: {
    V v_y_2430 = heff_dup(heff_field(v_x_244, 1));
    v_t_2431 = v_y_2430;
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_t_2432 = (g_list_2emap_24s18996220x10511024(v_require_247));
  V v_t_2435;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 2);
    v_t_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(v_module_248), heff_dup(v_root_2411), heff_dup(v_src_2412), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str0), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str1), heff_dup(v_heff_249), v_t_2432}), v_t_2435});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_248), NTAG(TAG_Nil)});
  V v_t_2438 = ({ V a_0 = v_t_2436; V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2437; V r_ = (g_heff_2ebuild_2eload_2ecycleAmong(a_0, a_1, a_2)); heff_drop_tag(v_t_2436, 2); r_; });
  V v_t_2443;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_Nothing: {
    v_t_2443 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_c_2439 = heff_field(v_t_2438, 0);
    heff_take_n(v_t_2438, 1ULL, 1);
    V v_t_2442;
    switch (heff_tag_of(v_c_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_c_2439, 0);
      V v_xs_2441 = heff_field(v_c_2439, 1);
      heff_take_n(v_c_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str3); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_c_2439);
    }
    v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str4), v_t_2442), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2431, v_t_2443));
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){v_module_248, v_root_2411, v_src_2412, ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str5), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0_str6), v_heff_249, v_t_2422}), v_t_2428});
  V v_x_2446 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, v_t_2444});
  V f_ = v_k_245;
  args[0] = v_x_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_lam0, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_entry, 6, 0};

V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1(V v_ps_240, V v_hd_241, V v_root_242, V v_x_243, V v_k_244, V v_x_245) {
top: ;
  V v_t_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_247 = heff_field(v_x_245, 0);
    v_t_248 = heff_dup(v_y_247);
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_x_249 = (g_list_2emap_24s1462590149x1582455373(v_t_248));
  V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(heff_rfield(v_ps_240, 0))));
  V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2410; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2413 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_lam0_clo)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2418, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_lam1, 1, 7, (V[]){v_ps_240, v_hd_241, v_root_242, v_x_249, heff_dup(v_x_243), v_k_244, v_path_2410})));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V r = g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1(a[0], a[1], a[2], a3, a[4], a5); heff_drop(a3); heff_drop(a5); return r;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_lam2(V self, V *args) {
  V v_n_2424 = args[0];
  V v_path_2410 = heff_env(self)[0];
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2424));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_2410, v_t_2425));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_root_242 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_path_2410 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    heff_clo_take(self, 7);
    heff_drop(v_path_2410);
    return ({ V a_0 = v_ps_240; V a_1 = v_hd_241; V a_2 = v_root_242; V a_3 = v_x_249; V a_4 = v_x_243; V a_5 = v_k_244; V b_6 = heff_tag_re_n(v_ru_24x_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2420}); V r_ = (g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(v_x_243); heff_drop(b_6); r_; });
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    switch (heff_tag_of(v_y_2421)) {
    case TAG_Left: {
      V v_err_2422 = heff_field(v_y_2421, 0);
      V v_ru_24y_2421_24Left = heff_take_reuse_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 7);
      heff_drop(v_path_2410);
      heff_drop_cell(v_ru_24x_2419_24Right, 1);
      return ({ V a_0 = v_ps_240; V a_1 = v_hd_241; V a_2 = v_root_242; V a_3 = v_x_249; V a_4 = v_x_243; V a_5 = v_k_244; V b_6 = heff_tag_re_n(v_ru_24y_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2422}); V r_ = (g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(v_x_243); heff_drop(b_6); r_; });
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_y_2421, 0);
      heff_take_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 7);
      V v_x_2426 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_lam2, 1, 1, (V[]){v_path_2410}), v_x_2423));
      V v_x_2427 = (g_list_2emap_24s219049803x1458391381(v_x_2426));
      return ({ V a_0 = v_ps_240; V a_1 = v_hd_241; V a_2 = v_root_242; V a_3 = v_x_249; V a_4 = v_x_243; V a_5 = v_k_244; V b_6 = heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Right, 1, (V[]){v_x_2427}); V r_ = (g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(v_x_243); heff_drop(b_6); r_; });
    }
    default: return heff_nomatch(v_y_2421);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}