// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Bin 14227
#define TAG_Tip 31527
#define LBL_numeric 378927440
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
V g_std_2eordmap_2einsert_24s1937835736x1362370727(V, V, V);
V g_std_2eordmap_2einsert_24s1937835736x1362370727_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1937835736x1362370727_clo;
V g_std_2eordmap_2einsert_24s2008157409x530425318(V, V, V);
V g_std_2eordmap_2einsert_24s2008157409x530425318_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s2008157409x530425318_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2einsert_24s772458816x1205354502(V, V, V);
V g_std_2eordmap_2einsert_24s772458816x1205354502_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s772458816x1205354502_clo;
HeffT2 g_std_2eordmap_2eleastSplit_24cpr(V);
V g_std_2eordmap_2elookup_24s1088265102x456727156(V, V);
V g_std_2eordmap_2elookup_24s1088265102x456727156_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s1088265102x456727156_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2emapValues(V, V);
V g_std_2eordmap_2emapValues_entry(V self, V *a);
extern Clo g_std_2eordmap_2emapValues_clo;
V g_std_2eordmap_2emapValues_24dps(V, V, V);
V g_std_2eordmap_2emapValues_24dps_entry(V self, V *a);
extern Clo g_std_2eordmap_2emapValues_24dps_clo;
V g_std_2eordmap_2emapValues_24s383523993x1452310955(V);
V g_std_2eordmap_2emapValues_24s383523993x1452310955_entry(V self, V *a);
extern Clo g_std_2eordmap_2emapValues_24s383523993x1452310955_clo;
V g_std_2eordmap_2emapValues_24s383523993x1452310955_24dps(V, V);
V g_std_2eordmap_2emapValues_24s383523993x1452310955_24dps_entry(V self, V *a);
extern Clo g_std_2eordmap_2emapValues_24s383523993x1452310955_24dps_clo;
V g_std_2eordmap_2erotated(V);
V g_std_2eordmap_2erotated_entry(V self, V *a);
extern Clo g_std_2eordmap_2erotated_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;

static V g_std_2eordmap_2eempty_val;
static HEFF_ONCE g_std_2eordmap_2eempty_st;
static V g_std_2eordmap_2eempty_init(void) {
  return NTAG(TAG_Tip);
}
V g_std_2eordmap_2eempty_get(void) {
  if (HEFF_DONE(g_std_2eordmap_2eempty_st)) return g_std_2eordmap_2eempty_val;
  return heff_global(&g_std_2eordmap_2eempty_val, &g_std_2eordmap_2eempty_st, g_std_2eordmap_2eempty_init);
}
Clo g_std_2eordmap_2erotated_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2erotated_entry, 1, 0};

V g_std_2eordmap_2erotated(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_k_242 = heff_field(v_x1_240, 1);
    V v_v_243 = heff_field(v_x1_240, 2);
    V v_l_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 30ULL, 5);
    V v_t_2411;
    switch (heff_tag_of(v_r_245)) {
    case TAG_Tip: {
      v_t_2411 = MK_INT(0LL);
      break;
    }
    case TAG_Bin: {
      V v_h_246 = heff_dup(heff_field(v_r_245, 0));
      v_t_2411 = v_h_246;
      break;
    }
    default: heff_nomatch(v_r_245);
    }
    V v_t_2417;
    switch (heff_tag_of(v_l_244)) {
    case TAG_Tip: {
      v_t_2417 = MK_INT(0LL);
      break;
    }
    case TAG_Bin: {
      V v_h_2412 = heff_dup(heff_field(v_l_244, 0));
      v_t_2417 = v_h_2412;
      break;
    }
    default: heff_nomatch(v_l_244);
    }
    if (heff_intLt_c(heff_intAdd(v_t_2411, MK_INT(1LL)), v_t_2417)) {
      switch (heff_tag_of(v_l_244)) {
      case TAG_Tip: {
        heff_drop(v_k_242);
        heff_drop(v_v_243);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x1_240_24Bin, 5);
        return heff_abandon();
      }
      case TAG_Bin: {
        V v_lk_2419 = heff_field(v_l_244, 1);
        V v_lv_2420 = heff_field(v_l_244, 2);
        V v_ll_2421 = heff_field(v_l_244, 3);
        V v_lr_2422 = heff_field(v_l_244, 4);
        V v_ru_24l_244_24Bin = heff_take_reuse_n(v_l_244, 30ULL, 5);
        V v_t_2428;
        switch (heff_tag_of(v_lr_2422)) {
        case TAG_Tip: {
          v_t_2428 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2423 = heff_dup(heff_field(v_lr_2422, 0));
          v_t_2428 = v_h_2423;
          break;
        }
        default: heff_nomatch(v_lr_2422);
        }
        V v_t_2434;
        switch (heff_tag_of(v_ll_2421)) {
        case TAG_Tip: {
          v_t_2434 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2429 = heff_dup(heff_field(v_ll_2421, 0));
          v_t_2434 = v_h_2429;
          break;
        }
        default: heff_nomatch(v_ll_2421);
        }
        if (heff_intLe_c(v_t_2428, v_t_2434)) {
          V v_x_2440;
          switch (heff_tag_of(v_lr_2422)) {
          case TAG_Tip: {
            v_x_2440 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2435 = heff_dup(heff_field(v_lr_2422, 0));
            v_x_2440 = v_h_2435;
            break;
          }
          default: heff_nomatch(v_lr_2422);
          }
          V v_y_2446;
          switch (heff_tag_of(v_r_245)) {
          case TAG_Tip: {
            v_y_2446 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2441 = heff_dup(heff_field(v_r_245, 0));
            v_y_2446 = v_h_2441;
            break;
          }
          default: heff_nomatch(v_r_245);
          }
          V v_t_2447;
          if (heff_intLe_c_lent(v_x_2440, v_y_2446, 0)) {
            heff_drop(v_x_2440);
            v_t_2447 = v_y_2446;
          } else {
            heff_drop(v_y_2446);
            v_t_2447 = v_x_2440;
          }
          V v_t_2448 = heff_intAdd(MK_INT(1LL), v_t_2447);
          V v_x_2454;
          switch (heff_tag_of(v_ll_2421)) {
          case TAG_Tip: {
            v_x_2454 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2449 = heff_dup(heff_field(v_ll_2421, 0));
            v_x_2454 = v_h_2449;
            break;
          }
          default: heff_nomatch(v_ll_2421);
          }
          V v_t_2455;
          if (heff_intLe_c_lent(v_x_2454, v_t_2448, 0)) {
            heff_drop(v_x_2454);
            v_t_2455 = heff_dup(v_t_2448);
          } else {
            v_t_2455 = v_x_2454;
          }
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2455), v_lk_2419, v_lv_2420, v_ll_2421, heff_tag_at_n(v_ru_24l_244_24Bin, TAG_Bin, 5, (V[]){v_t_2448, v_k_242, v_v_243, v_lr_2422, v_r_245})});
        } else {
          switch (heff_tag_of(v_lr_2422)) {
          case TAG_Tip: {
            heff_drop(v_k_242);
            heff_drop(v_v_243);
            heff_drop(v_r_245);
            heff_drop_cell(v_ru_24x1_240_24Bin, 5);
            heff_drop(v_lk_2419);
            heff_drop(v_lv_2420);
            heff_drop(v_ll_2421);
            heff_drop_cell(v_ru_24l_244_24Bin, 5);
            return heff_abandon();
          }
          case TAG_Bin: {
            V v_mk_2457 = heff_field(v_lr_2422, 1);
            V v_mv_2458 = heff_field(v_lr_2422, 2);
            V v_ml_2459 = heff_field(v_lr_2422, 3);
            V v_mr_2460 = heff_field(v_lr_2422, 4);
            V v_ru_24lr_2422_24Bin = heff_take_reuse_n(v_lr_2422, 30ULL, 5);
            V v_x_2466;
            switch (heff_tag_of(v_ll_2421)) {
            case TAG_Tip: {
              v_x_2466 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_2461 = heff_dup(heff_field(v_ll_2421, 0));
              v_x_2466 = v_h_2461;
              break;
            }
            default: heff_nomatch(v_ll_2421);
            }
            V v_y_2472;
            switch (heff_tag_of(v_ml_2459)) {
            case TAG_Tip: {
              v_y_2472 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_2467 = heff_dup(heff_field(v_ml_2459, 0));
              v_y_2472 = v_h_2467;
              break;
            }
            default: heff_nomatch(v_ml_2459);
            }
            V v_t_2473;
            if (heff_intLe_c_lent(v_x_2466, v_y_2472, 0)) {
              heff_drop(v_x_2466);
              v_t_2473 = v_y_2472;
            } else {
              heff_drop(v_y_2472);
              v_t_2473 = v_x_2466;
            }
            V v_t_2474 = heff_intAdd(MK_INT(1LL), v_t_2473);
            V v_x_2480;
            switch (heff_tag_of(v_mr_2460)) {
            case TAG_Tip: {
              v_x_2480 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_2475 = heff_dup(heff_field(v_mr_2460, 0));
              v_x_2480 = v_h_2475;
              break;
            }
            default: heff_nomatch(v_mr_2460);
            }
            V v_y_2486;
            switch (heff_tag_of(v_r_245)) {
            case TAG_Tip: {
              v_y_2486 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_2481 = heff_dup(heff_field(v_r_245, 0));
              v_y_2486 = v_h_2481;
              break;
            }
            default: heff_nomatch(v_r_245);
            }
            V v_t_2487;
            if (heff_intLe_c_lent(v_x_2480, v_y_2486, 0)) {
              heff_drop(v_x_2480);
              v_t_2487 = v_y_2486;
            } else {
              heff_drop(v_y_2486);
              v_t_2487 = v_x_2480;
            }
            V v_t_2488 = heff_intAdd(MK_INT(1LL), v_t_2487);
            V v_t_2489;
            if (heff_intLe_c_lent(v_t_2474, v_t_2488, 0)) {
              v_t_2489 = heff_dup(v_t_2488);
            } else {
              v_t_2489 = heff_dup(v_t_2474);
            }
            return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2489), v_mk_2457, v_mv_2458, heff_tag_at_n(v_ru_24l_244_24Bin, TAG_Bin, 5, (V[]){v_t_2474, v_lk_2419, v_lv_2420, v_ll_2421, v_ml_2459}), heff_tag_at_n(v_ru_24lr_2422_24Bin, TAG_Bin, 5, (V[]){v_t_2488, v_k_242, v_v_243, v_mr_2460, v_r_245})});
          }
          default: return heff_nomatch(v_lr_2422);
          }
        }
      }
      default: return heff_nomatch(v_l_244);
      }
    } else {
      V v_t_2495;
      switch (heff_tag_of(v_l_244)) {
      case TAG_Tip: {
        v_t_2495 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2490 = heff_dup(heff_field(v_l_244, 0));
        v_t_2495 = v_h_2490;
        break;
      }
      default: heff_nomatch(v_l_244);
      }
      V v_t_24101;
      switch (heff_tag_of(v_r_245)) {
      case TAG_Tip: {
        v_t_24101 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2496 = heff_dup(heff_field(v_r_245, 0));
        v_t_24101 = v_h_2496;
        break;
      }
      default: heff_nomatch(v_r_245);
      }
      if (heff_intLt_c(heff_intAdd(v_t_2495, MK_INT(1LL)), v_t_24101)) {
        switch (heff_tag_of(v_r_245)) {
        case TAG_Tip: {
          heff_drop(v_k_242);
          heff_drop(v_v_243);
          heff_drop(v_l_244);
          heff_drop_cell(v_ru_24x1_240_24Bin, 5);
          return heff_abandon();
        }
        case TAG_Bin: {
          V v_rk_24103 = heff_field(v_r_245, 1);
          V v_rv_24104 = heff_field(v_r_245, 2);
          V v_rl_24105 = heff_field(v_r_245, 3);
          V v_rr_24106 = heff_field(v_r_245, 4);
          V v_ru_24r_245_24Bin = heff_take_reuse_n(v_r_245, 30ULL, 5);
          V v_t_24112;
          switch (heff_tag_of(v_rl_24105)) {
          case TAG_Tip: {
            v_t_24112 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24107 = heff_dup(heff_field(v_rl_24105, 0));
            v_t_24112 = v_h_24107;
            break;
          }
          default: heff_nomatch(v_rl_24105);
          }
          V v_t_24118;
          switch (heff_tag_of(v_rr_24106)) {
          case TAG_Tip: {
            v_t_24118 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24113 = heff_dup(heff_field(v_rr_24106, 0));
            v_t_24118 = v_h_24113;
            break;
          }
          default: heff_nomatch(v_rr_24106);
          }
          if (heff_intLe_c(v_t_24112, v_t_24118)) {
            V v_x_24124;
            switch (heff_tag_of(v_l_244)) {
            case TAG_Tip: {
              v_x_24124 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24119 = heff_dup(heff_field(v_l_244, 0));
              v_x_24124 = v_h_24119;
              break;
            }
            default: heff_nomatch(v_l_244);
            }
            V v_y_24130;
            switch (heff_tag_of(v_rl_24105)) {
            case TAG_Tip: {
              v_y_24130 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24125 = heff_dup(heff_field(v_rl_24105, 0));
              v_y_24130 = v_h_24125;
              break;
            }
            default: heff_nomatch(v_rl_24105);
            }
            V v_t_24131;
            if (heff_intLe_c_lent(v_x_24124, v_y_24130, 0)) {
              heff_drop(v_x_24124);
              v_t_24131 = v_y_24130;
            } else {
              heff_drop(v_y_24130);
              v_t_24131 = v_x_24124;
            }
            V v_t_24132 = heff_intAdd(MK_INT(1LL), v_t_24131);
            V v_y_24138;
            switch (heff_tag_of(v_rr_24106)) {
            case TAG_Tip: {
              v_y_24138 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24133 = heff_dup(heff_field(v_rr_24106, 0));
              v_y_24138 = v_h_24133;
              break;
            }
            default: heff_nomatch(v_rr_24106);
            }
            V v_t_24139;
            if (heff_intLe_c_lent(v_t_24132, v_y_24138, 0)) {
              v_t_24139 = v_y_24138;
            } else {
              heff_drop(v_y_24138);
              v_t_24139 = heff_dup(v_t_24132);
            }
            return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24139), v_rk_24103, v_rv_24104, heff_tag_at_n(v_ru_24r_245_24Bin, TAG_Bin, 5, (V[]){v_t_24132, v_k_242, v_v_243, v_l_244, v_rl_24105}), v_rr_24106});
          } else {
            switch (heff_tag_of(v_rl_24105)) {
            case TAG_Tip: {
              heff_drop(v_k_242);
              heff_drop(v_v_243);
              heff_drop(v_l_244);
              heff_drop_cell(v_ru_24x1_240_24Bin, 5);
              heff_drop(v_rk_24103);
              heff_drop(v_rv_24104);
              heff_drop(v_rr_24106);
              heff_drop_cell(v_ru_24r_245_24Bin, 5);
              return heff_abandon();
            }
            case TAG_Bin: {
              V v_mk_24141 = heff_field(v_rl_24105, 1);
              V v_mv_24142 = heff_field(v_rl_24105, 2);
              V v_ml_24143 = heff_field(v_rl_24105, 3);
              V v_mr_24144 = heff_field(v_rl_24105, 4);
              V v_ru_24rl_24105_24Bin = heff_take_reuse_n(v_rl_24105, 30ULL, 5);
              V v_x_24150;
              switch (heff_tag_of(v_l_244)) {
              case TAG_Tip: {
                v_x_24150 = MK_INT(0LL);
                break;
              }
              case TAG_Bin: {
                V v_h_24145 = heff_dup(heff_field(v_l_244, 0));
                v_x_24150 = v_h_24145;
                break;
              }
              default: heff_nomatch(v_l_244);
              }
              V v_y_24156;
              switch (heff_tag_of(v_ml_24143)) {
              case TAG_Tip: {
                v_y_24156 = MK_INT(0LL);
                break;
              }
              case TAG_Bin: {
                V v_h_24151 = heff_dup(heff_field(v_ml_24143, 0));
                v_y_24156 = v_h_24151;
                break;
              }
              default: heff_nomatch(v_ml_24143);
              }
              V v_t_24157;
              if (heff_intLe_c_lent(v_x_24150, v_y_24156, 0)) {
                heff_drop(v_x_24150);
                v_t_24157 = v_y_24156;
              } else {
                heff_drop(v_y_24156);
                v_t_24157 = v_x_24150;
              }
              V v_t_24158 = heff_intAdd(MK_INT(1LL), v_t_24157);
              V v_x_24164;
              switch (heff_tag_of(v_mr_24144)) {
              case TAG_Tip: {
                v_x_24164 = MK_INT(0LL);
                break;
              }
              case TAG_Bin: {
                V v_h_24159 = heff_dup(heff_field(v_mr_24144, 0));
                v_x_24164 = v_h_24159;
                break;
              }
              default: heff_nomatch(v_mr_24144);
              }
              V v_y_24170;
              switch (heff_tag_of(v_rr_24106)) {
              case TAG_Tip: {
                v_y_24170 = MK_INT(0LL);
                break;
              }
              case TAG_Bin: {
                V v_h_24165 = heff_dup(heff_field(v_rr_24106, 0));
                v_y_24170 = v_h_24165;
                break;
              }
              default: heff_nomatch(v_rr_24106);
              }
              V v_t_24171;
              if (heff_intLe_c_lent(v_x_24164, v_y_24170, 0)) {
                heff_drop(v_x_24164);
                v_t_24171 = v_y_24170;
              } else {
                heff_drop(v_y_24170);
                v_t_24171 = v_x_24164;
              }
              V v_t_24172 = heff_intAdd(MK_INT(1LL), v_t_24171);
              V v_t_24173;
              if (heff_intLe_c_lent(v_t_24158, v_t_24172, 0)) {
                v_t_24173 = heff_dup(v_t_24172);
              } else {
                v_t_24173 = heff_dup(v_t_24158);
              }
              return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24173), v_mk_24141, v_mv_24142, heff_tag_at_n(v_ru_24r_245_24Bin, TAG_Bin, 5, (V[]){v_t_24158, v_k_242, v_v_243, v_l_244, v_ml_24143}), heff_tag_at_n(v_ru_24rl_24105_24Bin, TAG_Bin, 5, (V[]){v_t_24172, v_rk_24103, v_rv_24104, v_mr_24144, v_rr_24106})});
            }
            default: return heff_nomatch(v_rl_24105);
            }
          }
        }
        default: return heff_nomatch(v_r_245);
        }
      } else {
        V v_x_24179;
        switch (heff_tag_of(v_l_244)) {
        case TAG_Tip: {
          v_x_24179 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_24174 = heff_dup(heff_field(v_l_244, 0));
          v_x_24179 = v_h_24174;
          break;
        }
        default: heff_nomatch(v_l_244);
        }
        V v_y_24185;
        switch (heff_tag_of(v_r_245)) {
        case TAG_Tip: {
          v_y_24185 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_24180 = heff_dup(heff_field(v_r_245, 0));
          v_y_24185 = v_h_24180;
          break;
        }
        default: heff_nomatch(v_r_245);
        }
        V v_t_24186;
        if (heff_intLe_c_lent(v_x_24179, v_y_24185, 0)) {
          heff_drop(v_x_24179);
          v_t_24186 = v_y_24185;
        } else {
          heff_drop(v_y_24185);
          v_t_24186 = v_x_24179;
        }
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24186), v_k_242, v_v_243, v_l_244, v_r_245});
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2eordmap_2erotated_entry(V self, V *a) {
  (void)self;
  return g_std_2eordmap_2erotated(a[0]);
}

HeffT2 g_std_2eordmap_2eleastSplit_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return ((HeffT2){{NTAG(TAG_Tip), NTAG(TAG_Tip)}});
  }
  case TAG_Bin: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_x13_243 = heff_field(v_x1_240, 2);
    V v_x14_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 30ULL, 5);
    switch (heff_tag_of(v_x14_244)) {
    case TAG_Tip: {
      V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(1LL), v_x12_242, v_x13_243, NTAG(TAG_Tip), NTAG(TAG_Tip)});
      return ((HeffT2){{v_t_246, v_r_245}});
    }
    case TAG_Bin: {
      HeffT2 v_t_2412 = (g_std_2eordmap_2eleastSplit_24cpr(v_x14_244));
      {
        V v_field_2413 = v_t_2412.f[0];
        V v_field_2414 = v_t_2412.f[1];
        V v_least_2415 = v_field_2413;
        V v_l2_2416 = v_field_2414;
        V v_a_2422;
        switch (heff_tag_of(v_l2_2416)) {
        case TAG_Tip: {
          v_a_2422 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2417 = heff_dup(heff_field(v_l2_2416, 0));
          v_a_2422 = v_h_2417;
          break;
        }
        default: heff_nomatch(v_l2_2416);
        }
        V v_b_2428;
        switch (heff_tag_of(v_r_245)) {
        case TAG_Tip: {
          v_b_2428 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2423 = heff_dup(heff_field(v_r_245, 0));
          v_b_2428 = v_h_2423;
          break;
        }
        default: heff_nomatch(v_r_245);
        }
        V v_h_2430;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2428), MK_INT(1LL)), heff_dup(v_a_2422)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2422), MK_INT(1LL)), heff_dup(v_b_2428)))) {
          heff_drop(v_a_2422);
          heff_drop(v_b_2428);
          v_h_2430 = MK_INT(0LL);
        } else {
          V v_t_2429;
          if (heff_intLe_c_lent(v_a_2422, v_b_2428, 0)) {
            heff_drop(v_a_2422);
            v_t_2429 = v_b_2428;
          } else {
            heff_drop(v_b_2428);
            v_t_2429 = v_a_2422;
          }
          v_h_2430 = heff_intAdd(MK_INT(1LL), v_t_2429);
        }
        V v_f_2431;
        if (heff_intEq_c_lent(v_h_2430, MK_INT(0LL), 2)) {
          heff_drop(v_h_2430);
          v_f_2431 = (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_x12_242, v_x13_243, v_l2_2416, v_r_245})));
        } else {
          v_f_2431 = heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2430, v_x12_242, v_x13_243, v_l2_2416, v_r_245});
        }
        return ((HeffT2){{v_least_2415, v_f_2431}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x14_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2eordmap_2esize_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2esize_entry, 1, 0};

V g_std_2eordmap_2esize(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return MK_INT(0LL);
  }
  case TAG_Bin: {
    V v_l_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    V v_t_246 = (g_std_2eordmap_2esize(v_l_244));
    V v_t_247 = (g_std_2eordmap_2esize(v_r_245));
    return heff_intAdd(heff_intAdd(v_t_246, MK_INT(1LL)), v_t_247);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2eordmap_2esize_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eordmap_2esize(a0); heff_drop(a0); return r;
}
Clo g_std_2eordmap_2emapValues_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2emapValues_entry, 2, 0};

V g_std_2eordmap_2emapValues(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Tip: {
    heff_drop(v_f_240);
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_h_242 = heff_field(v_x2_241, 0);
    V v_k_243 = heff_field(v_x2_241, 1);
    V v_v_244 = heff_field(v_x2_241, 2);
    V v_l_245 = heff_field(v_x2_241, 3);
    V v_r_246 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24Bin = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_v_244}));
    V v_t_248 = (g_std_2eordmap_2emapValues(heff_dup(v_f_240), v_l_245));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Bin, TAG_Bin, 5, (V[]){v_h_242, v_k_243, v_t_247, v_t_248, heff_hole()});
    V v_u_2410 = (g_std_2eordmap_2emapValues_24dps(v_f_240, v_r_246, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eordmap_2emapValues_entry(V self, V *a) {
  (void)self;
  return g_std_2eordmap_2emapValues(a[0], a[1]);
}
Clo g_std_2eordmap_2emapValues_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2emapValues_24dps_entry, 3, 0};

V g_std_2eordmap_2emapValues_24dps(V v_f_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Tip: {
    heff_drop(v_f_240);
    return heff_setField(v_d_242, MK_INT(4LL), NTAG(TAG_Tip));
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x2_241, 0);
    V v_k_244 = heff_field(v_x2_241, 1);
    V v_v_245 = heff_field(v_x2_241, 2);
    V v_l_246 = heff_field(v_x2_241, 3);
    V v_r_247 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24Bin = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_v_245}));
    V v_t_249 = (g_std_2eordmap_2emapValues(heff_dup(v_f_240), v_l_246));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_k_244, v_t_248, v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_242, MK_INT(4LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_f_240;
    V t_1 = v_r_247;
    V t_2 = v_cell_2410;
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eordmap_2emapValues_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2eordmap_2emapValues_24dps(a[0], a[1], a[2]);
}
Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2einsert_24s615484302x989744458_entry, 3, 0};

V g_std_2eordmap_2einsert_24s615484302x989744458(V v_x1_240, V v_key_241, V v_value_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, v_value_242, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x1_240, 0);
    V v_k_27_244 = heff_field(v_x1_240, 1);
    V v_v_27_245 = heff_field(v_x1_240, 2);
    V v_l_246 = heff_field(v_x1_240, 3);
    V v_r_247 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    V v_a_248 = heff_strCompare_lent(v_key_241, v_k_27_244, 0);
    if (heff_intLt_c_lent(v_a_248, MK_INT(0LL), 2)) {
      heff_drop(v_h_243);
      heff_drop(v_a_248);
      V v_l2_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_l_246, v_key_241, v_value_242));
      V v_a_2415;
      switch (heff_tag_of(v_l2_249)) {
      case TAG_Tip: {
        v_a_2415 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2410 = heff_dup(heff_field(v_l2_249, 0));
        v_a_2415 = v_h_2410;
        break;
      }
      default: heff_nomatch(v_l2_249);
      }
      V v_b_2421;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2421 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2416 = heff_dup(heff_field(v_r_247, 0));
        v_b_2421 = v_h_2416;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2423;
      if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2421), MK_INT(1LL)), heff_dup(v_a_2415)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2415), MK_INT(1LL)), heff_dup(v_b_2421)))) {
        heff_drop(v_a_2415);
        heff_drop(v_b_2421);
        v_h_2423 = MK_INT(0LL);
      } else {
        V v_t_2422;
        if (heff_intLe_c_lent(v_a_2415, v_b_2421, 0)) {
          heff_drop(v_a_2415);
          v_t_2422 = v_b_2421;
        } else {
          heff_drop(v_b_2421);
          v_t_2422 = v_a_2415;
        }
        v_h_2423 = heff_intAdd(MK_INT(1LL), v_t_2422);
      }
      if (heff_intEq_c_lent(v_h_2423, MK_INT(0LL), 2)) {
        heff_drop(v_h_2423);
        return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_27_244, v_v_27_245, v_l2_249, v_r_247})));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2423, v_k_27_244, v_v_27_245, v_l2_249, v_r_247});
      }
    } else {
      if (heff_intEq_c(v_a_248, MK_INT(0LL))) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_241, v_value_242, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        V v_r2_2424 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_r_247, v_key_241, v_value_242));
        V v_a_2430;
        switch (heff_tag_of(v_l_246)) {
        case TAG_Tip: {
          v_a_2430 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2425 = heff_dup(heff_field(v_l_246, 0));
          v_a_2430 = v_h_2425;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_b_2436;
        switch (heff_tag_of(v_r2_2424)) {
        case TAG_Tip: {
          v_b_2436 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2431 = heff_dup(heff_field(v_r2_2424, 0));
          v_b_2436 = v_h_2431;
          break;
        }
        default: heff_nomatch(v_r2_2424);
        }
        V v_h_2438;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2436), MK_INT(1LL)), heff_dup(v_a_2430)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2430), MK_INT(1LL)), heff_dup(v_b_2436)))) {
          heff_drop(v_a_2430);
          heff_drop(v_b_2436);
          v_h_2438 = MK_INT(0LL);
        } else {
          V v_t_2437;
          if (heff_intLe_c_lent(v_a_2430, v_b_2436, 0)) {
            heff_drop(v_a_2430);
            v_t_2437 = v_b_2436;
          } else {
            heff_drop(v_b_2436);
            v_t_2437 = v_a_2430;
          }
          v_h_2438 = heff_intAdd(MK_INT(1LL), v_t_2437);
        }
        if (heff_intEq_c_lent(v_h_2438, MK_INT(0LL), 2)) {
          heff_drop(v_h_2438);
          return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_27_244, v_v_27_245, v_l_246, v_r2_2424})));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2438, v_k_27_244, v_v_27_245, v_l_246, v_r2_2424});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a) {
  (void)self;
  return g_std_2eordmap_2einsert_24s615484302x989744458(a[0], a[1], a[2]);
}

HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_a_247 = heff_strCompare_lent(v_k_241, v_k_27_243, 0);
    if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
      heff_drop(v_a_247);
      V t_0 = v_l_245;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_27_244)}});
      } else {
        V t_0 = v_r_246;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2elookup_24s305164685x44869932_entry, 2, 0};

V g_std_2eordmap_2elookup_24s305164685x44869932(V v_x1_240, V v_k_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_x1_240, v_k_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2eordmap_2elookup_24s305164685x44869932(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_a_247 = heff_strCompare_lent(v_k_241, v_k_27_243, 0);
    if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
      heff_drop(v_a_247);
      V t_0 = v_l_245;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_27_244)}});
      } else {
        V t_0 = v_r_246;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2eordmap_2einsert_24s1937835736x1362370727_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2einsert_24s1937835736x1362370727_entry, 3, 0};

V g_std_2eordmap_2einsert_24s1937835736x1362370727(V v_x1_240, V v_key_241, V v_value_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, v_value_242, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x1_240, 0);
    V v_k_27_244 = heff_field(v_x1_240, 1);
    V v_v_27_245 = heff_field(v_x1_240, 2);
    V v_l_246 = heff_field(v_x1_240, 3);
    V v_r_247 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    V v_a_248 = heff_strCompare_lent(v_key_241, v_k_27_244, 0);
    if (heff_intLt_c_lent(v_a_248, MK_INT(0LL), 2)) {
      heff_drop(v_h_243);
      heff_drop(v_a_248);
      V v_l2_249 = (g_std_2eordmap_2einsert_24s1937835736x1362370727(v_l_246, v_key_241, v_value_242));
      V v_a_2415;
      switch (heff_tag_of(v_l2_249)) {
      case TAG_Tip: {
        v_a_2415 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2410 = heff_dup(heff_field(v_l2_249, 0));
        v_a_2415 = v_h_2410;
        break;
      }
      default: heff_nomatch(v_l2_249);
      }
      V v_b_2421;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2421 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2416 = heff_dup(heff_field(v_r_247, 0));
        v_b_2421 = v_h_2416;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2423;
      if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2421), MK_INT(1LL)), heff_dup(v_a_2415)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2415), MK_INT(1LL)), heff_dup(v_b_2421)))) {
        heff_drop(v_a_2415);
        heff_drop(v_b_2421);
        v_h_2423 = MK_INT(0LL);
      } else {
        V v_t_2422;
        if (heff_intLe_c_lent(v_a_2415, v_b_2421, 0)) {
          heff_drop(v_a_2415);
          v_t_2422 = v_b_2421;
        } else {
          heff_drop(v_b_2421);
          v_t_2422 = v_a_2415;
        }
        v_h_2423 = heff_intAdd(MK_INT(1LL), v_t_2422);
      }
      if (heff_intEq_c_lent(v_h_2423, MK_INT(0LL), 2)) {
        heff_drop(v_h_2423);
        return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_27_244, v_v_27_245, v_l2_249, v_r_247})));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2423, v_k_27_244, v_v_27_245, v_l2_249, v_r_247});
      }
    } else {
      if (heff_intEq_c(v_a_248, MK_INT(0LL))) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_241, v_value_242, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        V v_r2_2424 = (g_std_2eordmap_2einsert_24s1937835736x1362370727(v_r_247, v_key_241, v_value_242));
        V v_a_2430;
        switch (heff_tag_of(v_l_246)) {
        case TAG_Tip: {
          v_a_2430 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2425 = heff_dup(heff_field(v_l_246, 0));
          v_a_2430 = v_h_2425;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_b_2436;
        switch (heff_tag_of(v_r2_2424)) {
        case TAG_Tip: {
          v_b_2436 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2431 = heff_dup(heff_field(v_r2_2424, 0));
          v_b_2436 = v_h_2431;
          break;
        }
        default: heff_nomatch(v_r2_2424);
        }
        V v_h_2438;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2436), MK_INT(1LL)), heff_dup(v_a_2430)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2430), MK_INT(1LL)), heff_dup(v_b_2436)))) {
          heff_drop(v_a_2430);
          heff_drop(v_b_2436);
          v_h_2438 = MK_INT(0LL);
        } else {
          V v_t_2437;
          if (heff_intLe_c_lent(v_a_2430, v_b_2436, 0)) {
            heff_drop(v_a_2430);
            v_t_2437 = v_b_2436;
          } else {
            heff_drop(v_b_2436);
            v_t_2437 = v_a_2430;
          }
          v_h_2438 = heff_intAdd(MK_INT(1LL), v_t_2437);
        }
        if (heff_intEq_c_lent(v_h_2438, MK_INT(0LL), 2)) {
          heff_drop(v_h_2438);
          return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_27_244, v_v_27_245, v_l_246, v_r2_2424})));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2438, v_k_27_244, v_v_27_245, v_l_246, v_r2_2424});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2eordmap_2einsert_24s1937835736x1362370727_entry(V self, V *a) {
  (void)self;
  return g_std_2eordmap_2einsert_24s1937835736x1362370727(a[0], a[1], a[2]);
}

HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    heff_drop(v_k_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    if (heff_intLt_c_lent(v_k_241, v_k_27_243, 0)) {
      V t_0 = v_l_245;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c_lent(v_k_241, v_k_27_243, 0)) {
        heff_drop(v_k_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_27_244)}});
      } else {
        V t_0 = v_r_246;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2eordmap_2elookup_24s1088265102x456727156_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2elookup_24s1088265102x456727156_entry, 2, 0};

V g_std_2eordmap_2elookup_24s1088265102x456727156(V v_x1_240, V v_k_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(v_x1_240, v_k_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_std_2eordmap_2elookup_24s1088265102x456727156_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eordmap_2elookup_24s1088265102x456727156(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2edelete_24s2135745297x1725920174_entry, 2, 0};

V g_std_2eordmap_2edelete_24s2135745297x1725920174(V v_x1_240, V v_key_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 30ULL, 5);
    V v_a_247 = heff_strCompare_lent(v_key_241, v_k_27_243, 0);
    if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
      heff_drop(v_a_247);
      V v_l2_248 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(v_l_245, v_key_241));
      V v_a_2414;
      switch (heff_tag_of(v_l2_248)) {
      case TAG_Tip: {
        v_a_2414 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_249 = heff_dup(heff_field(v_l2_248, 0));
        v_a_2414 = v_h_249;
        break;
      }
      default: heff_nomatch(v_l2_248);
      }
      V v_b_2420;
      switch (heff_tag_of(v_r_246)) {
      case TAG_Tip: {
        v_b_2420 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2415 = heff_dup(heff_field(v_r_246, 0));
        v_b_2420 = v_h_2415;
        break;
      }
      default: heff_nomatch(v_r_246);
      }
      V v_h_2422;
      if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2420), MK_INT(1LL)), heff_dup(v_a_2414)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2414), MK_INT(1LL)), heff_dup(v_b_2420)))) {
        heff_drop(v_a_2414);
        heff_drop(v_b_2420);
        v_h_2422 = MK_INT(0LL);
      } else {
        V v_t_2421;
        if (heff_intLe_c_lent(v_a_2414, v_b_2420, 0)) {
          heff_drop(v_a_2414);
          v_t_2421 = v_b_2420;
        } else {
          heff_drop(v_b_2420);
          v_t_2421 = v_a_2414;
        }
        v_h_2422 = heff_intAdd(MK_INT(1LL), v_t_2421);
      }
      if (heff_intEq_c_lent(v_h_2422, MK_INT(0LL), 2)) {
        heff_drop(v_h_2422);
        return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_27_243, v_v_27_244, v_l2_248, v_r_246})));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2422, v_k_27_243, v_v_27_244, v_l2_248, v_r_246});
      }
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        heff_drop(v_k_27_243);
        heff_drop(v_v_27_244);
        V v_l_2423 = v_l_245;
        V v_r_2424 = v_r_246;
        HeffT2 v_t_2425 = (g_std_2eordmap_2eleastSplit_24cpr(v_r_2424));
        {
          V v_field_2426 = v_t_2425.f[0];
          V v_field_2427 = v_t_2425.f[1];
          V v_it1_2428 = v_field_2426;
          V v_r2_2429 = v_field_2427;
          switch (heff_tag_of(v_it1_2428)) {
          case TAG_Tip: {
            heff_drop_cell(v_ru_24x1_240_24Bin, 5);
            heff_drop(v_r2_2429);
            return v_l_2423;
          }
          case TAG_Bin: {
            V v_k_2431 = heff_field(v_it1_2428, 1);
            V v_v_2432 = heff_field(v_it1_2428, 2);
            heff_take_n(v_it1_2428, 6ULL, 5);
            V v_a_2440;
            switch (heff_tag_of(v_l_2423)) {
            case TAG_Tip: {
              v_a_2440 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_2435 = heff_dup(heff_field(v_l_2423, 0));
              v_a_2440 = v_h_2435;
              break;
            }
            default: heff_nomatch(v_l_2423);
            }
            V v_b_2446;
            switch (heff_tag_of(v_r2_2429)) {
            case TAG_Tip: {
              v_b_2446 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_2441 = heff_dup(heff_field(v_r2_2429, 0));
              v_b_2446 = v_h_2441;
              break;
            }
            default: heff_nomatch(v_r2_2429);
            }
            V v_h_2448;
            if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2446), MK_INT(1LL)), heff_dup(v_a_2440)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2440), MK_INT(1LL)), heff_dup(v_b_2446)))) {
              heff_drop(v_a_2440);
              heff_drop(v_b_2446);
              v_h_2448 = MK_INT(0LL);
            } else {
              V v_t_2447;
              if (heff_intLe_c_lent(v_a_2440, v_b_2446, 0)) {
                heff_drop(v_a_2440);
                v_t_2447 = v_b_2446;
              } else {
                heff_drop(v_b_2446);
                v_t_2447 = v_a_2440;
              }
              v_h_2448 = heff_intAdd(MK_INT(1LL), v_t_2447);
            }
            if (heff_intEq_c_lent(v_h_2448, MK_INT(0LL), 2)) {
              heff_drop(v_h_2448);
              return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_2431, v_v_2432, v_l_2423, v_r2_2429})));
            } else {
              return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2448, v_k_2431, v_v_2432, v_l_2423, v_r2_2429});
            }
          }
          default: return heff_nomatch(v_it1_2428);
          }
        }
      } else {
        V v_r2_2449 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(v_r_246, v_key_241));
        V v_a_2455;
        switch (heff_tag_of(v_l_245)) {
        case TAG_Tip: {
          v_a_2455 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2450 = heff_dup(heff_field(v_l_245, 0));
          v_a_2455 = v_h_2450;
          break;
        }
        default: heff_nomatch(v_l_245);
        }
        V v_b_2461;
        switch (heff_tag_of(v_r2_2449)) {
        case TAG_Tip: {
          v_b_2461 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2456 = heff_dup(heff_field(v_r2_2449, 0));
          v_b_2461 = v_h_2456;
          break;
        }
        default: heff_nomatch(v_r2_2449);
        }
        V v_h_2463;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2461), MK_INT(1LL)), heff_dup(v_a_2455)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2455), MK_INT(1LL)), heff_dup(v_b_2461)))) {
          heff_drop(v_a_2455);
          heff_drop(v_b_2461);
          v_h_2463 = MK_INT(0LL);
        } else {
          V v_t_2462;
          if (heff_intLe_c_lent(v_a_2455, v_b_2461, 0)) {
            heff_drop(v_a_2455);
            v_t_2462 = v_b_2461;
          } else {
            heff_drop(v_b_2461);
            v_t_2462 = v_a_2455;
          }
          v_h_2463 = heff_intAdd(MK_INT(1LL), v_t_2462);
        }
        if (heff_intEq_c_lent(v_h_2463, MK_INT(0LL), 2)) {
          heff_drop(v_h_2463);
          return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_27_243, v_v_27_244, v_l_245, v_r2_2449})));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2463, v_k_27_243, v_v_27_244, v_l_245, v_r2_2449});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eordmap_2edelete_24s2135745297x1725920174(a[0], a1); heff_drop(a1); return r;
}
Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2einsert_24s1703101629x493626677_entry, 3, 0};

V g_std_2eordmap_2einsert_24s1703101629x493626677(V v_x1_240, V v_key_241, V v_value_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, v_value_242, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x1_240, 0);
    V v_k_27_244 = heff_field(v_x1_240, 1);
    V v_v_27_245 = heff_field(v_x1_240, 2);
    V v_l_246 = heff_field(v_x1_240, 3);
    V v_r_247 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    if (heff_intLt_c_lent(v_key_241, v_k_27_244, 0)) {
      heff_drop(v_h_243);
      V v_l2_248 = (g_std_2eordmap_2einsert_24s1703101629x493626677(v_l_246, v_key_241, v_value_242));
      V v_a_2414;
      switch (heff_tag_of(v_l2_248)) {
      case TAG_Tip: {
        v_a_2414 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_249 = heff_dup(heff_field(v_l2_248, 0));
        v_a_2414 = v_h_249;
        break;
      }
      default: heff_nomatch(v_l2_248);
      }
      V v_b_2420;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2420 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2415 = heff_dup(heff_field(v_r_247, 0));
        v_b_2420 = v_h_2415;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2422;
      if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2420), MK_INT(1LL)), heff_dup(v_a_2414)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2414), MK_INT(1LL)), heff_dup(v_b_2420)))) {
        heff_drop(v_a_2414);
        heff_drop(v_b_2420);
        v_h_2422 = MK_INT(0LL);
      } else {
        V v_t_2421;
        if (heff_intLe_c_lent(v_a_2414, v_b_2420, 0)) {
          heff_drop(v_a_2414);
          v_t_2421 = v_b_2420;
        } else {
          heff_drop(v_b_2420);
          v_t_2421 = v_a_2414;
        }
        v_h_2422 = heff_intAdd(MK_INT(1LL), v_t_2421);
      }
      if (heff_intEq_c_lent(v_h_2422, MK_INT(0LL), 2)) {
        heff_drop(v_h_2422);
        return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_27_244, v_v_27_245, v_l2_248, v_r_247})));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2422, v_k_27_244, v_v_27_245, v_l2_248, v_r_247});
      }
    } else {
      if (heff_intEq_c_lent(v_key_241, v_k_27_244, 0)) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_241, v_value_242, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        V v_r2_2423 = (g_std_2eordmap_2einsert_24s1703101629x493626677(v_r_247, v_key_241, v_value_242));
        V v_a_2429;
        switch (heff_tag_of(v_l_246)) {
        case TAG_Tip: {
          v_a_2429 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2424 = heff_dup(heff_field(v_l_246, 0));
          v_a_2429 = v_h_2424;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_b_2435;
        switch (heff_tag_of(v_r2_2423)) {
        case TAG_Tip: {
          v_b_2435 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2430 = heff_dup(heff_field(v_r2_2423, 0));
          v_b_2435 = v_h_2430;
          break;
        }
        default: heff_nomatch(v_r2_2423);
        }
        V v_h_2437;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2435), MK_INT(1LL)), heff_dup(v_a_2429)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2429), MK_INT(1LL)), heff_dup(v_b_2435)))) {
          heff_drop(v_a_2429);
          heff_drop(v_b_2435);
          v_h_2437 = MK_INT(0LL);
        } else {
          V v_t_2436;
          if (heff_intLe_c_lent(v_a_2429, v_b_2435, 0)) {
            heff_drop(v_a_2429);
            v_t_2436 = v_b_2435;
          } else {
            heff_drop(v_b_2435);
            v_t_2436 = v_a_2429;
          }
          v_h_2437 = heff_intAdd(MK_INT(1LL), v_t_2436);
        }
        if (heff_intEq_c_lent(v_h_2437, MK_INT(0LL), 2)) {
          heff_drop(v_h_2437);
          return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_27_244, v_v_27_245, v_l_246, v_r2_2423})));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2437, v_k_27_244, v_v_27_245, v_l_246, v_r2_2423});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a) {
  (void)self;
  return g_std_2eordmap_2einsert_24s1703101629x493626677(a[0], a[1], a[2]);
}
Clo g_std_2eordmap_2einsert_24s2008157409x530425318_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2einsert_24s2008157409x530425318_entry, 3, 0};

V g_std_2eordmap_2einsert_24s2008157409x530425318(V v_x1_240, V v_key_241, V v_value_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, v_value_242, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x1_240, 0);
    V v_k_27_244 = heff_field(v_x1_240, 1);
    V v_v_27_245 = heff_field(v_x1_240, 2);
    V v_l_246 = heff_field(v_x1_240, 3);
    V v_r_247 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24Bin = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    if (heff_intLt_c_lent(v_key_241, v_k_27_244, 0)) {
      heff_drop(v_h_243);
      V v_l2_248 = (g_std_2eordmap_2einsert_24s2008157409x530425318(v_l_246, v_key_241, v_value_242));
      V v_a_2414;
      switch (heff_tag_of(v_l2_248)) {
      case TAG_Tip: {
        v_a_2414 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_249 = heff_dup(heff_field(v_l2_248, 0));
        v_a_2414 = v_h_249;
        break;
      }
      default: heff_nomatch(v_l2_248);
      }
      V v_b_2420;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2420 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2415 = heff_dup(heff_field(v_r_247, 0));
        v_b_2420 = v_h_2415;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2422;
      if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2420), MK_INT(1LL)), heff_dup(v_a_2414)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2414), MK_INT(1LL)), heff_dup(v_b_2420)))) {
        heff_drop(v_a_2414);
        heff_drop(v_b_2420);
        v_h_2422 = MK_INT(0LL);
      } else {
        V v_t_2421;
        if (heff_intLe_c_lent(v_a_2414, v_b_2420, 0)) {
          heff_drop(v_a_2414);
          v_t_2421 = v_b_2420;
        } else {
          heff_drop(v_b_2420);
          v_t_2421 = v_a_2414;
        }
        v_h_2422 = heff_intAdd(MK_INT(1LL), v_t_2421);
      }
      if (heff_intEq_c_lent(v_h_2422, MK_INT(0LL), 2)) {
        heff_drop(v_h_2422);
        return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_27_244, v_v_27_245, v_l2_248, v_r_247})));
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2422, v_k_27_244, v_v_27_245, v_l2_248, v_r_247});
      }
    } else {
      if (heff_intEq_c_lent(v_key_241, v_k_27_244, 0)) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_241, v_value_242, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        V v_r2_2423 = (g_std_2eordmap_2einsert_24s2008157409x530425318(v_r_247, v_key_241, v_value_242));
        V v_a_2429;
        switch (heff_tag_of(v_l_246)) {
        case TAG_Tip: {
          v_a_2429 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2424 = heff_dup(heff_field(v_l_246, 0));
          v_a_2429 = v_h_2424;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_b_2435;
        switch (heff_tag_of(v_r2_2423)) {
        case TAG_Tip: {
          v_b_2435 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2430 = heff_dup(heff_field(v_r2_2423, 0));
          v_b_2435 = v_h_2430;
          break;
        }
        default: heff_nomatch(v_r2_2423);
        }
        V v_h_2437;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2435), MK_INT(1LL)), heff_dup(v_a_2429)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2429), MK_INT(1LL)), heff_dup(v_b_2435)))) {
          heff_drop(v_a_2429);
          heff_drop(v_b_2435);
          v_h_2437 = MK_INT(0LL);
        } else {
          V v_t_2436;
          if (heff_intLe_c_lent(v_a_2429, v_b_2435, 0)) {
            heff_drop(v_a_2429);
            v_t_2436 = v_b_2435;
          } else {
            heff_drop(v_b_2435);
            v_t_2436 = v_a_2429;
          }
          v_h_2437 = heff_intAdd(MK_INT(1LL), v_t_2436);
        }
        if (heff_intEq_c_lent(v_h_2437, MK_INT(0LL), 2)) {
          heff_drop(v_h_2437);
          return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_27_244, v_v_27_245, v_l_246, v_r2_2423})));
        } else {
          return heff_tag_at_n(v_ru_24x1_240_24Bin, TAG_Bin, 5, (V[]){v_h_2437, v_k_27_244, v_v_27_245, v_l_246, v_r2_2423});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2eordmap_2einsert_24s2008157409x530425318_entry(V self, V *a) {
  (void)self;
  return g_std_2eordmap_2einsert_24s2008157409x530425318(a[0], a[1], a[2]);
}
Clo g_std_2eordmap_2emapValues_24s383523993x1452310955_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2emapValues_24s383523993x1452310955_entry, 1, 0};

V g_std_2eordmap_2emapValues_24s383523993x1452310955(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_h_241 = heff_field(v_x2_240, 0);
    V v_k_242 = heff_field(v_x2_240, 1);
    V v_v_243 = heff_field(v_x2_240, 2);
    V v_l_244 = heff_field(v_x2_240, 3);
    V v_r_245 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24Bin = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_246 = (g_std_2eordmap_2emapValues_24s383523993x1452310955(v_l_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Bin, TAG_Bin, 5, (V[]){v_h_241, v_k_242, heff_get_n(v_v_243, 1, 3), v_t_246, heff_hole()});
    V v_u_248 = (g_std_2eordmap_2emapValues_24s383523993x1452310955_24dps(v_r_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_std_2eordmap_2emapValues_24s383523993x1452310955_entry(V self, V *a) {
  (void)self;
  return g_std_2eordmap_2emapValues_24s383523993x1452310955(a[0]);
}
Clo g_std_2eordmap_2emapValues_24s383523993x1452310955_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2emapValues_24s383523993x1452310955_24dps_entry, 2, 0};

V g_std_2eordmap_2emapValues_24s383523993x1452310955_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Tip: {
    return heff_setField(v_d_241, MK_INT(4LL), NTAG(TAG_Tip));
  }
  case TAG_Bin: {
    V v_h_242 = heff_field(v_x2_240, 0);
    V v_k_243 = heff_field(v_x2_240, 1);
    V v_v_244 = heff_field(v_x2_240, 2);
    V v_l_245 = heff_field(v_x2_240, 3);
    V v_r_246 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24Bin = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_247 = (g_std_2eordmap_2emapValues_24s383523993x1452310955(v_l_245));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Bin, TAG_Bin, 5, (V[]){v_h_242, v_k_243, heff_get_n(v_v_244, 1, 3), v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(4LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_r_246;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_std_2eordmap_2emapValues_24s383523993x1452310955_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2eordmap_2emapValues_24s383523993x1452310955_24dps(a[0], a[1]);
}

HeffT2 g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    heff_drop(v_k_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x1_240, 1);
    V v_v_27_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    if (heff_intLt_c_lent(v_k_241, v_k_27_243, 0)) {
      V t_0 = v_l_245;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c_lent(v_k_241, v_k_27_243, 0)) {
        heff_drop(v_k_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_27_244)}});
      } else {
        V t_0 = v_r_246;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_std_2eordmap_2einsert_24s772458816x1205354502_lam0(V self, V *args);
V g_std_2eordmap_2einsert_24s772458816x1205354502_lam1(V self, V *args);
Clo g_std_2eordmap_2einsert_24s772458816x1205354502_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2einsert_24s772458816x1205354502_entry, 3, 0};

V g_std_2eordmap_2einsert_24s772458816x1205354502(V v_lit_240, V v_x1_241, V v_key_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_242, heff_clo_n(g_std_2eordmap_2einsert_24s772458816x1205354502_lam0, 1, 1, (V[]){v_lit_240}), NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_244 = heff_field(v_x1_241, 0);
    V v_k_27_245 = heff_field(v_x1_241, 1);
    V v_v_27_246 = heff_field(v_x1_241, 2);
    V v_l_247 = heff_field(v_x1_241, 3);
    V v_r_248 = heff_field(v_x1_241, 4);
    V v_ru_24x1_241_24Bin = heff_take_reuse_n(v_x1_241, 31ULL, 5);
    V v_a_249 = heff_strCompare_lent(v_key_242, v_k_27_245, 0);
    if (heff_intLt_c_lent(v_a_249, MK_INT(0LL), 2)) {
      heff_drop(v_h_244);
      heff_drop(v_a_249);
      V v_l2_2410 = (g_std_2eordmap_2einsert_24s772458816x1205354502(v_lit_240, v_l_247, v_key_242));
      V v_a_2416;
      switch (heff_tag_of(v_l2_2410)) {
      case TAG_Tip: {
        v_a_2416 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2411 = heff_dup(heff_field(v_l2_2410, 0));
        v_a_2416 = v_h_2411;
        break;
      }
      default: heff_nomatch(v_l2_2410);
      }
      V v_b_2422;
      switch (heff_tag_of(v_r_248)) {
      case TAG_Tip: {
        v_b_2422 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2417 = heff_dup(heff_field(v_r_248, 0));
        v_b_2422 = v_h_2417;
        break;
      }
      default: heff_nomatch(v_r_248);
      }
      V v_h_2424;
      if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2422), MK_INT(1LL)), heff_dup(v_a_2416)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2416), MK_INT(1LL)), heff_dup(v_b_2422)))) {
        heff_drop(v_a_2416);
        heff_drop(v_b_2422);
        v_h_2424 = MK_INT(0LL);
      } else {
        V v_t_2423;
        if (heff_intLe_c_lent(v_a_2416, v_b_2422, 0)) {
          heff_drop(v_a_2416);
          v_t_2423 = v_b_2422;
        } else {
          heff_drop(v_b_2422);
          v_t_2423 = v_a_2416;
        }
        v_h_2424 = heff_intAdd(MK_INT(1LL), v_t_2423);
      }
      if (heff_intEq_c_lent(v_h_2424, MK_INT(0LL), 2)) {
        heff_drop(v_h_2424);
        return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_241_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_27_245, v_v_27_246, v_l2_2410, v_r_248})));
      } else {
        return heff_tag_at_n(v_ru_24x1_241_24Bin, TAG_Bin, 5, (V[]){v_h_2424, v_k_27_245, v_v_27_246, v_l2_2410, v_r_248});
      }
    } else {
      if (heff_intEq_c(v_a_249, MK_INT(0LL))) {
        heff_drop(v_k_27_245);
        heff_drop(v_v_27_246);
        return heff_tag_at_n(v_ru_24x1_241_24Bin, TAG_Bin, 5, (V[]){v_h_244, v_key_242, heff_clo_n(g_std_2eordmap_2einsert_24s772458816x1205354502_lam1, 1, 1, (V[]){v_lit_240}), v_l_247, v_r_248});
      } else {
        heff_drop(v_h_244);
        V v_r2_2426 = (g_std_2eordmap_2einsert_24s772458816x1205354502(v_lit_240, v_r_248, v_key_242));
        V v_a_2432;
        switch (heff_tag_of(v_l_247)) {
        case TAG_Tip: {
          v_a_2432 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2427 = heff_dup(heff_field(v_l_247, 0));
          v_a_2432 = v_h_2427;
          break;
        }
        default: heff_nomatch(v_l_247);
        }
        V v_b_2438;
        switch (heff_tag_of(v_r2_2426)) {
        case TAG_Tip: {
          v_b_2438 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2433 = heff_dup(heff_field(v_r2_2426, 0));
          v_b_2438 = v_h_2433;
          break;
        }
        default: heff_nomatch(v_r2_2426);
        }
        V v_h_2440;
        if ((heff_intLt_c(heff_intAdd(heff_dup(v_b_2438), MK_INT(1LL)), heff_dup(v_a_2432)) || heff_intLt_c(heff_intAdd(heff_dup(v_a_2432), MK_INT(1LL)), heff_dup(v_b_2438)))) {
          heff_drop(v_a_2432);
          heff_drop(v_b_2438);
          v_h_2440 = MK_INT(0LL);
        } else {
          V v_t_2439;
          if (heff_intLe_c_lent(v_a_2432, v_b_2438, 0)) {
            heff_drop(v_a_2432);
            v_t_2439 = v_b_2438;
          } else {
            heff_drop(v_b_2438);
            v_t_2439 = v_a_2432;
          }
          v_h_2440 = heff_intAdd(MK_INT(1LL), v_t_2439);
        }
        if (heff_intEq_c_lent(v_h_2440, MK_INT(0LL), 2)) {
          heff_drop(v_h_2440);
          return (g_std_2eordmap_2erotated(heff_tag_at_n(v_ru_24x1_241_24Bin, TAG_Bin, 5, (V[]){MK_INT(0LL), v_k_27_245, v_v_27_246, v_l_247, v_r2_2426})));
        } else {
          return heff_tag_at_n(v_ru_24x1_241_24Bin, TAG_Bin, 5, (V[]){v_h_2440, v_k_27_245, v_v_27_246, v_l_247, v_r2_2426});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_std_2eordmap_2einsert_24s772458816x1205354502_entry(V self, V *a) {
  (void)self;
  return g_std_2eordmap_2einsert_24s772458816x1205354502(a[0], a[1], a[2]);
}
V g_std_2eordmap_2einsert_24s772458816x1205354502_lam0(V self, V *args) {
  V v_a_243 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_243);
  return v_lit_240;
}
V g_std_2eordmap_2einsert_24s772458816x1205354502_lam1(V self, V *args) {
  V v_a_2425 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2425);
  return v_lit_240;
}
Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry, 3, 0};

V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V v_tok_240, V v_x1_241, V v_k_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_x1_241, v_k_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}