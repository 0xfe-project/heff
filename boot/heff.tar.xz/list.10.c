// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAbandon 62759
#define TAG_HE 9070
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkArm 55352
#define TAG_MkBinding 51651
#define TAG_MkCArm 24694
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SetField 47531
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_Unreached 46435
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_Within 10658
#define LBL_arity 294440695
#define LBL_atom 9500184
#define LBL_binder 558177493
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_e 319
#define LBL_field 298786068
#define LBL_fresh 299054408
#define LBL_hashes 722717031
#define LBL_hope 9703939
#define LBL_id 10114
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lent 9813446
#define LBL_loosest 581880769
#define LBL_member 869372357
#define LBL_members 1180739419
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_sigs 10025609
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_sums 10037327
#define LBL_target 1066236092
#define LBL_tracks 1081425843
#define LBL_use 325633
#define LBL_ver 326173
static uint32_t shape_name__field__use[] = {LBL_name, LBL_field, LBL_use};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_tracks__sigs__lent__sums__fresh[] = {LBL_tracks, LBL_sigs, LBL_lent, LBL_sums, LBL_fresh};
V g_heff_2ebuild_2ebenchmarks_2ecapital(V);
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo;
V g_heff_2ebuild_2ebenchmarks_2espaced(V);
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2ecaptures_2ecapSt(V, V, V);
V g_heff_2ecompile_2ecaptures_2ecapSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2ecapSt_clo;
V g_heff_2ecompile_2ecomponents_2ecomputed(V, V, V, V, V, V);
V g_heff_2ecompile_2ecomponents_2ecomputed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecomponents_2ecomputed_clo;
V g_heff_2ecompile_2ecpr_2efldAt(V, V);
V g_heff_2ecompile_2ecpr_2efldAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2efldAt_clo;
V g_heff_2ecompile_2edefun_2ehandsW(V, V);
V g_heff_2ecompile_2edefun_2ehandsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2ehandsW_clo;
V g_heff_2ecompile_2eemit_2ecallsHelper(V, V);
V g_heff_2ecompile_2eemit_2ecallsHelper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallsHelper_clo;
V g_heff_2ecompile_2eemitc_2elastDotGo(V, V, V);
V g_heff_2ecompile_2eemitc_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elastDotGo_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
HeffT2 g_heff_2ecompile_2eirtext_2ehashW_24cpr(V, V, V);
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_list_2eall_24s1512314936x520990916(V);
V g_list_2eall_24s1512314936x520990916_entry(V self, V *a);
extern Clo g_list_2eall_24s1512314936x520990916_clo;
V g_list_2eall_24s346977901x1952909174(V);
V g_list_2eall_24s346977901x1952909174_entry(V self, V *a);
extern Clo g_list_2eall_24s346977901x1952909174_clo;
V g_list_2eall_24s568190696x1372373514(V);
V g_list_2eall_24s568190696x1372373514_entry(V self, V *a);
extern Clo g_list_2eall_24s568190696x1372373514_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1041788812x158895160(V);
V g_list_2eany_24s1041788812x158895160_entry(V self, V *a);
extern Clo g_list_2eany_24s1041788812x158895160_clo;
V g_list_2eany_24s2023978511x2117594482(V);
V g_list_2eany_24s2023978511x2117594482_entry(V self, V *a);
extern Clo g_list_2eany_24s2023978511x2117594482_clo;
V g_list_2ecollapse_24s705464212x1327502534(V, V);
V g_list_2ecollapse_24s705464212x1327502534_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s705464212x1327502534_clo;
V g_list_2edescending(V, V, V, V);
V g_list_2edescending_entry(V self, V *a);
extern Clo g_list_2edescending_clo;
V g_list_2edescending_24s379747839x1236130333(V, V, V, V, V);
V g_list_2edescending_24s379747839x1236130333_entry(V self, V *a);
extern Clo g_list_2edescending_24s379747839x1236130333_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1879234972x1413867191(V, V, V);
V g_list_2efoldl_24f1879234972x1413867191_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1879234972x1413867191_clo;
V g_list_2efoldl_24f297647854x479783049(V, V);
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a);
extern Clo g_list_2efoldl_24f297647854x479783049_clo;
V g_list_2efoldl_24f928374809x1955888331(V, V);
V g_list_2efoldl_24f928374809x1955888331_entry(V self, V *a);
extern Clo g_list_2efoldl_24f928374809x1955888331_clo;
V g_list_2efoldl_24s1061937638x829298692(V, V);
V g_list_2efoldl_24s1061937638x829298692_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061937638x829298692_clo;
V g_list_2efoldl_24s1071292119x112543158(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1071292119x112543158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1071292119x112543158_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s141260856x1366916752(V, V, V, V, V);
V g_list_2efoldl_24s141260856x1366916752_entry(V self, V *a);
extern Clo g_list_2efoldl_24s141260856x1366916752_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s1568113292x813960132(V, V);
V g_list_2efoldl_24s1568113292x813960132_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1568113292x813960132_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1721918130x1703222899(V, V);
V g_list_2efoldl_24s1721918130x1703222899_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1721918130x1703222899_clo;
V g_list_2efoldl_24s1860157317x1198712058(V, V);
V g_list_2efoldl_24s1860157317x1198712058_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1860157317x1198712058_clo;
V g_list_2efoldl_24s1894035205x969464323(V, V, V);
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1894035205x969464323_clo;
V g_list_2efoldl_24s1996317718x1931167845(V, V);
V g_list_2efoldl_24s1996317718x1931167845_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1996317718x1931167845_clo;
V g_list_2efoldl_24s2036409923x213187476(V, V);
V g_list_2efoldl_24s2036409923x213187476_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2036409923x213187476_clo;
V g_list_2efoldl_24s2079805794x637914515(V, V);
V g_list_2efoldl_24s2079805794x637914515_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2079805794x637914515_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s278088687x1269971185(V, V);
V g_list_2efoldl_24s278088687x1269971185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s278088687x1269971185_clo;
V g_list_2efoldl_24s398854970x1533504811(V, V);
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a);
extern Clo g_list_2efoldl_24s398854970x1533504811_clo;
V g_list_2efoldl_24s441088199x272212076(V, V);
V g_list_2efoldl_24s441088199x272212076_entry(V self, V *a);
extern Clo g_list_2efoldl_24s441088199x272212076_clo;
V g_list_2efoldl_24s491084544x100802329(V, V);
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s491084544x100802329_clo;
V g_list_2efoldl_24s599926777x1799261815(V, V, V, V, V, V);
V g_list_2efoldl_24s599926777x1799261815_entry(V self, V *a);
extern Clo g_list_2efoldl_24s599926777x1799261815_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s6718001x1068992521(V, V, V);
V g_list_2efoldl_24s6718001x1068992521_entry(V self, V *a);
extern Clo g_list_2efoldl_24s6718001x1068992521_clo;
V g_list_2efoldl_24s878331809x629122930(V, V);
V g_list_2efoldl_24s878331809x629122930_entry(V self, V *a);
extern Clo g_list_2efoldl_24s878331809x629122930_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s2015972532x1874881274(V, V);
V g_list_2ekeepIf_24s2015972532x1874881274_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2015972532x1874881274_clo;
V g_list_2ekeepIf_24s2015972532x1874881274_24dps(V, V, V);
V g_list_2ekeepIf_24s2015972532x1874881274_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2015972532x1874881274_24dps_clo;
V g_list_2ekeepIf_24s425280038x249084439(V, V, V);
V g_list_2ekeepIf_24s425280038x249084439_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s425280038x249084439_clo;
V g_list_2ekeepIf_24s425280038x249084439_24dps(V, V, V, V);
V g_list_2ekeepIf_24s425280038x249084439_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s425280038x249084439_24dps_clo;
V g_list_2ekeepIf_24s549724630x1684056779_24dps(V, V);
V g_list_2ekeepIf_24s549724630x1684056779_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s549724630x1684056779_24dps_clo;
V g_list_2ekeepIf_24s614579978x208602650(V, V);
V g_list_2ekeepIf_24s614579978x208602650_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s614579978x208602650_clo;
V g_list_2ekeepIf_24s614579978x208602650_24dps(V, V, V);
V g_list_2ekeepIf_24s614579978x208602650_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s614579978x208602650_24dps_clo;
V g_list_2ekeepIf_24s647917584x875728492(V, V);
V g_list_2ekeepIf_24s647917584x875728492_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s647917584x875728492_clo;
V g_list_2ekeepIf_24s647917584x875728492_24dps(V, V, V);
V g_list_2ekeepIf_24s647917584x875728492_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s647917584x875728492_24dps_clo;
V g_list_2ekeepIf_24s924780574x2000457388(V, V);
V g_list_2ekeepIf_24s924780574x2000457388_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s924780574x2000457388_clo;
V g_list_2ekeepIf_24s924780574x2000457388_24dps(V, V, V);
V g_list_2ekeepIf_24s924780574x2000457388_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s924780574x2000457388_24dps_clo;
HeffT2 g_list_2elookup_24s1507486579x90027037_24cpr(V, V);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1677329353x1774765664_24dps(V, V, V);
V g_list_2emap_24f1677329353x1774765664_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1677329353x1774765664_24dps_clo;
V g_list_2emap_24f1677329353x1774765664_24tok2(V, V, V);
V g_list_2emap_24f1677329353x1774765664_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24f1677329353x1774765664_24tok2_clo;
V g_list_2emap_24f189927396x2059034600_24dps(V, V);
V g_list_2emap_24f189927396x2059034600_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f189927396x2059034600_24dps_clo;
V g_list_2emap_24f530523215x314966509_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24f530523215x314966509_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f530523215x314966509_24dps_clo;
V g_list_2emap_24f565269645x1954016017_24dps(V, V);
V g_list_2emap_24f565269645x1954016017_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f565269645x1954016017_24dps_clo;
V g_list_2emap_24s1180860948x1107067117_24dps(V, V);
V g_list_2emap_24s1180860948x1107067117_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1180860948x1107067117_24dps_clo;
V g_list_2emap_24s1397747289x2145601499(V);
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_clo;
V g_list_2emap_24s1397747289x2145601499_24dps(V, V);
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_24dps_clo;
V g_list_2emap_24s1613211967x1923010103(V, V, V, V);
V g_list_2emap_24s1613211967x1923010103_entry(V self, V *a);
extern Clo g_list_2emap_24s1613211967x1923010103_clo;
V g_list_2emap_24s1613211967x1923010103_24dps(V, V, V, V, V);
V g_list_2emap_24s1613211967x1923010103_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1613211967x1923010103_24dps_clo;
V g_list_2emap_24s1691158757x119117542(V);
V g_list_2emap_24s1691158757x119117542_entry(V self, V *a);
extern Clo g_list_2emap_24s1691158757x119117542_clo;
V g_list_2emap_24s1851573375x1006375246(V, V, V);
V g_list_2emap_24s1851573375x1006375246_entry(V self, V *a);
extern Clo g_list_2emap_24s1851573375x1006375246_clo;
V g_list_2emap_24s1851573375x1006375246_24dps(V, V, V, V);
V g_list_2emap_24s1851573375x1006375246_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1851573375x1006375246_24dps_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s2039279853x710813703(V, V);
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_clo;
V g_list_2emap_24s2039279853x710813703_24dps(V, V, V);
V g_list_2emap_24s2039279853x710813703_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_24dps_clo;
V g_list_2emap_24s2062166816x394105956_24dps(V, V);
V g_list_2emap_24s2062166816x394105956_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2062166816x394105956_24dps_clo;
V g_list_2emap_24s215892288x1392224072_24dps(V, V, V);
V g_list_2emap_24s215892288x1392224072_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24dps_clo;
V g_list_2emap_24s215892288x1392224072_24tok2(V, V, V);
V g_list_2emap_24s215892288x1392224072_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24tok2_clo;
V g_list_2emap_24s366344330x1145113647_24dps(V, V);
V g_list_2emap_24s366344330x1145113647_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_24dps_clo;
V g_list_2emap_24s388004800x1261967008(V);
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_clo;
V g_list_2emap_24s388004800x1261967008_24dps(V, V);
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_24dps_clo;
V g_list_2emap_24s570884835x2121220820(V);
V g_list_2emap_24s570884835x2121220820_entry(V self, V *a);
extern Clo g_list_2emap_24s570884835x2121220820_clo;
V g_list_2emap_24s570884835x2121220820_24dps(V, V);
V g_list_2emap_24s570884835x2121220820_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s570884835x2121220820_24dps_clo;
V g_list_2emap_24s97919758x216970748_24dps(V, V, V);
V g_list_2emap_24s97919758x216970748_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emapMaybe(V, V);
V g_list_2emapMaybe_entry(V self, V *a);
extern Clo g_list_2emapMaybe_clo;
V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_clo;
V g_list_2emergeRuns_24s1848188369x464661008(V, V);
V g_list_2emergeRuns_24s1848188369x464661008_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1848188369x464661008_clo;
V g_list_2epushRun_24s2022155310x1483676144(V, V, V);
V g_list_2epushRun_24s2022155310x1483676144_entry(V self, V *a);
extern Clo g_list_2epushRun_24s2022155310x1483676144_clo;
V g_list_2epushRun_24s495990157x1087861527(V, V, V);
V g_list_2epushRun_24s495990157x1087861527_entry(V self, V *a);
extern Clo g_list_2epushRun_24s495990157x1087861527_clo;
V g_list_2erange_24dps(V, V, V);
V g_list_2erange_24dps_entry(V self, V *a);
extern Clo g_list_2erange_24dps_clo;
V g_list_2erunFrom_24s272018256x1228369023(V, V);
V g_list_2erunFrom_24s272018256x1228369023_entry(V self, V *a);
extern Clo g_list_2erunFrom_24s272018256x1228369023_clo;
V g_list_2ezipWith_24s1530546918x299821644(V, V);
V g_list_2ezipWith_24s1530546918x299821644_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1530546918x299821644_clo;
V g_list_2ezipWith_24s1530546918x299821644_24dps(V, V, V);
V g_list_2ezipWith_24s1530546918x299821644_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1530546918x299821644_24dps_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s583291244x257539062_24dps(V, V, V);
V g_list_2ezipWith_24s583291244x257539062_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s583291244x257539062_24dps_clo;
V g_list_2ezipWith_24s634961829x758866838_24dps(V, V, V);
V g_list_2ezipWith_24s634961829x758866838_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634961829x758866838_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_list_2erange_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2erange_24dps_entry, 3, 0};

V g_list_2erange_24dps(V v_a_240, V v_b_241, V v_d_242) {
top: ;
  if (heff_intLt_c_lent(v_b_241, v_a_240, 0)) {
    heff_drop(v_a_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_240), heff_hole()});
    V v_u_244 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_243);
    V t_0 = heff_intAdd(v_a_240, MK_INT(1LL));
    V t_1 = v_b_241;
    V t_2 = v_u_244;
    v_a_240 = t_0;
    v_b_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_list_2erange_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2erange_24dps(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2edescending_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_entry, 4, 0};

V g_list_2edescending(V v_le_240, V v_x_241, V v_acc_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_x_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_242, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_244 = heff_field(v_x4_243, 0);
    V v_ys_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){v_x_241, heff_dup(v_y_244)}));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_242, heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_244, v_ys_245})});
    } else {
      heff_drop(v_t_246);
      V t_0 = v_le_240;
      V t_1 = heff_dup(v_y_244);
      V t_2 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_244, v_acc_242});
      V t_3 = v_ys_245;
      v_le_240 = t_0;
      v_x_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_list_2edescending_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2edescending(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s366344330x1145113647_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366344330x1145113647_24dps_entry, 2, 0};

V g_list_2emap_24s366344330x1145113647_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_247);
    V t_0 = v_xs_243;
    V t_1 = v_u_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366344330x1145113647_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s366344330x1145113647_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s2023978511x2117594482_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2023978511x2117594482_entry, 1, 0};

V g_list_2eany_24s2023978511x2117594482(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      v_t_246 = heff_bool(heff_strEq_c(heff_dup(v_t_243), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get())));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s2023978511x2117594482_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s2023978511x2117594482(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1061937638x829298692_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1061937638x829298692_entry, 2, 0};

V g_list_2efoldl_24s1061937638x829298692(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_key_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_body_245 = heff_dup(heff_rfield(v_x_242, 2));
    V v_t_246 = ({ V a_0 = v_z_240; V a_1 = v_key_244; V a_2 = v_body_245; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_key_244); heff_drop(v_body_245); r_; });
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1061937638x829298692_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1061937638x829298692(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s425280038x249084439_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s425280038x249084439_entry, 3, 0};

V g_list_2ekeepIf_24s425280038x249084439(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_243, 1));
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    switch (heff_tag_of(v_t_247)) {
    case TAG_Unreached: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_Within: {
      V v_a_248 = heff_field(v_t_247, 0);
      V v_a_249 = heff_field(v_t_247, 1);
      heff_take_n(v_t_247, 3ULL, 2);
      switch (heff_tag_of(v_a_248)) {
      case TAG_Nothing: {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        heff_drop(v_a_249);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
      case TAG_Just: {
        V v_a_2410 = heff_field(v_a_248, 0);
        heff_take_n(v_a_248, 1ULL, 1);
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          heff_drop(v_x_243);
          heff_drop_cell(v_ru_24x2_242_24Cons, 2);
          heff_drop(v_a_2410);
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_xs_244;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_x2_242 = t_2;
          goto top;
        }
        case TAG_Just: {
          V v_a_2411 = heff_field(v_a_249, 0);
          heff_take_n(v_a_249, 1ULL, 1);
          if ((heff_intLe_c_lent(v_lit_240, v_a_2410, 0) && heff_intLe_c_lent(v_a_2411, v_lit_241, 0))) {
            heff_drop(v_a_2410);
            heff_drop(v_a_2411);
            V v_cell_2412 = heff_tag_re_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
            V v_u_2413 = (g_list_2ekeepIf_24s425280038x249084439_24dps(v_lit_240, v_lit_241, v_xs_244, v_cell_2412));
            heff_drop(v_u_2413);
            return v_cell_2412;
          } else {
            heff_drop(v_x_243);
            heff_drop_cell(v_ru_24x2_242_24Cons, 2);
            heff_drop(v_a_2410);
            heff_drop(v_a_2411);
            V t_0 = v_lit_240;
            V t_1 = v_lit_241;
            V t_2 = v_xs_244;
            v_lit_240 = t_0;
            v_lit_241 = t_1;
            v_x2_242 = t_2;
            goto top;
          }
        }
        default: return heff_nomatch(v_a_249);
        }
      }
      default: return heff_nomatch(v_a_248);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s425280038x249084439_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s425280038x249084439(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eall_24s568190696x1372373514_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s568190696x1372373514_entry, 1, 0};

V g_list_2eall_24s568190696x1372373514(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_StmtBind: {
        return NTAG(TAG_False);
      }
      case TAG_StmtLet: {
        return NTAG(TAG_False);
      }
      case TAG_StmtExpr: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_StmtLetMut: {
        return NTAG(TAG_False);
      }
      case TAG_StmtLetElse: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_a_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s568190696x1372373514_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s568190696x1372373514(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1180860948x1107067117_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1180860948x1107067117_24dps_entry, 2, 0};

V g_list_2emap_24s1180860948x1107067117_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkBinding: {
        V v_a_247 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 2ULL, 2);
        v_t_248 = v_a_247;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_249);
    V t_0 = v_xs_243;
    V t_1 = v_u_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1180860948x1107067117_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1180860948x1107067117_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_list_2emap_24s97919758x216970748_24dps_lam0(V self, V *args);
Clo g_list_2emap_24s97919758x216970748_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s97919758x216970748_24dps_entry, 3, 0};

V g_list_2emap_24s97919758x216970748_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_245 = heff_dup(v_lit_240);
    V v_x2_246 = v_x_243;
    V v_t_2436;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_At: {
      V v_x21_247 = heff_field(v_x2_246, 0);
      V v_sp_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24At = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      switch (heff_tag_of(v_x21_247)) {
      case TAG_TagVariant: {
        V v_t_249 = heff_field(v_x21_247, 0);
        V v_tsp_2410 = heff_field(v_x21_247, 1);
        V v_args_2411 = heff_field(v_x21_247, 2);
        V v_ru_24x21_247_24TagVariant = heff_take_reuse_n(v_x21_247, 7ULL, 3);
        V v_t_2423 = (g_list_2emap(heff_clo_n(g_list_2emap_24s97919758x216970748_24dps_lam0, 1, 1, (V[]){v_r_245}), v_args_2411));
        v_t_2436 = heff_tag_re_n(v_ru_24x2_246_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_247_24TagVariant, TAG_TagVariant, 3, 3ULL, (V[]){v_t_249, v_tsp_2410, v_t_2423}), v_sp_248});
        break;
      }
      case TAG_BadVariant: {
        V v_e_2424 = heff_field(v_x21_247, 0);
        V v_ru_24x21_247_24BadVariant = heff_take_reuse_n(v_x21_247, 1ULL, 1);
        V v_x1_2425 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_e_2424}));
        V v_t_2435;
        switch (heff_tag_of(v_x1_2425)) {
        case TAG_IsInferable: {
          V v_i_2426 = heff_field(v_x1_2425, 0);
          V v_ru_24x1_2425_24IsInferable = heff_take_reuse_n(v_x1_2425, 1ULL, 1);
          V v_t_2429;
          switch (heff_tag_of(v_i_2426)) {
          case TAG_At: {
            V v_s_2428 = heff_dup(heff_field(v_i_2426, 1));
            v_t_2429 = v_s_2428;
            break;
          }
          default: heff_nomatch(v_i_2426);
          }
          v_t_2435 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2425_24IsInferable, TAG_TInf, 1, (V[]){v_i_2426}), v_t_2429});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2430 = heff_field(v_x1_2425, 0);
          V v_ru_24x1_2425_24IsCheckable = heff_take_reuse_n(v_x1_2425, 1ULL, 1);
          V v_t_2433;
          switch (heff_tag_of(v_c_2430)) {
          case TAG_At: {
            V v_s_2432 = heff_dup(heff_field(v_c_2430, 1));
            v_t_2433 = v_s_2432;
            break;
          }
          default: heff_nomatch(v_c_2430);
          }
          v_t_2435 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2425_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2430}), v_t_2433});
          break;
        }
        case TAG_IsType: {
          V v_t_2434 = heff_field(v_x1_2425, 0);
          heff_take_n(v_x1_2425, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_246_24At, 2);
          v_t_2435 = v_t_2434;
          break;
        }
        default: heff_nomatch(v_x1_2425);
        }
        v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_247_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2435}), v_sp_248});
        break;
      }
      default: heff_nomatch(v_x21_247);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_cell_2437 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2436, heff_hole()});
    V v_u_2438 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2437);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2438;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s97919758x216970748_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s97919758x216970748_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_list_2emap_24s97919758x216970748_24dps_lam0(V self, V *args) {
  V v_e_2412 = args[0];
  V v_r_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2413 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_e_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_IsInferable: {
    V v_i_2414 = heff_field(v_x1_2413, 0);
    V v_ru_24x1_2413_24IsInferable = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_i_2414)) {
    case TAG_At: {
      V v_s_2416 = heff_dup(heff_field(v_i_2414, 1));
      v_t_2417 = v_s_2416;
      break;
    }
    default: heff_nomatch(v_i_2414);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2413_24IsInferable, TAG_TInf, 1, (V[]){v_i_2414}), v_t_2417});
  }
  case TAG_IsCheckable: {
    V v_c_2418 = heff_field(v_x1_2413, 0);
    V v_ru_24x1_2413_24IsCheckable = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
    V v_t_2421;
    switch (heff_tag_of(v_c_2418)) {
    case TAG_At: {
      V v_s_2420 = heff_dup(heff_field(v_c_2418, 1));
      v_t_2421 = v_s_2420;
      break;
    }
    default: heff_nomatch(v_c_2418);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2413_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2418}), v_t_2421});
  }
  case TAG_IsType: {
    V v_t_2422 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 1);
    return v_t_2422;
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
Clo g_list_2emap_24s2039279853x710813703_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2039279853x710813703_entry, 2, 0};

V g_list_2emap_24s2039279853x710813703(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_244 = heff_dup(v_lit_240);
    V v_x2_245 = v_x_242;
    V v_t_2434;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_sp_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24At = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_SetField: {
        V v_x_248 = heff_field(v_x21_246, 0);
        V v_xsp_249 = heff_field(v_x21_246, 1);
        V v_e_2410 = heff_field(v_x21_246, 2);
        V v_ru_24x21_246_24SetField = heff_take_reuse_n(v_x21_246, 7ULL, 3);
        V v_x1_2411 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_e_2410}));
        V v_t_2421;
        switch (heff_tag_of(v_x1_2411)) {
        case TAG_IsInferable: {
          V v_i_2412 = heff_field(v_x1_2411, 0);
          V v_ru_24x1_2411_24IsInferable = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
          V v_t_2415;
          switch (heff_tag_of(v_i_2412)) {
          case TAG_At: {
            V v_s_2414 = heff_dup(heff_field(v_i_2412, 1));
            v_t_2415 = v_s_2414;
            break;
          }
          default: heff_nomatch(v_i_2412);
          }
          v_t_2421 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2411_24IsInferable, TAG_CInf, 1, (V[]){v_i_2412}), v_t_2415});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2416 = heff_field(v_x1_2411, 0);
          heff_take_n(v_x1_2411, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_245_24At, 2);
          v_t_2421 = v_c_2416;
          break;
        }
        case TAG_IsType: {
          V v_t_2417 = heff_field(v_x1_2411, 0);
          V v_ru_24x1_2411_24IsType = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
          V v_t_2420;
          switch (heff_tag_of(v_t_2417)) {
          case TAG_At: {
            V v_s_2419 = heff_dup(heff_field(v_t_2417, 1));
            v_t_2420 = v_s_2419;
            break;
          }
          default: heff_nomatch(v_t_2417);
          }
          v_t_2421 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2411_24IsType, TAG_CType, 1, (V[]){v_t_2417}), v_t_2420});
          break;
        }
        default: heff_nomatch(v_x1_2411);
        }
        v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_246_24SetField, TAG_SetField, 3, 3ULL, (V[]){v_x_248, v_xsp_249, v_t_2421}), v_sp_247});
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2422 = heff_field(v_x21_246, 0);
        V v_ru_24x21_246_24BadFieldSet = heff_take_reuse_n(v_x21_246, 1ULL, 1);
        V v_x1_2423 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_e_2422}));
        V v_t_2433;
        switch (heff_tag_of(v_x1_2423)) {
        case TAG_IsInferable: {
          V v_i_2424 = heff_field(v_x1_2423, 0);
          V v_ru_24x1_2423_24IsInferable = heff_take_reuse_n(v_x1_2423, 1ULL, 1);
          V v_t_2427;
          switch (heff_tag_of(v_i_2424)) {
          case TAG_At: {
            V v_s_2426 = heff_dup(heff_field(v_i_2424, 1));
            v_t_2427 = v_s_2426;
            break;
          }
          default: heff_nomatch(v_i_2424);
          }
          v_t_2433 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2423_24IsInferable, TAG_CInf, 1, (V[]){v_i_2424}), v_t_2427});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2428 = heff_field(v_x1_2423, 0);
          heff_take_n(v_x1_2423, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_245_24At, 2);
          v_t_2433 = v_c_2428;
          break;
        }
        case TAG_IsType: {
          V v_t_2429 = heff_field(v_x1_2423, 0);
          V v_ru_24x1_2423_24IsType = heff_take_reuse_n(v_x1_2423, 1ULL, 1);
          V v_t_2432;
          switch (heff_tag_of(v_t_2429)) {
          case TAG_At: {
            V v_s_2431 = heff_dup(heff_field(v_t_2429, 1));
            v_t_2432 = v_s_2431;
            break;
          }
          default: heff_nomatch(v_t_2429);
          }
          v_t_2433 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2423_24IsType, TAG_CType, 1, (V[]){v_t_2429}), v_t_2432});
          break;
        }
        default: heff_nomatch(v_x1_2423);
        }
        v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_246_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2433}), v_sp_247});
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_cell_2435 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2434, heff_hole()});
    V v_u_2436 = ({ V a_0 = v_lit_240; V a_1 = v_xs_243; V a_2 = v_cell_2435; V r_ = (g_list_2emap_24s2039279853x710813703_24dps(a_0, a_1, a_2)); heff_drop(v_lit_240); r_; });
    heff_drop(v_u_2436);
    return v_cell_2435;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2039279853x710813703(a[0], a[1]);
}
Clo g_list_2eall_24s1512314936x520990916_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1512314936x520990916_entry, 1, 0};

V g_list_2eall_24s1512314936x520990916(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2espec_2ecallsNothing(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1512314936x520990916_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1512314936x520990916(a0); heff_drop(a0); return r;
}
Clo g_list_2ezipWith_24s583291244x257539062_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s583291244x257539062_24dps_entry, 3, 0};

V g_list_2ezipWith_24s583291244x257539062_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_SSet, 2, (V[]){v_x_243, heff_tag_n(TAG_OSimple, 1, (V[]){v_y_245})});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_u_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s583291244x257539062_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ezipWith_24s583291244x257539062_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s549724630x1684056779_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s549724630x1684056779_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s549724630x1684056779_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = heff_get_n(v_t_246, 1, 4);
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_247, 0ULL, 1);
      V v_cell_249 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_2410 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_249);
      V t_0 = v_xs_243;
      V t_1 = v_u_2410;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s549724630x1684056779_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ekeepIf_24s549724630x1684056779_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2efoldl_24s599926777x1799261815_str0, 0, "");
HEFF_LIT(g_list_2efoldl_24s599926777x1799261815_str1, 1, "-");
HEFF_LIT(g_list_2efoldl_24s599926777x1799261815_str2, 1, "-");
HEFF_LIT(g_list_2efoldl_24s599926777x1799261815_str3, 0, "");
V g_list_2efoldl_24s599926777x1799261815_lam0(V self, V *args);
V g_list_2efoldl_24s599926777x1799261815_lam1(V self, V *args);
V g_list_2efoldl_24s599926777x1799261815_lam2(V self, V *args);
V g_list_2efoldl_24s599926777x1799261815_lam3(V self, V *args);
V g_list_2efoldl_24s599926777x1799261815_lam4(V self, V *args);
Clo g_list_2efoldl_24s599926777x1799261815_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s599926777x1799261815_entry, 6, 0};

V g_list_2efoldl_24s599926777x1799261815(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_z_244, V v_x3_245) {
top: ;
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nil: {
    return v_z_244;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x3_245, 0);
    V v_xs_247 = heff_field(v_x3_245, 1);
    V v_ru_24x3_245_24Cons = heff_take_reuse_n(v_x3_245, 3ULL, 2);
    V v_kept_248 = heff_dup(v_lit_240);
    V v_facts_249 = heff_dup(v_lit_241);
    V v_fl_2410 = heff_dup(v_lit_242);
    V v_byKey_2411 = heff_dup(v_lit_243);
    V v_w_2412 = v_z_244;
    V v_ks_2413 = v_x_246;
    V v_m_2414 = (g_list_2efoldl_24s1614667250x430274379(heff_dup(g_std_2eordmap_2eempty_get()), v_ks_2413));
    V v_t_2415 = ({ V a_0 = v_m_2414; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2414); r_; });
    V v_ks_2416 = (g_list_2emap_24s1937570095x2110149801(v_t_2415));
    V v_m_2417 = (g_list_2efoldl_24s1614667250x430274379(heff_dup(g_std_2eordmap_2eempty_get()), v_ks_2413));
    V v_t_2418 = ({ V a_0 = v_m_2417; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2417); r_; });
    V v_t_2419 = (g_list_2emap_24s1937570095x2110149801(v_t_2418));
    V v_defs_2421 = ({ V b_0 = heff_clo_n(g_list_2efoldl_24s599926777x1799261815_lam0, 1, 1, (V[]){heff_dup(v_byKey_2411)}); V a_1 = v_t_2419; V r_ = (g_list_2emapMaybe(b_0, a_1)); heff_drop(b_0); r_; });
    V v_w_2422 = heff_dup(v_w_2412);
    V v_own_2423 = (g_list_2efoldl_24s1614667250x430274379(heff_dup(g_std_2eordmap_2eempty_get()), v_ks_2413));
    V v_t_2425 = ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_clo_n(g_list_2efoldl_24s599926777x1799261815_lam1, 1, 1, (V[]){v_byKey_2411}); V a_2 = v_ks_2413; V r_ = (g_list_2efoldl_24f1879234972x1413867191(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s2036409923x213187476(a_0, a_1)); heff_drop(v_t_2425); r_; });
    V v_xs_2436 = ({ V b_0 = heff_clo_n(g_list_2efoldl_24s599926777x1799261815_lam2, 1, 2, (V[]){v_w_2422, v_own_2423}); V a_1 = v_t_2426; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_m_2437 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2436; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_2436); r_; });
    V v_t_2438 = ({ V a_0 = v_m_2437; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2437); r_; });
    V v_out_2439 = (g_list_2emap_24s1937570095x2110149801(v_t_2438));
    V v_facts_2440 = heff_dup(v_facts_249);
    V v_fl_2441 = v_fl_2410;
    V v_w_2442 = heff_dup(v_w_2412);
    V v_defs_2443 = heff_dup(v_defs_2421);
    V v_out_2444 = heff_dup(v_out_2439);
    V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_out_2444));
    V v_z_2454 = ({ V b_0 = heff_clo_n(g_list_2efoldl_24s599926777x1799261815_lam3, 2, 1, (V[]){v_w_2442}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2445; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2445); r_; });
    V v_t_2455 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_2443));
    V v_t_24100 = ({ V b_0 = heff_clo_n(g_list_2efoldl_24s599926777x1799261815_lam4, 2, 1, (V[]){v_facts_2440}); V a_1 = v_z_2454; V a_2 = v_t_2455; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2455); r_; });
    V v_items_24101 = heff_tag_at_n(v_ru_24x3_245_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_fl_2441}), v_t_24100});
    HeffT2 v_t_24102 = (g_heff_2ecompile_2eirtext_2ehashW_24cpr(MK_INT(5381LL), MK_INT(7919LL), v_items_24101));
    {
      V v_field_24103 = v_t_24102.f[0];
      V v_field_24104 = v_t_24102.f[1];
      V v_a_24105 = v_field_24103;
      V v_b_24106 = v_field_24104;
      V v_t_24107 = heff_strAppend(heff_intShow(v_a_24105), ((V)&g_list_2efoldl_24s599926777x1799261815_str2));
      V v_ver_24108 = heff_strAppend(v_t_24107, heff_intShow(v_b_24106));
      V v_facts_24109 = v_facts_249;
      V v_w_24110 = v_w_2412;
      V v_ks_24111 = heff_dup(v_ks_2416);
      V v_defs_24112 = v_defs_2421;
      V v_out_24113 = v_out_2439;
      V v_ver_24114 = heff_dup(v_ver_24108);
      V v_ver_24115 = v_ver_24108;
      V v_ks_24116 = heff_dup(v_ks_2416);
      V v_t_24119;
      switch (heff_tag_of(v_ks_2416)) {
      case TAG_Nil: {
        v_t_24119 = ((V)&g_list_2efoldl_24s599926777x1799261815_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_24117 = heff_field(v_ks_2416, 0);
        heff_take_n(v_ks_2416, 1ULL, 2);
        v_t_24119 = v_x_24117;
        break;
      }
      default: heff_nomatch(v_ks_2416);
      }
      HeffT2 v_t_24120 = ({ V a_0 = v_kept_248; V a_1 = v_t_24119; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_kept_248); heff_drop(v_t_24119); r_; });
      {
        V v_field_24122 = v_t_24120.f[1];
        int64_t v_tag_24121 = ((int64_t)v_t_24120.f[0]);
        V v_x7_24131;
        if ((v_tag_24121 == ((int64_t)0ULL))) {
          V v_k_24123 = v_field_24122;
          V v_ver_24124 = heff_take_field(v_k_24123, 0);
          V v_members_24125 = heff_get_n(v_k_24123, 1, 2);
          if (heff_strEq_c(v_ver_24124, v_ver_24115)) {
            V v_t_24126 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ks_24116));
            V v_t_24127 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_members_24125));
            if (heff_intEq_c(v_t_24126, v_t_24127)) {
              V v_t_24128 = (g_list_2emap_24s1691158757x119117542(heff_dup(v_members_24125)));
              V v_t_24129 = (g_list_2ezipWith_24s1876717925x1404326288(v_ks_24116, v_t_24128));
              V v_t_24130 = ({ V a_0 = v_t_24129; V r_ = (g_list_2eall_24s346977901x1952909174(a_0)); heff_drop(v_t_24129); r_; });
              if ((heff_dup(v_t_24130) == NTAG(TAG_True))) {
                heff_drop(v_t_24130);
                v_x7_24131 = heff_tag_n(TAG_Just, 1, (V[]){v_members_24125});
              } else {
                heff_drop(v_members_24125);
                heff_drop(v_t_24130);
                v_x7_24131 = NTAG(TAG_Nothing);
              }
            } else {
              heff_drop(v_ks_24116);
              heff_drop(v_members_24125);
              v_x7_24131 = NTAG(TAG_Nothing);
            }
          } else {
            heff_drop(v_ks_24116);
            heff_drop(v_members_24125);
            v_x7_24131 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_ver_24115);
          heff_drop(v_ks_24116);
          heff_drop(v_field_24122);
          v_x7_24131 = NTAG(TAG_Nothing);
        }
        V v_t_24138;
        switch (heff_tag_of(v_x7_24131)) {
        case TAG_Nothing: {
          v_t_24138 = (g_heff_2ecompile_2ecomponents_2ecomputed(v_facts_24109, v_w_24110, v_ks_24111, v_defs_24112, v_out_24113, v_ver_24114));
          break;
        }
        case TAG_Just: {
          V v_ms_24132 = heff_field(v_x7_24131, 0);
          heff_take_n(v_x7_24131, 1ULL, 1);
          heff_drop(v_facts_24109);
          heff_drop(v_ks_24111);
          heff_drop(v_defs_24112);
          heff_drop(v_out_24113);
          heff_drop(v_ver_24114);
          V v_fresh_24133 = heff_take_field(v_w_24110, 4);
          V v_t_24134 = (g_list_2efoldl_24s1721918130x1703222899(heff_take_field(v_w_24110, 0), v_ms_24132));
          V v_t_24135 = (g_list_2efoldl_24s1568113292x813960132(heff_take_field(v_w_24110, 1), v_ms_24132));
          V v_t_24136 = (g_list_2efoldl_24s2079805794x637914515(heff_take_field(v_w_24110, 2), v_ms_24132));
          V v_t_24137 = (g_list_2efoldl_24s878331809x629122930(heff_take_field(v_w_24110, 3), v_ms_24132));
          v_t_24138 = ({ V rv_0 = v_t_24134; V rv_1 = v_t_24135; V rv_2 = v_t_24136; V rv_3 = v_t_24137; V rv_4 = v_fresh_24133; V rr_ = heff_rec_reuse_nf(v_w_24110, 0ULL, 5, shape_tracks__sigs__lent__sums__fresh, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
          break;
        }
        default: heff_nomatch(v_x7_24131);
        }
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_t_24138;
        V t_5 = v_xs_247;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_z_244 = t_4;
        v_x3_245 = t_5;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_list_2efoldl_24s599926777x1799261815_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2efoldl_24s599926777x1799261815(a0, a1, a2, a3, a[4], a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_list_2efoldl_24s599926777x1799261815_lam0(V self, V *args) {
  V v_k_2420 = args[0];
  V v_byKey_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_byKey_2411; V a_1 = v_k_2420; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_byKey_2411); heff_drop(v_k_2420); r_; });
}
V g_list_2efoldl_24s599926777x1799261815_lam1(V self, V *args) {
  V v_k_2424 = args[0];
  V v_byKey_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_byKey_2411; V a_1 = v_k_2424; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_byKey_2411); heff_drop(v_k_2424); r_; });
}
V g_list_2efoldl_24s599926777x1799261815_lam2(V self, V *args) {
  V v_g_2427 = args[0];
  V v_w_2422 = heff_env(self)[0];
  V v_own_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2428 = ({ V b_0 = heff_get_n(v_w_2422, 3, 5); V a_1 = v_g_2427; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2430 = v_t_2428.f[1];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      V v_x_2431 = v_field_2430;
      heff_drop(v_x_2431);
      HeffT2 v_t_2432 = ({ V a_0 = v_own_2423; V a_1 = v_g_2427; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_own_2423); heff_drop(v_g_2427); r_; });
      {
        V v_field_2434 = v_t_2432.f[1];
        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
        V v_ret_24bool = heff_bool(((v_tag_2433 == ((int64_t)0ULL)) ? ({ V v_x_2435 = heff_dup(v_field_2434); int c_ = 0; heff_drop(v_x_2435); c_; }) : 1));
        heff_drop(v_field_2434);
        return v_ret_24bool;
      }
    } else {
      heff_drop(v_g_2427);
      heff_drop(v_own_2423);
      heff_drop(v_field_2430);
      return NTAG(TAG_False);
    }
  }
}
V g_list_2efoldl_24s599926777x1799261815_lam3(V self, V *args) {
  V v_acc_2446 = args[0];
  V v_x_2447 = args[1];
  V v_w_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2448 = ({ V b_0 = heff_get_n(v_w_2442, 3, 5); V a_1 = v_x_2447; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2450 = v_t_2448.f[1];
    int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
    V v_t_2452;
    if ((v_tag_2449 == ((int64_t)0ULL))) {
      V v_x_2451 = v_field_2450;
      v_t_2452 = v_x_2451;
    } else {
      heff_drop(v_field_2450);
      v_t_2452 = ((V)&g_list_2efoldl_24s599926777x1799261815_str0);
    }
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2452}), v_acc_2446});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_2447}), v_t_2453});
  }
}
V g_list_2efoldl_24s599926777x1799261815_lam4(V self, V *args) {
  V v_acc_2456 = args[0];
  V v_x_2457 = args[1];
  V v_facts_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_facts_2458 = v_facts_2440;
  V v_hashes_2459 = heff_take_field(v_facts_2458, 11);
  V v_arity_2460 = heff_take_field(v_facts_2458, 0);
  V v_bounce_2461 = heff_get_n(v_facts_2458, 1, 12);
  V v_d_2462 = v_x_2457;
  V v_body_2463 = heff_take_field(v_d_2462, 2);
  V v_key_2464 = heff_take_field(v_d_2462, 0);
  V v_name_2465 = heff_get_n(v_d_2462, 1, 3);
  V v_rest_2466 = v_acc_2456;
  V v_b_2467 = v_body_2463;
  HeffT2 v_t_2468 = ({ V a_0 = v_hashes_2459; V a_1 = v_key_2464; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_hashes_2459); r_; });
  {
    V v_field_2470 = v_t_2468.f[1];
    int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
    V v_t_2485;
    if ((v_tag_2469 == ((int64_t)0ULL))) {
      heff_drop(v_b_2467);
      V v_h_2471 = v_field_2470;
      v_t_2485 = v_h_2471;
    } else {
      heff_drop(v_field_2470);
      HeffT2 v_t_2472 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), v_b_2467));
      {
        V v_field_2473 = v_t_2472.f[0];
        V v_field_2474 = v_t_2472.f[1];
        V v_x_2475 = v_field_2473;
        V v_y_2476 = v_field_2474;
        heff_drop(v_y_2476);
        V v_t_2477 = v_x_2475;
        V v_items_2478 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_t_2477}), NTAG(TAG_Nil)});
        HeffT2 v_t_2479 = (g_heff_2ecompile_2eirtext_2ehashW_24cpr(MK_INT(5381LL), MK_INT(7919LL), v_items_2478));
        {
          V v_field_2480 = v_t_2479.f[0];
          V v_field_2481 = v_t_2479.f[1];
          V v_a_2482 = v_field_2480;
          V v_b_2483 = v_field_2481;
          V v_t_2484 = heff_strAppend(heff_intShow(v_a_2482), ((V)&g_list_2efoldl_24s599926777x1799261815_str1));
          v_t_2485 = heff_strAppend(v_t_2484, heff_intShow(v_b_2483));
        }
      }
    }
    HeffT2 v_t_2486 = ({ V a_0 = v_arity_2460; V a_1 = v_key_2464; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_arity_2460); r_; });
    {
      V v_field_2488 = v_t_2486.f[1];
      int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
      V v_t_2490;
      if ((v_tag_2487 == ((int64_t)0ULL))) {
        V v_x_2489 = v_field_2488;
        v_t_2490 = v_x_2489;
      } else {
        heff_drop(v_field_2488);
        v_t_2490 = MK_INT(-1LL);
      }
      HeffT2 v_t_2491 = ({ V a_0 = v_bounce_2461; V a_1 = v_key_2464; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_bounce_2461); r_; });
      {
        V v_field_2493 = v_t_2491.f[1];
        int64_t v_tag_2492 = ((int64_t)v_t_2491.f[0]);
        V v_t_2495;
        if ((v_tag_2492 == ((int64_t)0ULL))) {
          V v_x_2494 = v_field_2493;
          heff_drop(v_x_2494);
          v_t_2495 = MK_INT(1LL);
        } else {
          heff_drop(v_field_2493);
          v_t_2495 = MK_INT(0LL);
        }
        V v_t_2496 = heff_tag_n(TAG_HN, 1, (V[]){heff_intAdd(v_t_2490, MK_INT(1LL))});
        V v_t_2497 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2495}), v_rest_2466});
        V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2485}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2496, v_t_2497})});
        V v_t_2499 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_name_2465}), v_t_2498});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_key_2464}), v_t_2499});
      }
    }
  }
}
Clo g_list_2efoldl_24s1530401830x609500251_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1530401830x609500251_entry, 2, 0};

V g_list_2efoldl_24s1530401830x609500251(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1530401830x609500251(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1996317718x1931167845_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1996317718x1931167845_entry, 2, 0};

V g_list_2efoldl_24s1996317718x1931167845(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_list_2efoldl_24s1860157317x1198712058(v_z_240, v_t_2412));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1996317718x1931167845_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1996317718x1931167845(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s1530546918x299821644_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1530546918x299821644_entry, 2, 0};

V g_list_2ezipWith_24s1530546918x299821644(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_246 = (g_heff_2ecompile_2ecpr_2efldAt(v_x_242, v_y_244));
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s1530546918x299821644_24dps(v_xs_243, v_ys_245, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1530546918x299821644_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1530546918x299821644(a[0], a[1]);
}
Clo g_list_2emap_24s1851573375x1006375246_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1851573375x1006375246_entry, 3, 0};

V g_list_2emap_24s1851573375x1006375246(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2ecaptures_2ecapSt(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_xs_244; V a_3 = v_cell_246; V r_ = (g_list_2emap_24s1851573375x1006375246_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1851573375x1006375246_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1851573375x1006375246(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2efoldl_24s441088199x272212076_str0, 2, "$s");
HEFF_LIT(g_list_2efoldl_24s441088199x272212076_str1, 2, "$s");
HEFF_LIT(g_list_2efoldl_24s441088199x272212076_str2, 2, "$s");
Clo g_list_2efoldl_24s441088199x272212076_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s441088199x272212076_entry, 2, 0};

V g_list_2efoldl_24s441088199x272212076(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_m_244 = v_z_240;
    V v_d_245 = v_x_242;
    V v_g_246 = heff_dup(heff_rfield(v_d_245, 0));
    V v_j_247 = heff_strFind_lent(((V)&g_list_2efoldl_24s441088199x272212076_str0), v_g_246, MK_INT(0LL), 5);
    V v_t_248;
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      v_t_248 = v_g_246;
    } else {
      v_t_248 = heff_strSlice(v_g_246, MK_INT(0LL), v_j_247);
    }
    V v_t_2421;
    if (heff_strEq_c(v_t_248, heff_dup(heff_rfield(v_d_245, 0)))) {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop_rec(v_d_245, 3);
      v_t_2421 = v_m_244;
    } else {
      V v_g_249 = heff_dup(heff_rfield(v_d_245, 0));
      V v_j_2410 = heff_strFind_lent(((V)&g_list_2efoldl_24s441088199x272212076_str1), v_g_249, MK_INT(0LL), 5);
      V v_t_2411;
      if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
        heff_drop(v_j_2410);
        v_t_2411 = v_g_249;
      } else {
        v_t_2411 = heff_strSlice(v_g_249, MK_INT(0LL), v_j_2410);
      }
      V v_g_2412 = heff_dup(heff_rfield(v_d_245, 0));
      V v_j_2413 = heff_strFind_lent(((V)&g_list_2efoldl_24s441088199x272212076_str2), v_g_2412, MK_INT(0LL), 5);
      V v_t_2414;
      if (heff_intLt_c_lent(v_j_2413, MK_INT(0LL), 2)) {
        heff_drop(v_j_2413);
        v_t_2414 = v_g_2412;
      } else {
        v_t_2414 = heff_strSlice(v_g_2412, MK_INT(0LL), v_j_2413);
      }
      HeffT2 v_t_2415 = ({ V a_0 = v_m_244; V a_1 = v_t_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2414); r_; });
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        V v_t_2419;
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_x_2418 = v_field_2417;
          v_t_2419 = v_x_2418;
        } else {
          heff_drop(v_field_2417);
          v_t_2419 = NTAG(TAG_Nil);
        }
        V v_t_2420 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_d_245, 0, 3), v_t_2419});
        v_t_2421 = ({ V a_0 = v_m_244; V a_1 = v_t_2411; V a_2 = v_t_2420; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2411); heff_drop_tag(v_t_2420, 2); r_; });
      }
    }
    V t_0 = v_t_2421;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s441088199x272212076_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s441088199x272212076(a[0], a[1]);
}
V g_list_2ekeepIf_24s614579978x208602650_lam0(V self, V *args);
V g_list_2ekeepIf_24s614579978x208602650_lam1(V self, V *args);
V g_list_2ekeepIf_24s614579978x208602650_lam2(V self, V *args);
Clo g_list_2ekeepIf_24s614579978x208602650_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s614579978x208602650_entry, 2, 0};

V g_list_2ekeepIf_24s614579978x208602650(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_bodies_244 = heff_dup(v_lit_240);
    V v_ks_245 = heff_dup(v_x_242);
    V v_t_2414 = ({ V b_0 = heff_clo_n(g_list_2ekeepIf_24s614579978x208602650_lam0, 1, 1, (V[]){heff_dup(v_bodies_244)}); V a_1 = v_ks_245; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); r_; });
    if (((heff_dup(v_t_2414) == NTAG(TAG_True)) && ({ V v_t_2415 = (g_list_2efoldl_24s278088687x1269971185(heff_dup(g_std_2eordmap_2eempty_get()), v_ks_245)); int c_ = ({ V v_t_2421 = (g_list_2emap(heff_clo_n(g_list_2ekeepIf_24s614579978x208602650_lam1, 1, 1, (V[]){heff_dup(v_bodies_244)}), heff_dup(v_ks_245))); int c_ = ({ V v_c_2433 = heff_tr(g_heff_2ecompile_2edefun_2ehandsW(v_t_2415, heff_dup(v_t_2421))); int c_ = ((heff_dup(v_c_2433) == NTAG(TAG_True)) && ({ V v_t_2434 = ({ V b_0 = heff_clo_n(g_list_2ekeepIf_24s614579978x208602650_lam2, 2, 1, (V[]){heff_dup(v_bodies_244)}); V a_1 = MK_INT(0LL); V a_2 = v_ks_245; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; }); int c_ = heff_intLe_c_lent(v_t_2434, MK_INT(20000LL), 2); heff_drop(v_t_2434); c_; })); heff_drop(v_c_2433); c_; }); heff_drop(v_t_2421); c_; }); heff_drop(v_t_2415); c_; }))) {
      heff_drop(v_bodies_244);
      heff_drop(v_ks_245);
      heff_drop(v_t_2414);
      V v_cell_2431 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_2432 = (g_list_2ekeepIf_24s614579978x208602650_24dps(v_lit_240, v_xs_243, v_cell_2431));
      heff_drop(v_u_2432);
      return v_cell_2431;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_bodies_244);
      heff_drop(v_ks_245);
      heff_drop(v_t_2414);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s614579978x208602650_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s614579978x208602650(a0, a[1]); heff_drop(a0); return r;
}
V g_list_2ekeepIf_24s614579978x208602650_lam0(V self, V *args) {
  V v_k_246 = args[0];
  V v_bodies_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_247 = ({ V a_0 = v_bodies_244; V a_1 = v_k_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_244); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    V v_t_2411;
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_249;
      v_t_2411 = v_x_2410;
    } else {
      heff_drop(v_field_249);
      v_t_2411 = NTAG(TAG_EAbandon);
    }
    V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(v_t_2411));
    V v_xs_2413 = (g_heff_2ecompile_2eir_2enubI(v_t_2412));
    return ({ V a_0 = v_k_246; V a_1 = v_xs_2413; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_k_246); heff_drop(v_xs_2413); r_; });
  }
}
V g_list_2ekeepIf_24s614579978x208602650_lam1(V self, V *args) {
  V v_k_2416 = args[0];
  V v_bodies_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2417 = ({ V a_0 = v_bodies_244; V a_1 = v_k_2416; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_244); heff_drop(v_k_2416); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2419;
      return v_x_2420;
    } else {
      heff_drop(v_field_2419);
      return NTAG(TAG_EAbandon);
    }
  }
}
V g_list_2ekeepIf_24s614579978x208602650_lam2(V self, V *args) {
  V v_n_2422 = args[0];
  V v_k_2423 = args[1];
  V v_bodies_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2424 = ({ V a_0 = v_bodies_244; V a_1 = v_k_2423; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_244); heff_drop(v_k_2423); r_; });
  {
    V v_field_2426 = v_t_2424.f[1];
    int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
    V v_t_2428;
    if ((v_tag_2425 == ((int64_t)0ULL))) {
      V v_x_2427 = v_field_2426;
      v_t_2428 = v_x_2427;
    } else {
      heff_drop(v_field_2426);
      v_t_2428 = NTAG(TAG_EAbandon);
    }
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
    V v_t_2430 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2429));
    return heff_intAdd(v_n_2422, v_t_2430);
  }
}
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_str0, 1, "\"");
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_str1, 1, "\"");
Clo g_list_2emap_24s1397747289x2145601499_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1397747289x2145601499_entry, 1, 0};

V g_list_2emap_24s1397747289x2145601499(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V a_1 = MK_INT(0LL); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1397747289x2145601499_str0), v_t_243), ((V)&g_list_2emap_24s1397747289x2145601499_str1));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1397747289x2145601499_24dps(v_xs_242, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1397747289x2145601499(a[0]);
}
Clo g_list_2emap_24s570884835x2121220820_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570884835x2121220820_entry, 1, 0};

V g_list_2emap_24s570884835x2121220820(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), v_x_241});
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s570884835x2121220820_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570884835x2121220820_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570884835x2121220820(a[0]);
}
Clo g_list_2ekeepIf_24s924780574x2000457388_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s924780574x2000457388_entry, 2, 0};

V g_list_2ekeepIf_24s924780574x2000457388(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_UpdateTo: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_2412 = v_a_244;
      break;
    }
    case TAG_UpdateIn: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 0));
      v_t_2412 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_2412, v_lit_240, 1)) {
      V v_cell_2413 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_2414 = (g_list_2ekeepIf_24s924780574x2000457388_24dps(v_lit_240, v_xs_243, v_cell_2413));
      heff_drop(v_u_2414);
      return v_cell_2413;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s924780574x2000457388_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s924780574x2000457388(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2ezipWith_24s634961829x758866838_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s634961829x758866838_24dps_entry, 3, 0};

V g_list_2ezipWith_24s634961829x758866838_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_x_243, 0);
        heff_take_n(v_x_243, 1ULL, 2);
        v_t_249 = v_a_247;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_249, heff_get_n(v_y_245, 1, 2)});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2411);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_u_2412;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s634961829x758866838_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ezipWith_24s634961829x758866838_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s2062166816x394105956_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2062166816x394105956_24dps_entry, 2, 0};

V g_list_2emap_24s2062166816x394105956_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, NTAG(TAG_MkUnit)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2062166816x394105956_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s2062166816x394105956_24dps(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_list_2elookup_24s1507486579x90027037_24cpr(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_27_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c_lent(v_k_240, v_k_27_244, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_245)}});
      } else {
        V t_0 = v_k_240;
        V t_1 = v_rest_243;
        v_k_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_list_2efoldl_24s398854970x1533504811_str0, 1, "$");
HEFF_LIT(g_list_2efoldl_24s398854970x1533504811_str1, 2, "$c");
HEFF_LIT(g_list_2efoldl_24s398854970x1533504811_str2, 1, "$");
HEFF_LIT(g_list_2efoldl_24s398854970x1533504811_str3, 1, "(");
HEFF_LIT(g_list_2efoldl_24s398854970x1533504811_str4, 1, "$");
HEFF_LIT(g_list_2efoldl_24s398854970x1533504811_str5, 1, "(");
Clo g_list_2efoldl_24s398854970x1533504811_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s398854970x1533504811_entry, 2, 0};

V g_list_2efoldl_24s398854970x1533504811(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_m_244 = v_z_240;
    V v_part_245 = heff_dup(v_x_242);
    V v_t_2447;
    switch (heff_tag_of(v_part_245)) {
    case TAG_PartVal: {
      V v_part1_246 = heff_field(v_part_245, 0);
      heff_take_n(v_part_245, 1ULL, 1);
      switch (heff_tag_of(v_part1_246)) {
      case TAG_SVar: {
        heff_take_n(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_part1_246, 0ULL, 2);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SPrimFn: {
        V v_p_2416 = heff_field(v_part1_246, 0);
        heff_take_n(v_part1_246, 1ULL, 1);
        V v_t_2417 = ({ V a_0 = v_p_2416; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2416); r_; });
        V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_list_2efoldl_24s398854970x1533504811_str0), v_t_2417), ((V)&g_list_2efoldl_24s398854970x1533504811_str1));
        v_t_2447 = ({ V a_0 = v_m_244; V a_1 = v_t_2418; V a_2 = NTAG(TAG_MkUnit); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_part1_246, 0ULL, 2);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_STag: {
        heff_take_n(v_part1_246, 0ULL, 3);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_part1_246, 0ULL, 2);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_part1_246, 0ULL, 4);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SPrim: {
        V v_p_2430 = heff_field(v_part1_246, 0);
        V v_args_2431 = heff_field(v_part1_246, 1);
        heff_take_n(v_part1_246, 3ULL, 2);
        V v_t_2432 = ({ V a_0 = v_p_2430; V a_1 = v_args_2431; V r_ = (g_heff_2ecompile_2eemit_2ecallsHelper(a_0, a_1)); heff_drop(v_args_2431); r_; });
        if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
          heff_drop(v_t_2432);
          V v_t_2433 = ({ V a_0 = v_p_2430; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2430); r_; });
          V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_list_2efoldl_24s398854970x1533504811_str2), v_t_2433), ((V)&g_list_2efoldl_24s398854970x1533504811_str3));
          v_t_2447 = ({ V a_0 = v_m_244; V a_1 = v_t_2434; V a_2 = NTAG(TAG_MkUnit); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2434); r_; });
        } else {
          heff_drop(v_p_2430);
          heff_drop(v_t_2432);
          v_t_2447 = v_m_244;
        }
        break;
      }
      default: heff_nomatch(v_part1_246);
      }
      break;
    }
    case TAG_PartOp: {
      V v_part1_2435 = heff_field(v_part_245, 0);
      heff_take_n(v_part_245, 1ULL, 1);
      switch (heff_tag_of(v_part1_2435)) {
      case TAG_OSimple: {
        heff_take_n(v_part1_2435, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_OCall: {
        heff_take_n(v_part1_2435, 0ULL, 2);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_OApply: {
        heff_take_n(v_part1_2435, 0ULL, 2);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_OPrim: {
        V v_p_2441 = heff_field(v_part1_2435, 0);
        V v_args_2442 = heff_field(v_part1_2435, 1);
        heff_take_n(v_part1_2435, 3ULL, 2);
        V v_t_2443 = ({ V a_0 = v_p_2441; V a_1 = v_args_2442; V r_ = (g_heff_2ecompile_2eemit_2ecallsHelper(a_0, a_1)); heff_drop(v_args_2442); r_; });
        if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
          heff_drop(v_t_2443);
          V v_t_2444 = ({ V a_0 = v_p_2441; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2441); r_; });
          V v_t_2445 = heff_strAppend(heff_strAppend(((V)&g_list_2efoldl_24s398854970x1533504811_str4), v_t_2444), ((V)&g_list_2efoldl_24s398854970x1533504811_str5));
          v_t_2447 = ({ V a_0 = v_m_244; V a_1 = v_t_2445; V a_2 = NTAG(TAG_MkUnit); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2445); r_; });
        } else {
          heff_drop(v_p_2441);
          heff_drop(v_t_2443);
          v_t_2447 = v_m_244;
        }
        break;
      }
      case TAG_OAbandon: {
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_OBool: {
        heff_take_n(v_part1_2435, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      default: heff_nomatch(v_part1_2435);
      }
      break;
    }
    default: heff_nomatch(v_part_245);
    }
    V t_0 = v_t_2447;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s398854970x1533504811(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1613211967x1923010103_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1613211967x1923010103_entry, 4, 0};

V g_list_2emap_24s1613211967x1923010103(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(heff_dup(v_x_244)));
    V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, heff_dup(v_lit_241)), heff_intShow(v_x_244));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_247, heff_dup(v_lit_242)), heff_hole()});
    V v_u_249 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_xs_245; V a_4 = v_cell_248; V r_ = (g_list_2emap_24s1613211967x1923010103_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1613211967x1923010103_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1613211967x1923010103(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s1041788812x158895160_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1041788812x158895160_entry, 1, 0};

V g_list_2eany_24s1041788812x158895160(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkCArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      v_t_2411 = heff_bool(heff_strEq_c(heff_dup(v_t_243), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get())));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2411);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1041788812x158895160_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1041788812x158895160(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1071292119x112543158_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1071292119x112543158_entry, 10, 0};

V g_list_2efoldl_24s1071292119x112543158(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_z_248, V v_x3_249) {
top: ;
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nil: {
    return v_z_248;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x3_249, 0);
    V v_xs_2411 = heff_field(v_x3_249, 1);
    V v_ru_24x3_249_24Cons = heff_take_reuse_n(v_x3_249, 3ULL, 2);
    V v_a_2414;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2412 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2414 = heff_get_n(v_a_2412, 0, 3);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2415 = (g_heff_2ecompile_2eemitc_2elastDotGo(v_a_2414, heff_dup(v_lit_240), heff_dup(v_lit_241)));
    V v_t_2416;
    if (heff_intLt_c_lent(v_a_2415, v_lit_242, 0)) {
      heff_drop(v_a_2415);
      v_t_2416 = v_a_2414;
    } else {
      v_t_2416 = heff_strSlice_lent(v_a_2414, v_lit_243, v_a_2415, 5);
    }
    V v_a_2419;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2417 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2419 = heff_get_n(v_a_2417, 0, 3);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2420 = (g_heff_2ecompile_2eemitc_2elastDotGo(v_a_2419, heff_dup(v_lit_244), heff_dup(v_lit_245)));
    V v_t_2421;
    if (heff_intLt_c_lent(v_a_2420, v_lit_246, 0)) {
      heff_drop(v_a_2420);
      v_t_2421 = v_a_2419;
    } else {
      v_t_2421 = heff_strSlice_lent(v_a_2419, v_lit_247, v_a_2420, 5);
    }
    HeffT2 v_t_2422 = ({ V a_0 = v_z_248; V a_1 = v_t_2421; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2421); r_; });
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      V v_t_2426;
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        V v_a_2425 = v_field_2424;
        v_t_2426 = v_a_2425;
      } else {
        heff_drop(v_field_2424);
        v_t_2426 = NTAG(TAG_Nil);
      }
      V v_t_2427 = ({ V a_0 = v_z_248; V a_1 = v_t_2416; V b_2 = heff_tag_re_n(v_ru_24x3_249_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_2410, v_t_2426}); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, b_2)); heff_drop(v_t_2416); heff_drop(b_2); r_; });
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_t_2427;
      V t_9 = v_xs_2411;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_z_248 = t_8;
      v_x3_249 = t_9;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_249);
  }
}
V g_list_2efoldl_24s1071292119x112543158_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2efoldl_24s1071292119x112543158(a0, a1, a2, a3, a4, a5, a6, a7, a[8], a[9]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); return r;
}
Clo g_list_2efoldl_24s1894035205x969464323_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1894035205x969464323_entry, 3, 0};

V g_list_2efoldl_24s1894035205x969464323(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_intAdd(v_z_241, heff_strLength_lent(v_x_243, 0));
    V t_0 = v_lit_240;
    V t_1 = heff_intAdd_lent(v_t_245, v_lit_240, 1);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl_24s1894035205x969464323(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s2015972532x1874881274_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2015972532x1874881274_entry, 2, 0};

V g_list_2ekeepIf_24s2015972532x1874881274(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_intEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s2015972532x1874881274_24dps(v_lit_240, v_xs_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2015972532x1874881274_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s2015972532x1874881274(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s388004800x1261967008_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s388004800x1261967008_entry, 1, 0};

V g_list_2emap_24s388004800x1261967008(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s388004800x1261967008_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s388004800x1261967008(a[0]);
}
Clo g_list_2ekeepIf_24s647917584x875728492_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s647917584x875728492_entry, 2, 0};

V g_list_2ekeepIf_24s647917584x875728492(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_lit_240, 1)))) {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s647917584x875728492_24dps(v_lit_240, v_xs_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 14);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s647917584x875728492_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s647917584x875728492(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s647917584x875728492_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s647917584x875728492_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s647917584x875728492_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(heff_rfield(v_lit_240, 1)))) {
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 14);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s647917584x875728492_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24s647917584x875728492_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s491084544x100802329_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s491084544x100802329_entry, 2, 0};

V g_list_2efoldl_24s491084544x100802329(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_a_248)));
        v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_249); r_; });
        break;
      }
      case TAG_BadVariant: {
        V v_a_2410 = heff_field(v_a_244, 0);
        v_t_2411 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2410));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s491084544x100802329(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2epushRun_24s495990157x1087861527_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_24s495990157x1087861527_entry, 3, 0};

V g_list_2epushRun_24s495990157x1087861527(V v_k_240, V v_run_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_j_245 = heff_field(v_x41_243, 0);
      V v_below_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24MkPair = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_245, v_k_240, 0)) {
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_j_245);
        heff_drop_cell(v_ru_24x41_243_24MkPair, 2);
        V v_t_2411;
        switch (heff_tag_of(v_below_246)) {
        case TAG_Nil: {
          v_t_2411 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(NTAG(TAG_True), v_below_246, v_run_241));
          break;
        }
        case TAG_Cons: {
          V v_a_247 = heff_dup(heff_field(v_below_246, 0));
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nil: {
            heff_drop_rec(v_a_247, 7);
            v_t_2411 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(NTAG(TAG_True), v_below_246, v_run_241));
            break;
          }
          case TAG_Cons: {
            V v_b_249 = heff_dup(heff_field(v_run_241, 0));
            if (heff_intLe_c(heff_get_n(v_a_247, 2, 7), heff_get_n(v_b_249, 2, 7))) {
              v_t_2411 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(NTAG(TAG_True), v_below_246, v_run_241));
            } else {
              v_t_2411 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(NTAG(TAG_False), v_run_241, v_below_246));
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          break;
        }
        default: heff_nomatch(v_below_246);
        }
        V t_0 = heff_intAdd(v_k_240, MK_INT(1LL));
        V t_1 = v_t_2411;
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_run_241 = t_1;
        v_x4_242 = t_2;
        goto top;
      } else {
        V v_t_2412 = heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x41_243_24MkPair, TAG_MkPair, 2, 3ULL, (V[]){v_j_245, v_below_246}), v_rest_244});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), v_t_2412});
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2epushRun_24s495990157x1087861527_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun_24s495990157x1087861527(a[0], a[1], a[2]);
}
Clo g_list_2emergeRuns_24s1848188369x464661008_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s1848188369x464661008_entry, 2, 0};

V g_list_2emergeRuns_24s1848188369x464661008(V v_stack_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_run_242 = heff_field(v_x3_241, 0);
    V v_x32_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x32_243)) {
    case TAG_Nil: {
      return ({ V a_0 = v_run_242; V a_1 = v_stack_240; V r_ = (g_list_2ecollapse_24s705464212x1327502534(a_0, a_1)); heff_drop(v_stack_240); r_; });
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x32_243, 0);
      V v_xs_245 = heff_field(v_x32_243, 1);
      heff_take_n(v_x32_243, 3ULL, 2);
      V v_t_246 = (g_list_2epushRun_24s2022155310x1483676144(MK_INT(0LL), v_run_242, v_stack_240));
      V v_t_247 = (g_list_2erunFrom_24s272018256x1228369023(v_x_244, v_xs_245));
      V t_0 = v_t_246;
      V t_1 = v_t_247;
      v_stack_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x32_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2emergeRuns_24s1848188369x464661008_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeRuns_24s1848188369x464661008(a[0], a[1]);
}
Clo g_list_2efoldl_24s141260856x1366916752_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s141260856x1366916752_entry, 5, 0};

V g_list_2efoldl_24s141260856x1366916752(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    return v_z_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_244, 0);
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_Nil: {
      v_t_2412 = heff_dup(v_lit_240);
      break;
    }
    case TAG_Cons: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_t_249 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_a_247));
      V v_a_2410 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_249));
      V v_t_2411 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(v_lit_242, v_a_2410, v_a_248));
      v_t_2412 = heff_strAppend(heff_dup(v_lit_241), v_t_2411);
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2413 = heff_strLength(v_t_2412);
    V v_t_2414;
    if ((heff_peek_word(v_z_243) <= heff_peek_word(v_a_2413))) {
      heff_drop(v_z_243);
      v_t_2414 = v_a_2413;
    } else {
      heff_drop(v_a_2413);
      v_t_2414 = v_z_243;
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_2414;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s141260856x1366916752_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_list_2efoldl_24s141260856x1366916752(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_list_2edescending_24s379747839x1236130333_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_24s379747839x1236130333_entry, 5, 0};

V g_list_2edescending_24s379747839x1236130333(V v_lit_240, V v_lit_241, V v_x_242, V v_acc_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_242, 14);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x4_244, 0);
    V v_ys_246 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    V v_a_247 = heff_strCompare(heff_get_n(v_x_242, 0, 14), heff_dup(heff_rfield(v_y_245, 0)));
    if ((heff_intLt_c_lent(v_a_247, v_lit_240, 0) || heff_intEq_c_lent(v_a_247, v_lit_241, 0))) {
      heff_drop(v_a_247);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_245, v_ys_246})});
    } else {
      heff_drop(v_a_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = heff_dup(v_y_245);
      V t_3 = heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_245, v_acc_243});
      V t_4 = v_ys_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x_242 = t_2;
      v_acc_243 = t_3;
      v_x4_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2edescending_24s379747839x1236130333_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2edescending_24s379747839x1236130333(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s6718001x1068992521_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s6718001x1068992521_entry, 3, 0};

V g_list_2efoldl_24s6718001x1068992521(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_strRunes(heff_dup(heff_rfield(v_x_243, 0)));
    V v_a_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_t_247;
    if (heff_intLe_c_lent(v_z_241, v_a_246, 0)) {
      heff_drop(v_z_241);
      v_t_247 = v_a_246;
    } else {
      heff_drop(v_a_246);
      v_t_247 = v_z_241;
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_247;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s6718001x1068992521_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl_24s6718001x1068992521(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24f189927396x2059034600_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f189927396x2059034600_24dps_entry, 2, 0};

V g_list_2emap_24f189927396x2059034600_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_loosest_244 = heff_take_field(v_x_242, 3);
    V v_id_245 = heff_get_n(v_x_242, 0, 5);
    V v_t_246 = v_loosest_244;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_id_245, heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_247);
      V t_0 = v_xs_243;
      V t_1 = v_u_248;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_id_245);
      heff_drop(v_t_246);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f189927396x2059034600_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24f189927396x2059034600_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24f1677329353x1774765664_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1677329353x1774765664_24dps_entry, 3, 0};

V g_list_2emap_24f1677329353x1774765664_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      v_x_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, heff_dup(v_lit_240)}), heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_249;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1677329353x1774765664_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24f1677329353x1774765664_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24f565269645x1954016017_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f565269645x1954016017_24dps_entry, 2, 0};

V g_list_2emap_24f565269645x1954016017_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_binder_244 = heff_take_field(v_x_242, 0);
    V v_use_245 = heff_get_n(v_x_242, 1, 2);
    V v_t_246 = heff_take_field(v_binder_244, 2);
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_rec_n(3, shape_name__field__use, (V[]){heff_take_field(v_binder_244, 0), heff_get_n(v_binder_244, 1, 3), v_use_245});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
      V t_0 = v_xs_243;
      V t_1 = v_u_249;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop_rec(v_binder_244, 3);
      heff_drop(v_use_245);
      heff_drop(v_t_246);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f565269645x1954016017_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24f565269645x1954016017_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f297647854x479783049_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f297647854x479783049_entry, 2, 0};

V g_list_2efoldl_24f297647854x479783049(V v_z_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_241, 0);
    V v_cs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s647917584x875728492(v_c_242, v_cs_243));
    V t_0 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_c_242, v_z_240});
    V t_1 = v_t_244;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f297647854x479783049(a[0], a[1]);
}
Clo g_list_2emap_24f530523215x314966509_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f530523215x314966509_24dps_entry, 8, 0};

V g_list_2emap_24f530523215x314966509_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_247), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_target_2410 = heff_take_field(v_x_248, 0);
    V v_name_2411 = heff_take_field(v_x_248, 1);
    V v_span_2412 = heff_get_n(v_x_248, 2, 3);
    V v_t_2413 = heff_get_n(v_target_2410, 1, 3);
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      heff_drop(v_name_2411);
      heff_drop(v_span_2412);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_d_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_2413, 0ULL, 1);
      V v_t_2415 = heff_intAdd(heff_dup(heff_rfield(v_lit_241, 0)), heff_dup(v_lit_242));
      V v_t_2416 = heff_strSlice(heff_dup(heff_rfield(v_lit_240, 3)), heff_dup(heff_rfield(v_lit_241, 0)), v_t_2415);
      V v_t_2417;
      if (heff_strEq_c_lent(v_t_2416, v_lit_243, 1)) {
        v_t_2417 = heff_dup(v_lit_244);
      } else {
        v_t_2417 = heff_dup(v_lit_245);
      }
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__kind__span, (V[]){v_name_2411, v_t_2417, v_span_2412}), heff_hole()});
      V v_u_2419 = heff_setFieldPeek(v_d_247, MK_INT(1LL), v_cell_2418);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_u_2419;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24f530523215x314966509_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a7 = a[7]; V r = g_list_2emap_24f530523215x314966509_24dps(a0, a1, a2, a3, a4, a5, a[6], a7); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a7); return r;
}
Clo g_list_2emap_24f1677329353x1774765664_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1677329353x1774765664_24tok2_entry, 3, 0};

V g_list_2emap_24f1677329353x1774765664_24tok2(V v_tok_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      v_x_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_248 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_MkPair, 2, (V[]){v_x_247, heff_dup(v_lit_241)}), heff_hole()});
    V v_u_249 = ({ V a_0 = v_lit_241; V a_1 = v_xs_244; V a_2 = v_cell_248; V r_ = (g_list_2emap_24f1677329353x1774765664_24dps(a_0, a_1, a_2)); heff_drop(v_lit_241); r_; });
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1677329353x1774765664_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1677329353x1774765664_24tok2(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s215892288x1392224072_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s215892288x1392224072_24tok2_entry, 3, 0};

V g_list_2emap_24s215892288x1392224072_24tok2(V v_tok_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_lit_241), v_x_243}), heff_hole()});
    V v_u_246 = ({ V a_0 = v_lit_241; V a_1 = v_xs_244; V a_2 = v_cell_245; V r_ = (g_list_2emap_24s215892288x1392224072_24dps(a_0, a_1, a_2)); heff_drop(v_lit_241); r_; });
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s215892288x1392224072_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s215892288x1392224072_24tok2(a[0], a[1], a[2]);
}