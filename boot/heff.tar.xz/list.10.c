// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_DoneOrErrno 39355
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkRegex 19093
#define TAG_MkSegment 38079
#define TAG_OSimple 59809
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Right 62770
#define TAG_SSet 8516
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_Unreached 46435
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_Within 10658
#define LBL_args 9498020
#define LBL_binder 558177493
#define LBL_diags 296935042
#define LBL_doc 309170
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_errors 652506774
#define LBL_expectFrom 460383968
#define LBL_expectTo 956903013
#define LBL_field 298786068
#define LBL_holds 300818350
#define LBL_id 10114
#define LBL_index 301704428
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_l 326
#define LBL_local 304503685
#define LBL_loosest 581880769
#define LBL_member 869372357
#define LBL_name 9869138
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_result 1012715336
#define LBL_runs 10007567
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_use 325633
#define LBL_value 313331083
#define LBL_version 583465758
#define LBL_watch 314261737
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_name__field__use[] = {LBL_name, LBL_field, LBL_use};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
V g_heff_2ebuild_2ebenchmarks_2ecapital(V);
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo;
V g_heff_2ebuild_2ebenchmarks_2espaced(V);
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo;
V g_heff_2ebuild_2edriver_2epromoteAt(V, V, V, V);
V g_heff_2ebuild_2edriver_2epromoteAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epromoteAt_clo;
V g_heff_2ebuild_2eproject_2enewer(V, V);
V g_heff_2ebuild_2eproject_2enewer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewer_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2eprimUses(V, V);
V g_heff_2ecompile_2eemit_2eprimUses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimUses_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeFrom(V);
V g_heff_2ecompile_2eemit_2esafeFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeFrom_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemitc_2easLent(V, V);
V g_heff_2ecompile_2eemitc_2easLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2easLent_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efacts_2etailApp(V);
V g_heff_2ecompile_2efacts_2etailApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2etailApp_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2elocals_2epatternBinders(V);
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24tok2(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24tok2_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2esyntax_2eformat_2eequationKey(V, V);
V g_heff_2esyntax_2eformat_2eequationKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eequationKey_clo;
V g_heff_2esyntax_2eformat_2evariantKey(V, V);
V g_heff_2esyntax_2eformat_2evariantKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2evariantKey_clo;
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo;
V g_heff_2esyntax_2epresyntax_2earmStmts(V);
V g_heff_2esyntax_2epresyntax_2earmStmts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmStmts_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf(V, V);
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf(V, V);
V g_heff_2esyntax_2epresyntax_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_clo;
V g_json_2eescapeGo(V, V, V);
V g_json_2eescapeGo_entry(V self, V *a);
extern Clo g_json_2eescapeGo_clo;
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eall_24s1579400704x1789597964(V);
V g_list_2eall_24s1579400704x1789597964_entry(V self, V *a);
extern Clo g_list_2eall_24s1579400704x1789597964_clo;
V g_list_2eall_24s568190696x1372373514(V);
V g_list_2eall_24s568190696x1372373514_entry(V self, V *a);
extern Clo g_list_2eall_24s568190696x1372373514_clo;
V g_list_2eany_24s1075282620x806006020(V);
V g_list_2eany_24s1075282620x806006020_entry(V self, V *a);
extern Clo g_list_2eany_24s1075282620x806006020_clo;
V g_list_2eany_24s1266267134x726671983(V, V);
V g_list_2eany_24s1266267134x726671983_entry(V self, V *a);
extern Clo g_list_2eany_24s1266267134x726671983_clo;
V g_list_2eany_24s130813166x1111413304(V, V);
V g_list_2eany_24s130813166x1111413304_entry(V self, V *a);
extern Clo g_list_2eany_24s130813166x1111413304_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2eany_24s180477083x124477283(V, V);
V g_list_2eany_24s180477083x124477283_entry(V self, V *a);
extern Clo g_list_2eany_24s180477083x124477283_clo;
V g_list_2eany_24s378803910x892125795(V);
V g_list_2eany_24s378803910x892125795_entry(V self, V *a);
extern Clo g_list_2eany_24s378803910x892125795_clo;
V g_list_2eany_24s493638107x943509119(V);
V g_list_2eany_24s493638107x943509119_entry(V self, V *a);
extern Clo g_list_2eany_24s493638107x943509119_clo;
V g_list_2eany_24s495437461x764444341(V);
V g_list_2eany_24s495437461x764444341_entry(V self, V *a);
extern Clo g_list_2eany_24s495437461x764444341_clo;
V g_list_2eany_24s52192015x78999897(V, V);
V g_list_2eany_24s52192015x78999897_entry(V self, V *a);
extern Clo g_list_2eany_24s52192015x78999897_clo;
V g_list_2econcatMap(V, V);
V g_list_2econcatMap_entry(V self, V *a);
extern Clo g_list_2econcatMap_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1221993074x1235215335(V, V, V);
V g_list_2efoldl_24f1221993074x1235215335_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1221993074x1235215335_clo;
V g_list_2efoldl_24f2080327479x1330764413(V, V, V, V, V, V, V);
V g_list_2efoldl_24f2080327479x1330764413_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2080327479x1330764413_clo;
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24f297647854x479783049(V, V);
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a);
extern Clo g_list_2efoldl_24f297647854x479783049_clo;
V g_list_2efoldl_24f928374809x1955888331(V, V);
V g_list_2efoldl_24f928374809x1955888331_entry(V self, V *a);
extern Clo g_list_2efoldl_24f928374809x1955888331_clo;
V g_list_2efoldl_24s1149369025x804005338(V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1149369025x804005338_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1149369025x804005338_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s141260856x1366916752(V, V, V, V, V);
V g_list_2efoldl_24s141260856x1366916752_entry(V self, V *a);
extern Clo g_list_2efoldl_24s141260856x1366916752_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s1520027297x1040032870(V, V);
V g_list_2efoldl_24s1520027297x1040032870_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1520027297x1040032870_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s1894035205x969464323(V, V, V);
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1894035205x969464323_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s398854970x1533504811(V, V);
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a);
extern Clo g_list_2efoldl_24s398854970x1533504811_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2efoldl_24s491084544x100802329(V, V);
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s491084544x100802329_clo;
V g_list_2efoldl_24s571074576x1179600767_24scalars(V, V, V, V, V, V);
V g_list_2efoldl_24s571074576x1179600767_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_24scalars_clo;
V g_list_2efoldl_24s571527232x333134686(V, V);
V g_list_2efoldl_24s571527232x333134686_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571527232x333134686_clo;
V g_list_2efoldl_24s644727442x245553729(V, V);
V g_list_2efoldl_24s644727442x245553729_entry(V self, V *a);
extern Clo g_list_2efoldl_24s644727442x245553729_clo;
V g_list_2efoldl_24s6718001x1068992521(V, V, V);
V g_list_2efoldl_24s6718001x1068992521_entry(V self, V *a);
extern Clo g_list_2efoldl_24s6718001x1068992521_clo;
V g_list_2efoldl_24s977936796x564903144(V, V, V, V);
V g_list_2efoldl_24s977936796x564903144_entry(V self, V *a);
extern Clo g_list_2efoldl_24s977936796x564903144_clo;
V g_list_2ekeepIf_24f1278780364x1365377410_24dps(V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24f1278780364x1365377410_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1278780364x1365377410_24dps_clo;
V g_list_2ekeepIf_24f428638463x2144521938_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24f428638463x2144521938_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f428638463x2144521938_24dps_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2ekeepIf_24s1223034477x943356724(V);
V g_list_2ekeepIf_24s1223034477x943356724_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1223034477x943356724_clo;
V g_list_2ekeepIf_24s1223034477x943356724_24dps(V, V);
V g_list_2ekeepIf_24s1223034477x943356724_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1223034477x943356724_24dps_clo;
V g_list_2ekeepIf_24s1366776885x1474218589(V, V);
V g_list_2ekeepIf_24s1366776885x1474218589_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1366776885x1474218589_clo;
V g_list_2ekeepIf_24s1366776885x1474218589_24dps(V, V, V);
V g_list_2ekeepIf_24s1366776885x1474218589_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1366776885x1474218589_24dps_clo;
V g_list_2ekeepIf_24s2015972532x1874881274(V, V);
V g_list_2ekeepIf_24s2015972532x1874881274_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2015972532x1874881274_clo;
V g_list_2ekeepIf_24s2015972532x1874881274_24dps(V, V, V);
V g_list_2ekeepIf_24s2015972532x1874881274_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2015972532x1874881274_24dps_clo;
V g_list_2ekeepIf_24s425280038x249084439(V, V, V);
V g_list_2ekeepIf_24s425280038x249084439_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s425280038x249084439_clo;
V g_list_2ekeepIf_24s425280038x249084439_24dps(V, V, V, V);
V g_list_2ekeepIf_24s425280038x249084439_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s425280038x249084439_24dps_clo;
V g_list_2ekeepIf_24s478006518x1380334353_24dps(V, V);
V g_list_2ekeepIf_24s478006518x1380334353_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s478006518x1380334353_24dps_clo;
V g_list_2ekeepIf_24s647917584x875728492(V, V);
V g_list_2ekeepIf_24s647917584x875728492_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s647917584x875728492_clo;
V g_list_2ekeepIf_24s647917584x875728492_24dps(V, V, V);
V g_list_2ekeepIf_24s647917584x875728492_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s647917584x875728492_24dps_clo;
V g_list_2ekeepIf_24s741838803x941779121_24dps(V, V);
V g_list_2ekeepIf_24s741838803x941779121_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s741838803x941779121_24dps_clo;
V g_list_2ekeepIf_24s924780574x2000457388(V, V);
V g_list_2ekeepIf_24s924780574x2000457388_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s924780574x2000457388_clo;
V g_list_2ekeepIf_24s924780574x2000457388_24dps(V, V, V);
V g_list_2ekeepIf_24s924780574x2000457388_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s924780574x2000457388_24dps_clo;
V g_list_2emap_24f1632378148x1903828118_24dps(V, V, V);
V g_list_2emap_24f1632378148x1903828118_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1632378148x1903828118_24dps_clo;
V g_list_2emap_24f1893878025x389241368(V, V, V, V, V, V);
V g_list_2emap_24f1893878025x389241368_entry(V self, V *a);
extern Clo g_list_2emap_24f1893878025x389241368_clo;
V g_list_2emap_24f1893878025x389241368_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24f1893878025x389241368_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1893878025x389241368_24dps_clo;
V g_list_2emap_24f189927396x2059034600_24dps(V, V);
V g_list_2emap_24f189927396x2059034600_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f189927396x2059034600_24dps_clo;
V g_list_2emap_24f530523215x314966509_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24f530523215x314966509_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f530523215x314966509_24dps_clo;
V g_list_2emap_24f565269645x1954016017_24dps(V, V);
V g_list_2emap_24f565269645x1954016017_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f565269645x1954016017_24dps_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1007499915x73800978_24dps(V, V);
V g_list_2emap_24s1007499915x73800978_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_24dps_clo;
V g_list_2emap_24s1055307687x247454614_24dps(V, V, V);
V g_list_2emap_24s1055307687x247454614_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1055307687x247454614_24dps_clo;
V g_list_2emap_24s1068592055x839006909(V, V, V, V);
V g_list_2emap_24s1068592055x839006909_entry(V self, V *a);
extern Clo g_list_2emap_24s1068592055x839006909_clo;
V g_list_2emap_24s1105764576x1671327425(V, V, V);
V g_list_2emap_24s1105764576x1671327425_entry(V self, V *a);
extern Clo g_list_2emap_24s1105764576x1671327425_clo;
V g_list_2emap_24s1105764576x1671327425_24dps(V, V, V, V);
V g_list_2emap_24s1105764576x1671327425_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1105764576x1671327425_24dps_clo;
V g_list_2emap_24s1157931537x649184066_24dps(V, V, V);
V g_list_2emap_24s1157931537x649184066_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_24dps_clo;
V g_list_2emap_24s1230969749x2018313496_24dps(V, V);
V g_list_2emap_24s1230969749x2018313496_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_24dps_clo;
V g_list_2emap_24s1275294336x693095586_24dps(V, V, V);
V g_list_2emap_24s1275294336x693095586_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1275294336x693095586_24dps_clo;
V g_list_2emap_24s1276696116x507290452(V, V);
V g_list_2emap_24s1276696116x507290452_entry(V self, V *a);
extern Clo g_list_2emap_24s1276696116x507290452_clo;
V g_list_2emap_24s1276696116x507290452_24dps(V, V, V);
V g_list_2emap_24s1276696116x507290452_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1276696116x507290452_24dps_clo;
V g_list_2emap_24s1397747289x2145601499(V);
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_clo;
V g_list_2emap_24s1397747289x2145601499_24dps(V, V);
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_24dps_clo;
V g_list_2emap_24s1409451498x400757684_24dps(V, V);
V g_list_2emap_24s1409451498x400757684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_24dps_clo;
V g_list_2emap_24s1703643582x349630108_24dps(V, V, V);
V g_list_2emap_24s1703643582x349630108_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1703643582x349630108_24dps_clo;
V g_list_2emap_24s1727184187x1048417382(V);
V g_list_2emap_24s1727184187x1048417382_entry(V self, V *a);
extern Clo g_list_2emap_24s1727184187x1048417382_clo;
V g_list_2emap_24s1727184187x1048417382_24dps(V, V);
V g_list_2emap_24s1727184187x1048417382_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1727184187x1048417382_24dps_clo;
V g_list_2emap_24s1753874608x910016727(V);
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_clo;
V g_list_2emap_24s1753874608x910016727_24dps(V, V);
V g_list_2emap_24s1753874608x910016727_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_24dps_clo;
V g_list_2emap_24s1767134203x962737276(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1767134203x962737276_entry(V self, V *a);
extern Clo g_list_2emap_24s1767134203x962737276_clo;
V g_list_2emap_24s1782778565x402128078_24dps(V, V);
V g_list_2emap_24s1782778565x402128078_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_24dps_clo;
V g_list_2emap_24s1887874170x1747433177_24dps(V, V);
V g_list_2emap_24s1887874170x1747433177_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_24dps_clo;
V g_list_2emap_24s18996220x10511024_24dps(V, V);
V g_list_2emap_24s18996220x10511024_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_24dps_clo;
V g_list_2emap_24s1953633397x1251544744_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1953633397x1251544744_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1953633397x1251544744_24dps_clo;
V g_list_2emap_24s2039279853x710813703(V, V);
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_clo;
V g_list_2emap_24s2039279853x710813703_24dps(V, V, V);
V g_list_2emap_24s2039279853x710813703_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_24dps_clo;
V g_list_2emap_24s205414595x1692305030(V);
V g_list_2emap_24s205414595x1692305030_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_clo;
V g_list_2emap_24s205414595x1692305030_24dps(V, V);
V g_list_2emap_24s205414595x1692305030_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_24dps_clo;
V g_list_2emap_24s215892288x1392224072_24dps(V, V, V);
V g_list_2emap_24s215892288x1392224072_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24dps_clo;
V g_list_2emap_24s215892288x1392224072_24tok2(V, V, V);
V g_list_2emap_24s215892288x1392224072_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24tok2_clo;
V g_list_2emap_24s307517993x1025539700(V, V, V, V, V, V, V, V);
V g_list_2emap_24s307517993x1025539700_entry(V self, V *a);
extern Clo g_list_2emap_24s307517993x1025539700_clo;
V g_list_2emap_24s307517993x1025539700_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s307517993x1025539700_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s307517993x1025539700_24dps_clo;
V g_list_2emap_24s354283597x484250159(V, V);
V g_list_2emap_24s354283597x484250159_entry(V self, V *a);
extern Clo g_list_2emap_24s354283597x484250159_clo;
V g_list_2emap_24s354283597x484250159_24dps(V, V, V);
V g_list_2emap_24s354283597x484250159_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s354283597x484250159_24dps_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s366344330x1145113647_24dps(V, V);
V g_list_2emap_24s366344330x1145113647_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_24dps_clo;
V g_list_2emap_24s388004800x1261967008(V);
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_clo;
V g_list_2emap_24s388004800x1261967008_24dps(V, V);
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_24dps_clo;
V g_list_2emap_24s391931963x434308123_24dps(V, V);
V g_list_2emap_24s391931963x434308123_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_24dps_clo;
V g_list_2emap_24s456133444x1904936646(V, V, V, V, V, V, V, V);
V g_list_2emap_24s456133444x1904936646_entry(V self, V *a);
extern Clo g_list_2emap_24s456133444x1904936646_clo;
V g_list_2emap_24s456133444x1904936646_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s456133444x1904936646_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s456133444x1904936646_24dps_clo;
V g_list_2emap_24s467798769x1763085075_24dps(V, V);
V g_list_2emap_24s467798769x1763085075_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_24dps_clo;
V g_list_2emap_24s570884835x2121220820(V);
V g_list_2emap_24s570884835x2121220820_entry(V self, V *a);
extern Clo g_list_2emap_24s570884835x2121220820_clo;
V g_list_2emap_24s570884835x2121220820_24dps(V, V);
V g_list_2emap_24s570884835x2121220820_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s570884835x2121220820_24dps_clo;
V g_list_2emap_24s577716216x434174337(V, V, V, V, V);
V g_list_2emap_24s577716216x434174337_entry(V self, V *a);
extern Clo g_list_2emap_24s577716216x434174337_clo;
V g_list_2emap_24s577716216x434174337_24dps(V, V, V, V, V, V);
V g_list_2emap_24s577716216x434174337_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s577716216x434174337_24dps_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_list_2emap_24s803586165x1676441765_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_24dps_clo;
V g_list_2emap_24s849938259x51049885(V);
V g_list_2emap_24s849938259x51049885_entry(V self, V *a);
extern Clo g_list_2emap_24s849938259x51049885_clo;
V g_list_2emap_24s849938259x51049885_24dps(V, V);
V g_list_2emap_24s849938259x51049885_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s849938259x51049885_24dps_clo;
V g_list_2emap_24s925333445x1396764769(V, V, V, V, V, V);
V g_list_2emap_24s925333445x1396764769_entry(V self, V *a);
extern Clo g_list_2emap_24s925333445x1396764769_clo;
V g_list_2emap_24s925333445x1396764769_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s925333445x1396764769_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s925333445x1396764769_24dps_clo;
V g_list_2emap_24s97919758x216970748_24dps(V, V, V);
V g_list_2emap_24s97919758x216970748_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_24dps_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emerge_24dps(V, V, V, V);
V g_list_2emerge_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24dps_clo;
V g_list_2emerge_24s132798885x1165759438(V, V);
V g_list_2emerge_24s132798885x1165759438_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_clo;
V g_list_2emerge_24s132798885x1165759438_24dps(V, V, V);
V g_list_2emerge_24s132798885x1165759438_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_24dps_clo;
V g_list_2erange_24dps(V, V, V);
V g_list_2erange_24dps_entry(V self, V *a);
extern Clo g_list_2erange_24dps_clo;
V g_list_2ezipWith_24s1149721393x617397893(V, V, V);
V g_list_2ezipWith_24s1149721393x617397893_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1149721393x617397893_clo;
V g_list_2ezipWith_24s1149721393x617397893_24dps(V, V, V, V);
V g_list_2ezipWith_24s1149721393x617397893_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1149721393x617397893_24dps_clo;
V g_list_2ezipWith_24s583291244x257539062_24dps(V, V, V);
V g_list_2ezipWith_24s583291244x257539062_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s583291244x257539062_24dps_clo;
V g_list_2ezipWith_24s870182194x1066240094(V, V);
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_clo;
V g_list_2ezipWith_24s870182194x1066240094_24dps(V, V, V);
V g_list_2ezipWith_24s870182194x1066240094_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2ebranchOf(V);
V g_regex_2ebranchOf_entry(V self, V *a);
extern Clo g_regex_2ebranchOf_clo;
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2ecli_2eflagLine(V);
V g_std_2ecli_2eflagLine_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagLine_clo;
V g_std_2emap_2einsert_24s1863973822x2117969067(V, V, V);
V g_std_2emap_2einsert_24s1863973822x2117969067_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1863973822x2117969067_clo;
V g_std_2emap_2einsert_24s1913725254x907253835(V, V, V);
V g_std_2emap_2einsert_24s1913725254x907253835_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1913725254x907253835_clo;
V g_list_2econcatMap_lam0(V self, V *args);
Clo g_list_2econcatMap_clo = {{0x80000000u, K_CLO, 0}, g_list_2econcatMap_entry, 2, 0};

V g_list_2econcatMap(V v_f_240, V v_xs_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  return ({ V a_0 = heff_clo_n(g_list_2econcatMap_lam0, 2, 1, (V[]){v_f_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_list_2econcatMap_entry(V self, V *a) {
  (void)self;
  return g_list_2econcatMap(a[0], a[1]);
}
V g_list_2econcatMap_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_244}));
  return (g_prelude_2e_2b_2b(v_t_245, v_acc_243));
}
Clo g_list_2erange_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2erange_24dps_entry, 3, 0};

V g_list_2erange_24dps(V v_a_240, V v_b_241, V v_d_242) {
top: ;
  if (heff_intLt_c_lent(v_b_241, v_a_240, 0)) {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_240), heff_hole()});
    V v_u_244 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_243));
    heff_drop(v_u_244);
    V t_0 = heff_intAdd(v_a_240, MK_INT(1LL));
    V t_1 = v_b_241;
    V t_2 = v_cell_243;
    v_a_240 = t_0;
    v_b_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_list_2erange_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2erange_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emerge_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_entry, 3, 0};

V g_list_2emerge(V v_le_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return v_x3_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_241, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      return v_x2_241;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){heff_dup(v_x_243), heff_dup(v_y_245)}));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_cell_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = (g_list_2emerge_24dps(v_le_240, v_xs_244, heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246}), heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop(v_t_247);
        V v_cell_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = (g_list_2emerge_24dps(v_le_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244}), v_ys_246, heff_dup(v_cell_2410)));
        heff_drop(v_u_2411);
        return v_cell_2410;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s366344330x1145113647_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366344330x1145113647_entry, 1, 0};

V g_list_2emap_24s366344330x1145113647(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s366344330x1145113647_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366344330x1145113647(a[0]);
}
Clo g_list_2emap_24s366344330x1145113647_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366344330x1145113647_24dps_entry, 2, 0};

V g_list_2emap_24s366344330x1145113647_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366344330x1145113647_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366344330x1145113647_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s130813166x1111413304_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s130813166x1111413304_entry, 2, 0};

V g_list_2eany_24s130813166x1111413304(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_246, v_lit_240, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s130813166x1111413304_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s130813166x1111413304(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s644727442x245553729_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s644727442x245553729_entry, 2, 0};

V g_list_2efoldl_24s644727442x245553729(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_std_2emap_2einsert_24s1913725254x907253835(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s644727442x245553729_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s644727442x245553729(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s425280038x249084439_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s425280038x249084439_entry, 3, 0};

V g_list_2ekeepIf_24s425280038x249084439(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_243, 1));
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    switch (heff_tag_of(v_t_247)) {
    case TAG_Unreached: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_Within: {
      V v_a_248 = heff_field(v_t_247, 0);
      V v_a_249 = heff_field(v_t_247, 1);
      heff_take_n(v_t_247, 3ULL, 2);
      switch (heff_tag_of(v_a_248)) {
      case TAG_Nothing: {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        heff_drop(v_a_249);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
      case TAG_Just: {
        V v_a_2410 = heff_field(v_a_248, 0);
        heff_take_n(v_a_248, 1ULL, 1);
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          heff_drop(v_x_243);
          heff_drop_cell(v_ru_24x2_242_24Cons, 2);
          heff_drop(v_a_2410);
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_xs_244;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_x2_242 = t_2;
          goto top;
        }
        case TAG_Just: {
          V v_a_2411 = heff_field(v_a_249, 0);
          heff_take_n(v_a_249, 1ULL, 1);
          if ((heff_intLe_c_lent(v_lit_240, v_a_2410, 0) && heff_intLe_c_lent(v_a_2411, v_lit_241, 0))) {
            heff_drop(v_a_2410);
            heff_drop(v_a_2411);
            V v_cell_2412 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_u_2413 = (g_list_2ekeepIf_24s425280038x249084439_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_2412)));
            heff_drop(v_u_2413);
            return v_cell_2412;
          } else {
            heff_drop(v_x_243);
            heff_drop_cell(v_ru_24x2_242_24Cons, 2);
            heff_drop(v_a_2410);
            heff_drop(v_a_2411);
            V t_0 = v_lit_240;
            V t_1 = v_lit_241;
            V t_2 = v_xs_244;
            v_lit_240 = t_0;
            v_lit_241 = t_1;
            v_x2_242 = t_2;
            goto top;
          }
        }
        default: return heff_nomatch(v_a_249);
        }
      }
      default: return heff_nomatch(v_a_248);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s425280038x249084439_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s425280038x249084439(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s571527232x333134686_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s571527232x333134686_entry, 2, 0};

V g_list_2efoldl_24s571527232x333134686(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_std_2emap_2einsert_24s1863973822x2117969067(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s571527232x333134686_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s571527232x333134686(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1409451498x400757684_24dps_str0, 0, "");
Clo g_list_2emap_24s1409451498x400757684_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1409451498x400757684_24dps_entry, 2, 0};

V g_list_2emap_24s1409451498x400757684_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_dup(heff_rfield(v_x_242, 2)), heff_dup(heff_rfield(v_x_242, 3)), heff_tag_n(TAG_Just, 1, (V[]){v_x_242}), ((V)&g_list_2emap_24s1409451498x400757684_24dps_str0), MK_INT(0LL), MK_INT(0LL)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1409451498x400757684_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1409451498x400757684_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s1075282620x806006020_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1075282620x806006020_entry, 1, 0};

V g_list_2eany_24s1075282620x806006020(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_243, 1);
        V v_t_247 = (g_heff_2esyntax_2epresyntax_2earmStmts(heff_dup(v_a_246)));
        v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_list_2eany_24s493638107x943509119(a_0)); heff_drop(v_t_247); r_; });
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_248);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1075282620x806006020_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1075282620x806006020(a0); heff_drop(a0); return r;
}
Clo g_list_2eall_24s568190696x1372373514_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s568190696x1372373514_entry, 1, 0};

V g_list_2eall_24s568190696x1372373514(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_StmtBind: {
        return NTAG(TAG_False);
      }
      case TAG_StmtLet: {
        return NTAG(TAG_False);
      }
      case TAG_StmtExpr: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_StmtLetMut: {
        return NTAG(TAG_False);
      }
      case TAG_StmtLetElse: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_a_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s568190696x1372373514_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s568190696x1372373514(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s97919758x216970748_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s97919758x216970748_24dps_entry, 3, 0};

V g_list_2emap_24s97919758x216970748_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2evariantOf(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s97919758x216970748_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s97919758x216970748_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s2039279853x710813703_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2039279853x710813703_entry, 2, 0};

V g_list_2emap_24s2039279853x710813703(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2efieldSetOf(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s2039279853x710813703_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2039279853x710813703(a[0], a[1]);
}
Clo g_list_2emap_24s1157931537x649184066_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1157931537x649184066_24dps_entry, 3, 0};

V g_list_2emap_24s1157931537x649184066_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2eparamOf(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1157931537x649184066_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1157931537x649184066_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s205414595x1692305030_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s205414595x1692305030_entry, 1, 0};

V g_list_2emap_24s205414595x1692305030(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s205414595x1692305030_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s205414595x1692305030_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s205414595x1692305030(a[0]);
}
Clo g_list_2emap_24s1887874170x1747433177_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1887874170x1747433177_24dps_entry, 2, 0};

V g_list_2emap_24s1887874170x1747433177_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_242));
    V v_t_2416;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_a_247 = v_field_246;
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_249 = heff_dup(heff_field(v_a_247, 1));
          v_t_2410 = v_a_249;
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_a_247}), v_t_2410});
      } else {
        if ((v_tag_245 == ((int64_t)1ULL))) {
          V v_a_2411 = v_field_246;
          V v_t_2414;
          switch (heff_tag_of(v_a_2411)) {
          case TAG_At: {
            V v_a_2413 = heff_dup(heff_field(v_a_2411, 1));
            v_t_2414 = v_a_2413;
            break;
          }
          default: heff_nomatch(v_a_2411);
          }
          v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_a_2411}), v_t_2414});
        } else {
          V v_a_2415 = v_field_246;
          v_t_2416 = v_a_2415;
        }
      }
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2417;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1887874170x1747433177_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1887874170x1747433177_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1230969749x2018313496_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230969749x2018313496_24dps_entry, 2, 0};

V g_list_2emap_24s1230969749x2018313496_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1230969749x2018313496_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230969749x2018313496_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1782778565x402128078_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1782778565x402128078_24dps_entry, 2, 0};

V g_list_2emap_24s1782778565x402128078_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2414;
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkEquation: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_ru_24a_244_24MkEquation = heff_take_reuse_n(v_a_244, 15ULL, 4);
        V v_t_2413;
        switch (heff_tag_of(v_a_249)) {
        case TAG_At: {
          V v_a_2410 = heff_field(v_a_249, 0);
          V v_a_2411 = heff_field(v_a_249, 1);
          heff_take_n(v_a_249, 3ULL, 2);
          V v_t_2412 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2410));
          v_t_2413 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2412, v_a_2411});
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2414 = heff_tag_at_n(v_ru_24a_244_24MkEquation, TAG_MkEquation, 4, (V[]){v_a_246, v_a_247, v_a_248, v_t_2413});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2416));
    heff_drop(v_u_2417);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2416;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1782778565x402128078_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1782778565x402128078_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s378803910x892125795_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s378803910x892125795_entry, 1, 0};

V g_list_2eany_24s378803910x892125795(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s378803910x892125795_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s378803910x892125795(a0); heff_drop(a0); return r;
}
Clo g_list_2ezipWith_24s583291244x257539062_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s583291244x257539062_24dps_entry, 3, 0};

V g_list_2ezipWith_24s583291244x257539062_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_SSet, 2, (V[]){v_x_243, heff_tag_n(TAG_OSimple, 1, (V[]){v_y_245})});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s583291244x257539062_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s583291244x257539062_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s1266267134x726671983_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1266267134x726671983_entry, 2, 0};

V g_list_2eany_24s1266267134x726671983(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_lit_240, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (heff_intEq_c_lent(v_x_242, v_t_246, 2)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1266267134x726671983_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1266267134x726671983(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s495437461x764444341_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s495437461x764444341_entry, 1, 0};

V g_list_2eany_24s495437461x764444341(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2ecompile_2efacts_2etailApp(a_0)); heff_drop(v_t_246); r_; });
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_247);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s495437461x764444341_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s495437461x764444341(a0); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s1223034477x943356724_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1223034477x943356724_entry, 1, 0};

V g_list_2ekeepIf_24s1223034477x943356724(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_t_245, 0ULL, 2);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_249 = (g_list_2ekeepIf_24s1223034477x943356724_24dps(v_xs_242, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1223034477x943356724_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1223034477x943356724(a[0]);
}
Clo g_list_2efoldl_24s1530401830x609500251_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1530401830x609500251_entry, 2, 0};

V g_list_2efoldl_24s1530401830x609500251(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1530401830x609500251(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s870182194x1066240094_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s870182194x1066240094_entry, 2, 0};

V g_list_2ezipWith_24s870182194x1066240094(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247;
      switch (heff_tag_of(v_x_242)) {
      case TAG_RepV: {
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_247 = v_y_244;
        break;
      }
      case TAG_RepFix: {
        v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RWord, 2, (V[]){v_x_242, v_y_244});
        break;
      }
      case TAG_RepF64: {
        v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RWord, 2, (V[]){v_x_242, v_y_244});
        break;
      }
      case TAG_RepInt: {
        v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RWord, 2, (V[]){v_x_242, v_y_244});
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s870182194x1066240094_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s870182194x1066240094(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1366776885x1474218589_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1366776885x1474218589_entry, 2, 0};

V g_list_2ekeepIf_24s1366776885x1474218589(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1366776885x1474218589_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1366776885x1474218589_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1366776885x1474218589(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_str0, 1, "\"");
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_str1, 1, "\"");
Clo g_list_2emap_24s1397747289x2145601499_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1397747289x2145601499_entry, 1, 0};

V g_list_2emap_24s1397747289x2145601499(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V a_1 = MK_INT(0LL); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_t_244 = heff_strAppend(((V)&g_list_2emap_24s1397747289x2145601499_str0), heff_strAppend(v_t_243, ((V)&g_list_2emap_24s1397747289x2145601499_str1)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1397747289x2145601499_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1397747289x2145601499(a[0]);
}
Clo g_list_2emap_24s570884835x2121220820_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570884835x2121220820_entry, 1, 0};

V g_list_2emap_24s570884835x2121220820(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), v_x_241});
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s570884835x2121220820_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570884835x2121220820_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570884835x2121220820(a[0]);
}
Clo g_list_2ekeepIf_24s924780574x2000457388_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s924780574x2000457388_entry, 2, 0};

V g_list_2ekeepIf_24s924780574x2000457388(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_UpdateTo: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_2412 = v_a_244;
      break;
    }
    case TAG_UpdateIn: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 0));
      v_t_2412 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_2412, v_lit_240, 1)) {
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2414 = (g_list_2ekeepIf_24s924780574x2000457388_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2413)));
      heff_drop(v_u_2414);
      return v_cell_2413;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s924780574x2000457388_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s924780574x2000457388(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2eany_24s52192015x78999897_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s52192015x78999897_entry, 2, 0};

V g_list_2eany_24s52192015x78999897(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s52192015x78999897_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s52192015x78999897(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s1149721393x617397893_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1149721393x617397893_entry, 3, 0};

V g_list_2ezipWith_24s1149721393x617397893(V v_lit_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_247 = heff_strAppend(v_x_243, heff_strAppend(heff_dup(v_lit_240), v_y_245));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s1149721393x617397893_24dps(v_lit_240, v_xs_244, v_ys_246, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24s1149721393x617397893_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1149721393x617397893(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s307517993x1025539700_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s307517993x1025539700_entry, 8, 0};

V g_list_2emap_24s307517993x1025539700(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_a_2410 = (g_prelude_2esplitFrom(v_lit_240, v_x_248, heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_x_248, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_a_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_2410));
    V v_a_2414;
    switch (heff_tag_of(v_a_2411)) {
    case TAG_Nil: {
      v_a_2414 = v_x_248;
      break;
    }
    case TAG_Cons: {
      V v_a_2412 = heff_field(v_a_2411, 0);
      heff_take_n(v_a_2411, 1ULL, 2);
      heff_drop(v_x_248);
      v_a_2414 = v_a_2412;
      break;
    }
    default: heff_nomatch(v_a_2411);
    }
    int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_a_2414, 0)) - heff_peek_word(v_lit_244));
    V v_t_2416 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_a_2414, heff_box_word(v_t_2415)));
    V v_t_2417 = ({ V a_0 = v_a_2414; V a_1 = v_t_2416; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = heff_dup(v_lit_245); V a_2 = heff_dup(v_lit_246); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
    V v_t_2419 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2418));
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = (g_list_2emap_24s307517993x1025539700_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249, heff_dup(v_cell_2420)));
    heff_drop(v_u_2421);
    return v_cell_2420;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s307517993x1025539700_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24s307517993x1025539700(a0, a[1], a2, a3, a[4], a[5], a[6], a[7]); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emap_24s307517993x1025539700_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s307517993x1025539700_24dps_entry, 9, 0};

V g_list_2emap_24s307517993x1025539700_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_box_24lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_d_248) {
  int64_t v_lit_244 = heff_unbox_word(v_box_24lit_244);
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return heff_setField(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_a_2411 = (g_prelude_2esplitFrom(v_lit_240, v_x_249, heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_x_249, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_a_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_2411));
    V v_a_2415;
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      v_a_2415 = v_x_249;
      break;
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_a_2412, 0);
      heff_take_n(v_a_2412, 1ULL, 2);
      heff_drop(v_x_249);
      v_a_2415 = v_a_2413;
      break;
    }
    default: heff_nomatch(v_a_2412);
    }
    int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_a_2415, 0)) - v_lit_244);
    V v_t_2417 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_a_2415, heff_box_word(v_t_2416)));
    V v_t_2418 = ({ V a_0 = v_a_2415; V a_1 = v_t_2417; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2417); r_; });
    V v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = heff_dup(v_lit_245); V a_2 = heff_dup(v_lit_246); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2419));
    V v_cell_2421 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_t_2420, heff_hole()});
    V v_u_2422 = heff_setField(v_d_248, MK_INT(1LL), heff_dup(v_cell_2421));
    heff_drop(v_u_2422);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    int64_t t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_xs_2410;
    V t_8 = v_cell_2421;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_x2_247 = t_7;
    v_d_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s307517993x1025539700_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24s307517993x1025539700_24dps(a0, a[1], a2, a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s398854970x1533504811_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s398854970x1533504811_entry, 2, 0};

V g_list_2efoldl_24s398854970x1533504811(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemit_2eprimUses(v_z_240, v_x_242));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s398854970x1533504811(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s803586165x1676441765_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s803586165x1676441765_entry, 7, 0};

V g_list_2emap_24s803586165x1676441765(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = ({ V a_0 = v_lit_240; V a_1 = v_x_247; V a_2 = heff_dup(v_lit_241); V a_3 = heff_strFind_lent(v_lit_242, v_x_247, v_lit_243, 0); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_247); r_; });
    V v_a_2410 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_a_2410)) {
    case TAG_Nil: {
      v_t_2413 = heff_dup(v_lit_244);
      break;
    }
    case TAG_Cons: {
      V v_a_2411 = heff_field(v_a_2410, 0);
      V v_a_2412 = heff_field(v_a_2410, 1);
      heff_take_n(v_a_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = heff_dup(v_lit_245); V a_1 = v_a_2411; V a_2 = v_a_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2412); r_; });
      break;
    }
    default: heff_nomatch(v_a_2410);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = (g_list_2emap_24s803586165x1676441765_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24s803586165x1676441765(a0, a[1], a2, a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emap_24s391931963x434308123_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s391931963x434308123_24dps_entry, 2, 0};

V g_list_2emap_24s391931963x434308123_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_x_242; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s391931963x434308123_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s391931963x434308123_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1275294336x693095586_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1275294336x693095586_24dps_entry, 3, 0};

V g_list_2emap_24s1275294336x693095586_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eemitc_2easLent(v_lit_240, v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1275294336x693095586_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1275294336x693095586_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s456133444x1904936646_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s456133444x1904936646_entry, 8, 0};

V g_list_2emap_24s456133444x1904936646(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkDrop: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      switch (heff_tag_of(v_a_2411)) {
      case TAG_Nothing: {
        V v_t_2412 = ({ V a_0 = v_a_2410; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_a_2410); r_; });
        V v_t_2413 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2412), heff_dup(v_lit_245));
        v_t_2415 = heff_strAppend(heff_dup(v_lit_240), v_t_2413);
        break;
      }
      case TAG_Just: {
        V v_a_2414 = heff_field(v_a_2411, 0);
        heff_take_n(v_a_2411, 1ULL, 1);
        v_t_2415 = ({ V a_0 = v_a_2410; V a_1 = v_a_2414; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_a_2410); heff_drop(v_a_2414); r_; });
        break;
      }
      default: heff_nomatch(v_a_2411);
      }
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2415, heff_dup(v_lit_246)), heff_hole()});
    V v_u_2417 = (g_list_2emap_24s456133444x1904936646_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s456133444x1904936646_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s456133444x1904936646(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efoldl_24s1520027297x1040032870_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1520027297x1040032870_entry, 2, 0};

V g_list_2efoldl_24s1520027297x1040032870(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_args_244 = heff_take_field(v_x_242, 2);
    V v_result_245 = heff_get_n(v_x_242, 3, 5);
    V v_t_248;
    switch (heff_tag_of(v_result_245)) {
    case TAG_Gives: {
      V v_a_246 = heff_field(v_result_245, 0);
      heff_take_n(v_result_245, 1ULL, 1);
      v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_246, NTAG(TAG_Nil)});
      break;
    }
    case TAG_GivesOrErrno: {
      V v_a_247 = heff_field(v_result_245, 0);
      heff_take_n(v_result_245, 1ULL, 1);
      v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_247, NTAG(TAG_Nil)});
      break;
    }
    case TAG_DoneOrErrno: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_248 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_result_245);
    }
    V v_t_249 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_z_240, v_args_244, v_t_248));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1520027297x1040032870_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1520027297x1040032870(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s478006518x1380334353_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s478006518x1380334353_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s478006518x1380334353_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_244 = ({ V a_0 = v_x_242; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if (!(heff_dup(v_a_244) == NTAG(TAG_True))) {
      heff_drop(v_a_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s478006518x1380334353_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s478006518x1380334353_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1894035205x969464323_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1894035205x969464323_entry, 3, 0};

V g_list_2efoldl_24s1894035205x969464323(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_intAdd(v_z_241, heff_strLength_lent(v_x_243, 0));
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_t_245, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1894035205x969464323(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s577716216x434174337_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s577716216x434174337_entry, 5, 0};

V g_list_2emap_24s577716216x434174337(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_247 = heff_strAppend(heff_dup(v_lit_240), heff_dup(v_lit_241));
    V v_t_248 = heff_strSlice(heff_dup(v_x_245), heff_dup(v_lit_242), heff_strLength_lent(v_a_247, 0));
    V v_t_2411;
    if (heff_strEq_c(v_t_248, v_a_247)) {
      V v_t_249 = heff_intAdd(heff_strLength_lent(v_lit_240, 0), heff_dup(v_lit_243));
      V v_t_2410 = heff_strSlice(heff_dup(v_x_245), v_t_249, heff_strLength_lent(v_x_245, 0));
      v_t_2411 = heff_rec_n(2, shape_name__key, (V[]){v_t_2410, v_x_245});
    } else {
      v_t_2411 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_x_245), v_x_245});
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s577716216x434174337_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s577716216x434174337_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s577716216x434174337(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1149369025x804005338_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1149369025x804005338_entry, 8, 0};

V g_list_2efoldl_24s1149369025x804005338(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_z_246, V v_x3_247) {
top: ;
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_243);
    return v_z_246;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x3_247, 0);
    V v_xs_249 = heff_field(v_x3_247, 1);
    V v_a_2410 = heff_dup(heff_rfield(v_x_248, 4));
    V v_t_2411 = ({ V a_0 = v_lit_242; V a_1 = v_a_2410; V a_2 = heff_dup(v_lit_243); V a_3 = heff_strFind_lent(v_lit_244, v_a_2410, v_lit_245, 0); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_a_2410); r_; });
    V v_t_2412 = (g_list_2emap_24s1068592055x839006909(heff_dup(v_x_248), heff_dup(v_lit_240), heff_dup(v_lit_241), v_t_2411));
    V v_t_2413 = ({ V a_0 = v_z_246; V a_1 = heff_dup(heff_rfield(v_x_248, 7)); V a_2 = heff_rfield(v_x_248, 8); V a_3 = v_t_2412; V r_ = (g_heff_2ebuild_2edriver_2epromoteAt(a_0, a_1, a_2, a_3)); heff_drop(v_z_246); r_; });
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_t_2413;
    V t_7 = v_xs_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_z_246 = t_6;
    v_x3_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_list_2efoldl_24s1149369025x804005338_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a7 = a[7]; V r = g_list_2efoldl_24s1149369025x804005338(a[0], a[1], a2, a[3], a4, a5, a[6], a7); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a7); return r;
}
Clo g_list_2emap_24s467798769x1763085075_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s467798769x1763085075_24dps_entry, 2, 0};

V g_list_2emap_24s467798769x1763085075_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s467798769x1763085075_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s467798769x1763085075_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1476602679x302842688_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1476602679x302842688_entry, 2, 0};

V g_list_2efoldl_24s1476602679x302842688(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        v_t_2411 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_a_246)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1476602679x302842688(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s478414341x1543613922_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s478414341x1543613922_entry, 2, 0};

V g_list_2efoldl_24s478414341x1543613922(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s478414341x1543613922(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s2015972532x1874881274_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2015972532x1874881274_entry, 2, 0};

V g_list_2ekeepIf_24s2015972532x1874881274(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_intEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s2015972532x1874881274_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2015972532x1874881274_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s2015972532x1874881274(a[0], a[1]);
}
Clo g_list_2emap_24s1276696116x507290452_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1276696116x507290452_entry, 2, 0};

V g_list_2emap_24s1276696116x507290452(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_span_245 = heff_get_n(v_x_242, 1, 2);
    V v_a_246 = heff_dup(v_name_244);
    V v_a_247 = v_span_245;
    V v_start_248 = heff_take_field(v_a_247, 0);
    V v_end_249 = heff_get_n(v_a_247, 1, 2);
    V v_t_2410 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), heff_tag_n(TAG_Just, 1, (V[]){v_name_244}), NTAG(TAG_Nothing)});
    V v_a_2411 = v_start_248;
    V v_a_2412 = heff_intSub(heff_dup(v_end_249), heff_strLength_lent(v_a_246, 0));
    V v_t_2413;
    if (heff_intLe_c_lent(v_a_2411, v_a_2412, 0)) {
      heff_drop(v_a_2411);
      v_t_2413 = v_a_2412;
    } else {
      heff_drop(v_a_2412);
      v_t_2413 = v_a_2411;
    }
    V v_t_2414 = heff_rec_n(3, shape_target__name__span, (V[]){v_t_2410, v_a_246, heff_rec_n(2, shape_start__end, (V[]){v_t_2413, v_end_249})});
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = (g_list_2emap_24s1276696116x507290452_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2415)));
    heff_drop(v_u_2416);
    return v_cell_2415;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1276696116x507290452_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1276696116x507290452(a[0], a[1]);
}
Clo g_list_2emap_24s388004800x1261967008_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s388004800x1261967008_entry, 1, 0};

V g_list_2emap_24s388004800x1261967008(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s388004800x1261967008_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s388004800x1261967008(a[0]);
}
Clo g_list_2ekeepIf_24s647917584x875728492_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s647917584x875728492_entry, 2, 0};

V g_list_2ekeepIf_24s647917584x875728492(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_lit_240, 1)))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s647917584x875728492_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 14);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s647917584x875728492_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s647917584x875728492(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s647917584x875728492_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s647917584x875728492_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s647917584x875728492_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(heff_rfield(v_lit_240, 1)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 14);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s647917584x875728492_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s647917584x875728492_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s491084544x100802329_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s491084544x100802329_entry, 2, 0};

V g_list_2efoldl_24s491084544x100802329(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_a_248)));
        v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_249); r_; });
        break;
      }
      case TAG_BadVariant: {
        V v_a_2410 = heff_field(v_a_244, 0);
        v_t_2411 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2410));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s491084544x100802329(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s354283597x484250159_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s354283597x484250159_entry, 2, 0};

V g_list_2emap_24s354283597x484250159(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2evariantKey(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s354283597x484250159_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s354283597x484250159_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s354283597x484250159(a[0], a[1]);
}
Clo g_list_2emap_24s1055307687x247454614_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1055307687x247454614_24dps_entry, 3, 0};

V g_list_2emap_24s1055307687x247454614_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2eequationKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1055307687x247454614_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1055307687x247454614_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1703643582x349630108_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1703643582x349630108_24dps_entry, 3, 0};

V g_list_2emap_24s1703643582x349630108_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = ({ V a_0 = v_x_243; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_x_243); r_; });
    V v_t_249;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_a_248 = v_field_247;
        v_t_249 = v_a_248;
      } else {
        heff_drop(v_field_247);
        v_t_249 = heff_dup(v_lit_240);
      }
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_2410;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1703643582x349630108_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1703643582x349630108_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emerge_24s132798885x1165759438_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s132798885x1165759438_entry, 2, 0};

V g_list_2emerge_24s132798885x1165759438(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_x3_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_243 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 3);
      heff_drop(v_xs_243);
      return v_x2_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_strLt_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_y_244, 0)))) {
        V v_cell_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_247 = (g_list_2emerge_24s132798885x1165759438_24dps(v_xs_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys_245}), heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_y_244, 0)))) {
          V v_x1_248 = (g_heff_2ebuild_2eproject_2enewer(heff_rfield(v_x_242, 1), heff_rfield(v_y_244, 1)));
          if (!(heff_dup(v_x1_248) == NTAG(TAG_True))) {
            heff_drop(v_x1_248);
            V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
            V v_u_2410 = (g_list_2emerge_24s132798885x1165759438_24dps(v_xs_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys_245}), heff_dup(v_cell_249)));
            heff_drop(v_u_2410);
            return v_cell_249;
          } else {
            heff_drop(v_x1_248);
            V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
            V v_u_2412 = (g_list_2emerge_24s132798885x1165759438_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs_243}), v_ys_245, heff_dup(v_cell_2411)));
            heff_drop(v_u_2412);
            return v_cell_2411;
          }
        } else {
          V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
          V v_u_2414 = (g_list_2emerge_24s132798885x1165759438_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs_243}), v_ys_245, heff_dup(v_cell_2413)));
          heff_drop(v_u_2414);
          return v_cell_2413;
        }
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s132798885x1165759438_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s132798885x1165759438(a[0], a[1]);
}
Clo g_list_2emap_24s18996220x10511024_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s18996220x10511024_24dps_entry, 2, 0};

V g_list_2emap_24s18996220x10511024_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_path_245 = heff_get_n(v_x_242, 1, 3);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_244, v_path_245}), heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s18996220x10511024_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s18996220x10511024_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s180477083x124477283_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s180477083x124477283_entry, 2, 0};

V g_list_2eany_24s180477083x124477283(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s180477083x124477283_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s180477083x124477283(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s925333445x1396764769_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s925333445x1396764769_entry, 6, 0};

V g_list_2emap_24s925333445x1396764769(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_246, 0));
      v_t_2410 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = heff_dup(v_lit_241); V a_2 = heff_dup(v_lit_242); V r_ = (g_json_2eescapeGo(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
    V v_t_2415;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_246, 1);
      heff_take_n(v_x_246, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_json_2estringify(a_0)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), v_t_2416));
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s925333445x1396764769_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s925333445x1396764769_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s925333445x1396764769(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s1727184187x1048417382_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1727184187x1048417382_entry, 1, 0};

V g_list_2emap_24s1727184187x1048417382(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_regex_2ebranchOf(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1727184187x1048417382_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1727184187x1048417382_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1727184187x1048417382(a[0]);
}
Clo g_list_2emap_24s1007499915x73800978_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1007499915x73800978_entry, 1, 0};

V g_list_2emap_24s1007499915x73800978(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = MK_INT(124LL); V a_1 = v_x_241; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_241); r_; });
    V v_t_244 = (g_list_2emap_24s1727184187x1048417382(v_t_243));
    HeffT2 v_t_245 = (g_regex_2eallRead_24cpr(v_t_244));
    V v_t_2410;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_why_248 = v_field_247;
        v_t_2410 = heff_tag_n(TAG_Left, 1, (V[]){v_why_248});
      } else {
        V v_bs_249 = v_field_247;
        v_t_2410 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkRegex, 1, (V[]){v_bs_249})});
      }
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s1007499915x73800978_24dps(v_xs_242, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1007499915x73800978(a[0]);
}
Clo g_list_2efoldl_24s571074576x1179600767_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s571074576x1179600767_24scalars_entry, 6, 0};

V g_list_2efoldl_24s571074576x1179600767_24scalars(V v_sources_240, V v_errors_241, V v_paths_242, V v_package_243, V v_packages_244, V v_x3_245) {
top: ;
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nil: {
    return heff_rec_n(5, shape_sources__errors__paths__package__packages, (V[]){v_sources_240, v_errors_241, v_paths_242, v_package_243, v_packages_244});
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x3_245, 0);
    V v_xs_247 = heff_field(v_x3_245, 1);
    V v_ru_24x3_245_24Cons = heff_take_reuse_n(v_x3_245, 3ULL, 2);
    V t_0 = v_sources_240;
    V t_1 = heff_tag_at_n(v_ru_24x3_245_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_errors_241});
    V t_2 = v_paths_242;
    V t_3 = v_package_243;
    V t_4 = v_packages_244;
    V t_5 = v_xs_247;
    v_sources_240 = t_0;
    v_errors_241 = t_1;
    v_paths_242 = t_2;
    v_package_243 = t_3;
    v_packages_244 = t_4;
    v_x3_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_list_2efoldl_24s571074576x1179600767_24scalars_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s571074576x1179600767_24scalars(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2eany_24s1740858080x874135214_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1740858080x874135214_entry, 1, 0};

V g_list_2eany_24s1740858080x874135214(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_243 = (g_list_2ekeepIf_24s1161549307x1906011635(heff_dup(heff_rfield(v_x_241, 6))));
    switch (heff_tag_of(v_a_243)) {
    case TAG_Nil: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_a_243, 0ULL, 2);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1740858080x874135214(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s977936796x564903144_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s977936796x564903144_entry, 4, 0};

V g_list_2efoldl_24s977936796x564903144(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_list_2efoldl_24f2094160282x1876485468(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_rfield(v_x_244, 6)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_z_242, v_t_246);
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s977936796x564903144_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s977936796x564903144(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2ekeepIf_24s741838803x941779121_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s741838803x941779121_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s741838803x941779121_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 6, 10);
    if (!(heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s741838803x941779121_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s741838803x941779121_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1953633397x1251544744_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1953633397x1251544744_24dps_entry, 9, 0};

V g_list_2emap_24s1953633397x1251544744_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_d_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_241, 12);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return heff_setField(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_a_2411 = heff_dup(heff_rfield(v_lit_241, 4));
    V v_t_2415;
    if (heff_intEq_c_lent(v_a_2411, v_lit_242, 0)) {
      heff_drop(v_a_2411);
      v_t_2415 = heff_dup(v_lit_243);
    } else {
      V v_t_2414;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_dup(heff_field(v_x_249, 1));
        v_t_2414 = v_a_2413;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      v_t_2415 = heff_intDiv(heff_intMul(v_t_2414, heff_dup(v_lit_244)), v_a_2411);
    }
    V v_t_2416 = heff_strAppend(heff_intShow(v_t_2415), heff_dup(v_lit_245));
    V v_t_2419;
    switch (heff_tag_of(v_x_249)) {
    case TAG_MkPair: {
      V v_a_2417 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 2);
      v_t_2419 = v_a_2417;
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    V v_t_2420 = heff_strAppend(v_t_2416, heff_strAppend(heff_dup(v_lit_246), v_t_2419));
    V v_cell_2421 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2420), heff_hole()});
    V v_u_2422 = heff_setField(v_d_248, MK_INT(1LL), heff_dup(v_cell_2421));
    heff_drop(v_u_2422);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_xs_2410;
    V t_8 = v_cell_2421;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_x2_247 = t_7;
    v_d_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s1953633397x1251544744_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1953633397x1251544744_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
HEFF_LIT(g_list_2emap_24s849938259x51049885_str0, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_str1, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_str2, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_str3, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_str4, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_str5, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_str6, 0, "");
Clo g_list_2emap_24s849938259x51049885_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s849938259x51049885_entry, 1, 0};

V g_list_2emap_24s849938259x51049885(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_JNull: {
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JArray: {
      V v_ns_247 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = (g_list_2emap_24s1767134203x962737276(((V)&g_list_2emap_24s849938259x51049885_str0), ((V)&g_list_2emap_24s849938259x51049885_str1), ((V)&g_list_2emap_24s849938259x51049885_str2), ((V)&g_list_2emap_24s849938259x51049885_str3), ((V)&g_list_2emap_24s849938259x51049885_str4), ((V)&g_list_2emap_24s849938259x51049885_str5), ((V)&g_list_2emap_24s849938259x51049885_str6), v_ns_247));
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s849938259x51049885_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s849938259x51049885_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s849938259x51049885(a[0]);
}
Clo g_list_2efoldl_24s141260856x1366916752_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s141260856x1366916752_entry, 5, 0};

V g_list_2efoldl_24s141260856x1366916752(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_244, 0);
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_Nil: {
      v_t_2412 = heff_dup(v_lit_240);
      break;
    }
    case TAG_Cons: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_t_249 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_a_247));
      V v_a_2410 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_249));
      V v_t_2411 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(heff_dup(v_lit_242), v_a_2410, v_a_248));
      v_t_2412 = heff_strAppend(heff_dup(v_lit_241), v_t_2411);
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2413 = heff_strLength(v_t_2412);
    V v_t_2414;
    if ((heff_peek_word(v_z_243) <= heff_peek_word(v_a_2413))) {
      heff_drop(v_z_243);
      v_t_2414 = v_a_2413;
    } else {
      heff_drop(v_a_2413);
      v_t_2414 = v_z_243;
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_2414;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s141260856x1366916752_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2efoldl_24s141260856x1366916752(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
HEFF_LIT(g_list_2eall_24s1579400704x1789597964_str0, 2, "..");
HEFF_LIT(g_list_2eall_24s1579400704x1789597964_str1, 0, "");
HEFF_LIT(g_list_2eall_24s1579400704x1789597964_str2, 1, ".");
Clo g_list_2eall_24s1579400704x1789597964_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1579400704x1789597964_entry, 1, 0};

V g_list_2eall_24s1579400704x1789597964(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if ((heff_strEq_c_lent(v_x_241, ((V)&g_list_2eall_24s1579400704x1789597964_str0), 2) ? 0 : (heff_strEq_c_lent(v_x_241, ((V)&g_list_2eall_24s1579400704x1789597964_str1), 2) ? 0 : !heff_strEq_c_lent(v_x_241, ((V)&g_list_2eall_24s1579400704x1789597964_str2), 2)))) {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1579400704x1789597964_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1579400704x1789597964(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1105764576x1671327425_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1105764576x1671327425_entry, 3, 0};

V g_list_2emap_24s1105764576x1671327425(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop_rec(v_lit_241, 5);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_a_245 = heff_dup(heff_rfield(v_lit_240, 3));
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 0, 2);
    V v_t_247 = heff_strSlice(heff_dup(v_a_245), heff_dup(heff_rfield(v_lit_241, 2)), v_t_246);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 1, 2);
    V v_t_249 = heff_strSlice(v_a_245, v_t_248, heff_dup(heff_rfield(v_lit_241, 4)));
    V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(v_x_243, v_t_249));
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s1105764576x1671327425_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1105764576x1671327425_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1105764576x1671327425(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1753874608x910016727_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1753874608x910016727_entry, 1, 0};

V g_list_2emap_24s1753874608x910016727(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagLine(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1753874608x910016727_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1753874608x910016727(a[0]);
}
Clo g_list_2efoldl_24s6718001x1068992521_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s6718001x1068992521_entry, 3, 0};

V g_list_2efoldl_24s6718001x1068992521(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_strRunes(heff_dup(heff_rfield(v_x_243, 0)));
    V v_a_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_t_247;
    if (heff_intLe_c_lent(v_z_241, v_a_246, 0)) {
      heff_drop(v_z_241);
      v_t_247 = v_a_246;
    } else {
      heff_drop(v_a_246);
      v_t_247 = v_z_241;
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_247;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s6718001x1068992521_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s6718001x1068992521(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f189927396x2059034600_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f189927396x2059034600_24dps_entry, 2, 0};

V g_list_2emap_24f189927396x2059034600_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_loosest_244 = heff_take_field(v_x_242, 3);
    V v_id_245 = heff_get_n(v_x_242, 0, 5);
    if ((heff_dup(v_loosest_244) == NTAG(TAG_True))) {
      heff_drop(v_loosest_244);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_id_245, heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_xs_243;
      V t_1 = v_cell_246;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_loosest_244);
      heff_drop(v_id_245);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f189927396x2059034600_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f189927396x2059034600_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24f428638463x2144521938_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f428638463x2144521938_24dps_entry, 5, 0};

V g_list_2ekeepIf_24f428638463x2144521938_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x1_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_243, 0);
    V v_xs_246 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24Cons = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x1_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    case TAG_Just: {
      V v_x_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      if (!heff_strEq_c(heff_strSlice_lent(v_x_247, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        V v_cell_248 = heff_tag_at_n(v_ru_24x1_243_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
        V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_cell_248;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x1_243 = t_3;
        v_d_244 = t_4;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x1_243_24Cons, 2);
        heff_drop(v_x_247);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_d_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x1_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_list_2ekeepIf_24f428638463x2144521938_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24f428638463x2144521938_24dps(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24f1632378148x1903828118_24dps_str0, 13, "static Clo g_");
Clo g_list_2emap_24f1632378148x1903828118_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1632378148x1903828118_24dps_entry, 3, 0};

V g_list_2emap_24f1632378148x1903828118_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_243, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_list_2emap_24f1632378148x1903828118_24dps_str0))) {
      V v_t_245 = heff_strSlice(heff_dup(v_x_243), heff_dup(v_lit_240), heff_strLength(v_x_243));
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1632378148x1903828118_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f1632378148x1903828118_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24f565269645x1954016017_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f565269645x1954016017_24dps_entry, 2, 0};

V g_list_2emap_24f565269645x1954016017_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_binder_244 = heff_take_field(v_x_242, 0);
    V v_use_245 = heff_get_n(v_x_242, 1, 2);
    V v_t_246 = heff_take_field(v_binder_244, 2);
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_rec_n(3, shape_name__field__use, (V[]){heff_take_field(v_binder_244, 0), heff_get_n(v_binder_244, 1, 3), v_use_245});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_243;
      V t_1 = v_cell_248;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop_rec(v_binder_244, 3);
      heff_drop(v_use_245);
      heff_drop(v_t_246);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f565269645x1954016017_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f565269645x1954016017_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24f2080327479x1330764413_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2080327479x1330764413_entry, 7, 0};

V g_list_2efoldl_24f2080327479x1330764413(V v_z_240, V v_box_24lit_241, V v_lit_242, V v_box_24lit_243, V v_box_24lit_244, V v_box_24a_245, V v_box_24b_246) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_244 = heff_unbox_word(v_box_24lit_244);
  int64_t v_a_245 = heff_unbox_word(v_box_24a_245);
  int64_t v_b_246 = heff_unbox_word(v_box_24b_246);
top: ;
  if ((v_b_246 < v_a_245)) {
    return v_z_240;
  } else {
    if (((v_a_245 == v_lit_241) || (heff_unbox_word(heff_strByteAt_lent(v_lit_242, heff_box_word((v_a_245 - v_lit_243)), 2)) == v_lit_244))) {
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_box_word(v_a_245), v_z_240});
      int64_t t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      int64_t t_4 = v_lit_244;
      int64_t t_5 = (v_a_245 + ((int64_t)1ULL));
      int64_t t_6 = v_b_246;
      v_z_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_a_245 = t_5;
      v_b_246 = t_6;
      goto top;
    } else {
      V t_0 = v_z_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      int64_t t_4 = v_lit_244;
      int64_t t_5 = (v_a_245 + ((int64_t)1ULL));
      int64_t t_6 = v_b_246;
      v_z_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_a_245 = t_5;
      v_b_246 = t_6;
      goto top;
    }
  }
}
V g_list_2efoldl_24f2080327479x1330764413_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f2080327479x1330764413(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f297647854x479783049_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f297647854x479783049_entry, 2, 0};

V g_list_2efoldl_24f297647854x479783049(V v_z_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_241, 0);
    V v_cs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s647917584x875728492(heff_dup(v_c_242), v_cs_243));
    V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_z_240});
    V t_1 = v_t_244;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f297647854x479783049(a[0], a[1]);
}
Clo g_list_2emap_24f530523215x314966509_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f530523215x314966509_24dps_entry, 8, 0};

V g_list_2emap_24f530523215x314966509_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop_rec(v_lit_241, 2);
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_target_2410 = heff_take_field(v_x_248, 0);
    V v_name_2411 = heff_take_field(v_x_248, 1);
    V v_span_2412 = heff_get_n(v_x_248, 2, 3);
    V v_t_2413 = heff_get_n(v_target_2410, 1, 3);
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      heff_drop(v_name_2411);
      heff_drop(v_span_2412);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_d_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_2413, 0ULL, 1);
      V v_t_2415 = heff_intAdd(heff_dup(heff_rfield(v_lit_241, 0)), heff_dup(v_lit_242));
      V v_t_2416 = heff_strSlice(heff_dup(heff_rfield(v_lit_240, 3)), heff_dup(heff_rfield(v_lit_241, 0)), v_t_2415);
      V v_t_2417;
      if (heff_strEq_c_lent(v_t_2416, v_lit_243, 1)) {
        v_t_2417 = heff_dup(v_lit_244);
      } else {
        v_t_2417 = heff_dup(v_lit_245);
      }
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__kind__span, (V[]){v_name_2411, v_t_2417, v_span_2412}), heff_hole()});
      V v_u_2419 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2418));
      heff_drop(v_u_2419);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_cell_2418;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24f530523215x314966509_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2emap_24f530523215x314966509_24dps(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7]); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f1221993074x1235215335_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1221993074x1235215335_entry, 3, 0};

V g_list_2efoldl_24f1221993074x1235215335(V v_z_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (!heff_strEq_c_lent(v_x_243, v_lit_241, 0)) {
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_z_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1221993074x1235215335_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1221993074x1235215335(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24f1278780364x1365377410_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f1278780364x1365377410_24dps_entry, 8, 0};

V g_list_2ekeepIf_24f1278780364x1365377410_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2410 = heff_strSlice(heff_dup(v_lit_242), heff_dup(v_lit_243), heff_intAdd(heff_dup(v_lit_244), heff_dup(v_lit_245)));
    V v_x_2411 = heff_strAppend(v_t_2410, v_x_248);
    V v_t_2412 = heff_strSlice(heff_dup(v_x_2411), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_2412, v_lit_241, 1)) {
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
      V v_u_2414 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_cell_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      heff_drop(v_x_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_d_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2ekeepIf_24f1278780364x1365377410_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2ekeepIf_24f1278780364x1365377410_24dps(a0, a1, a2, a3, a[4], a[5], a[6], a[7]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emap_24f1893878025x389241368_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1893878025x389241368_entry, 6, 0};

V g_list_2emap_24f1893878025x389241368(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_shown_248 = heff_take_field(v_x_246, 2);
    V v_name_249 = heff_take_field(v_x_246, 0);
    V v_doc_2410 = heff_get_n(v_x_246, 1, 4);
    if (((heff_dup(v_shown_248) == NTAG(TAG_True)) && heff_strEq_c(heff_strSlice(heff_dup(v_name_249), heff_dup(v_lit_243), heff_strLength_lent(v_lit_244, 0)), heff_dup(v_lit_244)))) {
      heff_drop(v_shown_248);
      V v_a_2411 = v_name_249;
      V v_a_2412 = v_doc_2410;
      V v_t_2413;
      if (heff_strEq_c_lent(v_a_2412, v_lit_240, 0)) {
        heff_drop(v_a_2412);
        v_t_2413 = v_a_2411;
      } else {
        v_t_2413 = heff_strAppend(v_a_2411, heff_strAppend(heff_dup(v_lit_241), v_a_2412));
      }
      V v_cell_2414 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, heff_dup(v_lit_242)), heff_hole()});
      V v_u_2415 = (g_list_2emap_24f1893878025x389241368_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    } else {
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_shown_248);
      heff_drop(v_name_249);
      heff_drop(v_doc_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24f1893878025x389241368_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V a4 = a[4]; V r = g_list_2emap_24f1893878025x389241368(a0, a[1], a[2], a3, a4, a[5]); heff_drop(a0); heff_drop(a3); heff_drop(a4); return r;
}
Clo g_list_2emap_24s215892288x1392224072_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s215892288x1392224072_24tok2_entry, 3, 0};

V g_list_2emap_24s215892288x1392224072_24tok2(V v_tok_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lit_241), v_x_243}), heff_hole()});
    V v_u_246 = (g_list_2emap_24s215892288x1392224072_24dps(v_lit_241, v_xs_244, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s215892288x1392224072_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s215892288x1392224072_24tok2(a[0], a[1], a[2]);
}