// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAbandon 62759
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SetField 47531
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_Unreached 46435
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_Within 10658
#define LBL_atom 9500184
#define LBL_binder 558177493
#define LBL_body 9524841
#define LBL_e 319
#define LBL_errors 652506774
#define LBL_field 298786068
#define LBL_id 10114
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_loosest 581880769
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_use 325633
static uint32_t shape_name__field__use[] = {LBL_name, LBL_field, LBL_use};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
V g_heff_2ebuild_2ebenchmarks_2ecapital(V);
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo;
V g_heff_2ebuild_2ebenchmarks_2espaced(V);
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2ecpr_2efldAt(V, V);
V g_heff_2ecompile_2ecpr_2efldAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2efldAt_clo;
V g_heff_2ecompile_2edefun_2ehandsW(V, V);
V g_heff_2ecompile_2edefun_2ehandsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2ehandsW_clo;
V g_heff_2ecompile_2eemit_2ecallsHelper(V, V);
V g_heff_2ecompile_2eemit_2ecallsHelper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallsHelper_clo;
V g_heff_2ecompile_2eemitc_2elastDotGo(V, V, V);
V g_heff_2ecompile_2eemitc_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elastDotGo_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_list_2eall_24s1512314936x520990916(V);
V g_list_2eall_24s1512314936x520990916_entry(V self, V *a);
extern Clo g_list_2eall_24s1512314936x520990916_clo;
V g_list_2eall_24s1579400704x1789597964(V);
V g_list_2eall_24s1579400704x1789597964_entry(V self, V *a);
extern Clo g_list_2eall_24s1579400704x1789597964_clo;
V g_list_2eall_24s568190696x1372373514(V);
V g_list_2eall_24s568190696x1372373514_entry(V self, V *a);
extern Clo g_list_2eall_24s568190696x1372373514_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1041788812x158895160(V);
V g_list_2eany_24s1041788812x158895160_entry(V self, V *a);
extern Clo g_list_2eany_24s1041788812x158895160_clo;
V g_list_2eany_24s2023978511x2117594482(V);
V g_list_2eany_24s2023978511x2117594482_entry(V self, V *a);
extern Clo g_list_2eany_24s2023978511x2117594482_clo;
V g_list_2ecollapse_24s705464212x1327502534(V, V);
V g_list_2ecollapse_24s705464212x1327502534_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s705464212x1327502534_clo;
V g_list_2edescending(V, V, V, V);
V g_list_2edescending_entry(V self, V *a);
extern Clo g_list_2edescending_clo;
V g_list_2edescending_24s379747839x1236130333(V, V, V, V, V);
V g_list_2edescending_24s379747839x1236130333_entry(V self, V *a);
extern Clo g_list_2edescending_24s379747839x1236130333_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f297647854x479783049(V, V);
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a);
extern Clo g_list_2efoldl_24f297647854x479783049_clo;
V g_list_2efoldl_24f928374809x1955888331(V, V);
V g_list_2efoldl_24f928374809x1955888331_entry(V self, V *a);
extern Clo g_list_2efoldl_24f928374809x1955888331_clo;
V g_list_2efoldl_24s1061937638x829298692(V, V);
V g_list_2efoldl_24s1061937638x829298692_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061937638x829298692_clo;
V g_list_2efoldl_24s1071292119x112543158(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1071292119x112543158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1071292119x112543158_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s141260856x1366916752(V, V, V, V, V);
V g_list_2efoldl_24s141260856x1366916752_entry(V self, V *a);
extern Clo g_list_2efoldl_24s141260856x1366916752_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s1894035205x969464323(V, V, V);
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1894035205x969464323_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s278088687x1269971185(V, V);
V g_list_2efoldl_24s278088687x1269971185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s278088687x1269971185_clo;
V g_list_2efoldl_24s398854970x1533504811(V, V);
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a);
extern Clo g_list_2efoldl_24s398854970x1533504811_clo;
V g_list_2efoldl_24s441088199x272212076(V, V);
V g_list_2efoldl_24s441088199x272212076_entry(V self, V *a);
extern Clo g_list_2efoldl_24s441088199x272212076_clo;
V g_list_2efoldl_24s491084544x100802329(V, V);
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s491084544x100802329_clo;
V g_list_2efoldl_24s571074576x1179600767_24scalars(V, V, V, V, V, V);
V g_list_2efoldl_24s571074576x1179600767_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_24scalars_clo;
V g_list_2efoldl_24s6718001x1068992521(V, V, V);
V g_list_2efoldl_24s6718001x1068992521_entry(V self, V *a);
extern Clo g_list_2efoldl_24s6718001x1068992521_clo;
V g_list_2ekeepIf_24s2015972532x1874881274(V, V);
V g_list_2ekeepIf_24s2015972532x1874881274_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2015972532x1874881274_clo;
V g_list_2ekeepIf_24s2015972532x1874881274_24dps(V, V, V);
V g_list_2ekeepIf_24s2015972532x1874881274_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2015972532x1874881274_24dps_clo;
V g_list_2ekeepIf_24s425280038x249084439(V, V, V);
V g_list_2ekeepIf_24s425280038x249084439_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s425280038x249084439_clo;
V g_list_2ekeepIf_24s425280038x249084439_24dps(V, V, V, V);
V g_list_2ekeepIf_24s425280038x249084439_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s425280038x249084439_24dps_clo;
V g_list_2ekeepIf_24s614579978x208602650(V, V);
V g_list_2ekeepIf_24s614579978x208602650_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s614579978x208602650_clo;
V g_list_2ekeepIf_24s614579978x208602650_24dps(V, V, V);
V g_list_2ekeepIf_24s614579978x208602650_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s614579978x208602650_24dps_clo;
V g_list_2ekeepIf_24s647917584x875728492(V, V);
V g_list_2ekeepIf_24s647917584x875728492_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s647917584x875728492_clo;
V g_list_2ekeepIf_24s647917584x875728492_24dps(V, V, V);
V g_list_2ekeepIf_24s647917584x875728492_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s647917584x875728492_24dps_clo;
V g_list_2ekeepIf_24s924780574x2000457388(V, V);
V g_list_2ekeepIf_24s924780574x2000457388_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s924780574x2000457388_clo;
V g_list_2ekeepIf_24s924780574x2000457388_24dps(V, V, V);
V g_list_2ekeepIf_24s924780574x2000457388_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s924780574x2000457388_24dps_clo;
HeffT2 g_list_2elookup_24s1507486579x90027037_24cpr(V, V);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1677329353x1774765664_24dps(V, V, V);
V g_list_2emap_24f1677329353x1774765664_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1677329353x1774765664_24dps_clo;
V g_list_2emap_24f1677329353x1774765664_24tok2(V, V, V);
V g_list_2emap_24f1677329353x1774765664_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24f1677329353x1774765664_24tok2_clo;
V g_list_2emap_24f189927396x2059034600_24dps(V, V);
V g_list_2emap_24f189927396x2059034600_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f189927396x2059034600_24dps_clo;
V g_list_2emap_24f530523215x314966509_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24f530523215x314966509_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f530523215x314966509_24dps_clo;
V g_list_2emap_24f565269645x1954016017_24dps(V, V);
V g_list_2emap_24f565269645x1954016017_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f565269645x1954016017_24dps_clo;
V g_list_2emap_24s1397747289x2145601499(V);
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_clo;
V g_list_2emap_24s1397747289x2145601499_24dps(V, V);
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_24dps_clo;
V g_list_2emap_24s1613211967x1923010103(V, V, V, V);
V g_list_2emap_24s1613211967x1923010103_entry(V self, V *a);
extern Clo g_list_2emap_24s1613211967x1923010103_clo;
V g_list_2emap_24s1613211967x1923010103_24dps(V, V, V, V, V);
V g_list_2emap_24s1613211967x1923010103_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1613211967x1923010103_24dps_clo;
V g_list_2emap_24s2039279853x710813703(V, V);
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_clo;
V g_list_2emap_24s2039279853x710813703_24dps(V, V, V);
V g_list_2emap_24s2039279853x710813703_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_24dps_clo;
V g_list_2emap_24s215892288x1392224072_24dps(V, V, V);
V g_list_2emap_24s215892288x1392224072_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24dps_clo;
V g_list_2emap_24s215892288x1392224072_24tok2(V, V, V);
V g_list_2emap_24s215892288x1392224072_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24tok2_clo;
V g_list_2emap_24s366344330x1145113647_24dps(V, V);
V g_list_2emap_24s366344330x1145113647_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_24dps_clo;
V g_list_2emap_24s388004800x1261967008(V);
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_clo;
V g_list_2emap_24s388004800x1261967008_24dps(V, V);
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_24dps_clo;
V g_list_2emap_24s570884835x2121220820(V);
V g_list_2emap_24s570884835x2121220820_entry(V self, V *a);
extern Clo g_list_2emap_24s570884835x2121220820_clo;
V g_list_2emap_24s570884835x2121220820_24dps(V, V);
V g_list_2emap_24s570884835x2121220820_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s570884835x2121220820_24dps_clo;
V g_list_2emap_24s97919758x216970748_24dps(V, V, V);
V g_list_2emap_24s97919758x216970748_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_clo;
V g_list_2emergeRuns_24s1848188369x464661008(V, V);
V g_list_2emergeRuns_24s1848188369x464661008_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1848188369x464661008_clo;
V g_list_2epushRun_24s2022155310x1483676144(V, V, V);
V g_list_2epushRun_24s2022155310x1483676144_entry(V self, V *a);
extern Clo g_list_2epushRun_24s2022155310x1483676144_clo;
V g_list_2epushRun_24s495990157x1087861527(V, V, V);
V g_list_2epushRun_24s495990157x1087861527_entry(V self, V *a);
extern Clo g_list_2epushRun_24s495990157x1087861527_clo;
V g_list_2erange_24dps(V, V, V);
V g_list_2erange_24dps_entry(V self, V *a);
extern Clo g_list_2erange_24dps_clo;
V g_list_2erunFrom_24s272018256x1228369023(V, V);
V g_list_2erunFrom_24s272018256x1228369023_entry(V self, V *a);
extern Clo g_list_2erunFrom_24s272018256x1228369023_clo;
V g_list_2ezipWith_24s1530546918x299821644(V, V);
V g_list_2ezipWith_24s1530546918x299821644_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1530546918x299821644_clo;
V g_list_2ezipWith_24s1530546918x299821644_24dps(V, V, V);
V g_list_2ezipWith_24s1530546918x299821644_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1530546918x299821644_24dps_clo;
V g_list_2ezipWith_24s583291244x257539062_24dps(V, V, V);
V g_list_2ezipWith_24s583291244x257539062_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s583291244x257539062_24dps_clo;
V g_list_2ezipWith_24s634961829x758866838_24dps(V, V, V);
V g_list_2ezipWith_24s634961829x758866838_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634961829x758866838_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_list_2erange_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2erange_24dps_entry, 3, 0};

V g_list_2erange_24dps(V v_a_240, V v_b_241, V v_d_242) {
top: ;
  if (heff_intLt_c_lent(v_b_241, v_a_240, 0)) {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_240), heff_hole()});
    V v_u_244 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_243));
    heff_drop(v_u_244);
    V t_0 = heff_intAdd(v_a_240, MK_INT(1LL));
    V t_1 = v_b_241;
    V t_2 = v_cell_243;
    v_a_240 = t_0;
    v_b_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_list_2erange_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2erange_24dps(a[0], a[1], a[2]);
}
Clo g_list_2edescending_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_entry, 4, 0};

V g_list_2edescending(V v_le_240, V v_x_241, V v_acc_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    heff_drop(v_x_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_242, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_244 = heff_field(v_x4_243, 0);
    V v_ys_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){v_x_241, heff_dup(v_y_244)}));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_le_240);
      heff_drop(v_t_246);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_242, heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_y_244, v_ys_245})});
    } else {
      heff_drop(v_t_246);
      V t_0 = v_le_240;
      V t_1 = heff_dup(v_y_244);
      V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_y_244, v_acc_242});
      V t_3 = v_ys_245;
      v_le_240 = t_0;
      v_x_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_list_2edescending_entry(V self, V *a) {
  (void)self;
  return g_list_2edescending(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s366344330x1145113647_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366344330x1145113647_24dps_entry, 2, 0};

V g_list_2emap_24s366344330x1145113647_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366344330x1145113647_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366344330x1145113647_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s2023978511x2117594482_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2023978511x2117594482_entry, 1, 0};

V g_list_2eany_24s2023978511x2117594482(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      v_t_246 = heff_bool(heff_strEq_c(heff_dup(v_t_243), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get())));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s2023978511x2117594482_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s2023978511x2117594482(a0); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s425280038x249084439_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s425280038x249084439_entry, 3, 0};

V g_list_2ekeepIf_24s425280038x249084439(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_243, 1));
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    switch (heff_tag_of(v_t_247)) {
    case TAG_Unreached: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_Within: {
      V v_a_248 = heff_field(v_t_247, 0);
      V v_a_249 = heff_field(v_t_247, 1);
      heff_take_n(v_t_247, 3ULL, 2);
      switch (heff_tag_of(v_a_248)) {
      case TAG_Nothing: {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        heff_drop(v_a_249);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
      case TAG_Just: {
        V v_a_2410 = heff_field(v_a_248, 0);
        heff_take_n(v_a_248, 1ULL, 1);
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          heff_drop(v_x_243);
          heff_drop_cell(v_ru_24x2_242_24Cons, 2);
          heff_drop(v_a_2410);
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_xs_244;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_x2_242 = t_2;
          goto top;
        }
        case TAG_Just: {
          V v_a_2411 = heff_field(v_a_249, 0);
          heff_take_n(v_a_249, 1ULL, 1);
          if ((heff_intLe_c_lent(v_lit_240, v_a_2410, 0) && heff_intLe_c_lent(v_a_2411, v_lit_241, 0))) {
            heff_drop(v_a_2410);
            heff_drop(v_a_2411);
            V v_cell_2412 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_u_2413 = (g_list_2ekeepIf_24s425280038x249084439_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_2412)));
            heff_drop(v_u_2413);
            return v_cell_2412;
          } else {
            heff_drop(v_x_243);
            heff_drop_cell(v_ru_24x2_242_24Cons, 2);
            heff_drop(v_a_2410);
            heff_drop(v_a_2411);
            V t_0 = v_lit_240;
            V t_1 = v_lit_241;
            V t_2 = v_xs_244;
            v_lit_240 = t_0;
            v_lit_241 = t_1;
            v_x2_242 = t_2;
            goto top;
          }
        }
        default: return heff_nomatch(v_a_249);
        }
      }
      default: return heff_nomatch(v_a_248);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s425280038x249084439_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s425280038x249084439(a[0], a[1], a[2]);
}
Clo g_list_2eall_24s568190696x1372373514_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s568190696x1372373514_entry, 1, 0};

V g_list_2eall_24s568190696x1372373514(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_StmtBind: {
        return NTAG(TAG_False);
      }
      case TAG_StmtLet: {
        return NTAG(TAG_False);
      }
      case TAG_StmtExpr: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_StmtLetMut: {
        return NTAG(TAG_False);
      }
      case TAG_StmtLetElse: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_a_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s568190696x1372373514_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s568190696x1372373514(a0); heff_drop(a0); return r;
}
V g_list_2emap_24s97919758x216970748_24dps_lam0(V self, V *args);
Clo g_list_2emap_24s97919758x216970748_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s97919758x216970748_24dps_entry, 3, 0};

V g_list_2emap_24s97919758x216970748_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_245 = heff_dup(v_lit_240);
    V v_x2_246 = v_x_243;
    V v_t_2436;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_At: {
      V v_x21_247 = heff_field(v_x2_246, 0);
      V v_sp_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24At = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      switch (heff_tag_of(v_x21_247)) {
      case TAG_TagVariant: {
        V v_t_249 = heff_field(v_x21_247, 0);
        V v_tsp_2410 = heff_field(v_x21_247, 1);
        V v_args_2411 = heff_field(v_x21_247, 2);
        V v_ru_24x21_247_24TagVariant = heff_take_reuse_n(v_x21_247, 7ULL, 3);
        V v_t_2423 = (g_list_2emap(heff_clo_n(g_list_2emap_24s97919758x216970748_24dps_lam0, 1, 1, (V[]){v_r_245}), v_args_2411));
        v_t_2436 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_247_24TagVariant, TAG_TagVariant, 3, (V[]){v_t_249, v_tsp_2410, v_t_2423}), v_sp_248});
        break;
      }
      case TAG_BadVariant: {
        V v_e_2424 = heff_field(v_x21_247, 0);
        V v_ru_24x21_247_24BadVariant = heff_take_reuse_n(v_x21_247, 1ULL, 1);
        V v_x1_2425 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_e_2424}));
        V v_t_2435;
        switch (heff_tag_of(v_x1_2425)) {
        case TAG_IsInferable: {
          V v_i_2426 = heff_field(v_x1_2425, 0);
          V v_ru_24x1_2425_24IsInferable = heff_take_reuse_n(v_x1_2425, 1ULL, 1);
          V v_t_2429;
          switch (heff_tag_of(v_i_2426)) {
          case TAG_At: {
            V v_s_2428 = heff_dup(heff_field(v_i_2426, 1));
            v_t_2429 = v_s_2428;
            break;
          }
          default: heff_nomatch(v_i_2426);
          }
          v_t_2435 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2425_24IsInferable, TAG_TInf, 1, (V[]){v_i_2426}), v_t_2429});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2430 = heff_field(v_x1_2425, 0);
          V v_ru_24x1_2425_24IsCheckable = heff_take_reuse_n(v_x1_2425, 1ULL, 1);
          V v_t_2433;
          switch (heff_tag_of(v_c_2430)) {
          case TAG_At: {
            V v_s_2432 = heff_dup(heff_field(v_c_2430, 1));
            v_t_2433 = v_s_2432;
            break;
          }
          default: heff_nomatch(v_c_2430);
          }
          v_t_2435 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2425_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2430}), v_t_2433});
          break;
        }
        case TAG_IsType: {
          V v_t_2434 = heff_field(v_x1_2425, 0);
          heff_take_n(v_x1_2425, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_246_24At, 2);
          v_t_2435 = v_t_2434;
          break;
        }
        default: heff_nomatch(v_x1_2425);
        }
        v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_247_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2435}), v_sp_248});
        break;
      }
      default: heff_nomatch(v_x21_247);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_cell_2437 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2436, heff_hole()});
    V v_u_2438 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2437));
    heff_drop(v_u_2438);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_2437;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s97919758x216970748_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s97919758x216970748_24dps(a[0], a[1], a[2]);
}
V g_list_2emap_24s97919758x216970748_24dps_lam0(V self, V *args) {
  V v_e_2412 = args[0];
  V v_r_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2413 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_e_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_IsInferable: {
    V v_i_2414 = heff_field(v_x1_2413, 0);
    V v_ru_24x1_2413_24IsInferable = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_i_2414)) {
    case TAG_At: {
      V v_s_2416 = heff_dup(heff_field(v_i_2414, 1));
      v_t_2417 = v_s_2416;
      break;
    }
    default: heff_nomatch(v_i_2414);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2413_24IsInferable, TAG_TInf, 1, (V[]){v_i_2414}), v_t_2417});
  }
  case TAG_IsCheckable: {
    V v_c_2418 = heff_field(v_x1_2413, 0);
    V v_ru_24x1_2413_24IsCheckable = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
    V v_t_2421;
    switch (heff_tag_of(v_c_2418)) {
    case TAG_At: {
      V v_s_2420 = heff_dup(heff_field(v_c_2418, 1));
      v_t_2421 = v_s_2420;
      break;
    }
    default: heff_nomatch(v_c_2418);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2413_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2418}), v_t_2421});
  }
  case TAG_IsType: {
    V v_t_2422 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 1);
    return v_t_2422;
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
Clo g_list_2emap_24s2039279853x710813703_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2039279853x710813703_entry, 2, 0};

V g_list_2emap_24s2039279853x710813703(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_244 = heff_dup(v_lit_240);
    V v_x2_245 = v_x_242;
    V v_t_2434;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_sp_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24At = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_SetField: {
        V v_x_248 = heff_field(v_x21_246, 0);
        V v_xsp_249 = heff_field(v_x21_246, 1);
        V v_e_2410 = heff_field(v_x21_246, 2);
        V v_ru_24x21_246_24SetField = heff_take_reuse_n(v_x21_246, 7ULL, 3);
        V v_x1_2411 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_e_2410}));
        V v_t_2421;
        switch (heff_tag_of(v_x1_2411)) {
        case TAG_IsInferable: {
          V v_i_2412 = heff_field(v_x1_2411, 0);
          V v_ru_24x1_2411_24IsInferable = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
          V v_t_2415;
          switch (heff_tag_of(v_i_2412)) {
          case TAG_At: {
            V v_s_2414 = heff_dup(heff_field(v_i_2412, 1));
            v_t_2415 = v_s_2414;
            break;
          }
          default: heff_nomatch(v_i_2412);
          }
          v_t_2421 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2411_24IsInferable, TAG_CInf, 1, (V[]){v_i_2412}), v_t_2415});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2416 = heff_field(v_x1_2411, 0);
          heff_take_n(v_x1_2411, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_245_24At, 2);
          v_t_2421 = v_c_2416;
          break;
        }
        case TAG_IsType: {
          V v_t_2417 = heff_field(v_x1_2411, 0);
          V v_ru_24x1_2411_24IsType = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
          V v_t_2420;
          switch (heff_tag_of(v_t_2417)) {
          case TAG_At: {
            V v_s_2419 = heff_dup(heff_field(v_t_2417, 1));
            v_t_2420 = v_s_2419;
            break;
          }
          default: heff_nomatch(v_t_2417);
          }
          v_t_2421 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2411_24IsType, TAG_CType, 1, (V[]){v_t_2417}), v_t_2420});
          break;
        }
        default: heff_nomatch(v_x1_2411);
        }
        v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_246_24SetField, TAG_SetField, 3, (V[]){v_x_248, v_xsp_249, v_t_2421}), v_sp_247});
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2422 = heff_field(v_x21_246, 0);
        V v_ru_24x21_246_24BadFieldSet = heff_take_reuse_n(v_x21_246, 1ULL, 1);
        V v_x1_2423 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_e_2422}));
        V v_t_2433;
        switch (heff_tag_of(v_x1_2423)) {
        case TAG_IsInferable: {
          V v_i_2424 = heff_field(v_x1_2423, 0);
          V v_ru_24x1_2423_24IsInferable = heff_take_reuse_n(v_x1_2423, 1ULL, 1);
          V v_t_2427;
          switch (heff_tag_of(v_i_2424)) {
          case TAG_At: {
            V v_s_2426 = heff_dup(heff_field(v_i_2424, 1));
            v_t_2427 = v_s_2426;
            break;
          }
          default: heff_nomatch(v_i_2424);
          }
          v_t_2433 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2423_24IsInferable, TAG_CInf, 1, (V[]){v_i_2424}), v_t_2427});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2428 = heff_field(v_x1_2423, 0);
          heff_take_n(v_x1_2423, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_245_24At, 2);
          v_t_2433 = v_c_2428;
          break;
        }
        case TAG_IsType: {
          V v_t_2429 = heff_field(v_x1_2423, 0);
          V v_ru_24x1_2423_24IsType = heff_take_reuse_n(v_x1_2423, 1ULL, 1);
          V v_t_2432;
          switch (heff_tag_of(v_t_2429)) {
          case TAG_At: {
            V v_s_2431 = heff_dup(heff_field(v_t_2429, 1));
            v_t_2432 = v_s_2431;
            break;
          }
          default: heff_nomatch(v_t_2429);
          }
          v_t_2433 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2423_24IsType, TAG_CType, 1, (V[]){v_t_2429}), v_t_2432});
          break;
        }
        default: heff_nomatch(v_x1_2423);
        }
        v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_246_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2433}), v_sp_247});
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_cell_2435 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2434, heff_hole()});
    V v_u_2436 = (g_list_2emap_24s2039279853x710813703_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2435)));
    heff_drop(v_u_2436);
    return v_cell_2435;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2039279853x710813703(a[0], a[1]);
}
Clo g_list_2eall_24s1512314936x520990916_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1512314936x520990916_entry, 1, 0};

V g_list_2eall_24s1512314936x520990916(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2espec_2ecallsNothing(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1512314936x520990916_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1512314936x520990916(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1061937638x829298692_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1061937638x829298692_entry, 2, 0};

V g_list_2efoldl_24s1061937638x829298692(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_key_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_body_245 = heff_dup(heff_rfield(v_x_242, 2));
    V v_t_246 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_key_244, v_body_245));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1061937638x829298692_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1061937638x829298692(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s583291244x257539062_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s583291244x257539062_24dps_entry, 3, 0};

V g_list_2ezipWith_24s583291244x257539062_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_SSet, 2, (V[]){v_x_243, heff_tag_n(TAG_OSimple, 1, (V[]){v_y_245})});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s583291244x257539062_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s583291244x257539062_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1530401830x609500251_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1530401830x609500251_entry, 2, 0};

V g_list_2efoldl_24s1530401830x609500251(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1530401830x609500251(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s1530546918x299821644_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1530546918x299821644_entry, 2, 0};

V g_list_2ezipWith_24s1530546918x299821644(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_246 = (g_heff_2ecompile_2ecpr_2efldAt(v_x_242, v_y_244));
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s1530546918x299821644_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1530546918x299821644_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1530546918x299821644(a[0], a[1]);
}
HEFF_LIT(g_list_2efoldl_24s441088199x272212076_str0, 2, "$s");
HEFF_LIT(g_list_2efoldl_24s441088199x272212076_str1, 2, "$s");
HEFF_LIT(g_list_2efoldl_24s441088199x272212076_str2, 2, "$s");
Clo g_list_2efoldl_24s441088199x272212076_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s441088199x272212076_entry, 2, 0};

V g_list_2efoldl_24s441088199x272212076(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_m_244 = v_z_240;
    V v_d_245 = v_x_242;
    V v_g_246 = heff_dup(heff_rfield(v_d_245, 0));
    V v_j_247 = heff_strFind_lent(((V)&g_list_2efoldl_24s441088199x272212076_str0), v_g_246, MK_INT(0LL), 5);
    V v_t_248;
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      v_t_248 = v_g_246;
    } else {
      v_t_248 = heff_strSlice(v_g_246, MK_INT(0LL), v_j_247);
    }
    V v_t_2421;
    if (heff_strEq_c(v_t_248, heff_dup(heff_rfield(v_d_245, 0)))) {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop_rec(v_d_245, 3);
      v_t_2421 = v_m_244;
    } else {
      V v_g_249 = heff_dup(heff_rfield(v_d_245, 0));
      V v_j_2410 = heff_strFind_lent(((V)&g_list_2efoldl_24s441088199x272212076_str1), v_g_249, MK_INT(0LL), 5);
      V v_t_2411;
      if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
        heff_drop(v_j_2410);
        v_t_2411 = v_g_249;
      } else {
        v_t_2411 = heff_strSlice(v_g_249, MK_INT(0LL), v_j_2410);
      }
      V v_g_2412 = heff_dup(heff_rfield(v_d_245, 0));
      V v_j_2413 = heff_strFind_lent(((V)&g_list_2efoldl_24s441088199x272212076_str2), v_g_2412, MK_INT(0LL), 5);
      V v_t_2414;
      if (heff_intLt_c_lent(v_j_2413, MK_INT(0LL), 2)) {
        heff_drop(v_j_2413);
        v_t_2414 = v_g_2412;
      } else {
        v_t_2414 = heff_strSlice(v_g_2412, MK_INT(0LL), v_j_2413);
      }
      HeffT2 v_t_2415 = ({ V a_0 = v_m_244; V a_1 = v_t_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2414); r_; });
      V v_t_2419;
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_x_2418 = v_field_2417;
          v_t_2419 = v_x_2418;
        } else {
          heff_drop(v_field_2417);
          v_t_2419 = NTAG(TAG_Nil);
        }
      }
      V v_t_2420 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_d_245, 0, 3), v_t_2419});
      v_t_2421 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_244, v_t_2411, v_t_2420));
    }
    V t_0 = v_t_2421;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s441088199x272212076_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s441088199x272212076(a[0], a[1]);
}
V g_list_2ekeepIf_24s614579978x208602650_lam0(V self, V *args);
V g_list_2ekeepIf_24s614579978x208602650_lam1(V self, V *args);
V g_list_2ekeepIf_24s614579978x208602650_lam2(V self, V *args);
Clo g_list_2ekeepIf_24s614579978x208602650_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s614579978x208602650_entry, 2, 0};

V g_list_2ekeepIf_24s614579978x208602650(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_bodies_244 = heff_dup(v_lit_240);
    V v_ks_245 = heff_dup(v_x_242);
    V v_t_2414 = (g_list_2eany(heff_clo_n(g_list_2ekeepIf_24s614579978x208602650_lam0, 1, 1, (V[]){heff_dup(v_bodies_244)}), v_ks_245));
    if (((heff_dup(v_t_2414) == NTAG(TAG_True)) && ({ V v_t_2415 = (g_list_2efoldl_24s278088687x1269971185(heff_dup(g_std_2eordmap_2eempty_get()), v_ks_245)); int c_ = ({ V v_t_2421 = (g_list_2emap(heff_clo_n(g_list_2ekeepIf_24s614579978x208602650_lam1, 1, 1, (V[]){heff_dup(v_bodies_244)}), heff_dup(v_ks_245))); int c_ = ({ V v_c_2433 = heff_tr(g_heff_2ecompile_2edefun_2ehandsW(heff_dup(v_t_2415), heff_dup(v_t_2421))); int c_ = ((heff_dup(v_c_2433) == NTAG(TAG_True)) && ({ V v_t_2434 = (g_list_2efoldl(heff_clo_n(g_list_2ekeepIf_24s614579978x208602650_lam2, 2, 1, (V[]){heff_dup(v_bodies_244)}), MK_INT(0LL), v_ks_245)); int c_ = heff_intLe_c_lent(v_t_2434, MK_INT(20000LL), 2); heff_drop(v_t_2434); c_; })); heff_drop(v_c_2433); c_; }); heff_drop(v_t_2421); c_; }); heff_drop(v_t_2415); c_; }))) {
      heff_drop(v_bodies_244);
      heff_drop(v_ks_245);
      heff_drop(v_t_2414);
      V v_cell_2431 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2432 = (g_list_2ekeepIf_24s614579978x208602650_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2431)));
      heff_drop(v_u_2432);
      return v_cell_2431;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_bodies_244);
      heff_drop(v_ks_245);
      heff_drop(v_t_2414);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s614579978x208602650_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s614579978x208602650(a[0], a[1]);
}
V g_list_2ekeepIf_24s614579978x208602650_lam0(V self, V *args) {
  V v_k_246 = args[0];
  V v_bodies_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_247 = ({ V a_0 = v_bodies_244; V a_1 = v_k_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_244); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    V v_t_2411;
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_249;
      v_t_2411 = v_x_2410;
    } else {
      heff_drop(v_field_249);
      v_t_2411 = NTAG(TAG_EAbandon);
    }
    V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(v_t_2411));
    V v_xs_2413 = (g_heff_2ecompile_2eir_2enubI(v_t_2412));
    return ({ V a_0 = v_k_246; V a_1 = v_xs_2413; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_k_246); heff_drop(v_xs_2413); r_; });
  }
}
V g_list_2ekeepIf_24s614579978x208602650_lam1(V self, V *args) {
  V v_k_2416 = args[0];
  V v_bodies_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2417 = ({ V a_0 = v_bodies_244; V a_1 = v_k_2416; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_244); heff_drop(v_k_2416); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2419;
      return v_x_2420;
    } else {
      heff_drop(v_field_2419);
      return NTAG(TAG_EAbandon);
    }
  }
}
V g_list_2ekeepIf_24s614579978x208602650_lam2(V self, V *args) {
  V v_n_2422 = args[0];
  V v_k_2423 = args[1];
  V v_bodies_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2424 = ({ V a_0 = v_bodies_244; V a_1 = v_k_2423; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_244); heff_drop(v_k_2423); r_; });
  V v_t_2430;
  {
    V v_field_2426 = v_t_2424.f[1];
    int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
    V v_t_2428;
    if ((v_tag_2425 == ((int64_t)0ULL))) {
      V v_x_2427 = v_field_2426;
      v_t_2428 = v_x_2427;
    } else {
      heff_drop(v_field_2426);
      v_t_2428 = NTAG(TAG_EAbandon);
    }
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
    v_t_2430 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2429));
  }
  return heff_intAdd(v_n_2422, v_t_2430);
}
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_str0, 1, "\"");
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_str1, 1, "\"");
Clo g_list_2emap_24s1397747289x2145601499_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1397747289x2145601499_entry, 1, 0};

V g_list_2emap_24s1397747289x2145601499(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V a_1 = MK_INT(0LL); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1397747289x2145601499_str0), v_t_243), ((V)&g_list_2emap_24s1397747289x2145601499_str1));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1397747289x2145601499_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1397747289x2145601499(a[0]);
}
Clo g_list_2emap_24s570884835x2121220820_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570884835x2121220820_entry, 1, 0};

V g_list_2emap_24s570884835x2121220820(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), v_x_241});
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s570884835x2121220820_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570884835x2121220820_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570884835x2121220820(a[0]);
}
Clo g_list_2ekeepIf_24s924780574x2000457388_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s924780574x2000457388_entry, 2, 0};

V g_list_2ekeepIf_24s924780574x2000457388(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_UpdateTo: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_2412 = v_a_244;
      break;
    }
    case TAG_UpdateIn: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 0));
      v_t_2412 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_2412, v_lit_240, 1)) {
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2414 = (g_list_2ekeepIf_24s924780574x2000457388_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2413)));
      heff_drop(v_u_2414);
      return v_cell_2413;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s924780574x2000457388_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s924780574x2000457388(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2ezipWith_24s634961829x758866838_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s634961829x758866838_24dps_entry, 3, 0};

V g_list_2ezipWith_24s634961829x758866838_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_x_243, 0);
        heff_take_n(v_x_243, 1ULL, 2);
        v_t_249 = v_a_247;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_249, heff_get_n(v_y_245, 1, 2)});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_2411;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s634961829x758866838_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s634961829x758866838_24dps(a[0], a[1], a[2]);
}

HeffT2 g_list_2elookup_24s1507486579x90027037_24cpr(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_27_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c_lent(v_k_240, v_k_27_244, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_245)}});
      } else {
        V t_0 = v_k_240;
        V t_1 = v_rest_243;
        v_k_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_list_2efoldl_24s398854970x1533504811_str0, 1, "$");
HEFF_LIT(g_list_2efoldl_24s398854970x1533504811_str1, 2, "$c");
HEFF_LIT(g_list_2efoldl_24s398854970x1533504811_str2, 1, "$");
HEFF_LIT(g_list_2efoldl_24s398854970x1533504811_str3, 1, "(");
HEFF_LIT(g_list_2efoldl_24s398854970x1533504811_str4, 1, "$");
HEFF_LIT(g_list_2efoldl_24s398854970x1533504811_str5, 1, "(");
Clo g_list_2efoldl_24s398854970x1533504811_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s398854970x1533504811_entry, 2, 0};

V g_list_2efoldl_24s398854970x1533504811(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_m_244 = v_z_240;
    V v_part_245 = heff_dup(v_x_242);
    V v_t_2447;
    switch (heff_tag_of(v_part_245)) {
    case TAG_PartVal: {
      V v_part1_246 = heff_field(v_part_245, 0);
      heff_take_n(v_part_245, 1ULL, 1);
      switch (heff_tag_of(v_part1_246)) {
      case TAG_SVar: {
        heff_take_n(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_part1_246, 0ULL, 2);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_part1_246, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SPrimFn: {
        V v_p_2416 = heff_field(v_part1_246, 0);
        heff_take_n(v_part1_246, 1ULL, 1);
        V v_t_2417 = ({ V a_0 = v_p_2416; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2416); r_; });
        V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_list_2efoldl_24s398854970x1533504811_str0), v_t_2417), ((V)&g_list_2efoldl_24s398854970x1533504811_str1));
        v_t_2447 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_244, v_t_2418, NTAG(TAG_MkUnit)));
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_part1_246, 0ULL, 2);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_STag: {
        heff_take_n(v_part1_246, 0ULL, 3);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_part1_246, 0ULL, 2);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_part1_246, 0ULL, 4);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_SPrim: {
        V v_p_2430 = heff_field(v_part1_246, 0);
        V v_args_2431 = heff_field(v_part1_246, 1);
        heff_take_n(v_part1_246, 3ULL, 2);
        V v_t_2432 = ({ V a_0 = v_p_2430; V a_1 = v_args_2431; V r_ = (g_heff_2ecompile_2eemit_2ecallsHelper(a_0, a_1)); heff_drop(v_args_2431); r_; });
        if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
          heff_drop(v_t_2432);
          V v_t_2433 = ({ V a_0 = v_p_2430; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2430); r_; });
          V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_list_2efoldl_24s398854970x1533504811_str2), v_t_2433), ((V)&g_list_2efoldl_24s398854970x1533504811_str3));
          v_t_2447 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_244, v_t_2434, NTAG(TAG_MkUnit)));
        } else {
          heff_drop(v_p_2430);
          heff_drop(v_t_2432);
          v_t_2447 = v_m_244;
        }
        break;
      }
      default: heff_nomatch(v_part1_246);
      }
      break;
    }
    case TAG_PartOp: {
      V v_part1_2435 = heff_field(v_part_245, 0);
      heff_take_n(v_part_245, 1ULL, 1);
      switch (heff_tag_of(v_part1_2435)) {
      case TAG_OSimple: {
        heff_take_n(v_part1_2435, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_OCall: {
        heff_take_n(v_part1_2435, 0ULL, 2);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_OApply: {
        heff_take_n(v_part1_2435, 0ULL, 2);
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_OPrim: {
        V v_p_2441 = heff_field(v_part1_2435, 0);
        V v_args_2442 = heff_field(v_part1_2435, 1);
        heff_take_n(v_part1_2435, 3ULL, 2);
        V v_t_2443 = ({ V a_0 = v_p_2441; V a_1 = v_args_2442; V r_ = (g_heff_2ecompile_2eemit_2ecallsHelper(a_0, a_1)); heff_drop(v_args_2442); r_; });
        if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
          heff_drop(v_t_2443);
          V v_t_2444 = ({ V a_0 = v_p_2441; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2441); r_; });
          V v_t_2445 = heff_strAppend(heff_strAppend(((V)&g_list_2efoldl_24s398854970x1533504811_str4), v_t_2444), ((V)&g_list_2efoldl_24s398854970x1533504811_str5));
          v_t_2447 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_244, v_t_2445, NTAG(TAG_MkUnit)));
        } else {
          heff_drop(v_p_2441);
          heff_drop(v_t_2443);
          v_t_2447 = v_m_244;
        }
        break;
      }
      case TAG_OAbandon: {
        v_t_2447 = v_m_244;
        break;
      }
      case TAG_OBool: {
        heff_take_n(v_part1_2435, 0ULL, 1);
        v_t_2447 = v_m_244;
        break;
      }
      default: heff_nomatch(v_part1_2435);
      }
      break;
    }
    default: heff_nomatch(v_part_245);
    }
    V t_0 = v_t_2447;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s398854970x1533504811(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1613211967x1923010103_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1613211967x1923010103_entry, 4, 0};

V g_list_2emap_24s1613211967x1923010103(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(heff_dup(v_x_244)));
    V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, heff_dup(v_lit_241)), heff_intShow(v_x_244));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_247, heff_dup(v_lit_242)), heff_hole()});
    V v_u_249 = (g_list_2emap_24s1613211967x1923010103_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1613211967x1923010103_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1613211967x1923010103(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s1041788812x158895160_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1041788812x158895160_entry, 1, 0};

V g_list_2eany_24s1041788812x158895160(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkCArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      v_t_2411 = heff_bool(heff_strEq_c(heff_dup(v_t_243), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get())));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2411);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1041788812x158895160_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1041788812x158895160(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1071292119x112543158_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1071292119x112543158_entry, 10, 0};

V g_list_2efoldl_24s1071292119x112543158(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_z_248, V v_x3_249) {
top: ;
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return v_z_248;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x3_249, 0);
    V v_xs_2411 = heff_field(v_x3_249, 1);
    V v_ru_24x3_249_24Cons = heff_take_reuse_n(v_x3_249, 3ULL, 2);
    V v_a_2414;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2412 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2414 = heff_get_n(v_a_2412, 0, 3);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2415 = (g_heff_2ecompile_2eemitc_2elastDotGo(v_a_2414, heff_dup(v_lit_240), heff_dup(v_lit_241)));
    V v_t_2416;
    if (heff_intLt_c_lent(v_a_2415, v_lit_242, 0)) {
      heff_drop(v_a_2415);
      v_t_2416 = v_a_2414;
    } else {
      v_t_2416 = heff_strSlice_lent(v_a_2414, v_lit_243, v_a_2415, 5);
    }
    V v_a_2419;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2417 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2419 = heff_get_n(v_a_2417, 0, 3);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2420 = (g_heff_2ecompile_2eemitc_2elastDotGo(v_a_2419, heff_dup(v_lit_244), heff_dup(v_lit_245)));
    V v_t_2421;
    if (heff_intLt_c_lent(v_a_2420, v_lit_246, 0)) {
      heff_drop(v_a_2420);
      v_t_2421 = v_a_2419;
    } else {
      v_t_2421 = heff_strSlice_lent(v_a_2419, v_lit_247, v_a_2420, 5);
    }
    HeffT2 v_t_2422 = ({ V a_0 = v_z_248; V a_1 = v_t_2421; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2421); r_; });
    V v_t_2426;
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        V v_a_2425 = v_field_2424;
        v_t_2426 = v_a_2425;
      } else {
        heff_drop(v_field_2424);
        v_t_2426 = NTAG(TAG_Nil);
      }
    }
    V v_t_2427 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_248, v_t_2416, heff_tag_at_n(v_ru_24x3_249_24Cons, TAG_Cons, 2, (V[]){v_x_2410, v_t_2426})));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_t_2427;
    V t_9 = v_xs_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_z_248 = t_8;
    v_x3_249 = t_9;
    goto top;
  }
  default: return heff_nomatch(v_x3_249);
  }
}
V g_list_2efoldl_24s1071292119x112543158_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a7 = a[7]; V r = g_list_2efoldl_24s1071292119x112543158(a[0], a[1], a[2], a3, a[4], a[5], a[6], a7, a[8], a[9]); heff_drop(a3); heff_drop(a7); return r;
}
Clo g_list_2efoldl_24s1894035205x969464323_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1894035205x969464323_entry, 3, 0};

V g_list_2efoldl_24s1894035205x969464323(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_intAdd(v_z_241, heff_strLength_lent(v_x_243, 0));
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_t_245, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1894035205x969464323(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s2015972532x1874881274_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2015972532x1874881274_entry, 2, 0};

V g_list_2ekeepIf_24s2015972532x1874881274(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_intEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s2015972532x1874881274_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2015972532x1874881274_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s2015972532x1874881274(a[0], a[1]);
}
Clo g_list_2emap_24s388004800x1261967008_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s388004800x1261967008_entry, 1, 0};

V g_list_2emap_24s388004800x1261967008(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s388004800x1261967008_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s388004800x1261967008(a[0]);
}
Clo g_list_2ekeepIf_24s647917584x875728492_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s647917584x875728492_entry, 2, 0};

V g_list_2ekeepIf_24s647917584x875728492(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_lit_240, 1)))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s647917584x875728492_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 14);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s647917584x875728492_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s647917584x875728492(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s647917584x875728492_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s647917584x875728492_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s647917584x875728492_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(heff_rfield(v_lit_240, 1)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 14);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s647917584x875728492_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s647917584x875728492_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s491084544x100802329_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s491084544x100802329_entry, 2, 0};

V g_list_2efoldl_24s491084544x100802329(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_a_248)));
        v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_249); r_; });
        break;
      }
      case TAG_BadVariant: {
        V v_a_2410 = heff_field(v_a_244, 0);
        v_t_2411 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2410));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s491084544x100802329(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2epushRun_24s495990157x1087861527_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_24s495990157x1087861527_entry, 3, 0};

V g_list_2epushRun_24s495990157x1087861527(V v_k_240, V v_run_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_j_245 = heff_field(v_x41_243, 0);
      V v_below_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24MkPair = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_245, v_k_240, 0)) {
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_j_245);
        heff_drop_cell(v_ru_24x41_243_24MkPair, 2);
        V v_t_2411;
        switch (heff_tag_of(v_below_246)) {
        case TAG_Nil: {
          v_t_2411 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(NTAG(TAG_True), v_below_246, v_run_241));
          break;
        }
        case TAG_Cons: {
          V v_a_247 = heff_dup(heff_field(v_below_246, 0));
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nil: {
            heff_drop_rec(v_a_247, 7);
            v_t_2411 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(NTAG(TAG_True), v_below_246, v_run_241));
            break;
          }
          case TAG_Cons: {
            V v_b_249 = heff_dup(heff_field(v_run_241, 0));
            if (heff_intLe_c(heff_get_n(v_a_247, 2, 7), heff_get_n(v_b_249, 2, 7))) {
              v_t_2411 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(NTAG(TAG_True), v_below_246, v_run_241));
            } else {
              v_t_2411 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(NTAG(TAG_False), v_run_241, v_below_246));
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          break;
        }
        default: heff_nomatch(v_below_246);
        }
        V t_0 = heff_intAdd(v_k_240, MK_INT(1LL));
        V t_1 = v_t_2411;
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_run_241 = t_1;
        v_x4_242 = t_2;
        goto top;
      } else {
        V v_t_2412 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24MkPair, TAG_MkPair, 2, (V[]){v_j_245, v_below_246}), v_rest_244});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), v_t_2412});
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2epushRun_24s495990157x1087861527_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun_24s495990157x1087861527(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s571074576x1179600767_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s571074576x1179600767_24scalars_entry, 6, 0};

V g_list_2efoldl_24s571074576x1179600767_24scalars(V v_sources_240, V v_errors_241, V v_paths_242, V v_package_243, V v_packages_244, V v_x3_245) {
top: ;
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nil: {
    return heff_rec_n(5, shape_sources__errors__paths__package__packages, (V[]){v_sources_240, v_errors_241, v_paths_242, v_package_243, v_packages_244});
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x3_245, 0);
    V v_xs_247 = heff_field(v_x3_245, 1);
    V v_ru_24x3_245_24Cons = heff_take_reuse_n(v_x3_245, 3ULL, 2);
    V t_0 = v_sources_240;
    V t_1 = heff_tag_at_n(v_ru_24x3_245_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_errors_241});
    V t_2 = v_paths_242;
    V t_3 = v_package_243;
    V t_4 = v_packages_244;
    V t_5 = v_xs_247;
    v_sources_240 = t_0;
    v_errors_241 = t_1;
    v_paths_242 = t_2;
    v_package_243 = t_3;
    v_packages_244 = t_4;
    v_x3_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_list_2efoldl_24s571074576x1179600767_24scalars_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s571074576x1179600767_24scalars(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emergeRuns_24s1848188369x464661008_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s1848188369x464661008_entry, 2, 0};

V g_list_2emergeRuns_24s1848188369x464661008(V v_stack_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_run_242 = heff_field(v_x3_241, 0);
    V v_x32_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x32_243)) {
    case TAG_Nil: {
      return ({ V a_0 = v_run_242; V a_1 = v_stack_240; V r_ = (g_list_2ecollapse_24s705464212x1327502534(a_0, a_1)); heff_drop(v_stack_240); r_; });
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x32_243, 0);
      V v_xs_245 = heff_field(v_x32_243, 1);
      heff_take_n(v_x32_243, 3ULL, 2);
      V v_t_246 = (g_list_2epushRun_24s2022155310x1483676144(MK_INT(0LL), v_run_242, v_stack_240));
      V v_t_247 = (g_list_2erunFrom_24s272018256x1228369023(v_x_244, v_xs_245));
      V t_0 = v_t_246;
      V t_1 = v_t_247;
      v_stack_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x32_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2emergeRuns_24s1848188369x464661008_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeRuns_24s1848188369x464661008(a[0], a[1]);
}
Clo g_list_2efoldl_24s141260856x1366916752_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s141260856x1366916752_entry, 5, 0};

V g_list_2efoldl_24s141260856x1366916752(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_244, 0);
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_Nil: {
      v_t_2412 = heff_dup(v_lit_240);
      break;
    }
    case TAG_Cons: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_t_249 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_a_247));
      V v_a_2410 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_249));
      V v_t_2411 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(heff_dup(v_lit_242), v_a_2410, v_a_248));
      v_t_2412 = heff_strAppend(heff_dup(v_lit_241), v_t_2411);
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2413 = heff_strLength(v_t_2412);
    V v_t_2414;
    if ((heff_peek_word(v_z_243) <= heff_peek_word(v_a_2413))) {
      heff_drop(v_z_243);
      v_t_2414 = v_a_2413;
    } else {
      heff_drop(v_a_2413);
      v_t_2414 = v_z_243;
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_2414;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s141260856x1366916752_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2efoldl_24s141260856x1366916752(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
HEFF_LIT(g_list_2eall_24s1579400704x1789597964_str0, 2, "..");
HEFF_LIT(g_list_2eall_24s1579400704x1789597964_str1, 0, "");
HEFF_LIT(g_list_2eall_24s1579400704x1789597964_str2, 1, ".");
Clo g_list_2eall_24s1579400704x1789597964_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1579400704x1789597964_entry, 1, 0};

V g_list_2eall_24s1579400704x1789597964(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if ((heff_strEq_c_lent(v_x_241, ((V)&g_list_2eall_24s1579400704x1789597964_str0), 2) ? 0 : (heff_strEq_c_lent(v_x_241, ((V)&g_list_2eall_24s1579400704x1789597964_str1), 2) ? 0 : !heff_strEq_c_lent(v_x_241, ((V)&g_list_2eall_24s1579400704x1789597964_str2), 2)))) {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1579400704x1789597964_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1579400704x1789597964(a0); heff_drop(a0); return r;
}
Clo g_list_2edescending_24s379747839x1236130333_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_24s379747839x1236130333_entry, 5, 0};

V g_list_2edescending_24s379747839x1236130333(V v_lit_240, V v_lit_241, V v_x_242, V v_acc_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop_rec(v_x_242, 14);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x4_244, 0);
    V v_ys_246 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    V v_a_247 = heff_strCompare(heff_get_n(v_x_242, 0, 14), heff_dup(heff_rfield(v_y_245, 0)));
    if ((heff_intLt_c_lent(v_a_247, v_lit_240, 0) || heff_intEq_c_lent(v_a_247, v_lit_241, 0))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_a_247);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_ys_246})});
    } else {
      heff_drop(v_a_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = heff_dup(v_y_245);
      V t_3 = heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_acc_243});
      V t_4 = v_ys_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x_242 = t_2;
      v_acc_243 = t_3;
      v_x4_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2edescending_24s379747839x1236130333_entry(V self, V *a) {
  (void)self;
  return g_list_2edescending_24s379747839x1236130333(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24s6718001x1068992521_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s6718001x1068992521_entry, 3, 0};

V g_list_2efoldl_24s6718001x1068992521(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_strRunes(heff_dup(heff_rfield(v_x_243, 0)));
    V v_a_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_t_247;
    if (heff_intLe_c_lent(v_z_241, v_a_246, 0)) {
      heff_drop(v_z_241);
      v_t_247 = v_a_246;
    } else {
      heff_drop(v_a_246);
      v_t_247 = v_z_241;
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_247;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s6718001x1068992521_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s6718001x1068992521(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f189927396x2059034600_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f189927396x2059034600_24dps_entry, 2, 0};

V g_list_2emap_24f189927396x2059034600_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_loosest_244 = heff_take_field(v_x_242, 3);
    V v_id_245 = heff_get_n(v_x_242, 0, 5);
    if ((heff_dup(v_loosest_244) == NTAG(TAG_True))) {
      heff_drop(v_loosest_244);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_id_245, heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_xs_243;
      V t_1 = v_cell_246;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_loosest_244);
      heff_drop(v_id_245);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f189927396x2059034600_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f189927396x2059034600_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f1677329353x1774765664_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1677329353x1774765664_24dps_entry, 3, 0};

V g_list_2emap_24f1677329353x1774765664_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      v_x_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, heff_dup(v_lit_240)}), heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_248;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1677329353x1774765664_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1677329353x1774765664_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f565269645x1954016017_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f565269645x1954016017_24dps_entry, 2, 0};

V g_list_2emap_24f565269645x1954016017_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_binder_244 = heff_take_field(v_x_242, 0);
    V v_use_245 = heff_get_n(v_x_242, 1, 2);
    V v_t_246 = heff_take_field(v_binder_244, 2);
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_rec_n(3, shape_name__field__use, (V[]){heff_take_field(v_binder_244, 0), heff_get_n(v_binder_244, 1, 3), v_use_245});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_243;
      V t_1 = v_cell_248;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop_rec(v_binder_244, 3);
      heff_drop(v_use_245);
      heff_drop(v_t_246);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f565269645x1954016017_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f565269645x1954016017_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24f297647854x479783049_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f297647854x479783049_entry, 2, 0};

V g_list_2efoldl_24f297647854x479783049(V v_z_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_241, 0);
    V v_cs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s647917584x875728492(heff_dup(v_c_242), v_cs_243));
    V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_z_240});
    V t_1 = v_t_244;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f297647854x479783049(a[0], a[1]);
}
Clo g_list_2emap_24f530523215x314966509_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f530523215x314966509_24dps_entry, 8, 0};

V g_list_2emap_24f530523215x314966509_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop_rec(v_lit_241, 2);
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_target_2410 = heff_take_field(v_x_248, 0);
    V v_name_2411 = heff_take_field(v_x_248, 1);
    V v_span_2412 = heff_get_n(v_x_248, 2, 3);
    V v_t_2413 = heff_get_n(v_target_2410, 1, 3);
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      heff_drop(v_name_2411);
      heff_drop(v_span_2412);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_d_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_2413, 0ULL, 1);
      V v_t_2415 = heff_intAdd(heff_dup(heff_rfield(v_lit_241, 0)), heff_dup(v_lit_242));
      V v_t_2416 = heff_strSlice(heff_dup(heff_rfield(v_lit_240, 3)), heff_dup(heff_rfield(v_lit_241, 0)), v_t_2415);
      V v_t_2417;
      if (heff_strEq_c_lent(v_t_2416, v_lit_243, 1)) {
        v_t_2417 = heff_dup(v_lit_244);
      } else {
        v_t_2417 = heff_dup(v_lit_245);
      }
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__kind__span, (V[]){v_name_2411, v_t_2417, v_span_2412}), heff_hole()});
      V v_u_2419 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2418));
      heff_drop(v_u_2419);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_cell_2418;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24f530523215x314966509_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2emap_24f530523215x314966509_24dps(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7]); heff_drop(a3); return r;
}
Clo g_list_2emap_24f1677329353x1774765664_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1677329353x1774765664_24tok2_entry, 3, 0};

V g_list_2emap_24f1677329353x1774765664_24tok2(V v_tok_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      v_x_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_248 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_MkPair, 2, (V[]){v_x_247, heff_dup(v_lit_241)}), heff_hole()});
    V v_u_249 = (g_list_2emap_24f1677329353x1774765664_24dps(v_lit_241, v_xs_244, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1677329353x1774765664_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1677329353x1774765664_24tok2(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s215892288x1392224072_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s215892288x1392224072_24tok2_entry, 3, 0};

V g_list_2emap_24s215892288x1392224072_24tok2(V v_tok_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_lit_241), v_x_243}), heff_hole()});
    V v_u_246 = (g_list_2emap_24s215892288x1392224072_24dps(v_lit_241, v_xs_244, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s215892288x1392224072_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s215892288x1392224072_24tok2(a[0], a[1], a[2]);
}