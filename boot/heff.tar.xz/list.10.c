// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkSegment 38079
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define LBL_binder 558177493
#define LBL_copies 592412158
#define LBL_done 9584713
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_expectFrom 460383968
#define LBL_expectTo 956903013
#define LBL_holds 300818350
#define LBL_key 315609
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_ops 319788
#define LBL_owner 307523277
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_task 10048076
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_total 311908190
#define LBL_units 312791945
#define LBL_value 313331083
#define LBL_ver 326173
#define LBL_version 583465758
#define LBL_watch 314261737
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
V g_heff_2ebuild_2edriver_2epromoteAt(V, V, V, V);
V g_heff_2ebuild_2edriver_2epromoteAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epromoteAt_clo;
V g_heff_2ebuild_2eproject_2esumBefore(V, V);
V g_heff_2ebuild_2eproject_2esumBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumBefore_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2eprimUses(V, V);
V g_heff_2ecompile_2eemit_2eprimUses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimUses_clo;
V g_heff_2ecompile_2eemitc_2easLent(V, V);
V g_heff_2ecompile_2eemitc_2easLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2easLent_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efacts_2etailApp(V);
V g_heff_2ecompile_2efacts_2etailApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2etailApp_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2elocals_2epatternBinders(V);
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2esyntax_2eformat_2eequationKey(V, V);
V g_heff_2esyntax_2eformat_2eequationKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eequationKey_clo;
V g_heff_2esyntax_2eformat_2evariantKey(V, V);
V g_heff_2esyntax_2eformat_2evariantKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2evariantKey_clo;
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf(V, V);
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf(V, V);
V g_heff_2esyntax_2epresyntax_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_clo;
V g_list_2eany_24s1081981235x855852216(V, V);
V g_list_2eany_24s1081981235x855852216_entry(V self, V *a);
extern Clo g_list_2eany_24s1081981235x855852216_clo;
V g_list_2eany_24s378803910x892125795(V);
V g_list_2eany_24s378803910x892125795_entry(V self, V *a);
extern Clo g_list_2eany_24s378803910x892125795_clo;
V g_list_2eany_24s495437461x764444341(V);
V g_list_2eany_24s495437461x764444341_entry(V self, V *a);
extern Clo g_list_2eany_24s495437461x764444341_clo;
V g_list_2econcatMap(V, V);
V g_list_2econcatMap_entry(V self, V *a);
extern Clo g_list_2econcatMap_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1330420811x172858565(V, V, V, V);
V g_list_2efilter_24s1330420811x172858565_entry(V self, V *a);
extern Clo g_list_2efilter_24s1330420811x172858565_clo;
V g_list_2efilter_24s1330420811x172858565_24dps(V, V, V, V, V);
V g_list_2efilter_24s1330420811x172858565_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1330420811x172858565_24dps_clo;
V g_list_2efilter_24s1875062608x222844981(V, V, V, V, V, V);
V g_list_2efilter_24s1875062608x222844981_entry(V self, V *a);
extern Clo g_list_2efilter_24s1875062608x222844981_clo;
V g_list_2efilter_24s1875062608x222844981_24dps(V, V, V, V, V, V, V);
V g_list_2efilter_24s1875062608x222844981_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1875062608x222844981_24dps_clo;
V g_list_2efilter_24s1966236437x1225976932_24dps(V, V, V);
V g_list_2efilter_24s1966236437x1225976932_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1966236437x1225976932_24dps_clo;
V g_list_2efilter_24s1967523567x64647275_24dps(V, V);
V g_list_2efilter_24s1967523567x64647275_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1967523567x64647275_24dps_clo;
V g_list_2efilter_24s2085830190x1097871222(V);
V g_list_2efilter_24s2085830190x1097871222_entry(V self, V *a);
extern Clo g_list_2efilter_24s2085830190x1097871222_clo;
V g_list_2efilter_24s2085830190x1097871222_24dps(V, V);
V g_list_2efilter_24s2085830190x1097871222_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2085830190x1097871222_24dps_clo;
V g_list_2efilter_24s316268077x2111002396(V, V);
V g_list_2efilter_24s316268077x2111002396_entry(V self, V *a);
extern Clo g_list_2efilter_24s316268077x2111002396_clo;
V g_list_2efilter_24s999680916x306845608_24dps(V, V, V);
V g_list_2efilter_24s999680916x306845608_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s999680916x306845608_24dps_clo;
V g_list_2efind_24s1230956425x1562898054(V, V);
V g_list_2efind_24s1230956425x1562898054_entry(V self, V *a);
extern Clo g_list_2efind_24s1230956425x1562898054_clo;
V g_list_2efind_24s1303721783x1302064695(V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efind_24s1303721783x1302064695_entry(V self, V *a);
extern Clo g_list_2efind_24s1303721783x1302064695_clo;
V g_list_2efind_24s1504327023x469120796(V, V);
V g_list_2efind_24s1504327023x469120796_entry(V self, V *a);
extern Clo g_list_2efind_24s1504327023x469120796_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1117322828x1334654706(V, V, V);
V g_list_2efoldl_24f1117322828x1334654706_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1117322828x1334654706_clo;
V g_list_2efoldl_24f297647854x479783049(V, V);
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a);
extern Clo g_list_2efoldl_24f297647854x479783049_clo;
V g_list_2efoldl_24s1149369025x804005338(V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1149369025x804005338_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1149369025x804005338_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s1894035205x969464323(V, V, V);
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1894035205x969464323_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s378225814x484524589(V, V);
V g_list_2efoldl_24s378225814x484524589_entry(V self, V *a);
extern Clo g_list_2efoldl_24s378225814x484524589_clo;
V g_list_2efoldl_24s398854970x1533504811(V, V);
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a);
extern Clo g_list_2efoldl_24s398854970x1533504811_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2efoldl_24s489050722x1368997552(V, V);
V g_list_2efoldl_24s489050722x1368997552_entry(V self, V *a);
extern Clo g_list_2efoldl_24s489050722x1368997552_clo;
V g_list_2efoldl_24s491084544x100802329(V, V);
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s491084544x100802329_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s809624008x2043497973(V, V);
V g_list_2efoldl_24s809624008x2043497973_entry(V self, V *a);
extern Clo g_list_2efoldl_24s809624008x2043497973_clo;
V g_list_2efoldl_24s950896375x422349662(V, V);
V g_list_2efoldl_24s950896375x422349662_entry(V self, V *a);
extern Clo g_list_2efoldl_24s950896375x422349662_clo;
V g_list_2emap_24f1638246995x433291654(V, V, V);
V g_list_2emap_24f1638246995x433291654_entry(V self, V *a);
extern Clo g_list_2emap_24f1638246995x433291654_clo;
V g_list_2emap_24f1638246995x433291654_24dps(V, V, V, V);
V g_list_2emap_24f1638246995x433291654_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1638246995x433291654_24dps_clo;
V g_list_2emap_24f990982947x2126256822(V, V);
V g_list_2emap_24f990982947x2126256822_entry(V self, V *a);
extern Clo g_list_2emap_24f990982947x2126256822_clo;
V g_list_2emap_24f990982947x2126256822_24dps(V, V, V);
V g_list_2emap_24f990982947x2126256822_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f990982947x2126256822_24dps_clo;
V g_list_2emap_24s1055307687x247454614_24dps(V, V, V);
V g_list_2emap_24s1055307687x247454614_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1055307687x247454614_24dps_clo;
V g_list_2emap_24s1068592055x839006909(V, V, V, V);
V g_list_2emap_24s1068592055x839006909_entry(V self, V *a);
extern Clo g_list_2emap_24s1068592055x839006909_clo;
V g_list_2emap_24s1157931537x649184066_24dps(V, V, V);
V g_list_2emap_24s1157931537x649184066_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_24dps_clo;
V g_list_2emap_24s1230969749x2018313496_24dps(V, V);
V g_list_2emap_24s1230969749x2018313496_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_24dps_clo;
V g_list_2emap_24s1234524601x742515152(V);
V g_list_2emap_24s1234524601x742515152_entry(V self, V *a);
extern Clo g_list_2emap_24s1234524601x742515152_clo;
V g_list_2emap_24s1234524601x742515152_24dps(V, V);
V g_list_2emap_24s1234524601x742515152_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1234524601x742515152_24dps_clo;
V g_list_2emap_24s1275294336x693095586_24dps(V, V, V);
V g_list_2emap_24s1275294336x693095586_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1275294336x693095586_24dps_clo;
V g_list_2emap_24s1397747289x2145601499(V);
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_clo;
V g_list_2emap_24s1397747289x2145601499_24dps(V, V);
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_24dps_clo;
V g_list_2emap_24s1409451498x400757684_24dps(V, V);
V g_list_2emap_24s1409451498x400757684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_24dps_clo;
V g_list_2emap_24s1661513421x830177447(V, V, V);
V g_list_2emap_24s1661513421x830177447_entry(V self, V *a);
extern Clo g_list_2emap_24s1661513421x830177447_clo;
V g_list_2emap_24s1661513421x830177447_24dps(V, V, V, V);
V g_list_2emap_24s1661513421x830177447_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1661513421x830177447_24dps_clo;
V g_list_2emap_24s1703643582x349630108_24dps(V, V, V);
V g_list_2emap_24s1703643582x349630108_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1703643582x349630108_24dps_clo;
V g_list_2emap_24s1753874608x910016727(V);
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_clo;
V g_list_2emap_24s1753874608x910016727_24dps(V, V);
V g_list_2emap_24s1753874608x910016727_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_24dps_clo;
V g_list_2emap_24s1782778565x402128078_24dps(V, V);
V g_list_2emap_24s1782778565x402128078_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_24dps_clo;
V g_list_2emap_24s1814289659x520383890_24dps(V, V, V, V);
V g_list_2emap_24s1814289659x520383890_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1814289659x520383890_24dps_clo;
V g_list_2emap_24s1887874170x1747433177_24dps(V, V);
V g_list_2emap_24s1887874170x1747433177_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_24dps_clo;
V g_list_2emap_24s18996220x10511024_24dps(V, V);
V g_list_2emap_24s18996220x10511024_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_24dps_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1943354043x700174004_24dps(V, V, V, V);
V g_list_2emap_24s1943354043x700174004_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1943354043x700174004_24dps_clo;
V g_list_2emap_24s2039279853x710813703(V, V);
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_clo;
V g_list_2emap_24s2039279853x710813703_24dps(V, V, V);
V g_list_2emap_24s2039279853x710813703_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_24dps_clo;
V g_list_2emap_24s205414595x1692305030(V);
V g_list_2emap_24s205414595x1692305030_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_clo;
V g_list_2emap_24s205414595x1692305030_24dps(V, V);
V g_list_2emap_24s205414595x1692305030_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_24dps_clo;
V g_list_2emap_24s354283597x484250159(V, V);
V g_list_2emap_24s354283597x484250159_entry(V self, V *a);
extern Clo g_list_2emap_24s354283597x484250159_clo;
V g_list_2emap_24s354283597x484250159_24dps(V, V, V);
V g_list_2emap_24s354283597x484250159_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s354283597x484250159_24dps_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s366344330x1145113647_24dps(V, V);
V g_list_2emap_24s366344330x1145113647_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_24dps_clo;
V g_list_2emap_24s388004800x1261967008(V);
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_clo;
V g_list_2emap_24s388004800x1261967008_24dps(V, V);
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_24dps_clo;
V g_list_2emap_24s391931963x434308123_24dps(V, V);
V g_list_2emap_24s391931963x434308123_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_24dps_clo;
V g_list_2emap_24s456133444x1904936646(V, V, V, V, V, V, V, V);
V g_list_2emap_24s456133444x1904936646_entry(V self, V *a);
extern Clo g_list_2emap_24s456133444x1904936646_clo;
V g_list_2emap_24s456133444x1904936646_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s456133444x1904936646_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s456133444x1904936646_24dps_clo;
V g_list_2emap_24s467798769x1763085075_24dps(V, V);
V g_list_2emap_24s467798769x1763085075_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_24dps_clo;
V g_list_2emap_24s567711145x425963688(V, V, V, V);
V g_list_2emap_24s567711145x425963688_entry(V self, V *a);
extern Clo g_list_2emap_24s567711145x425963688_clo;
V g_list_2emap_24s567711145x425963688_24dps(V, V, V, V, V);
V g_list_2emap_24s567711145x425963688_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s567711145x425963688_24dps_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_list_2emap_24s803586165x1676441765_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_24dps_clo;
V g_list_2emap_24s917234327x1197288555(V);
V g_list_2emap_24s917234327x1197288555_entry(V self, V *a);
extern Clo g_list_2emap_24s917234327x1197288555_clo;
V g_list_2emap_24s917234327x1197288555_24dps(V, V);
V g_list_2emap_24s917234327x1197288555_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s917234327x1197288555_24dps_clo;
V g_list_2emap_24s97919758x216970748_24dps(V, V, V);
V g_list_2emap_24s97919758x216970748_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_24dps_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emerge_24dps(V, V, V, V);
V g_list_2emerge_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24dps_clo;
V g_list_2emerge_24s132798885x1165759438(V, V);
V g_list_2emerge_24s132798885x1165759438_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_clo;
V g_list_2emerge_24s132798885x1165759438_24dps(V, V, V);
V g_list_2emerge_24s132798885x1165759438_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_24dps_clo;
V g_list_2emerge_24s1904498032x521599863(V, V);
V g_list_2emerge_24s1904498032x521599863_entry(V self, V *a);
extern Clo g_list_2emerge_24s1904498032x521599863_clo;
V g_list_2erange_24dps(V, V, V);
V g_list_2erange_24dps_entry(V self, V *a);
extern Clo g_list_2erange_24dps_clo;
V g_list_2esortBy_24s1230002843x105774350(V);
V g_list_2esortBy_24s1230002843x105774350_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1230002843x105774350_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24s1149721393x617397893(V, V, V);
V g_list_2ezipWith_24s1149721393x617397893_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1149721393x617397893_clo;
V g_list_2ezipWith_24s1149721393x617397893_24dps(V, V, V, V);
V g_list_2ezipWith_24s1149721393x617397893_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1149721393x617397893_24dps_clo;
V g_list_2ezipWith_24s870182194x1066240094(V, V);
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_clo;
V g_list_2ezipWith_24s870182194x1066240094_24dps(V, V, V);
V g_list_2ezipWith_24s870182194x1066240094_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2ecli_2eflagLine(V);
V g_std_2ecli_2eflagLine_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagLine_clo;
V g_list_2econcatMap_lam0(V self, V *args);
Clo g_list_2econcatMap_clo = {{0x80000000u, K_CLO, 0}, g_list_2econcatMap_entry, 2, 0};

V g_list_2econcatMap(V v_f_240, V v_xs_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  return ({ V a_0 = heff_clo_n(g_list_2econcatMap_lam0, 2, 1, (V[]){v_f_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_list_2econcatMap_entry(V self, V *a) {
  (void)self;
  return g_list_2econcatMap(a[0], a[1]);
}
V g_list_2econcatMap_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_244}));
  return (g_prelude_2e_2b_2b(v_t_245, v_acc_243));
}
Clo g_list_2erange_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2erange_24dps_entry, 3, 0};

V g_list_2erange_24dps(V v_a_240, V v_b_241, V v_d_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_241), heff_dup(v_a_240))) {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_240), heff_hole()});
    V v_u_245 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = heff_intAdd(v_a_240, MK_INT(1LL));
    V t_1 = v_b_241;
    V t_2 = v_cell_244;
    v_a_240 = t_0;
    v_b_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_list_2erange_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2erange_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emerge_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_entry, 3, 0};

V g_list_2emerge(V v_le_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      return v_xs_241;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      V v_ru_24ys_242_24Cons = heff_take_reuse_n(v_ys_242, 3ULL, 2);
      heff_drop_tag(v_xs_241, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){heff_dup(v_x_243), heff_dup(v_y_245)}));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_cell_248 = heff_tag_at_n(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = (g_list_2emerge_24dps(v_le_240, v_xs2_244, heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246}), heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop(v_t_247);
        V v_cell_2410 = heff_tag_at_n(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = (g_list_2emerge_24dps(v_le_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244}), v_ys2_246, heff_dup(v_cell_2410)));
        heff_drop(v_u_2411);
        return v_cell_2410;
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2emerge_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s366344330x1145113647_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366344330x1145113647_entry, 1, 0};

V g_list_2emap_24s366344330x1145113647(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s366344330x1145113647_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366344330x1145113647(a[0]);
}
Clo g_list_2emap_24s366344330x1145113647_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366344330x1145113647_24dps_entry, 2, 0};

V g_list_2emap_24s366344330x1145113647_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366344330x1145113647_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366344330x1145113647_24dps(a[0], a[1]);
}
Clo g_list_2efind_24s1303721783x1302064695_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1303721783x1302064695_entry, 32, 0};

V g_list_2efind_24s1303721783x1302064695(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_lit_2412, V v_lit_2413, V v_lit_2414, V v_lit_2415, V v_lit_2416, V v_lit_2417, V v_lit_2418, V v_lit_2419, V v_lit_2420, V v_lit_2421, V v_lit_2422, V v_lit_2423, V v_lit_2424, V v_lit_2425, V v_lit_2426, V v_lit_2427, V v_lit_2428, V v_lit_2429, V v_lit_2430, V v_x2_2431) {
top: ;
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    heff_drop(v_lit_2411);
    heff_drop(v_lit_2412);
    heff_drop(v_lit_2413);
    heff_drop(v_lit_2414);
    heff_drop(v_lit_2415);
    heff_drop(v_lit_2416);
    heff_drop(v_lit_2417);
    heff_drop(v_lit_2418);
    heff_drop(v_lit_2419);
    heff_drop(v_lit_2420);
    heff_drop(v_lit_2421);
    heff_drop(v_lit_2422);
    heff_drop(v_lit_2423);
    heff_drop(v_lit_2424);
    heff_drop(v_lit_2425);
    heff_drop(v_lit_2426);
    heff_drop(v_lit_2427);
    heff_drop(v_lit_2428);
    heff_drop(v_lit_2429);
    heff_drop(v_lit_2430);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_xs_2433 = heff_field(v_x2_2431, 1);
    V v_t_2434;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_I8: {
      v_t_2434 = heff_dup(v_lit_241);
      break;
    }
    case TAG_I16: {
      v_t_2434 = heff_dup(v_lit_242);
      break;
    }
    case TAG_I32: {
      v_t_2434 = heff_dup(v_lit_243);
      break;
    }
    case TAG_I64: {
      v_t_2434 = heff_dup(v_lit_244);
      break;
    }
    case TAG_U8: {
      v_t_2434 = heff_dup(v_lit_245);
      break;
    }
    case TAG_U16: {
      v_t_2434 = heff_dup(v_lit_246);
      break;
    }
    case TAG_U32: {
      v_t_2434 = heff_dup(v_lit_247);
      break;
    }
    case TAG_U64: {
      v_t_2434 = heff_dup(v_lit_248);
      break;
    }
    case TAG_F32: {
      v_t_2434 = heff_dup(v_lit_249);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    V v_t_2435;
    switch (heff_tag_of(v_x_2432)) {
    case TAG_OpAdd: {
      v_t_2435 = heff_dup(v_lit_2410);
      break;
    }
    case TAG_OpSub: {
      v_t_2435 = heff_dup(v_lit_2411);
      break;
    }
    case TAG_OpMul: {
      v_t_2435 = heff_dup(v_lit_2412);
      break;
    }
    case TAG_OpDiv: {
      v_t_2435 = heff_dup(v_lit_2413);
      break;
    }
    case TAG_OpRem: {
      v_t_2435 = heff_dup(v_lit_2414);
      break;
    }
    case TAG_OpEq: {
      v_t_2435 = heff_dup(v_lit_2415);
      break;
    }
    case TAG_OpLt: {
      v_t_2435 = heff_dup(v_lit_2416);
      break;
    }
    case TAG_OpLe: {
      v_t_2435 = heff_dup(v_lit_2417);
      break;
    }
    case TAG_OpAnd: {
      v_t_2435 = heff_dup(v_lit_2418);
      break;
    }
    case TAG_OpOr: {
      v_t_2435 = heff_dup(v_lit_2419);
      break;
    }
    case TAG_OpXor: {
      v_t_2435 = heff_dup(v_lit_2420);
      break;
    }
    case TAG_OpShl: {
      v_t_2435 = heff_dup(v_lit_2421);
      break;
    }
    case TAG_OpShr: {
      v_t_2435 = heff_dup(v_lit_2422);
      break;
    }
    case TAG_OpShow: {
      v_t_2435 = heff_dup(v_lit_2423);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2435 = heff_dup(v_lit_2424);
      break;
    }
    case TAG_OpToInt: {
      v_t_2435 = heff_dup(v_lit_2425);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2435 = heff_dup(v_lit_2426);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2435 = heff_dup(v_lit_2427);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2435 = heff_dup(v_lit_2428);
      break;
    }
    case TAG_OpFloor: {
      v_t_2435 = heff_dup(v_lit_2429);
      break;
    }
    default: heff_nomatch(v_x_2432);
    }
    if (heff_strEq_c(heff_strAppend(v_t_2434, v_t_2435), heff_dup(v_lit_2430))) {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_lit_247);
      heff_drop(v_lit_248);
      heff_drop(v_lit_249);
      heff_drop(v_lit_2410);
      heff_drop(v_lit_2411);
      heff_drop(v_lit_2412);
      heff_drop(v_lit_2413);
      heff_drop(v_lit_2414);
      heff_drop(v_lit_2415);
      heff_drop(v_lit_2416);
      heff_drop(v_lit_2417);
      heff_drop(v_lit_2418);
      heff_drop(v_lit_2419);
      heff_drop(v_lit_2420);
      heff_drop(v_lit_2421);
      heff_drop(v_lit_2422);
      heff_drop(v_lit_2423);
      heff_drop(v_lit_2424);
      heff_drop(v_lit_2425);
      heff_drop(v_lit_2426);
      heff_drop(v_lit_2427);
      heff_drop(v_lit_2428);
      heff_drop(v_lit_2429);
      heff_drop(v_lit_2430);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2432)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_lit_2410;
      V t_11 = v_lit_2411;
      V t_12 = v_lit_2412;
      V t_13 = v_lit_2413;
      V t_14 = v_lit_2414;
      V t_15 = v_lit_2415;
      V t_16 = v_lit_2416;
      V t_17 = v_lit_2417;
      V t_18 = v_lit_2418;
      V t_19 = v_lit_2419;
      V t_20 = v_lit_2420;
      V t_21 = v_lit_2421;
      V t_22 = v_lit_2422;
      V t_23 = v_lit_2423;
      V t_24 = v_lit_2424;
      V t_25 = v_lit_2425;
      V t_26 = v_lit_2426;
      V t_27 = v_lit_2427;
      V t_28 = v_lit_2428;
      V t_29 = v_lit_2429;
      V t_30 = v_lit_2430;
      V t_31 = v_xs_2433;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_lit_2411 = t_11;
      v_lit_2412 = t_12;
      v_lit_2413 = t_13;
      v_lit_2414 = t_14;
      v_lit_2415 = t_15;
      v_lit_2416 = t_16;
      v_lit_2417 = t_17;
      v_lit_2418 = t_18;
      v_lit_2419 = t_19;
      v_lit_2420 = t_20;
      v_lit_2421 = t_21;
      v_lit_2422 = t_22;
      v_lit_2423 = t_23;
      v_lit_2424 = t_24;
      v_lit_2425 = t_25;
      v_lit_2426 = t_26;
      v_lit_2427 = t_27;
      v_lit_2428 = t_28;
      v_lit_2429 = t_29;
      v_lit_2430 = t_30;
      v_x2_2431 = t_31;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_list_2efind_24s1303721783x1302064695_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a31 = a[31]; V r = g_list_2efind_24s1303721783x1302064695(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a[13], a[14], a[15], a[16], a[17], a[18], a[19], a[20], a[21], a[22], a[23], a[24], a[25], a[26], a[27], a[28], a[29], a[30], a31); heff_drop(a0); heff_drop(a31); return r;
}
HEFF_LIT(g_list_2emap_24s1409451498x400757684_24dps_str0, 0, "");
Clo g_list_2emap_24s1409451498x400757684_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1409451498x400757684_24dps_entry, 2, 0};

V g_list_2emap_24s1409451498x400757684_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_dup(heff_rfield(v_x_242, 2)), heff_dup(heff_rfield(v_x_242, 3)), heff_tag_n(TAG_Just, 1, (V[]){v_x_242}), ((V)&g_list_2emap_24s1409451498x400757684_24dps_str0), MK_INT(0LL), MK_INT(0LL)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1409451498x400757684_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1409451498x400757684_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s97919758x216970748_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s97919758x216970748_24dps_entry, 3, 0};

V g_list_2emap_24s97919758x216970748_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2evariantOf(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s97919758x216970748_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s97919758x216970748_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s2039279853x710813703_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2039279853x710813703_entry, 2, 0};

V g_list_2emap_24s2039279853x710813703(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2efieldSetOf(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s2039279853x710813703_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2039279853x710813703(a[0], a[1]);
}
Clo g_list_2emap_24s1157931537x649184066_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1157931537x649184066_24dps_entry, 3, 0};

V g_list_2emap_24s1157931537x649184066_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2eparamOf(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1157931537x649184066_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1157931537x649184066_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s205414595x1692305030_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s205414595x1692305030_entry, 1, 0};

V g_list_2emap_24s205414595x1692305030(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s105425268x398545052(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s205414595x1692305030_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s205414595x1692305030_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s205414595x1692305030(a[0]);
}
Clo g_list_2emap_24s1887874170x1747433177_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1887874170x1747433177_24dps_entry, 2, 0};

V g_list_2emap_24s1887874170x1747433177_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_x_242));
    V v_t_2414;
    switch (heff_tag_of(v_a_244)) {
    case TAG_IsInferable: {
      V v_a_245 = heff_field(v_a_244, 0);
      V v_ru_24a_244_24IsInferable = heff_take_reuse_n(v_a_244, 1ULL, 1);
      V v_t_248;
      switch (heff_tag_of(v_a_245)) {
      case TAG_At: {
        V v_a_247 = heff_dup(heff_field(v_a_245, 1));
        v_t_248 = v_a_247;
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24IsInferable, TAG_TInf, 1, (V[]){v_a_245}), v_t_248});
      break;
    }
    case TAG_IsCheckable: {
      V v_a_249 = heff_field(v_a_244, 0);
      V v_ru_24a_244_24IsCheckable = heff_take_reuse_n(v_a_244, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_a_249)) {
      case TAG_At: {
        V v_a_2411 = heff_dup(heff_field(v_a_249, 1));
        v_t_2412 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_a_249);
      }
      v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24IsCheckable, TAG_TChk, 1, (V[]){v_a_249}), v_t_2412});
      break;
    }
    case TAG_IsType: {
      V v_a_2413 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      v_t_2414 = v_a_2413;
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2415;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1887874170x1747433177_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1887874170x1747433177_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1230969749x2018313496_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230969749x2018313496_24dps_entry, 2, 0};

V g_list_2emap_24s1230969749x2018313496_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1230969749x2018313496_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230969749x2018313496_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1782778565x402128078_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1782778565x402128078_24dps_entry, 2, 0};

V g_list_2emap_24s1782778565x402128078_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2414;
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkEquation: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_ru_24a_244_24MkEquation = heff_take_reuse_n(v_a_244, 15ULL, 4);
        V v_t_2413;
        switch (heff_tag_of(v_a_249)) {
        case TAG_At: {
          V v_a_2410 = heff_field(v_a_249, 0);
          V v_a_2411 = heff_field(v_a_249, 1);
          heff_take_n(v_a_249, 3ULL, 2);
          V v_t_2412 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2410));
          v_t_2413 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2412, v_a_2411});
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2414 = heff_tag_at_n(v_ru_24a_244_24MkEquation, TAG_MkEquation, 4, (V[]){v_a_246, v_a_247, v_a_248, v_t_2413});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2416));
    heff_drop(v_u_2417);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2416;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1782778565x402128078_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1782778565x402128078_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s1330420811x172858565_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1330420811x172858565_entry, 4, 0};

V g_list_2efilter_24s1330420811x172858565(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_rfield(v_x_244, 1)));
    if (heff_intEq_c(v_t_246, heff_dup(v_lit_242))) {
      heff_drop_rec(v_x_244, 8);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = (g_list_2efilter_24s1330420811x172858565_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s1330420811x172858565_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1330420811x172858565(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s378803910x892125795_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s378803910x892125795_entry, 1, 0};

V g_list_2eany_24s378803910x892125795(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s378803910x892125795_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s378803910x892125795(a0); heff_drop(a0); return r;
}
Clo g_list_2eany_24s495437461x764444341_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s495437461x764444341_entry, 1, 0};

V g_list_2eany_24s495437461x764444341(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2ecompile_2efacts_2etailApp(a_0)); heff_drop(v_t_246); r_; });
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_247);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s495437461x764444341_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s495437461x764444341(a0); heff_drop(a0); return r;
}
Clo g_list_2efilter_24s2085830190x1097871222_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2085830190x1097871222_entry, 1, 0};

V g_list_2efilter_24s2085830190x1097871222(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_t_245, 0ULL, 2);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_249 = (g_list_2efilter_24s2085830190x1097871222_24dps(v_xs_242, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s2085830190x1097871222_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2085830190x1097871222(a[0]);
}
Clo g_list_2efoldl_24s1530401830x609500251_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1530401830x609500251_entry, 2, 0};

V g_list_2efoldl_24s1530401830x609500251(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1530401830x609500251(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_str0, 1, "\"");
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_str1, 1, "\"");
Clo g_list_2emap_24s1397747289x2145601499_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1397747289x2145601499_entry, 1, 0};

V g_list_2emap_24s1397747289x2145601499(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2eprint_2eescFrom(v_x_241, MK_INT(0LL)));
    V v_t_244 = heff_strAppend(((V)&g_list_2emap_24s1397747289x2145601499_str0), heff_strAppend(v_t_243, ((V)&g_list_2emap_24s1397747289x2145601499_str1)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1397747289x2145601499_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1397747289x2145601499(a[0]);
}
Clo g_list_2efilter_24s1966236437x1225976932_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1966236437x1225976932_24dps_entry, 3, 0};

V g_list_2efilter_24s1966236437x1225976932_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_243)) {
    case TAG_UpdateTo: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_2413 = v_a_245;
      break;
    }
    case TAG_UpdateIn: {
      V v_a_249 = heff_dup(heff_field(v_x_243, 0));
      v_t_2413 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_strEq_c_lent(v_t_2413, v_lit_240, 1)) {
      V v_cell_2415 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2416 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_2415;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1966236437x1225976932_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1966236437x1225976932_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s870182194x1066240094_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s870182194x1066240094_entry, 2, 0};

V g_list_2ezipWith_24s870182194x1066240094(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_247;
      switch (heff_tag_of(v_x_242)) {
      case TAG_RepV: {
        heff_drop_cell(v_ru_24ys_241_24Cons, 2);
        v_t_247 = v_y_244;
        break;
      }
      case TAG_RepFix: {
        v_t_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_RWord, 2, (V[]){v_x_242, v_y_244});
        break;
      }
      case TAG_RepF64: {
        v_t_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_RWord, 2, (V[]){v_x_242, v_y_244});
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s870182194x1066240094_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s870182194x1066240094(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1149721393x617397893_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1149721393x617397893_entry, 3, 0};

V g_list_2ezipWith_24s1149721393x617397893(V v_lit_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247 = heff_strAppend(v_x_243, heff_strAppend(heff_dup(v_lit_240), v_y_245));
      V v_cell_248 = heff_tag_at_n(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s1149721393x617397893_24dps(v_lit_240, v_xs2_244, v_ys2_246, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2ezipWith_24s1149721393x617397893_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1149721393x617397893(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s567711145x425963688_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s567711145x425963688_entry, 4, 0};

V g_list_2emap_24s567711145x425963688(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_244, 0);
      V v_a_247 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 3ULL, 2);
      if (heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_a_246, v_lit_241, v_lit_242, 1))) {
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_a_247});
      } else {
        heff_drop(v_a_247);
        v_t_249 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s567711145x425963688_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s567711145x425963688_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s567711145x425963688(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s398854970x1533504811_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s398854970x1533504811_entry, 2, 0};

V g_list_2efoldl_24s398854970x1533504811(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemit_2eprimUses(v_z_240, v_x_242));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s398854970x1533504811(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s803586165x1676441765_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s803586165x1676441765_entry, 7, 0};

V g_list_2emap_24s803586165x1676441765(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_x_247), heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_x_247, v_lit_243, 2), NTAG(TAG_Nil)));
    V v_a_2410 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_a_2410)) {
    case TAG_Nil: {
      v_t_2413 = heff_dup(v_lit_244);
      break;
    }
    case TAG_Cons: {
      V v_a_2411 = heff_field(v_a_2410, 0);
      V v_a_2412 = heff_field(v_a_2410, 1);
      heff_take_n(v_a_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = heff_dup(v_lit_245); V a_1 = v_a_2411; V a_2 = v_a_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2412); r_; });
      break;
    }
    default: heff_nomatch(v_a_2410);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = (g_list_2emap_24s803586165x1676441765_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s803586165x1676441765(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s1275294336x693095586_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1275294336x693095586_24dps_entry, 3, 0};

V g_list_2emap_24s1275294336x693095586_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eemitc_2easLent(v_lit_240, v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1275294336x693095586_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1275294336x693095586_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s456133444x1904936646_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s456133444x1904936646_entry, 8, 0};

V g_list_2emap_24s456133444x1904936646(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkDrop: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      switch (heff_tag_of(v_a_2411)) {
      case TAG_Nothing: {
        V v_t_2412 = (g_heff_2ecompile_2eemitc_2emangleW(v_a_2410, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)));
        V v_t_2413 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2412), heff_dup(v_lit_245));
        v_t_2415 = heff_strAppend(heff_dup(v_lit_240), v_t_2413);
        break;
      }
      case TAG_Just: {
        V v_a_2414 = heff_field(v_a_2411, 0);
        heff_take_n(v_a_2411, 1ULL, 1);
        v_t_2415 = ({ V a_0 = v_a_2410; V a_1 = v_a_2414; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_a_2414); r_; });
        break;
      }
      default: heff_nomatch(v_a_2411);
      }
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2415, heff_dup(v_lit_246)), heff_hole()});
    V v_u_2417 = (g_list_2emap_24s456133444x1904936646_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s456133444x1904936646_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s456133444x1904936646(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efilter_24s1967523567x64647275_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1967523567x64647275_24dps_entry, 2, 0};

V g_list_2efilter_24s1967523567x64647275_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_244 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_a_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_a_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1967523567x64647275_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1967523567x64647275_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1894035205x969464323_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1894035205x969464323_entry, 3, 0};

V g_list_2efoldl_24s1894035205x969464323(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_intAdd(v_z_241, heff_strLength_lent(v_x_243, 0));
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_t_245, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1894035205x969464323(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s950896375x422349662_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s950896375x422349662_entry, 2, 0};

V g_list_2efoldl_24s950896375x422349662(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_242, 0));
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_list_2emap_24s1937570095x2110149801(heff_get_n(v_t_2412, 2, 3)));
    V v_t_2414 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_t_249, 1, 3), v_t_2413});
    V v_t_2415 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_t_246, 0, 3), v_t_2414, v_z_240));
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s950896375x422349662_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s950896375x422349662(a[0], a[1]);
}
Clo g_list_2efoldl_24s809624008x2043497973_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s809624008x2043497973_entry, 2, 0};

V g_list_2efoldl_24s809624008x2043497973(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s378225814x484524589(v_z_240, heff_rfield(v_x_242, 1)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s809624008x2043497973_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s809624008x2043497973(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s391931963x434308123_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s391931963x434308123_24dps_entry, 2, 0};

V g_list_2emap_24s391931963x434308123_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_x_242; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s391931963x434308123_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s391931963x434308123_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1149369025x804005338_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1149369025x804005338_entry, 8, 0};

V g_list_2efoldl_24s1149369025x804005338(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_z_246, V v_x3_247) {
top: ;
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return v_z_246;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x3_247, 0);
    V v_xs_249 = heff_field(v_x3_247, 1);
    V v_a_2410 = heff_dup(heff_rfield(v_x_248, 4));
    V v_t_2411 = (g_prelude_2esplitFrom(heff_dup(v_lit_242), heff_dup(v_a_2410), heff_dup(v_lit_243), heff_strFind_lent(v_lit_244, v_a_2410, v_lit_245, 2), NTAG(TAG_Nil)));
    V v_t_2412 = (g_list_2emap_24s1068592055x839006909(heff_dup(v_x_248), heff_dup(v_lit_240), heff_dup(v_lit_241), v_t_2411));
    V v_t_2413 = (g_heff_2ebuild_2edriver_2epromoteAt(v_z_246, heff_dup(heff_rfield(v_x_248, 7)), heff_dup(heff_rfield(v_x_248, 8)), v_t_2412));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_t_2413;
    V t_7 = v_xs_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_z_246 = t_6;
    v_x3_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_list_2efoldl_24s1149369025x804005338_entry(V self, V *a) {
  (void)self;
  V a7 = a[7]; V r = g_list_2efoldl_24s1149369025x804005338(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a7); heff_drop(a7); return r;
}
Clo g_list_2efind_24s1230956425x1562898054_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1230956425x1562898054_entry, 2, 0};

V g_list_2efind_24s1230956425x1562898054(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 13);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1230956425x1562898054_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1230956425x1562898054(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s467798769x1763085075_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s467798769x1763085075_24dps_entry, 2, 0};

V g_list_2emap_24s467798769x1763085075_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s467798769x1763085075_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s467798769x1763085075_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s354283597x484250159_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s354283597x484250159_entry, 2, 0};

V g_list_2emap_24s354283597x484250159(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2evariantKey(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s354283597x484250159_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s354283597x484250159_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s354283597x484250159(a[0], a[1]);
}
Clo g_list_2emap_24s1055307687x247454614_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1055307687x247454614_24dps_entry, 3, 0};

V g_list_2emap_24s1055307687x247454614_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2eequationKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1055307687x247454614_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1055307687x247454614_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1703643582x349630108_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1703643582x349630108_24dps_entry, 3, 0};

V g_list_2emap_24s1703643582x349630108_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_prelude_2eparseInt(v_x_243));
    V v_t_247;
    switch (heff_tag_of(v_a_245)) {
    case TAG_Nothing: {
      v_t_247 = heff_dup(v_lit_240);
      break;
    }
    case TAG_Just: {
      V v_a_246 = heff_field(v_a_245, 0);
      heff_take_n(v_a_245, 1ULL, 1);
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_a_245);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_248;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1703643582x349630108_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1703643582x349630108_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emerge_24s132798885x1165759438_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s132798885x1165759438_entry, 2, 0};

V g_list_2emerge_24s132798885x1165759438(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = (g_heff_2ebuild_2eproject_2esumBefore(heff_dup(v_x_242), heff_dup(v_y_244)));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_cell_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s132798885x1165759438_24dps(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        heff_drop(v_t_246);
        V v_cell_249 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s132798885x1165759438_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s132798885x1165759438_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s132798885x1165759438(a[0], a[1]);
}
Clo g_list_2emap_24s18996220x10511024_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s18996220x10511024_24dps_entry, 2, 0};

V g_list_2emap_24s18996220x10511024_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_x_242, 0), heff_get_n(v_x_242, 1, 3)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s18996220x10511024_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s18996220x10511024_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s489050722x1368997552_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s489050722x1368997552_entry, 2, 0};

V g_list_2efoldl_24s489050722x1368997552(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s1081981235x855852216(heff_dup(v_x_242), v_z_240));
    V v_t_246;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop(v_t_244);
      v_t_246 = v_z_240;
    } else {
      heff_drop(v_t_244);
      V v_t_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
      v_t_246 = (g_prelude_2e_2b_2b(v_z_240, v_t_245));
    }
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s489050722x1368997552_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s489050722x1368997552(a[0], a[1]);
}
Clo g_list_2emap_24s917234327x1197288555_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s917234327x1197288555_entry, 1, 0};

V g_list_2emap_24s917234327x1197288555(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s917234327x1197288555_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s917234327x1197288555_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s917234327x1197288555(a[0]);
}
Clo g_list_2efoldl_24s1476602679x302842688_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1476602679x302842688_entry, 2, 0};

V g_list_2efoldl_24s1476602679x302842688(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        v_t_2411 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_a_246)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1476602679x302842688(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s478414341x1543613922_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s478414341x1543613922_entry, 2, 0};

V g_list_2efoldl_24s478414341x1543613922(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s478414341x1543613922(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s388004800x1261967008_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s388004800x1261967008_entry, 1, 0};

V g_list_2emap_24s388004800x1261967008(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s388004800x1261967008_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s388004800x1261967008(a[0]);
}
Clo g_list_2efoldl_24s491084544x100802329_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s491084544x100802329_entry, 2, 0};

V g_list_2efoldl_24s491084544x100802329(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_a_248)));
        v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_249); r_; });
        break;
      }
      case TAG_BadVariant: {
        V v_a_2410 = heff_field(v_a_244, 0);
        v_t_2411 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2410));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s491084544x100802329(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2esortBy_24s1230002843x105774350_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1230002843x105774350_entry, 1, 0};

V g_list_2esortBy_24s1230002843x105774350(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s1230002843x105774350(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s1230002843x105774350(v_t_249));
      return (g_list_2emerge_24s1904498032x521599863(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1230002843x105774350_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1230002843x105774350(a[0]);
}
Clo g_list_2emap_24s1661513421x830177447_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1661513421x830177447_entry, 3, 0};

V g_list_2emap_24s1661513421x830177447(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247;
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_t_246 = heff_intAdd(heff_take_field(v_x_243, 3), heff_dup(v_lit_241));
      v_t_247 = ({ V rv_3 = v_t_246; V rr_ = heff_rec_reuse_nf(v_x_243, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      v_t_247 = v_x_243;
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s1661513421x830177447_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1661513421x830177447_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1661513421x830177447(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s1875062608x222844981_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1875062608x222844981_entry, 6, 0};

V g_list_2efilter_24s1875062608x222844981(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_a_248 = heff_dup(heff_rfield(v_x_246, 1));
    V v_t_249 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_a_248), heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_a_248, v_lit_243, 2), NTAG(TAG_Nil)));
    V v_t_2410 = (g_list_2emap_24s649333309x1802289391(v_t_249));
    V v_a_2411 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2410));
    switch (heff_tag_of(v_a_2411)) {
    case TAG_Nil: {
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
      V v_u_2413 = (g_list_2efilter_24s1875062608x222844981_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    case TAG_Cons: {
      V v_a_2414 = heff_field(v_a_2411, 0);
      heff_take_n(v_a_2411, 1ULL, 2);
      if (heff_strEq_c_lent(v_a_2414, v_lit_244, 1)) {
        V v_cell_2417 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
        V v_u_2418 = (g_list_2efilter_24s1875062608x222844981_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2417)));
        heff_drop(v_u_2418);
        return v_cell_2417;
      } else {
        heff_drop_rec(v_x_246, 2);
        heff_drop_cell(v_ru_24x2_245_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_247;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        goto top;
      }
    }
    default: return heff_nomatch(v_a_2411);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2efilter_24s1875062608x222844981_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1875062608x222844981(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s1234524601x742515152_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1234524601x742515152_entry, 1, 0};

V g_list_2emap_24s1234524601x742515152(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V rr_ = heff_rec_reuse_na(v_x_241, 3ULL, 2, shape_name__key, 15u, 0u); rr_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1234524601x742515152_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1234524601x742515152_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1234524601x742515152(a[0]);
}
Clo g_list_2emap_24s1814289659x520383890_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1814289659x520383890_24dps_entry, 4, 0};

V g_list_2emap_24s1814289659x520383890_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_240))) {
      v_t_247 = ({ V rv_1 = heff_dup(v_lit_240); V rv_2 = heff_dup(v_lit_241); V rr_ = heff_rec_reuse_nf(v_x_244, 1ULL, 3, shape_name__path__version, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    } else {
      v_t_247 = v_x_244;
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1814289659x520383890_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1814289659x520383890_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efind_24s1504327023x469120796_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1504327023x469120796_entry, 2, 0};

V g_list_2efind_24s1504327023x469120796(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 1));
    V v_a_245 = heff_dup(heff_rfield(v_lit_240, 1));
    if (heff_intEq_c(heff_dup(heff_rfield(v_a_244, 0)), heff_dup(heff_rfield(v_a_245, 0)))) {
      if (heff_intEq_c(heff_get_n(v_a_244, 1, 2), heff_get_n(v_a_245, 1, 2))) {
        heff_drop_rec(v_lit_240, 5);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_a_244, 2);
      heff_drop_rec(v_a_245, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1504327023x469120796_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1504327023x469120796(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1943354043x700174004_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1943354043x700174004_24dps_entry, 4, 0};

V g_list_2emap_24s1943354043x700174004_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    heff_drop_rec(v_lit_241, 5);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_a_246 = heff_dup(heff_rfield(v_lit_240, 3));
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 0, 2);
    V v_t_248 = heff_strSlice(heff_dup(v_a_246), heff_dup(heff_rfield(v_lit_241, 2)), v_t_247);
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 1, 2);
    V v_t_2410 = heff_strSlice(v_a_246, v_t_249, heff_dup(heff_rfield(v_lit_241, 4)));
    V v_t_2411 = heff_strAppend(v_t_248, heff_strAppend(v_x_244, v_t_2410));
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2412;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1943354043x700174004_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1943354043x700174004_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24s999680916x306845608_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s999680916x306845608_24dps_entry, 3, 0};

V g_list_2efilter_24s999680916x306845608_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 4);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s999680916x306845608_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s999680916x306845608_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1753874608x910016727_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1753874608x910016727_entry, 1, 0};

V g_list_2emap_24s1753874608x910016727(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagLine(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1753874608x910016727_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1753874608x910016727(a[0]);
}
Clo g_list_2emap_24f1638246995x433291654_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1638246995x433291654_entry, 3, 0};

V g_list_2emap_24f1638246995x433291654(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_intLt_c(heff_dup(v_lit_241), heff_strLength_lent(v_x_243, 0))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_243), heff_hole()});
      V v_u_247 = (g_list_2emap_24f1638246995x433291654_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1638246995x433291654_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1638246995x433291654(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f990982947x2126256822_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f990982947x2126256822_entry, 2, 0};

V g_list_2emap_24f990982947x2126256822(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
      V v_u_246 = (g_list_2emap_24f990982947x2126256822_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f990982947x2126256822_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f990982947x2126256822(a[0], a[1]);
}
Clo g_list_2efoldl_24f297647854x479783049_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f297647854x479783049_entry, 2, 0};

V g_list_2efoldl_24f297647854x479783049(V v_z_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_241, 0);
    V v_cs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_244 = (g_list_2efilter_24s316268077x2111002396(heff_dup(v_c_242), v_cs_243));
    V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_z_240});
    V t_1 = v_t_244;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f297647854x479783049(a[0], a[1]);
}
Clo g_list_2efoldl_24f1117322828x1334654706_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1117322828x1334654706_entry, 3, 0};

V g_list_2efoldl_24f1117322828x1334654706(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 6, 10);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1117322828x1334654706_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1117322828x1334654706(a[0], a[1], a2); heff_drop(a2); return r;
}