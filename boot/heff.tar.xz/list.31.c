// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_ArgEvidence 24309
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_ArmCovered 35323
#define TAG_ArmRuledOut 21752
#define TAG_ArmTaken 39536
#define TAG_At 8900
#define TAG_AtLeast0 52203
#define TAG_AtVar 7142
#define TAG_AtWord 2344
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_BadFieldSet 46507
#define TAG_Below 46697
#define TAG_Braces 8205
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_Case 4415
#define TAG_Dim 16148
#define TAG_Do 8988
#define TAG_EAbandon 62759
#define TAG_EAlt 33043
#define TAG_EApp 33163
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinding 25795
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EFor 37939
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetMut 54984
#define TAG_EMatch 41631
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EquationCovered 28162
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_Lam 23588
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_Looser 37443
#define TAG_MkCArm 24694
#define TAG_Named 2049
#define TAG_OfFixed 17267
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Plain 3036
#define TAG_RepV 61860
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SIf 29564
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SSet 8516
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_SetField 47531
#define TAG_Sum 30935
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_above 293969847
#define LBL_aliases 1464806715
#define LBL_args 9498020
#define LBL_atom 9500184
#define LBL_b 316
#define LBL_bad 306815
#define LBL_body 9524841
#define LBL_col 308218
#define LBL_doc 309170
#define LBL_e 319
#define LBL_end 310101
#define LBL_es 10005
#define LBL_esc 310255
#define LBL_field 298786068
#define LBL_first 298798794
#define LBL_fixed 298804110
#define LBL_fixities 357800079
#define LBL_fl 10029
#define LBL_grew 9676708
#define LBL_groups 709681407
#define LBL_k 325
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_line 9817275
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_multi 305615187
#define LBL_n 328
#define LBL_name 9869138
#define LBL_op 10312
#define LBL_opens 307306371
#define LBL_out 319944
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_tag 324116
#define LBL_text 10052084
#define LBL_units 312791945
#define LBL_val 326043
#define LBL_values 1123329101
#define LBL_ver 326173
#define LBL_version 583465758
#define LBL_xs 10594
static uint32_t shape_fl__op__bad__esc__grew__lams[] = {LBL_fl, LBL_op, LBL_bad, LBL_esc, LBL_grew, LBL_lams};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_n__out__k[] = {LBL_n, LBL_out, LBL_k};
static uint32_t shape_out__multi__first[] = {LBL_out, LBL_multi, LBL_first};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ecompile_2earrayloops_2ego(V, V, V);
V g_heff_2ecompile_2earrayloops_2ego_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2ego_clo;
V g_heff_2ecompile_2ecpr_2emergeFld(V, V);
V g_heff_2ecompile_2ecpr_2emergeFld_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2emergeFld_clo;
V g_heff_2ecompile_2efacts_2eflatW(V, V);
V g_heff_2ecompile_2efacts_2eflatW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2eflatW_clo;
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V, V);
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok1_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_clo;
V g_heff_2ecompile_2eimperative_2epk_get(void);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
HeffT2 g_heff_2ecompile_2etrmc_2eprodOf_24cpr(V, V);
V g_heff_2ecompile_2eworker_2ewithSig(V, V, V);
V g_heff_2ecompile_2eworker_2ewithSig_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ewithSig_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_list_2eall_24s2006536460x193465515(V, V, V);
V g_list_2eall_24s2006536460x193465515_entry(V self, V *a);
extern Clo g_list_2eall_24s2006536460x193465515_clo;
V g_list_2eall_24s78096928x1476871221(V, V, V);
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a);
extern Clo g_list_2eall_24s78096928x1476871221_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1073512242x148531643(V, V);
V g_list_2eany_24s1073512242x148531643_entry(V self, V *a);
extern Clo g_list_2eany_24s1073512242x148531643_clo;
V g_list_2eany_24s1419545795x962553976(V, V, V);
V g_list_2eany_24s1419545795x962553976_entry(V self, V *a);
extern Clo g_list_2eany_24s1419545795x962553976_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s180477083x124477283(V, V);
V g_list_2eany_24s180477083x124477283_entry(V self, V *a);
extern Clo g_list_2eany_24s180477083x124477283_clo;
V g_list_2eany_24s371864724x604755177(V, V);
V g_list_2eany_24s371864724x604755177_entry(V self, V *a);
extern Clo g_list_2eany_24s371864724x604755177_clo;
V g_list_2eany_24s683544084x423451648(V, V);
V g_list_2eany_24s683544084x423451648_entry(V self, V *a);
extern Clo g_list_2eany_24s683544084x423451648_clo;
V g_list_2eascending_24s918142136x542754241(V, V, V, V, V);
V g_list_2eascending_24s918142136x542754241_entry(V self, V *a);
extern Clo g_list_2eascending_24s918142136x542754241_clo;
V g_list_2ecollapse_24s239375235x1062143192(V, V, V, V);
V g_list_2ecollapse_24s239375235x1062143192_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s239375235x1062143192_clo;
V g_list_2ecollapse_24s880359666x1597741115(V, V);
V g_list_2ecollapse_24s880359666x1597741115_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s880359666x1597741115_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1047446376x6295489(V, V, V);
V g_list_2efoldl_24f1047446376x6295489_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1047446376x6295489_clo;
V g_list_2efoldl_24f139246788x401086883(V, V);
V g_list_2efoldl_24f139246788x401086883_entry(V self, V *a);
extern Clo g_list_2efoldl_24f139246788x401086883_clo;
V g_list_2efoldl_24f1419248316x13095286(V, V, V);
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1419248316x13095286_clo;
V g_list_2efoldl_24f158727028x1528233175(V, V, V);
V g_list_2efoldl_24f158727028x1528233175_entry(V self, V *a);
extern Clo g_list_2efoldl_24f158727028x1528233175_clo;
V g_list_2efoldl_24s1078918265x314186258(V, V);
V g_list_2efoldl_24s1078918265x314186258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1078918265x314186258_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1318914558x1386196507(V, V);
V g_list_2efoldl_24s1318914558x1386196507_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1318914558x1386196507_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1445201118x2106648802(V, V);
V g_list_2efoldl_24s1445201118x2106648802_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1445201118x2106648802_clo;
V g_list_2efoldl_24s1715799092x2143201243(V, V);
V g_list_2efoldl_24s1715799092x2143201243_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1715799092x2143201243_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s2004150897x784001505(V, V);
V g_list_2efoldl_24s2004150897x784001505_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2004150897x784001505_clo;
V g_list_2efoldl_24s2096737737x1558226812(V, V);
V g_list_2efoldl_24s2096737737x1558226812_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2096737737x1558226812_clo;
V g_list_2efoldl_24s2098410461x866205771(V, V, V);
V g_list_2efoldl_24s2098410461x866205771_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2098410461x866205771_clo;
V g_list_2efoldl_24s2103009317x1481930218(V, V);
V g_list_2efoldl_24s2103009317x1481930218_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2103009317x1481930218_clo;
V g_list_2efoldl_24s366449469x130665619(V, V);
V g_list_2efoldl_24s366449469x130665619_entry(V self, V *a);
extern Clo g_list_2efoldl_24s366449469x130665619_clo;
V g_list_2efoldl_24s422700624x1171050237(V, V);
V g_list_2efoldl_24s422700624x1171050237_entry(V self, V *a);
extern Clo g_list_2efoldl_24s422700624x1171050237_clo;
V g_list_2efoldl_24s556506759x1439950987(V, V);
V g_list_2efoldl_24s556506759x1439950987_entry(V self, V *a);
extern Clo g_list_2efoldl_24s556506759x1439950987_clo;
V g_list_2efoldl_24s634644062x504497039_24scalars(V, V, V);
V g_list_2efoldl_24s634644062x504497039_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634644062x504497039_24scalars_clo;
V g_list_2efoldl_24s634927308x1347712163(V, V);
V g_list_2efoldl_24s634927308x1347712163_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634927308x1347712163_clo;
V g_list_2efoldl_24s636448764x233713460(V, V);
V g_list_2efoldl_24s636448764x233713460_entry(V self, V *a);
extern Clo g_list_2efoldl_24s636448764x233713460_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s88009013x1334911863(V, V);
V g_list_2efoldl_24s88009013x1334911863_entry(V self, V *a);
extern Clo g_list_2efoldl_24s88009013x1334911863_clo;
V g_list_2ekeepIf_24f1368804635x922296653_24dps(V, V, V);
V g_list_2ekeepIf_24f1368804635x922296653_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1368804635x922296653_24dps_clo;
V g_list_2ekeepIf_24s1066353734x1075193228_24dps(V, V, V);
V g_list_2ekeepIf_24s1066353734x1075193228_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1066353734x1075193228_24dps_clo;
V g_list_2ekeepIf_24s1911725233x106069160(V, V, V, V);
V g_list_2ekeepIf_24s1911725233x106069160_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1911725233x106069160_clo;
V g_list_2ekeepIf_24s1911725233x106069160_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s1911725233x106069160_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1911725233x106069160_24dps_clo;
V g_list_2ekeepIf_24s742867582x682687968(V, V);
V g_list_2ekeepIf_24s742867582x682687968_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s742867582x682687968_clo;
V g_list_2ekeepIf_24s742867582x682687968_24dps(V, V, V);
V g_list_2ekeepIf_24s742867582x682687968_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s742867582x682687968_24dps_clo;
V g_list_2ekeepIf_24s930188071x496633547_24dps(V, V, V);
V g_list_2ekeepIf_24s930188071x496633547_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_24dps_clo;
V g_list_2emap_24dps(V, V, V);
V g_list_2emap_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24dps_clo;
V g_list_2emap_24f1050596570x1917004924(V, V, V);
V g_list_2emap_24f1050596570x1917004924_entry(V self, V *a);
extern Clo g_list_2emap_24f1050596570x1917004924_clo;
V g_list_2emap_24f1217399696x462307458_24dps(V, V, V, V);
V g_list_2emap_24f1217399696x462307458_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_24dps_clo;
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123(V, V, V, V);
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_entry(V self, V *a);
extern Clo g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_clo;
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps(V, V, V, V, V);
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps_clo;
V g_list_2emap_24f1511070573x340395911(V, V, V);
V g_list_2emap_24f1511070573x340395911_entry(V self, V *a);
extern Clo g_list_2emap_24f1511070573x340395911_clo;
V g_list_2emap_24f1511070573x340395911_24dps(V, V, V, V);
V g_list_2emap_24f1511070573x340395911_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1511070573x340395911_24dps_clo;
V g_list_2emap_24f1651437062x1594169608_24dps(V, V, V);
V g_list_2emap_24f1651437062x1594169608_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1651437062x1594169608_24dps_clo;
V g_list_2emap_24f525774350x554415833(V, V, V, V, V);
V g_list_2emap_24f525774350x554415833_entry(V self, V *a);
extern Clo g_list_2emap_24f525774350x554415833_clo;
V g_list_2emap_24f525774350x554415833_24dps(V, V, V, V, V, V);
V g_list_2emap_24f525774350x554415833_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f525774350x554415833_24dps_clo;
V g_list_2emap_24s1006818869x590968200(V);
V g_list_2emap_24s1006818869x590968200_entry(V self, V *a);
extern Clo g_list_2emap_24s1006818869x590968200_clo;
V g_list_2emap_24s1006818869x590968200_24dps(V, V);
V g_list_2emap_24s1006818869x590968200_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1006818869x590968200_24dps_clo;
V g_list_2emap_24s107931167x1978109134_24dps(V, V);
V g_list_2emap_24s107931167x1978109134_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s107931167x1978109134_24dps_clo;
V g_list_2emap_24s1093229560x1486136516(V);
V g_list_2emap_24s1093229560x1486136516_entry(V self, V *a);
extern Clo g_list_2emap_24s1093229560x1486136516_clo;
V g_list_2emap_24s126994153x1029399760(V);
V g_list_2emap_24s126994153x1029399760_entry(V self, V *a);
extern Clo g_list_2emap_24s126994153x1029399760_clo;
V g_list_2emap_24s126994153x1029399760_24dps(V, V);
V g_list_2emap_24s126994153x1029399760_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s126994153x1029399760_24dps_clo;
V g_list_2emap_24s1381986540x1952410492(V);
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_clo;
V g_list_2emap_24s1381986540x1952410492_24dps(V, V);
V g_list_2emap_24s1381986540x1952410492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_24dps_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1420651609x666245096_24dps(V, V);
V g_list_2emap_24s1420651609x666245096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_24dps_clo;
V g_list_2emap_24s1478286876x830244177(V);
V g_list_2emap_24s1478286876x830244177_entry(V self, V *a);
extern Clo g_list_2emap_24s1478286876x830244177_clo;
V g_list_2emap_24s1791433880x1360378684(V);
V g_list_2emap_24s1791433880x1360378684_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_clo;
V g_list_2emap_24s1791433880x1360378684_24dps(V, V);
V g_list_2emap_24s1791433880x1360378684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_24dps_clo;
V g_list_2emap_24s1809017761x1063871171_24dps(V, V);
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24dps_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24s1819241345x1511673126_24dps(V, V);
V g_list_2emap_24s1819241345x1511673126_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_24dps_clo;
V g_list_2emap_24s1845612977x612508518(V);
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_clo;
V g_list_2emap_24s1845612977x612508518_24dps(V, V);
V g_list_2emap_24s1845612977x612508518_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_24dps_clo;
V g_list_2emap_24s1917875516x88484758(V);
V g_list_2emap_24s1917875516x88484758_entry(V self, V *a);
extern Clo g_list_2emap_24s1917875516x88484758_clo;
V g_list_2emap_24s1917875516x88484758_24dps(V, V);
V g_list_2emap_24s1917875516x88484758_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1917875516x88484758_24dps_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s2007813875x1918122072_24dps(V, V);
V g_list_2emap_24s2007813875x1918122072_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2007813875x1918122072_24dps_clo;
V g_list_2emap_24s2039279853x710813703_24dps(V, V, V);
V g_list_2emap_24s2039279853x710813703_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s328130413x305756849_24dps(V, V, V, V, V);
V g_list_2emap_24s328130413x305756849_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s328130413x305756849_24dps_clo;
V g_list_2emap_24s3575633x347355318(V);
V g_list_2emap_24s3575633x347355318_entry(V self, V *a);
extern Clo g_list_2emap_24s3575633x347355318_clo;
V g_list_2emap_24s499193121x1224230698(V);
V g_list_2emap_24s499193121x1224230698_entry(V self, V *a);
extern Clo g_list_2emap_24s499193121x1224230698_clo;
V g_list_2emap_24s499193121x1224230698_24dps(V, V);
V g_list_2emap_24s499193121x1224230698_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s499193121x1224230698_24dps_clo;
V g_list_2emap_24s537124232x94423304(V);
V g_list_2emap_24s537124232x94423304_entry(V self, V *a);
extern Clo g_list_2emap_24s537124232x94423304_clo;
V g_list_2emap_24s537124232x94423304_24dps(V, V);
V g_list_2emap_24s537124232x94423304_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s537124232x94423304_24dps_clo;
V g_list_2emap_24s693155583x821663253_24dps(V, V, V, V);
V g_list_2emap_24s693155583x821663253_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s693155583x821663253_24dps_clo;
V g_list_2emap_24s732475005x1616712052_24dps(V, V);
V g_list_2emap_24s732475005x1616712052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_24dps_clo;
V g_list_2emap_24s73473062x206541869(V);
V g_list_2emap_24s73473062x206541869_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_clo;
V g_list_2emap_24s73473062x206541869_24dps(V, V);
V g_list_2emap_24s73473062x206541869_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_24dps_clo;
V g_list_2emap_24s79542405x478516404_24dps(V, V);
V g_list_2emap_24s79542405x478516404_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_24dps_clo;
V g_list_2emap_24s813634804x1844296865(V);
V g_list_2emap_24s813634804x1844296865_entry(V self, V *a);
extern Clo g_list_2emap_24s813634804x1844296865_clo;
V g_list_2emap_24s813634804x1844296865_24dps(V, V);
V g_list_2emap_24s813634804x1844296865_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s813634804x1844296865_24dps_clo;
V g_list_2emap_24s865484684x739952503_24dps(V, V);
V g_list_2emap_24s865484684x739952503_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s865484684x739952503_24dps_clo;
V g_list_2emap_24s88069640x1067514236_24dps(V, V);
V g_list_2emap_24s88069640x1067514236_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s88069640x1067514236_24dps_clo;
V g_list_2emap_24s903588428x1469638784_24dps(V, V, V);
V g_list_2emap_24s903588428x1469638784_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s903588428x1469638784_24dps_clo;
V g_list_2emap_24s94444922x1860431141_24dps(V, V);
V g_list_2emap_24s94444922x1860431141_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s94444922x1860431141_24dps_clo;
V g_list_2emap_24s94933736x72301022_24dps(V, V);
V g_list_2emap_24s94933736x72301022_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s94933736x72301022_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_clo;
V g_list_2emergeRuns_24s935175472x420697861(V, V, V, V);
V g_list_2emergeRuns_24s935175472x420697861_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s935175472x420697861_clo;
V g_list_2epushRun_24s2065172444x1912428477(V, V, V, V, V);
V g_list_2epushRun_24s2065172444x1912428477_entry(V self, V *a);
extern Clo g_list_2epushRun_24s2065172444x1912428477_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2erange_24dps(V, V, V);
V g_list_2erange_24dps_entry(V self, V *a);
extern Clo g_list_2erange_24dps_clo;
V g_list_2erunFrom(V, V, V);
V g_list_2erunFrom_entry(V self, V *a);
extern Clo g_list_2erunFrom_clo;
V g_list_2etake_24dps(V, V, V);
V g_list_2etake_24dps_entry(V self, V *a);
extern Clo g_list_2etake_24dps_clo;
V g_list_2ezipWith_24s270223073x952913921_24dps(V, V, V);
V g_list_2ezipWith_24s270223073x952913921_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s270223073x952913921_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1960751014x547354513(V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1960751014x547354513_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1960751014x547354513_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_list_2etake_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2etake_24dps_entry, 3, 0};

V g_list_2etake_24dps(V v_n_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_u_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2etake_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2etake_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2erange_clo = {{0x80000000u, K_CLO, 0}, g_list_2erange_entry, 2, 0};

V g_list_2erange(V v_a_240, V v_b_241) {
top: ;
  if (heff_intLt_c_lent(v_b_241, v_a_240, 0)) {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_240), heff_hole()});
    V v_u_243 = (g_list_2erange_24dps(heff_box_word((heff_unbox_word(v_a_240) + ((int64_t)1ULL))), v_b_241, v_cell_242));
    heff_drop(v_u_243);
    return v_cell_242;
  }
}
V g_list_2erange_entry(V self, V *a) {
  (void)self;
  return g_list_2erange(a[0], a[1]);
}
Clo g_list_2emap_24s94933736x72301022_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s94933736x72301022_24dps_entry, 2, 0};

V g_list_2emap_24s94933736x72301022_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_fixed_244 = heff_take_field(v_x_242, 0);
    V v_op_245 = heff_get_n(v_x_242, 1, 2);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OfFixed, 2, (V[]){v_fixed_244, v_op_245}), heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_246);
    V t_0 = v_xs_243;
    V t_1 = v_u_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s94933736x72301022_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s94933736x72301022_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s930188071x496633547_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s930188071x496633547_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s930188071x496633547_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c_lent(v_x_243, v_lit_240, 0)) {
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s930188071x496633547_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24s930188071x496633547_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s2039279853x710813703_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2039279853x710813703_24dps_entry, 3, 0};

V g_list_2emap_24s2039279853x710813703_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_245 = heff_dup(v_lit_240);
    V v_x2_246 = v_x_243;
    V v_t_2435;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_At: {
      V v_x21_247 = heff_field(v_x2_246, 0);
      V v_sp_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24At = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      switch (heff_tag_of(v_x21_247)) {
      case TAG_SetField: {
        V v_x_249 = heff_field(v_x21_247, 0);
        V v_xsp_2410 = heff_field(v_x21_247, 1);
        V v_e_2411 = heff_field(v_x21_247, 2);
        V v_ru_24x21_247_24SetField = heff_take_reuse_n(v_x21_247, 7ULL, 3);
        V v_x1_2412 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_e_2411}));
        V v_t_2422;
        switch (heff_tag_of(v_x1_2412)) {
        case TAG_IsInferable: {
          V v_i_2413 = heff_field(v_x1_2412, 0);
          V v_ru_24x1_2412_24IsInferable = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
          V v_t_2416;
          switch (heff_tag_of(v_i_2413)) {
          case TAG_At: {
            V v_s_2415 = heff_dup(heff_field(v_i_2413, 1));
            v_t_2416 = v_s_2415;
            break;
          }
          default: heff_nomatch(v_i_2413);
          }
          v_t_2422 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2412_24IsInferable, TAG_CInf, 1, (V[]){v_i_2413}), v_t_2416});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2417 = heff_field(v_x1_2412, 0);
          heff_take_n(v_x1_2412, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_246_24At, 2);
          v_t_2422 = v_c_2417;
          break;
        }
        case TAG_IsType: {
          V v_t_2418 = heff_field(v_x1_2412, 0);
          V v_ru_24x1_2412_24IsType = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
          V v_t_2421;
          switch (heff_tag_of(v_t_2418)) {
          case TAG_At: {
            V v_s_2420 = heff_dup(heff_field(v_t_2418, 1));
            v_t_2421 = v_s_2420;
            break;
          }
          default: heff_nomatch(v_t_2418);
          }
          v_t_2422 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2412_24IsType, TAG_CType, 1, (V[]){v_t_2418}), v_t_2421});
          break;
        }
        default: heff_nomatch(v_x1_2412);
        }
        v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_247_24SetField, TAG_SetField, 3, 3ULL, (V[]){v_x_249, v_xsp_2410, v_t_2422}), v_sp_248});
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2423 = heff_field(v_x21_247, 0);
        V v_ru_24x21_247_24BadFieldSet = heff_take_reuse_n(v_x21_247, 1ULL, 1);
        V v_x1_2424 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_e_2423}));
        V v_t_2434;
        switch (heff_tag_of(v_x1_2424)) {
        case TAG_IsInferable: {
          V v_i_2425 = heff_field(v_x1_2424, 0);
          V v_ru_24x1_2424_24IsInferable = heff_take_reuse_n(v_x1_2424, 1ULL, 1);
          V v_t_2428;
          switch (heff_tag_of(v_i_2425)) {
          case TAG_At: {
            V v_s_2427 = heff_dup(heff_field(v_i_2425, 1));
            v_t_2428 = v_s_2427;
            break;
          }
          default: heff_nomatch(v_i_2425);
          }
          v_t_2434 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2424_24IsInferable, TAG_CInf, 1, (V[]){v_i_2425}), v_t_2428});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2429 = heff_field(v_x1_2424, 0);
          heff_take_n(v_x1_2424, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_246_24At, 2);
          v_t_2434 = v_c_2429;
          break;
        }
        case TAG_IsType: {
          V v_t_2430 = heff_field(v_x1_2424, 0);
          V v_ru_24x1_2424_24IsType = heff_take_reuse_n(v_x1_2424, 1ULL, 1);
          V v_t_2433;
          switch (heff_tag_of(v_t_2430)) {
          case TAG_At: {
            V v_s_2432 = heff_dup(heff_field(v_t_2430, 1));
            v_t_2433 = v_s_2432;
            break;
          }
          default: heff_nomatch(v_t_2430);
          }
          v_t_2434 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2424_24IsType, TAG_CType, 1, (V[]){v_t_2430}), v_t_2433});
          break;
        }
        default: heff_nomatch(v_x1_2424);
        }
        v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_247_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2434}), v_sp_248});
        break;
      }
      default: heff_nomatch(v_x21_247);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_cell_2436 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2435, heff_hole()});
    V v_u_2437 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2436);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2437;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2039279853x710813703_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s2039279853x710813703_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s126994153x1029399760_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s126994153x1029399760_entry, 1, 0};

V g_list_2emap_24s126994153x1029399760(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_a_243)) {
      case TAG_ArgExplicit: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgExplicit = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_a_245)) {
        case TAG_At: {
          V v_a_246 = heff_field(v_a_245, 0);
          V v_a_247 = heff_field(v_a_245, 1);
          heff_take_n(v_a_245, 3ULL, 2);
          V v_t_248 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_246));
          v_t_249 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_248, v_a_247});
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_243_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_249});
        break;
      }
      case TAG_ArgProject: {
        V v_a_2410 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgProject = heff_take_reuse_n(v_a_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2418 = heff_tag_re_n(v_ru_24a_243_24ArgProject, TAG_ArgProject, 1, 1ULL, (V[]){v_a_2410});
        break;
      }
      case TAG_ArgNamed: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_a_2412 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24ArgNamed = heff_take_reuse_n(v_a_243, 3ULL, 2);
        V v_t_2416;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2413));
          v_t_2416 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2415, v_a_2414});
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2418 = heff_tag_re_n(v_ru_24a_243_24ArgNamed, TAG_ArgNamed, 2, 1ULL, (V[]){v_a_2411, v_t_2416});
        break;
      }
      case TAG_ArgEvidence: {
        V v_a_2417 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgEvidence = heff_take_reuse_n(v_a_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2418 = heff_tag_re_n(v_ru_24a_243_24ArgEvidence, TAG_ArgEvidence, 1, 1ULL, (V[]){v_a_2417});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = (g_list_2emap_24s126994153x1029399760_24dps(v_xs_242, v_cell_2420));
    heff_drop(v_u_2421);
    return v_cell_2420;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s126994153x1029399760_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s126994153x1029399760(a[0]);
}
Clo g_list_2emap_24s79542405x478516404_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s79542405x478516404_24dps_entry, 2, 0};

V g_list_2emap_24s79542405x478516404_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_244));
      v_t_247 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){v_t_246, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
    V t_0 = v_xs_243;
    V t_1 = v_u_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s79542405x478516404_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s79542405x478516404_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1006818869x590968200_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1006818869x590968200_entry, 1, 0};

V g_list_2emap_24s1006818869x590968200(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 7), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1006818869x590968200_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1006818869x590968200_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1006818869x590968200(a[0]);
}
Clo g_list_2emap_24s73473062x206541869_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s73473062x206541869_entry, 1, 0};

V g_list_2emap_24s73473062x206541869(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), heff_hole()});
    V v_u_244 = (g_list_2emap_24s73473062x206541869_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s73473062x206541869_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s73473062x206541869(a[0]);
}
Clo g_list_2efoldl_24s88009013x1334911863_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s88009013x1334911863_entry, 2, 0};

V g_list_2efoldl_24s88009013x1334911863(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s88009013x1334911863_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s88009013x1334911863(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s94444922x1860431141_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s94444922x1860431141_24dps_entry, 2, 0};

V g_list_2emap_24s94444922x1860431141_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s94444922x1860431141_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s94444922x1860431141_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s634927308x1347712163_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s634927308x1347712163_entry, 2, 0};

V g_list_2efoldl_24s634927308x1347712163(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s634927308x1347712163_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s634927308x1347712163(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2003609603x1707519208_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2003609603x1707519208_entry, 2, 0};

V g_list_2efoldl_24s2003609603x1707519208(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_x2_244 = v_x_242;
    V v_acc_245 = v_z_240;
    V v_t_2424;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_SLet: {
      V v_o_247 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 2ULL, 2);
      v_t_2424 = (g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2(v_ru_24x3_241_24Cons, v_o_247, v_acc_245));
      break;
    }
    case TAG_SOnce: {
      V v_o_249 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 2ULL, 2);
      v_t_2424 = (g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2(v_ru_24x3_241_24Cons, v_o_249, v_acc_245));
      break;
    }
    case TAG_SDecl: {
      heff_take_n(v_x2_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2424 = v_acc_245;
      break;
    }
    case TAG_SSet: {
      V v_o_2412 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 2ULL, 2);
      v_t_2424 = (g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2(v_ru_24x3_241_24Cons, v_o_2412, v_acc_245));
      break;
    }
    case TAG_SIf: {
      V v_c_2413 = heff_field(v_x2_244, 0);
      V v_ts_2414 = heff_field(v_x2_244, 1);
      V v_fs_2415 = heff_field(v_x2_244, 2);
      heff_take_n(v_x2_244, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2415));
      V v_acc_2417 = (g_list_2efoldl_24s2003609603x1707519208(v_acc_245, v_t_2416));
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ts_2414));
      V v_acc_2419 = (g_list_2efoldl_24s2003609603x1707519208(v_acc_2417, v_t_2418));
      v_t_2424 = ({ V a_0 = v_c_2413; V a_1 = v_acc_2419; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(a_0, a_1)); heff_drop(v_c_2413); r_; });
      break;
    }
    case TAG_SCase: {
      V v_v_2420 = heff_field(v_x2_244, 0);
      V v_arms_2421 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2421));
      V v_t_2423 = ({ V a_0 = v_acc_245; V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s1318914558x1386196507(a_0, a_1)); heff_drop(v_t_2422); r_; });
      v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 0)), 2, (V[]){v_v_2420, v_t_2423}));
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V t_0 = v_t_2424;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2003609603x1707519208(a[0], a[1]);
}
Clo g_list_2emap_24s1917875516x88484758_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1917875516x88484758_entry, 1, 0};

V g_list_2emap_24s1917875516x88484758(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_241, NTAG(TAG_RepV)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1917875516x88484758_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1917875516x88484758_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1917875516x88484758(a[0]);
}
Clo g_list_2efoldl_24s2004150897x784001505_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2004150897x784001505_entry, 2, 0};

V g_list_2efoldl_24s2004150897x784001505(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), NTAG(TAG_Nil)});
    V v_t_245 = (g_heff_2ecompile_2efacts_2eflatW(v_z_240, v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2004150897x784001505_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2004150897x784001505(a[0], a[1]);
}
Clo g_list_2efoldl_24s1078918265x314186258_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1078918265x314186258_entry, 2, 0};

V g_list_2efoldl_24s1078918265x314186258(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_z_240)) {
    case TAG_MkPair: {
      V v_acc_244 = heff_field(v_z_240, 0);
      V v_n_245 = heff_field(v_z_240, 1);
      V v_ru_24z_240_24MkPair = heff_take_reuse_n(v_z_240, 3ULL, 2);
      V v_n_246 = v_n_245;
      V v_d_247 = v_x_242;
      V v_t_248 = (g_heff_2ecompile_2earrayloops_2ego(heff_dup(heff_rfield(v_d_247, 0)), heff_dup(heff_rfield(v_d_247, 1)), heff_take_field(v_d_247, 2)));
      V v_t_249 = heff_rec_n(3, shape_n__out__k, (V[]){v_n_246, NTAG(TAG_Nil), MK_INT(0LL)});
      V v_x1_2410 = heff_tr(heff_call(v_t_248, 1, (V[]){v_t_249}));
      switch (heff_tag_of(v_x1_2410)) {
      case TAG_MkPair: {
        V v_b_2411 = heff_field(v_x1_2410, 0);
        V v_s_2412 = heff_field(v_x1_2410, 1);
        V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
        V v_out_2413 = heff_take_field(v_s_2412, 1);
        V v_n_2414 = heff_get_n(v_s_2412, 0, 3);
        V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_out_2413));
        V v_t_2416 = ({ V rv_2 = v_b_2411; V rr_ = heff_rec_reuse_nf(v_d_247, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_ds_2417 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, v_t_2415});
        V v_n2_2418 = v_n_2414;
        v_t_2419 = heff_tag_at_n(v_ru_24z_240_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_Cons, 2, (V[]){v_ds_2417, v_acc_244}), v_n2_2418});
        break;
      }
      default: heff_nomatch(v_x1_2410);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_2419;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1078918265x314186258_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1078918265x314186258(a[0], a[1]);
}
Clo g_list_2eany_24s1419545795x962553976_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1419545795x962553976_entry, 3, 0};

V g_list_2eany_24s1419545795x962553976(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2411;
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      V v_t_2414;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_249 = heff_field(v_x_243, 1);
        v_t_2414 = heff_dup(v_a_249);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      v_t_2411 = heff_strEq_lent(v_t_2414, v_lit_241, 1);
    } else {
      v_t_2411 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s1419545795x962553976_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2eany_24s1419545795x962553976(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24s88069640x1067514236_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s88069640x1067514236_24dps_entry, 2, 0};

V g_list_2emap_24s88069640x1067514236_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_t_249, 1);
      heff_take_n(v_t_249, 2ULL, 2);
      v_t_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_t_2412}), heff_hole()});
    V v_u_2414 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2413);
    V t_0 = v_xs_243;
    V t_1 = v_u_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s88069640x1067514236_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s88069640x1067514236_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s556506759x1439950987_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s556506759x1439950987_entry, 2, 0};

V g_list_2efoldl_24s556506759x1439950987(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Given: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_244, NTAG(TAG_Nil)});
      break;
    }
    case TAG_GivenU: {
      V v_a_246 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_246, NTAG(TAG_Nil)});
      break;
    }
    case TAG_LentVar: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_LentValue: {
      V v_a_249 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_249, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s556506759x1439950987_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s556506759x1439950987(a[0], a[1]);
}
Clo g_list_2ezipWith_24s270223073x952913921_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s270223073x952913921_24dps_entry, 3, 0};

V g_list_2ezipWith_24s270223073x952913921_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2ecpr_2emergeFld(v_x_243, v_y_245));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_u_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s270223073x952913921_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ezipWith_24s270223073x952913921_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s1911725233x106069160_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1911725233x106069160_entry, 4, 0};

V g_list_2ekeepIf_24s1911725233x106069160(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_246 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_244));
    if (heff_intLe_c_lent(v_lit_242, v_a_246, 2)) {
      V v_cell_247 = heff_tag_re_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s1911725233x106069160_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s1911725233x106069160_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1911725233x106069160(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s1715799092x2143201243_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1715799092x2143201243_entry, 2, 0};

V g_list_2efoldl_24s1715799092x2143201243(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_z_240, 1), v_x_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_t_2410;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        v_t_2410 = v_z_240;
      } else {
        heff_drop(v_field_246);
        V v_t_248 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_z_240, 1), heff_dup(v_x_242), NTAG(TAG_MkUnit)));
        V v_t_249 = heff_intAdd(heff_take_field(v_z_240, 4), MK_INT(1LL));
        v_t_2410 = ({ V rv_1 = v_t_248; V rv_4 = v_t_249; V rr_ = heff_rec_reuse_nf(v_z_240, 45ULL, 6, shape_fl__op__bad__esc__grew__lams, 3315u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 4) = rv_4; rr_; });
      }
      V t_0 = v_t_2410;
      V t_1 = v_xs_243;
      v_z_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1715799092x2143201243_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1715799092x2143201243(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s2007813875x1918122072_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2007813875x1918122072_24dps_entry, 2, 0};

V g_list_2emap_24s2007813875x1918122072_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_False), v_x_242});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2007813875x1918122072_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s2007813875x1918122072_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s371864724x604755177_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s371864724x604755177_entry, 2, 0};

V g_list_2eany_24s371864724x604755177(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_2443;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      V v_a_2427 = heff_field(v_x_242, 0);
      v_t_2443 = heff_bool(heff_strEq_c_lent(v_a_2427, v_lit_240, 0));
      break;
    }
    case TAG_EInt: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
      heff_drop(v_t_2443);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2443);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s371864724x604755177_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s371864724x604755177(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s636448764x233713460_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s636448764x233713460_entry, 2, 0};

V g_list_2efoldl_24s636448764x233713460(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2443;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ETag: {
      V v_a_2419 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 3);
      v_t_2443 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_2419, NTAG(TAG_Nil)});
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2443, v_z_240));
    V t_0 = v_t_2444;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s636448764x233713460_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s636448764x233713460(a[0], a[1]);
}
Clo g_list_2efoldl_24s1445201118x2106648802_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1445201118x2106648802_entry, 2, 0};

V g_list_2efoldl_24s1445201118x2106648802(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_list_2efoldl_24s366449469x130665619(v_z_240, v_t_2412));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1445201118x2106648802_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1445201118x2106648802(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s537124232x94423304_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s537124232x94423304_entry, 1, 0};

V g_list_2emap_24s537124232x94423304(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkCArm: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = heff_field(v_x_241, 2);
      V v_a_246 = heff_field(v_x_241, 3);
      V v_a_247 = heff_field(v_x_241, 4);
      V v_a_248 = heff_field(v_x_241, 5);
      V v_a_249 = heff_field(v_x_241, 6);
      V v_a_2410 = heff_field(v_x_241, 7);
      V v_ru_24x_241_24MkCArm = heff_take_reuse_n(v_x_241, 255ULL, 8);
      V v_t_2411 = (g_list_2emap_24s1478286876x830244177(v_a_249));
      v_t_2412 = heff_tag_re_n(v_ru_24x_241_24MkCArm, TAG_MkCArm, 8, 191ULL, (V[]){v_a_243, v_a_244, v_a_245, v_a_246, v_a_247, v_a_248, v_t_2411, v_a_2410});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s537124232x94423304_24dps(v_xs_242, v_cell_2413));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s537124232x94423304_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s537124232x94423304(a[0]);
}
Clo g_list_2efoldl_24s2098410461x866205771_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2098410461x866205771_entry, 3, 0};

V g_list_2efoldl_24s2098410461x866205771(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_uses_245 = heff_dup(v_lit_240);
    V v_m_246 = v_z_241;
    V v_x3_247 = heff_dup(v_x_243);
    V v_t_2418;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_MkPair: {
      V v_g_248 = heff_field(v_x3_247, 0);
      V v_c_249 = heff_field(v_x3_247, 1);
      heff_take_n(v_x3_247, 3ULL, 2);
      HeffT2 v_t_2410 = ({ V a_0 = v_uses_245; V a_1 = v_g_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_uses_245); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_u_2413 = v_field_2412;
          V v_n_2414 = heff_take_field(v_u_2413, 0);
          V v_args_2415 = heff_get_n(v_u_2413, 1, 2);
          if ((heff_intEq_c_lent(v_n_2414, MK_INT(1LL), 2) && ({ V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_249, 0))); int c_ = heff_intEq_c_lent(v_args_2415, v_t_2419, 0); heff_drop(v_t_2419); c_; }))) {
            heff_drop(v_n_2414);
            heff_drop(v_args_2415);
            V v_xs_2416 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_c_249, 1))));
            V v_x1_2417 = ({ V a_0 = v_g_248; V a_1 = v_xs_2416; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_2416); r_; });
            if (!(heff_dup(v_x1_2417) == NTAG(TAG_True))) {
              heff_drop(v_x1_2417);
              v_t_2418 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_246, v_g_248, v_c_249));
            } else {
              heff_drop(v_g_248);
              heff_drop_rec(v_c_249, 2);
              heff_drop(v_x1_2417);
              v_t_2418 = v_m_246;
            }
          } else {
            heff_drop(v_g_248);
            heff_drop_rec(v_c_249, 2);
            heff_drop(v_n_2414);
            heff_drop(v_args_2415);
            v_t_2418 = v_m_246;
          }
        } else {
          heff_drop(v_g_248);
          heff_drop_rec(v_c_249, 2);
          heff_drop(v_field_2412);
          v_t_2418 = v_m_246;
        }
      }
      break;
    }
    default: heff_nomatch(v_x3_247);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2418;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s2098410461x866205771_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s2098410461x866205771(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s813634804x1844296865_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s813634804x1844296865_entry, 1, 0};

V g_list_2emap_24s813634804x1844296865(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s813634804x1844296865_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s813634804x1844296865_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s813634804x1844296865(a[0]);
}
Clo g_list_2ekeepIf_24s1066353734x1075193228_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1066353734x1075193228_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1066353734x1075193228_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x_243)) {
    case TAG_AtLeast0: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      switch (heff_tag_of(v_a_245)) {
      case TAG_AtVar: {
        V v_a_246 = heff_field(v_a_245, 0);
        heff_take_n(v_a_245, 1ULL, 1);
        if (!heff_strEq_c_lent(v_lit_240, v_a_246, 0)) {
          heff_drop(v_a_246);
          V v_cell_247 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
          V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
          V t_0 = v_lit_240;
          V t_1 = v_xs_244;
          V t_2 = v_u_248;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          v_d_242 = t_2;
          goto top;
        } else {
          heff_drop_tag(v_x_243, 1);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_a_246);
          V t_0 = v_lit_240;
          V t_1 = v_xs_244;
          V t_2 = v_d_242;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          v_d_242 = t_2;
          goto top;
        }
      }
      case TAG_AtWord: {
        heff_take_n(v_a_245, 0ULL, 1);
        V v_cell_2410 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
        V v_u_2411 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2410);
        V t_0 = v_lit_240;
        V t_1 = v_xs_244;
        V t_2 = v_u_2411;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_a_245);
      }
    }
    case TAG_Below: {
      V v_a_2412 = heff_dup(heff_field(v_x_243, 0));
      V v_a_2413 = heff_dup(heff_field(v_x_243, 1));
      V v_t_2416;
      switch (heff_tag_of(v_a_2412)) {
      case TAG_AtVar: {
        V v_a_2414 = heff_field(v_a_2412, 0);
        heff_take_n(v_a_2412, 1ULL, 1);
        v_t_2416 = heff_bool(heff_strEq_c_lent(v_lit_240, v_a_2414, 0));
        heff_drop(v_a_2414);
        break;
      }
      case TAG_AtWord: {
        heff_take_n(v_a_2412, 0ULL, 1);
        v_t_2416 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_2412);
      }
      if (((heff_dup(v_t_2416) == NTAG(TAG_True)) ? 0 : !heff_strEq_c_lent(v_lit_240, v_a_2413, 0))) {
        heff_drop(v_a_2413);
        heff_drop(v_t_2416);
        V v_cell_2417 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
        V v_u_2418 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2417);
        V t_0 = v_lit_240;
        V t_1 = v_xs_244;
        V t_2 = v_u_2418;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop_tag(v_x_243, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_a_2413);
        heff_drop(v_t_2416);
        V t_0 = v_lit_240;
        V t_1 = v_xs_244;
        V t_2 = v_d_242;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1066353734x1075193228_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24s1066353734x1075193228_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2eall_24s2006536460x193465515_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s2006536460x193465515_entry, 3, 0};

V g_list_2eall_24s2006536460x193465515(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_s_245 = heff_dup(v_lit_240);
    V v_q_246 = heff_dup(v_lit_241);
    V v_tag_247 = heff_take_field(v_q_246, 0);
    V v_es_248 = heff_take_field(v_q_246, 4);
    V v_field_249 = heff_get_n(v_q_246, 1, 6);
    V v_e_2410 = heff_dup(v_x_243);
    V v_t_2420;
    switch (heff_tag_of(v_e_2410)) {
    case TAG_ETag: {
      V v_t_2411 = heff_field(v_e_2410, 0);
      V v_es_2412 = heff_field(v_e_2410, 1);
      heff_take_n(v_e_2410, 3ULL, 3);
      heff_drop(v_s_245);
      heff_drop(v_field_249);
      v_t_2420 = heff_bool((heff_strEq_c_lent(v_t_2411, v_tag_247, 0) && ({ V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es_2412)); int c_ = ({ V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es_248)); int c_ = heff_intEq_c_lent(v_t_2421, v_t_2422, 0); heff_drop(v_t_2422); c_; }); heff_drop(v_t_2421); c_; })));
      heff_drop(v_tag_247);
      heff_drop(v_es_248);
      heff_drop(v_t_2411);
      heff_drop(v_es_2412);
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_s_245);
      heff_drop(v_tag_247);
      heff_drop(v_es_248);
      heff_drop(v_field_249);
      v_t_2420 = NTAG(TAG_True);
      break;
    }
    default: {
      heff_drop(v_es_248);
      HeffT2 v_t_2414 = ({ V a_0 = v_s_245; V a_1 = v_e_2410; HeffT2 r_ = (g_heff_2ecompile_2etrmc_2eprodOf_24cpr(a_0, a_1)); heff_drop(v_e_2410); r_; });
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_x_2417 = v_field_2416;
          V v_tag_2418 = heff_take_field(v_x_2417, 0);
          V v_field_2419 = heff_get_n(v_x_2417, 1, 6);
          v_t_2420 = heff_bool((heff_strEq_c_lent(v_tag_2418, v_tag_247, 0) && heff_intEq_c_lent(v_field_2419, v_field_249, 0)));
          heff_drop(v_tag_247);
          heff_drop(v_field_249);
          heff_drop(v_tag_2418);
          heff_drop(v_field_2419);
        } else {
          heff_drop(v_tag_247);
          heff_drop(v_field_249);
          heff_drop(v_field_2416);
          v_t_2420 = NTAG(TAG_False);
        }
      }
      break;
    }
    }
    if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
      heff_drop(v_t_2420);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_t_2420);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eall_24s2006536460x193465515_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eall_24s2006536460x193465515(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s2103009317x1481930218_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2103009317x1481930218_entry, 2, 0};

V g_list_2efoldl_24s2103009317x1481930218(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_heff_2ecompile_2eworker_2ewithSig(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2103009317x1481930218_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2103009317x1481930218(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s732475005x1616712052_24dps_str0, 13, "export const ");
HEFF_LIT(g_list_2emap_24s732475005x1616712052_24dps_str1, 1, " ");
Clo g_list_2emap_24s732475005x1616712052_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s732475005x1616712052_24dps_entry, 2, 0};

V g_list_2emap_24s732475005x1616712052_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_l_244 = v_x_242;
    V v_t_249;
    if (heff_strEq_c(heff_strSlice_lent(v_l_244, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_list_2emap_24s732475005x1616712052_24dps_str0))) {
      V v_t_245 = heff_strSlice_lent(v_l_244, MK_INT(13LL), heff_strLength_lent(v_l_244, 0), 6);
      V v_j_246 = heff_strFind(((V)&g_list_2emap_24s732475005x1616712052_24dps_str1), v_t_245, MK_INT(0LL));
      if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
        heff_drop(v_j_246);
        V v_t_247 = heff_strSlice(heff_dup(v_l_244), MK_INT(13LL), heff_strLength(v_l_244));
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
      } else {
        V v_t_248 = heff_strSlice(v_l_244, MK_INT(13LL), heff_intAdd(MK_INT(13LL), v_j_246));
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
      }
    } else {
      heff_drop(v_l_244);
      v_t_249 = NTAG(TAG_Nothing);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2410);
    V t_0 = v_xs_243;
    V t_1 = v_u_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s732475005x1616712052_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s732475005x1616712052_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s693155583x821663253_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s693155583x821663253_24dps_entry, 4, 0};

V g_list_2emap_24s693155583x821663253_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_246, heff_dup(v_lit_241)), heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_247);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_u_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s693155583x821663253_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2emap_24s693155583x821663253_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s2096737737x1558226812_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2096737737x1558226812_entry, 2, 0};

V g_list_2efoldl_24s2096737737x1558226812(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_242, 0));
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_list_2emap_24s1937570095x2110149801(heff_get_n(v_t_2412, 2, 3)));
    V v_t_2414 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_t_249, 1, 3), v_t_2413});
    V v_t_2415 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, heff_get_n(v_t_246, 0, 3), v_t_2414));
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2096737737x1558226812_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2096737737x1558226812(a[0], a[1]);
}
Clo g_list_2eany_24s683544084x423451648_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s683544084x423451648_entry, 2, 0};

V g_list_2eany_24s683544084x423451648(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x_242)) {
    case TAG_ArmTaken: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_start_245 = heff_dup(heff_rfield(v_a_244, 0));
      V v_end_246 = heff_dup(heff_rfield(v_a_244, 1));
      if ((heff_intEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_start_245)) && heff_intEq_c(heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(v_end_246)))) {
        heff_drop_rec(v_lit_240, 2);
        heff_drop(v_start_245);
        heff_drop(v_end_246);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_start_245);
        heff_drop(v_end_246);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_ArmRuledOut: {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ArmCovered: {
      V v_a_2410 = heff_field(v_x_242, 0);
      V v_start_2412 = heff_dup(heff_rfield(v_a_2410, 0));
      V v_end_2413 = heff_dup(heff_rfield(v_a_2410, 1));
      if ((heff_intEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_start_2412)) && heff_intEq_c(heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(v_end_2413)))) {
        heff_drop_rec(v_lit_240, 2);
        heff_drop(v_start_2412);
        heff_drop(v_end_2413);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_start_2412);
        heff_drop(v_end_2413);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EquationCovered: {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s683544084x423451648_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s683544084x423451648(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s634644062x504497039_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s634644062x504497039_24scalars_entry, 3, 0};

V g_list_2efoldl_24s634644062x504497039_24scalars(V v_groups_240, V v_above_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_groups__above, (V[]){v_groups_240, v_above_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_a_245 = heff_dup(heff_rfield(v_x_243, 11));
    V v_groups_246 = heff_take_field(v_a_245, 0);
    V v_above_247 = heff_get_n(v_a_245, 1, 2);
    V v_t_248 = (g_heff_2esyntax_2efixity_2eappendF(v_groups_240, v_groups_246));
    V v_t_249 = (g_heff_2esyntax_2efixity_2enubByG(v_t_248));
    V v_t_2410 = (g_heff_2esyntax_2efixity_2eappendF(v_above_241, v_above_247));
    V v_t_2411 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2410));
    V t_0 = v_t_249;
    V t_1 = v_t_2411;
    V t_2 = v_xs_244;
    v_groups_240 = t_0;
    v_above_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s634644062x504497039_24scalars_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s634644062x504497039_24scalars(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1791433880x1360378684_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1791433880x1360378684_entry, 1, 0};

V g_list_2emap_24s1791433880x1360378684(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1791433880x1360378684_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1791433880x1360378684_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1791433880x1360378684(a[0]);
}
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str0, 9, "{ name = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str1, 9, ", path = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str2, 12, ", version = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str3, 2, " }");
Clo g_list_2emap_24s1381986540x1952410492_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1381986540x1952410492_entry, 1, 0};

V g_list_2emap_24s1381986540x1952410492(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_243 = heff_take_field(v_x_241, 0);
    V v_path_244 = heff_take_field(v_x_241, 1);
    V v_version_245 = heff_get_n(v_x_241, 2, 3);
    V v_t_246 = ({ V a_0 = v_name_243; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_name_243); r_; });
    V v_t_247 = ({ V a_0 = v_path_244; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_path_244); r_; });
    V v_t_248 = ({ V a_0 = v_version_245; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_version_245); r_; });
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_str0), v_t_246), ((V)&g_list_2emap_24s1381986540x1952410492_str1));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, v_t_247), ((V)&g_list_2emap_24s1381986540x1952410492_str2));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, v_t_248), ((V)&g_list_2emap_24s1381986540x1952410492_str3));
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1381986540x1952410492_24dps(v_xs_242, v_cell_2412));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1381986540x1952410492(a[0]);
}
Clo g_list_2efoldl_24s422700624x1171050237_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s422700624x1171050237_entry, 2, 0};

V g_list_2efoldl_24s422700624x1171050237(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s180477083x124477283(heff_dup(v_x_242), v_z_240));
    V v_t_246;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop(v_t_244);
      v_t_246 = v_z_240;
    } else {
      heff_drop(v_t_244);
      V v_t_245 = heff_tag_re_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, NTAG(TAG_Nil)});
      v_t_246 = (g_prelude_2e_2b_2b(v_z_240, v_t_245));
    }
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s422700624x1171050237_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s422700624x1171050237(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_str0, 5, "-- | ");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_str1, 4, "-- |");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_str2, 0, "");
Clo g_list_2emap_24s1819241345x1511673126_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1819241345x1511673126_entry, 1, 0};

V g_list_2emap_24s1819241345x1511673126(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    if (heff_strEq_c(heff_strSlice_lent(v_x_241, MK_INT(0LL), MK_INT(5LL), 6), ((V)&g_list_2emap_24s1819241345x1511673126_str0))) {
      V v_t_243 = heff_strSlice(heff_dup(v_x_241), MK_INT(5LL), heff_strLength(v_x_241));
      v_t_244 = heff_tag_n(TAG_Just, 1, (V[]){v_t_243});
    } else {
      if (heff_strEq_c(v_x_241, ((V)&g_list_2emap_24s1819241345x1511673126_str1))) {
        v_t_244 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_list_2emap_24s1819241345x1511673126_str2)});
      } else {
        v_t_244 = NTAG(TAG_Nothing);
      }
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1819241345x1511673126_24dps(v_xs_242, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1819241345x1511673126(a[0]);
}
Clo g_list_2ecollapse_24s880359666x1597741115_clo = {{0x80000000u, K_CLO, 0}, g_list_2ecollapse_24s880359666x1597741115_entry, 2, 0};

V g_list_2ecollapse_24s880359666x1597741115(V v_run_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_run_240;
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkPair: {
      V v_below_245 = heff_field(v_x31_242, 1);
      V v_t_2410;
      switch (heff_tag_of(v_below_245)) {
      case TAG_Nil: {
        v_t_2410 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(NTAG(TAG_True), heff_dup(v_below_245), v_run_240));
        break;
      }
      case TAG_Cons: {
        V v_a_246 = heff_field(v_below_245, 0);
        switch (heff_tag_of(v_run_240)) {
        case TAG_Nil: {
          v_t_2410 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(NTAG(TAG_True), heff_dup(v_below_245), v_run_240));
          break;
        }
        case TAG_Cons: {
          V v_b_248 = heff_dup(heff_field(v_run_240, 0));
          if (heff_intLe_c(heff_dup(heff_rfield(v_a_246, 2)), heff_get_n(v_b_248, 2, 7))) {
            v_t_2410 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(NTAG(TAG_True), heff_dup(v_below_245), v_run_240));
          } else {
            v_t_2410 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(NTAG(TAG_False), v_run_240, heff_dup(v_below_245)));
          }
          break;
        }
        default: heff_nomatch(v_run_240);
        }
        break;
      }
      default: heff_nomatch(v_below_245);
      }
      V t_0 = v_t_2410;
      V t_1 = v_rest_243;
      v_run_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2ecollapse_24s880359666x1597741115_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ecollapse_24s880359666x1597741115(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1845612977x612508518_str0, 6, "import");
HEFF_LIT(g_list_2emap_24s1845612977x612508518_str1, 0, "");
Clo g_list_2emap_24s1845612977x612508518_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1845612977x612508518_entry, 1, 0};

V g_list_2emap_24s1845612977x612508518(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 2)), 0, 2);
    V v_t_244 = heff_get_n(heff_get_n(v_x_241, 2, 3), 1, 2);
    V v_t_245 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_list_2emap_24s1845612977x612508518_str0), ((V)&g_list_2emap_24s1845612977x612508518_str1), v_t_243, v_t_244, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1845612977x612508518_24dps(v_xs_242, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1845612977x612508518(a[0]);
}
Clo g_list_2eall_24s78096928x1476871221_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s78096928x1476871221_entry, 3, 0};

V g_list_2eall_24s78096928x1476871221(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_f_245 = heff_dup(v_lit_240);
    V v_m_246 = heff_dup(v_lit_241);
    V v_r_247 = heff_dup(v_x_243);
    V v_t_24175;
    switch (heff_tag_of(v_r_247)) {
    case TAG_Atom: {
      heff_take_n(v_r_247, 0ULL, 1);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EParen: {
      heff_take_n(v_r_247, 0ULL, 3);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_Named: {
      heff_take_n(v_r_247, 0ULL, 5);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_Tup: {
      heff_take_n(v_r_247, 0ULL, 4);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_Seg: {
      heff_take_n(v_r_247, 0ULL, 3);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_Braces: {
      heff_take_n(v_r_247, 0ULL, 4);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_Update: {
      heff_take_n(v_r_247, 0ULL, 6);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EUSet: {
      heff_take_n(v_r_247, 0ULL, 3);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_InstB: {
      heff_take_n(v_r_247, 0ULL, 5);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EFSet: {
      heff_take_n(v_r_247, 0ULL, 3);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EFDefault: {
      heff_take_n(v_r_247, 0ULL, 3);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_Sum: {
      heff_take_n(v_r_247, 0ULL, 5);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_ECon: {
      heff_take_n(v_r_247, 0ULL, 2);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EField: {
      heff_take_n(v_r_247, 0ULL, 2);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_ENeg: {
      heff_take_n(v_r_247, 0ULL, 2);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_ETilde: {
      heff_take_n(v_r_247, 0ULL, 2);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_App: {
      heff_take_n(v_r_247, 0ULL, 2);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_Op: {
      heff_take_n(v_r_247, 0ULL, 3);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_Ops: {
      heff_take_n(v_r_247, 0ULL, 2);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_OpRhs: {
      V v_op_2468 = heff_field(v_r_247, 0);
      heff_take_n(v_r_247, 1ULL, 2);
      V v_t_2470 = (g_heff_2esyntax_2efixity_2erelate(v_f_245, v_m_246, heff_get_n(v_op_2468, 1, 9)));
      switch (heff_tag_of(v_t_2470)) {
      case TAG_Tighter: {
        v_t_24175 = NTAG(TAG_False);
        break;
      }
      case TAG_Looser: {
        v_t_24175 = NTAG(TAG_False);
        break;
      }
      case TAG_Same: {
        heff_take_n(v_t_2470, 0ULL, 1);
        v_t_24175 = NTAG(TAG_True);
        break;
      }
      case TAG_Unrelated: {
        v_t_24175 = NTAG(TAG_False);
        break;
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_2470, 0ULL, 1);
        v_t_24175 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2470);
      }
      break;
    }
    case TAG_Ann: {
      heff_take_n(v_r_247, 0ULL, 3);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_BVar: {
      heff_take_n(v_r_247, 0ULL, 1);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_BImp: {
      heff_take_n(v_r_247, 0ULL, 3);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_BAnn: {
      heff_take_n(v_r_247, 0ULL, 5);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_BPat: {
      heff_take_n(v_r_247, 0ULL, 1);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_Lam: {
      heff_take_n(v_r_247, 0ULL, 4);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_Case: {
      heff_take_n(v_r_247, 0ULL, 4);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EAlt: {
      heff_take_n(v_r_247, 0ULL, 3);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_If: {
      heff_take_n(v_r_247, 0ULL, 6);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_Do: {
      heff_take_n(v_r_247, 0ULL, 2);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_ESBind: {
      heff_take_n(v_r_247, 0ULL, 3);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_r_247, 0ULL, 6);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_ELetElse: {
      heff_take_n(v_r_247, 0ULL, 7);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_ELetMut: {
      heff_take_n(v_r_247, 0ULL, 6);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EAssign: {
      heff_take_n(v_r_247, 0ULL, 3);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EWhile: {
      heff_take_n(v_r_247, 0ULL, 4);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EFor: {
      heff_take_n(v_r_247, 0ULL, 6);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EJump: {
      heff_take_n(v_r_247, 0ULL, 1);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EReturn: {
      heff_take_n(v_r_247, 0ULL, 2);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_ENest: {
      heff_take_n(v_r_247, 0ULL, 4);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EArrow: {
      heff_take_n(v_r_247, 0ULL, 2);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_IfThen: {
      heff_take_n(v_r_247, 0ULL, 4);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_ETry: {
      heff_take_n(v_r_247, 0ULL, 4);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_ECatch: {
      heff_take_n(v_r_247, 0ULL, 4);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EWith: {
      heff_take_n(v_r_247, 0ULL, 6);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EWithBound: {
      heff_take_n(v_r_247, 0ULL, 5);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_EBinding: {
      heff_take_n(v_r_247, 0ULL, 3);
      heff_drop(v_f_245);
      heff_drop(v_m_246);
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_r_247);
    }
    if ((heff_dup(v_t_24175) == NTAG(TAG_True))) {
      heff_drop(v_t_24175);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_t_24175);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eall_24s78096928x1476871221(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s903588428x1469638784_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s903588428x1469638784_24dps_entry, 3, 0};

V g_list_2emap_24s903588428x1469638784_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = heff_get_n(v_x_243, 2, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(v_a_245, heff_strLength_lent(v_a_245, 0)));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strSlice_lent(v_a_245, v_lit_240, v_t_246, 5), heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_248;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s903588428x1469638784_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s903588428x1469638784_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24s107931167x1978109134_24dps_str0, 8, "std.fuel");
HEFF_LIT(g_list_2emap_24s107931167x1978109134_24dps_str1, 8, ".limited");
HEFF_LIT(g_list_2emap_24s107931167x1978109134_24dps_str2, 8, "std.fuel");
HEFF_LIT(g_list_2emap_24s107931167x1978109134_24dps_str3, 8, "std.fuel");
HEFF_LIT(g_list_2emap_24s107931167x1978109134_24dps_str4, 7, "limited");
HEFF_LIT(g_list_2emap_24s107931167x1978109134_24dps_str5, 121, "this program is built without fuel: `limited` stops it only at an operation, so a pure loop with none runs past its limit");
HEFF_LIT(g_list_2emap_24s107931167x1978109134_24dps_str6, 133, "build it with fuel -- `fuel = True` in its build.hf, or `heff compile --fuel` -- for every loop to be ticked, at a cost to every loop");
V g_list_2emap_24s107931167x1978109134_24dps_lam0(V self, V *args);
Clo g_list_2emap_24s107931167x1978109134_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s107931167x1978109134_24dps_entry, 2, 0};

V g_list_2emap_24s107931167x1978109134_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_c_244 = v_x_242;
    V v_t_2412;
    if (heff_strEq_c(heff_dup(heff_rfield(v_c_244, 0)), ((V)&g_list_2emap_24s107931167x1978109134_24dps_str0))) {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2412 = v_c_244;
    } else {
      V v_t_245 = ({ V a_0 = ((V)&g_list_2emap_24s107931167x1978109134_24dps_str1); V b_1 = ((V)&g_list_2emap_24s107931167x1978109134_24dps_str2); V a_2 = heff_dup(heff_rfield(v_c_244, 10)); V r_ = (g_list_2emap_24f1050596570x1917004924(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      V v_t_246 = ({ V b_0 = ((V)&g_list_2emap_24s107931167x1978109134_24dps_str3); V a_1 = heff_rfield(v_c_244, 9); V r_ = (g_list_2eany_24s1477604419x1568736711(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_247;
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        v_t_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_list_2emap_24s107931167x1978109134_24dps_str4), NTAG(TAG_Nil)});
      } else {
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_t_246);
        v_t_247 = NTAG(TAG_Nil);
      }
      V v_t_248 = (g_list_2efoldl_24f1419248316x13095286(NTAG(TAG_Nil), v_t_245, v_t_247));
      V v_t_2411 = ({ V a_0 = heff_clo_n(g_list_2emap_24s107931167x1978109134_24dps_lam0, 2, 1, (V[]){heff_dup(v_c_244)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
      v_t_2412 = (g_heff_2ebuild_2edriver_2ewithDiags(v_c_244, v_t_2411));
    }
    V v_cell_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2413);
    V t_0 = v_xs_243;
    V t_1 = v_u_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s107931167x1978109134_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s107931167x1978109134_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_list_2emap_24s107931167x1978109134_24dps_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_acc_249; V a_1 = MK_INT(390LL); V a_2 = ((V)&g_list_2emap_24s107931167x1978109134_24dps_str5); V a_3 = v_x_2410; V a_4 = ((V)&g_list_2emap_24s107931167x1978109134_24dps_str6); V b_5 = heff_get_n(v_c_244, 3, 14); V a_6 = v_x_2410; V a_7 = MK_INT(0LL); V r_ = (g_prelude_2e_2b_2b_24f1960751014x547354513(a_0, a_1, a_2, a_3, a_4, b_5, a_6, a_7)); heff_drop(b_5); heff_drop(v_x_2410); r_; });
}
Clo g_list_2ekeepIf_24s742867582x682687968_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s742867582x682687968_entry, 2, 0};

V g_list_2ekeepIf_24s742867582x682687968(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s742867582x682687968_24dps(v_lit_240, v_xs_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 4);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s742867582x682687968_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s742867582x682687968(a[0], a[1]);
}
Clo g_list_2emap_24s1420651609x666245096_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1420651609x666245096_entry, 1, 0};

V g_list_2emap_24s1420651609x666245096(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_x_241});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1420651609x666245096_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1420651609x666245096(a[0]);
}
V g_list_2emergeRuns_24s935175472x420697861_lam0(V self, V *args);
Clo g_list_2emergeRuns_24s935175472x420697861_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s935175472x420697861_entry, 4, 0};

V g_list_2emergeRuns_24s935175472x420697861(V v_lit_240, V v_lit_241, V v_stack_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_MkPair: {
    V v_run_244 = heff_field(v_x3_243, 0);
    V v_x32_245 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    switch (heff_tag_of(v_x32_245)) {
    case TAG_Nil: {
      return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_run_244; V a_3 = v_stack_242; V r_ = (g_list_2ecollapse_24s239375235x1062143192(a_0, a_1, a_2, a_3)); heff_drop(v_stack_242); r_; });
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x32_245, 0);
      V v_xs_247 = heff_field(v_x32_245, 1);
      heff_take_n(v_x32_245, 3ULL, 2);
      V v_t_248 = (g_list_2epushRun_24s2065172444x1912428477(heff_dup(v_lit_240), heff_dup(v_lit_241), MK_INT(0LL), v_run_244, v_stack_242));
      V v_t_2412 = (g_list_2erunFrom(heff_clo_n(g_list_2emergeRuns_24s935175472x420697861_lam0, 2, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_x_246, v_xs_247));
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_t_248;
      V t_3 = v_t_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_stack_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x32_245);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2emergeRuns_24s935175472x420697861_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeRuns_24s935175472x420697861(a[0], a[1], a[2], a[3]);
}
V g_list_2emergeRuns_24s935175472x420697861_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_a_2410 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_a_2411 = heff_strCompare(heff_get_n(v_a_249, 0, 14), heff_get_n(v_a_2410, 0, 14));
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_a_2411, v_lit_240, 0) || heff_intEq_c_lent(v_a_2411, v_lit_241, 0)));
  heff_drop(self);
  heff_drop(v_a_2411);
  return v_ret_24bool;
}
Clo g_list_2eascending_24s918142136x542754241_clo = {{0x80000000u, K_CLO, 0}, g_list_2eascending_24s918142136x542754241_entry, 5, 0};

V g_list_2eascending_24s918142136x542754241(V v_lit_240, V v_lit_241, V v_x_242, V v_acc_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop_rec(v_x_242, 14);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_246 = heff_field(v_x4_244, 0);
    V v_ys_247 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    V v_a_248 = heff_strCompare(heff_get_n(v_x_242, 0, 14), heff_dup(heff_rfield(v_y_246, 0)));
    if ((heff_intLt_c_lent(v_a_248, v_lit_240, 0) || heff_intEq_c_lent(v_a_248, v_lit_241, 0))) {
      heff_drop(v_a_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = heff_dup(v_y_246);
      V t_3 = heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_246, v_acc_243});
      V t_4 = v_ys_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x_242 = t_2;
      v_acc_243 = t_3;
      v_x4_244 = t_4;
      goto top;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_a_248);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_246, v_ys_247})});
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2eascending_24s918142136x542754241_entry(V self, V *a) {
  (void)self;
  return g_list_2eascending_24s918142136x542754241(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s499193121x1224230698_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s499193121x1224230698_entry, 1, 0};

V g_list_2emap_24s499193121x1224230698(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2422;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_PatVar: {
        V v_x_245 = heff_field(v_x11_243, 0);
        V v_ru_24x11_243_24PatVar = heff_take_reuse_n(v_x11_243, 1ULL, 1);
        v_t_2422 = heff_tag_at_n(v_ru_24x11_243_24PatVar, TAG_Just, 1, (V[]){v_x_245});
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_243, 0ULL, 3);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_243, 0ULL, 3);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_243, 0ULL, 3);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
    V v_u_2424 = (g_list_2emap_24s499193121x1224230698_24dps(v_xs_242, v_cell_2423));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s499193121x1224230698_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s499193121x1224230698(a[0]);
}
Clo g_list_2emap_24s328130413x305756849_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s328130413x305756849_24dps_entry, 5, 0};

V g_list_2emap_24s328130413x305756849_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_source_247 = heff_take_field(v_x_245, 1);
    V v_span_248 = heff_get_n(v_x_245, 2, 4);
    V v_t_249 = ({ V a_0 = v_source_247; V a_1 = v_span_248; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_247); r_; });
    V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lit_241), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_lit_242)})});
    V v_t_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lit_240), v_t_249}), v_t_2411});
    V v_cell_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2412}), heff_hole()});
    V v_u_2414 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2413);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_u_2414;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s328130413x305756849_24dps_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2emap_24s328130413x305756849_24dps(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_list_2eany_24s1073512242x148531643_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1073512242x148531643_entry, 2, 0};

V g_list_2eany_24s1073512242x148531643(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_meta_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_values_245 = heff_dup(heff_rfield(v_x_242, 4));
    if (heff_strEq_c_lent(v_meta_244, v_lit_240, 1)) {
      V v_t_246 = v_values_245;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_246);
      }
    } else {
      heff_drop(v_values_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1073512242x148531643_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1073512242x148531643(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s865484684x739952503_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s865484684x739952503_24dps_entry, 2, 0};

V g_list_2emap_24s865484684x739952503_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec_n(2, shape_text__style, (V[]){v_x_242, NTAG(TAG_Dim)});
    V v_t_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_246);
    V t_0 = v_xs_243;
    V t_1 = v_u_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s865484684x739952503_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s865484684x739952503_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2efoldl_24f158727028x1528233175_str0, 3, "sym");
Clo g_list_2efoldl_24f158727028x1528233175_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f158727028x1528233175_entry, 3, 0};

V g_list_2efoldl_24f158727028x1528233175(V v_lit_240, V v_z_241, V v_x1_242) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_u_243 = heff_field(v_x1_242, 0);
    V v_rest_244 = heff_field(v_x1_242, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_u_243, 0)), ((V)&g_list_2efoldl_24f158727028x1528233175_str0))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_rest_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x1_242 = t_2;
      goto top;
    } else {
      heff_drop(v_lit_240);
      return v_z_241;
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_list_2efoldl_24f158727028x1528233175_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f158727028x1528233175(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1217399696x462307458_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1217399696x462307458_24dps_entry, 4, 0};

V g_list_2emap_24f1217399696x462307458_24dps(V v_lit_240, V v_x1_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    V v_t_244 = (g_list_2emap_24s231073986x752637537(v_lit_240, v_ys_242));
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), v_t_244);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_241, 0);
    V v_xs_246 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_245), heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_246;
    V t_2 = v_ys_242;
    V t_3 = v_u_248;
    v_lit_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2emap_24f1217399696x462307458_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2emap_24f1217399696x462307458_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24f525774350x554415833_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f525774350x554415833_entry, 5, 0};

V g_list_2emap_24f525774350x554415833(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_241, 10);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_lit_241, 9));
    V v_t_248;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_t_248 = heff_dup(v_lit_242);
    } else {
      heff_drop(v_t_247);
      v_t_248 = heff_dup(v_lit_243);
    }
    V v_x_249 = heff_strAppend(v_t_248, v_x_245);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_249, heff_dup(v_lit_240)), heff_hole()});
    V v_u_2411 = (g_list_2emap_24f525774350x554415833_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246, v_cell_2410));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f525774350x554415833_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f525774350x554415833(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_list_2efoldl_24f139246788x401086883_str0, 1, "\012");
HEFF_LIT(g_list_2efoldl_24f139246788x401086883_str1, 1, "\012");
HEFF_LIT(g_list_2efoldl_24f139246788x401086883_str2, 1, "\012");
HEFF_LIT(g_list_2efoldl_24f139246788x401086883_str3, 0, "");
HEFF_LIT(g_list_2efoldl_24f139246788x401086883_str4, 0, "");
HEFF_LIT(g_list_2efoldl_24f139246788x401086883_str5, 1, "\012");
Clo g_list_2efoldl_24f139246788x401086883_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f139246788x401086883_entry, 2, 0};

V g_list_2efoldl_24f139246788x401086883(V v_z_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_xs_243 = heff_field(v_x1_241, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      V t_0 = v_z_240;
      V t_1 = v_xs_243;
      v_z_240 = t_0;
      v_x1_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_acc_245 = v_z_240;
      V v_first_246 = heff_take_field(v_acc_245, 2);
      V v_multi_247 = heff_take_field(v_acc_245, 1);
      V v_out_248 = heff_take_field(v_acc_245, 0);
      V v_d_249 = heff_dup(v_x_244);
      V v_t_2413;
      if (!(heff_dup(v_first_246) == NTAG(TAG_True))) {
        heff_drop(v_first_246);
        int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_d_249, 0)) - ((int64_t)1ULL));
        V v_t_2411 = heff_strFind(((V)&g_list_2efoldl_24f139246788x401086883_str0), heff_strSlice_lent(v_d_249, MK_INT(0LL), heff_box_word(v_t_2410), 6), MK_INT(0LL));
        if (heff_intLe_c(MK_INT(0LL), v_t_2411)) {
          heff_drop(v_multi_247);
          v_t_2413 = ((V)&g_list_2efoldl_24f139246788x401086883_str1);
        } else {
          V v_t_2412 = v_multi_247;
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_t_2412);
            v_t_2413 = ((V)&g_list_2efoldl_24f139246788x401086883_str2);
          } else {
            heff_drop(v_t_2412);
            v_t_2413 = ((V)&g_list_2efoldl_24f139246788x401086883_str3);
          }
        }
      } else {
        heff_drop(v_first_246);
        heff_drop(v_multi_247);
        v_t_2413 = ((V)&g_list_2efoldl_24f139246788x401086883_str4);
      }
      V v_t_2414 = heff_strAppend(heff_strAppend(v_out_248, v_t_2413), heff_dup(v_d_249));
      int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_d_249, 0)) - ((int64_t)1ULL));
      V v_t_2416 = heff_strFind(((V)&g_list_2efoldl_24f139246788x401086883_str5), heff_strSlice(v_d_249, MK_INT(0LL), heff_box_word(v_t_2415)), MK_INT(0LL));
      V v_t_2417 = heff_bool(heff_intLe_c_lent(MK_INT(0LL), v_t_2416, 1));
      heff_drop(v_t_2416);
      V v_t_2418 = ({ V rv_0 = v_t_2414; V rv_1 = v_t_2417; V rv_2 = NTAG(TAG_False); V rr_ = heff_rec_reuse_nf(v_acc_245, 0ULL, 3, shape_out__multi__first, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      V t_0 = v_t_2418;
      V t_1 = v_xs_243;
      v_z_240 = t_0;
      v_x1_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f139246788x401086883_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f139246788x401086883(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24f1651437062x1594169608_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1651437062x1594169608_24dps_entry, 3, 0};

V g_list_2emap_24f1651437062x1594169608_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_text_245 = heff_take_field(v_x_243, 0);
    V v_span_246 = heff_get_n(v_x_243, 1, 2);
    if (heff_strEq_c_lent(v_text_245, v_lit_240, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_span_246, heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_248;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_span_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1651437062x1594169608_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24f1651437062x1594169608_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24f1368804635x922296653_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f1368804635x922296653_24dps_entry, 3, 0};

V g_list_2ekeepIf_24f1368804635x922296653_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_get_n(v_x_243, 1, 8);
    if (!heff_strEq_c_lent(v_x_245, v_lit_240, 0)) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_247;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_x_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24f1368804635x922296653_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24f1368804635x922296653_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_entry, 4, 0};

V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_shown_246 = heff_take_field(v_x_244, 2);
    V v_name_247 = heff_get_n(v_x_244, 0, 4);
    V v_t_248 = v_shown_246;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_x_249 = v_name_247;
      V v_t_2410 = heff_strSlice_lent(v_x_249, v_lit_241, heff_strLength_lent(v_lit_242, 0), 4);
      if (heff_strEq_c_lent(v_t_2410, v_lit_242, 1)) {
        V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_249, heff_dup(v_lit_240)), heff_hole()});
        V v_u_2412 = (g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, v_cell_2411));
        heff_drop(v_u_2412);
        return v_cell_2411;
      } else {
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        heff_drop(v_x_249);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_245;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        goto top;
      }
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_name_247);
      heff_drop(v_t_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24f1340051005x157438530_24f1161082868x102492123(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24f1511070573x340395911_str0, 0, "");
HEFF_LIT(g_list_2emap_24f1511070573x340395911_str1, 0, "");
HEFF_LIT(g_list_2emap_24f1511070573x340395911_str2, 1, " ");
Clo g_list_2emap_24f1511070573x340395911_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1511070573x340395911_entry, 3, 0};

V g_list_2emap_24f1511070573x340395911(V v_w_240, V v_line_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_list_2emap_24f1511070573x340395911_str0), 2)) {
      heff_drop(v_line_241);
      return NTAG(TAG_Nil);
    } else {
      V v_t_243 = (g_list_2emap_24s1093229560x1486136516(NTAG(TAG_Nil)));
      V v_t_244 = heff_rec_n(2, shape_text__style, (V[]){v_line_241, NTAG(TAG_Plain)});
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_243});
    }
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_242, 0);
    V v_xs_247 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_list_2emap_24f1511070573x340395911_str1), 2)) {
      heff_drop(v_line_241);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_w_240;
      V t_1 = v_x_246;
      V t_2 = v_xs_247;
      v_w_240 = t_0;
      v_line_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      V v_xs_248 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_line_241))));
      V v_t_249 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_248; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_248); r_; });
      V v_xs_2410 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_x_246))));
      V v_t_2411 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2410; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_2410); r_; });
      V v_t_2412 = heff_intAdd(heff_intAdd(v_t_249, MK_INT(1LL)), v_t_2411);
      if (heff_intLe_c_lent(v_t_2412, v_w_240, 1)) {
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        V v_t_2413 = heff_strAppend(heff_strAppend(v_line_241, ((V)&g_list_2emap_24f1511070573x340395911_str2)), v_x_246);
        V t_0 = v_w_240;
        V t_1 = v_t_2413;
        V t_2 = v_xs_247;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      } else {
        V v_t_2414 = heff_rec_n(2, shape_text__style, (V[]){v_line_241, NTAG(TAG_Plain)});
        V v_t_2415 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
        V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
        V v_u_2417 = (g_list_2emap_24f1511070573x340395911_24dps(v_w_240, v_x_246, v_xs_247, v_cell_2416));
        heff_drop(v_u_2417);
        return v_cell_2416;
      }
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1511070573x340395911_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1511070573x340395911(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f1047446376x6295489_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1047446376x6295489_entry, 3, 0};

V g_list_2efoldl_24f1047446376x6295489(V v_z_240, V v_seen_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_rest_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_243, v_seen_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_z_240;
      V t_1 = v_seen_241;
      V t_2 = v_rest_244;
      v_z_240 = t_0;
      v_seen_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), v_z_240});
      V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_seen_241});
      V t_2 = v_rest_244;
      v_z_240 = t_0;
      v_seen_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1047446376x6295489_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1047446376x6295489(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_24tok1_entry, 2, 0};

V g_list_2emap_24s1809017761x1063871171_24tok1(V v_tok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_EVar, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1809017761x1063871171_24dps(v_xs_243, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171_24tok1(a[0], a[1]);
}
Clo g_list_2emap_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24tok2_entry, 3, 0};

V g_list_2emap_24tok2(V v_tok_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24dps(v_f_241, v_xs_244, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24tok2(a[0], a[1], a[2]);
}