// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AsDefinition 21504
#define TAG_At 8900
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Doc 16324
#define TAG_ESig 50235
#define TAG_EStruct 20136
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_Left 13886
#define TAG_MkEquation 38417
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Sig 30557
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_TypeWord 10401
#define TAG_Whole 6035
#define LBL_code 9554612
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_fix 310927
#define LBL_kind 9787483
#define LBL_lenient 294367673
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_severity 75955546
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_eqns__end[] = {LBL_eqns, LBL_end};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V, V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2eassembleDiagOne(V, V, V, V);
V g_heff_2esyntax_2esurface_2eassembleDiagOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleDiagOne_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurface_2efixDeclAt_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletL_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2emutualBody(V, V, V);
V g_heff_2esyntax_2esurface_2emutualBody_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualBody_clo;
V g_heff_2esyntax_2esurface_2emutualOut(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualOut_clo;
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_clo;
V g_heff_2esyntax_2esurface_2erightsOf(V);
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2esizeSaid(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esizeSaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esizeSaid_clo;
V g_heff_2esyntax_2esurface_2especGroup(V, V, V);
V g_heff_2esyntax_2esurface_2especGroup_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroup_clo;
V g_heff_2esyntax_2esurface_2especWord(V, V, V);
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especWord_clo;
V g_heff_2esyntax_2esurface_2eunitOf(V, V, V);
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1744384903x906515519(V);
V g_list_2emap_24f1744384903x906515519_entry(V self, V *a);
extern Clo g_list_2emap_24f1744384903x906515519_clo;
V g_list_2emap_24s1691485302x273983346(V, V);
V g_list_2emap_24s1691485302x273983346_entry(V self, V *a);
extern Clo g_list_2emap_24s1691485302x273983346_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);

HeffT2 g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Sig: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Eqn: {
      V v_g_249 = heff_field(v_x21_242, 0);
      V v_e_2410 = heff_field(v_x21_242, 1);
      V v_esp_2411 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      if (heff_strEq_c_lent(v_f_240, v_g_249, 2)) {
        HeffT2 v_t_2413 = (g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(v_f_240, v_rest_243));
        V v_f_2424;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_rest_2417 = v_field_2415;
            V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2410, heff_dup(heff_rfield(v_rest_2417, 0))});
            V v_a_2419 = heff_get_n(v_esp_2411, 1, 2);
            V v_b_2420 = heff_get_n(v_rest_2417, 1, 2);
            V v_t_2422;
            if (heff_intLt_c_lent(v_a_2419, v_b_2420, 0)) {
              heff_drop(v_a_2419);
              v_t_2422 = v_b_2420;
            } else {
              heff_drop(v_b_2420);
              v_t_2422 = v_a_2419;
            }
            v_f_2424 = heff_rec_n(2, shape_eqns__end, (V[]){v_t_2418, v_t_2422});
          } else {
            heff_drop(v_field_2415);
            V v_t_2423 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2410, NTAG(TAG_Nil)});
            v_f_2424 = heff_rec_n(2, shape_eqns__end, (V[]){v_t_2423, heff_get_n(v_esp_2411, 1, 2)});
          }
        }
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
      } else {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_e_2410);
        heff_drop_rec(v_esp_2411, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_Whole: {
      V v_d_2425 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      switch (heff_tag_of(v_d_2425)) {
      case TAG_At: {
        V v_x11_2426 = heff_field(v_d_2425, 0);
        heff_take_n(v_d_2425, 1ULL, 2);
        switch (heff_tag_of(v_x11_2426)) {
        case TAG_DeclEquations: {
          heff_take_n(v_x11_2426, 0ULL, 5);
          heff_drop(v_rest_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_DeclDefine: {
          heff_take_n(v_x11_2426, 0ULL, 5);
          heff_drop(v_rest_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_DeclTheory: {
          heff_take_n(v_x11_2426, 0ULL, 4);
          heff_drop(v_rest_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_x11_2426, 0ULL, 3);
          heff_drop(v_rest_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_DeclTest: {
          heff_take_n(v_x11_2426, 0ULL, 2);
          V t_0 = v_f_240;
          V t_1 = v_rest_243;
          v_f_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_x11_2426, 0ULL, 1);
          V t_0 = v_f_240;
          V t_1 = v_rest_243;
          v_f_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2426)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_d_2425)}});
      }
    }
    case TAG_Doc: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_rest_243;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2esyntax_2esurface_2esigNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esigNames_entry, 1, 0};

V g_heff_2esyntax_2esurface_2esigNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_std_2emap_2eempty_get());
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Sig: {
      V v_f_244 = heff_field(v_x11_241, 1);
      V v_t_248 = (g_heff_2esyntax_2esurface_2esigNames(v_rest_242));
      return (g_std_2emap_2einsert_24s1305793909x1049798133(v_t_248, heff_dup(v_f_244), NTAG(TAG_MkUnit)));
    }
    case TAG_Eqn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Whole: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Doc: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esigNames(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eassembleDiagOne_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eassembleDiagOne_str1, 30, "` has a type but no definition");
HEFF_LIT(g_heff_2esyntax_2esurface_2eassembleDiagOne_str2, 17, "` needs a type: `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eassembleDiagOne_str3, 7, " : ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eassembleDiagOne_str4, 1, "`");
Clo g_heff_2esyntax_2esurface_2eassembleDiagOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eassembleDiagOne_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eassembleDiagOne(V v_broken_240, V v_sigs_241, V v_eqns_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Sig: {
    V v_f_245 = heff_field(v_x4_243, 1);
    V v_sp_248 = heff_field(v_x4_243, 4);
    HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_eqns_242, v_f_245));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_x_2413 = v_field_2411;
        heff_drop(v_x_2413);
        return NTAG(TAG_Nothing);
      } else {
        heff_drop(v_field_2411);
        HeffT2 v_t_2414 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_broken_240, v_f_245));
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          if ((v_tag_2415 == ((int64_t)0ULL))) {
            V v_x_2418 = v_field_2416;
            heff_drop(v_x_2418);
            return NTAG(TAG_Nothing);
          } else {
            heff_drop(v_field_2416);
            V v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_str0), heff_strAppend(heff_dup(v_f_245), ((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_str1)));
            V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2419, heff_dup(v_sp_248), NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
          }
        }
      }
    }
  }
  case TAG_Eqn: {
    V v_f_2421 = heff_field(v_x4_243, 0);
    V v_sp_2423 = heff_field(v_x4_243, 2);
    HeffT2 v_t_2424 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_sigs_241, v_f_2421));
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        V v_x_2428 = v_field_2426;
        heff_drop(v_x_2428);
        return NTAG(TAG_Nothing);
      } else {
        heff_drop(v_field_2426);
        HeffT2 v_t_2429 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_broken_240, v_f_2421));
        {
          V v_field_2431 = v_t_2429.f[1];
          int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
          if ((v_tag_2430 == ((int64_t)0ULL))) {
            V v_x_2433 = v_field_2431;
            heff_drop(v_x_2433);
            return NTAG(TAG_Nothing);
          } else {
            heff_drop(v_field_2431);
            V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_str2), heff_strAppend(heff_dup(v_f_2421), ((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_str3)));
            V v_t_2435 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_str4), heff_strAppend(heff_dup(v_f_2421), v_t_2434));
            V v_t_2436 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2435, heff_dup(v_sp_2423), NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2436});
          }
        }
      }
    }
  }
  case TAG_Whole: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Doc: {
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2esurface_2eassembleDiagOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2esyntax_2esurface_2eassembleDiagOne(a0, a1, a2, a3); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2esyntax_2esurface_2eletL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eletL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eletL(V v_r_240, V v_x2_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2eletL_24cpr(v_r_240, v_x2_241, v_z_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eletL(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str0, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str1, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str2, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str3, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str4, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str5, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str6, 4, "size");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str7, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str9, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str10, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str11, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str12, 4, "unit");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str13, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str15, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str16, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str17, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str18, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
V g_heff_2esyntax_2esurface_2especGroup_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam7(V self, V *args);
Clo g_heff_2esyntax_2esurface_2especGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especGroup_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especGroup(V v_sp_240, V v_s_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_s_241, 5);
    return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam0, 1, 1, (V[]){v_sp_240});
  }
  case TAG_Cons: {
    V v_t_245 = heff_field(v_x3_242, 0);
    V v_x32_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    heff_drop(v_sp_240);
    switch (heff_tag_of(v_x32_246)) {
    case TAG_Nil: {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str1))) {
        V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_245, 3), heff_take_field(v_t_245, 4)});
        V v_t_249 = ({ V b_0 = heff_get_n(v_t_245, 1, 9); V r_ = (g_heff_2esyntax_2esurface_2eintOfText(b_0)); heff_drop(b_0); r_; });
        return heff_tail(((V)&g_heff_2esyntax_2esurface_2esizeSaid_clo), 4, (V[]){v_t_248, heff_tag_n(TAG_SizeNumber, 1, (V[]){v_t_249}), heff_dup(heff_rfield(v_s_241, 1)), v_s_241});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str2))) {
          return heff_tail(((V)&g_heff_2esyntax_2esurface_2especWord_clo), 2, (V[]){v_t_245, v_s_241});
        } else {
          heff_drop_rec(v_s_241, 5);
          return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam1, 1, 1, (V[]){v_t_245});
        }
      }
    }
    case TAG_Cons: {
      V v_o_2414 = heff_field(v_x32_246, 0);
      V v_x322_2415 = heff_field(v_x32_246, 1);
      heff_take_n(v_x32_246, 3ULL, 2);
      switch (heff_tag_of(v_x322_2415)) {
      case TAG_Nil: {
        heff_drop_rec(v_s_241, 5);
        heff_drop_rec(v_o_2414, 9);
        return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam2, 1, 1, (V[]){v_t_245});
      }
      case TAG_Cons: {
        V v_n_2419 = heff_field(v_x322_2415, 0);
        V v_x3222_2420 = heff_field(v_x322_2415, 1);
        heff_take_n(v_x322_2415, 3ULL, 2);
        switch (heff_tag_of(v_x3222_2420)) {
        case TAG_Nil: {
          heff_drop_rec(v_s_241, 5);
          heff_drop_rec(v_o_2414, 9);
          heff_drop_rec(v_n_2419, 9);
          return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam3, 1, 1, (V[]){v_t_245});
        }
        case TAG_Cons: {
          V v_c_2424 = heff_field(v_x3222_2420, 0);
          V v_x32222_2425 = heff_field(v_x3222_2420, 1);
          heff_take_n(v_x3222_2420, 3ULL, 2);
          switch (heff_tag_of(v_x32222_2425)) {
          case TAG_Nil: {
            V v_t_2430 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_245, 1)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str6)) && (heff_strEq_c(heff_dup(heff_rfield(v_o_2414, 1)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str7)) && (heff_strEq_c(heff_dup(heff_rfield(v_c_2424, 1)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str8)) && (heff_strEq_c(heff_dup(heff_rfield(v_n_2419, 0)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str9)) || heff_strEq_c(heff_dup(heff_rfield(v_n_2419, 0)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str10)))))));
            if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
              heff_drop_rec(v_o_2414, 9);
              heff_drop(v_t_2430);
              V v_t_2431 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_t_245, 3, 9), heff_get_n(v_c_2424, 4, 9)});
              V v_t_2435;
              if (heff_strEq_c(heff_dup(heff_rfield(v_n_2419, 0)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str11))) {
                V v_t_2433 = ({ V b_0 = heff_get_n(v_n_2419, 1, 9); V r_ = (g_heff_2esyntax_2esurface_2eintOfText(b_0)); heff_drop(b_0); r_; });
                v_t_2435 = heff_tag_n(TAG_SizeNumber, 1, (V[]){v_t_2433});
              } else {
                V v_t_2434 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_n_2419, 3), heff_take_field(v_n_2419, 4)});
                v_t_2435 = heff_tag_n(TAG_SizeName, 3, (V[]){heff_get_n(v_n_2419, 1, 9), v_t_2434, MK_INT(1LL)});
              }
              return heff_tail(((V)&g_heff_2esyntax_2esurface_2esizeSaid_clo), 4, (V[]){v_t_2431, v_t_2435, heff_dup(heff_rfield(v_s_241, 1)), v_s_241});
            } else {
              heff_drop(v_t_2430);
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 1)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str12))) {
                if (heff_strEq_c(heff_get_n(v_o_2414, 1, 9), ((V)&g_heff_2esyntax_2esurface_2especGroup_str13))) {
                  if (heff_strEq_c(heff_dup(heff_rfield(v_c_2424, 1)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str14))) {
                    V v_t_2439 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_t_245, 3, 9), heff_get_n(v_c_2424, 4, 9)});
                    HEFF_LAST return g_heff_2esyntax_2esurface_2eunitOf(v_t_2439, v_n_2419, v_s_241);
                  } else {
                    heff_drop_rec(v_s_241, 5);
                    heff_drop_rec(v_n_2419, 9);
                    return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam4, 1, 2, (V[]){v_t_245, v_c_2424});
                  }
                } else {
                  heff_drop_rec(v_s_241, 5);
                  heff_drop_rec(v_n_2419, 9);
                  return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam5, 1, 2, (V[]){v_t_245, v_c_2424});
                }
              } else {
                heff_drop_rec(v_s_241, 5);
                heff_drop_rec(v_o_2414, 9);
                heff_drop_rec(v_n_2419, 9);
                return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam6, 1, 2, (V[]){v_t_245, v_c_2424});
              }
            }
          }
          case TAG_Cons: {
            heff_take_n(v_x32222_2425, 0ULL, 2);
            heff_drop_rec(v_s_241, 5);
            heff_drop_rec(v_o_2414, 9);
            heff_drop_rec(v_n_2419, 9);
            heff_drop_rec(v_c_2424, 9);
            return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam7, 1, 1, (V[]){v_t_245});
          }
          default: return heff_nomatch(v_x32222_2425);
          }
        }
        default: return heff_nomatch(v_x3222_2420);
        }
      }
      default: return heff_nomatch(v_x322_2415);
      }
    }
    default: return heff_nomatch(v_x32_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2especGroup_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especGroup(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2especGroup_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str0), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_244}), v_st_243});
}
V g_heff_2esyntax_2esurface_2especGroup_lam1(V self, V *args) {
  V v_st_2411 = args[0];
  V v_t_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_245, 3), heff_get_n(v_t_245, 4, 9)});
  V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str3), v_t_2412, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2413}), v_st_2411});
}
V g_heff_2esyntax_2esurface_2especGroup_lam2(V self, V *args) {
  V v_st_2416 = args[0];
  V v_t_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_245, 3), heff_get_n(v_t_245, 4, 9)});
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str4), v_t_2417, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2418}), v_st_2416});
}
V g_heff_2esyntax_2esurface_2especGroup_lam3(V self, V *args) {
  V v_st_2421 = args[0];
  V v_t_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_245, 3), heff_get_n(v_t_245, 4, 9)});
  V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str5), v_t_2422, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2423}), v_st_2421});
}
V g_heff_2esyntax_2esurface_2especGroup_lam4(V self, V *args) {
  V v_st_2440 = args[0];
  V v_t_245 = heff_env(self)[0];
  V v_c_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_t_245, 3, 9), heff_get_n(v_c_2424, 4, 9)});
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str15), v_t_2441, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2442}), v_st_2440});
}
V g_heff_2esyntax_2esurface_2especGroup_lam5(V self, V *args) {
  V v_st_2443 = args[0];
  V v_t_245 = heff_env(self)[0];
  V v_c_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2444 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_t_245, 3, 9), heff_get_n(v_c_2424, 4, 9)});
  V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str16), v_t_2444, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2445}), v_st_2443});
}
V g_heff_2esyntax_2esurface_2especGroup_lam6(V self, V *args) {
  V v_st_2446 = args[0];
  V v_t_245 = heff_env(self)[0];
  V v_c_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2447 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_t_245, 3, 9), heff_get_n(v_c_2424, 4, 9)});
  V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str17), v_t_2447, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2448}), v_st_2446});
}
V g_heff_2esyntax_2esurface_2especGroup_lam7(V self, V *args) {
  V v_st_2451 = args[0];
  V v_t_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2452 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_245, 3), heff_get_n(v_t_245, 4, 9)});
  V v_t_2453 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str18), v_t_2452, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2453}), v_st_2451});
}
Clo g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(V v_st_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_st_240, 0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    return v_st_240;
  }
  case TAG_Cons: {
    heff_take_n(v_t_241, 0ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_st_240, 0));
    V v_t_2413;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nil: {
      v_t_2413 = v_st_240;
      break;
    }
    case TAG_Cons: {
      V v_o_245 = heff_field(v_t_244, 0);
      V v_os_246 = heff_field(v_t_244, 1);
      heff_take_n(v_t_244, 3ULL, 2);
      V v_t_247 = heff_dup(heff_rfield(v_st_240, 1));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nil: {
        heff_drop(v_o_245);
        heff_drop(v_os_246);
        v_t_2413 = v_st_240;
        break;
      }
      case TAG_Cons: {
        V v_r_248 = heff_field(v_t_247, 0);
        V v_it2_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        switch (heff_tag_of(v_it2_249)) {
        case TAG_Nil: {
          heff_drop(v_o_245);
          heff_drop(v_os_246);
          heff_drop(v_r_248);
          v_t_2413 = v_st_240;
          break;
        }
        case TAG_Cons: {
          V v_l_2410 = heff_field(v_it2_249, 0);
          V v_rest_2411 = heff_field(v_it2_249, 1);
          heff_take_n(v_it2_249, 3ULL, 2);
          heff_drop_rec(v_st_240, 2);
          V v_t_2412 = (g_heff_2esyntax_2esurface_2eapplyOp(v_o_245, v_l_2410, v_r_248));
          v_t_2413 = heff_rec_n(2, shape_ops__out, (V[]){v_os_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_rest_2411})});
          break;
        }
        default: heff_nomatch(v_it2_249);
        }
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2413;
    v_st_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(a[0]);
}
Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(V v_e0_240, V v_rest_241, V v_st_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_st_242, 5));
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 6));
  V v_m_245 = (g_heff_2esyntax_2esurface_2echeckFixOf(heff_dup(v_t_243), v_t_244, heff_dup(v_rest_241)));
  V v_x1_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_242}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop(v_e0_240);
      heff_drop(v_rest_241);
      heff_drop(v_t_243);
      heff_drop(v_t_244);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      heff_take_n(v_x11_247, 0ULL, 1);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e0_240), NTAG(TAG_Nil)});
      V v_t_2412 = heff_rec_n(2, shape_ops__out, (V[]){NTAG(TAG_Nil), v_t_2411});
      V v_m_2413 = ({ V a_0 = v_t_243; V a_1 = v_t_244; V a_2 = v_t_2412; V a_3 = v_rest_241; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(a_0, a_1, a_2, a_3)); heff_drop(v_t_244); r_; });
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_248}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_e0_240);
          return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_st_2419 = (g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(v_x_2418));
          V v_t_2420 = heff_get_n(v_st_2419, 1, 2);
          V v_t_2423;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_Nil: {
            v_t_2423 = v_e0_240;
            break;
          }
          case TAG_Cons: {
            V v_x_2421 = heff_field(v_t_2420, 0);
            heff_take_n(v_t_2420, 1ULL, 2);
            heff_drop(v_e0_240);
            v_t_2423 = v_x_2421;
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2423}), v_st_2416});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(heff_dup(v_x_241), v_t_243));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2emutualOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emutualOut_entry, 5, 0};

V g_heff_2esyntax_2esurface_2emutualOut(V v_ksp_240, V v_bsp_241, V v_m_242, V v_k_243, V v_defs_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_246 = (g_list_2emap_24f1744384903x906515519(heff_dup(v_defs_244)));
  V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ESig, 1, (V[]){v_t_246}), heff_dup(v_bsp_241)});
  V v_t_248 = heff_tag_n(TAG_DeclDefine, 5, (V[]){heff_dup(v_m_242), heff_dup(v_ksp_240), NTAG(TAG_Nil), heff_tag_n(TAG_At, 2, (V[]){v_t_245, heff_dup(v_ksp_240)}), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, heff_dup(v_bsp_241)})});
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_m_242)}), heff_dup(v_ksp_240)});
  V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2emutualBody_clo), 2, (V[]){v_t_2410, heff_dup(v_k_243)}));
  V v_t_2412 = (g_heff_2esyntax_2esurface_2erightsOf(heff_dup(v_defs_244)));
  V v_t_2413 = (g_list_2emap(v_t_2411, v_t_2412));
  V v_defs_2414 = (g_heff_2esyntax_2esurface_2erightsOf(heff_dup(v_defs_244)));
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_m_242}), v_ksp_240});
  V v_t_2416 = (g_list_2emap_24s1691485302x273983346(heff_dup(v_k_243), v_defs_2414));
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EStruct, 1, (V[]){v_t_2416}), heff_dup(v_bsp_241)});
  V v_t_2418 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_dup(v_k_243), heff_dup(v_bsp_241), NTAG(TAG_Nil), v_t_2417});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_bsp_241)}), NTAG(TAG_Nil)});
  V v_t_2420 = heff_tag_n(TAG_DeclEquations, 5, (V[]){heff_dup(v_k_243), heff_dup(v_bsp_241), NTAG(TAG_AsDefinition), v_t_2415, v_t_2419});
  V v_t_2421 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_bsp_241})});
  V v_t_2422 = ({ V a_0 = v_k_243; V a_1 = v_defs_244; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119(a_0, a_1)); heff_drop(v_defs_244); r_; });
  V v_t_2423 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2422})));
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2423});
}
V g_heff_2esyntax_2esurface_2emutualOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emutualOut(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esyntax_2esurface_2efixDecls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixDecls_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixDecls(V v_ts_240, V v_box_24k_241, V v_acc_242) {
  int64_t v_k_241 = heff_unbox_word(v_box_24k_241);
top: ;
  if ((((int64_t)0ULL) <= v_k_241)) {
    if ((v_k_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
      V v_t_245 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_k_241), 2);
      HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2efixDeclAt_24cpr(v_ts_240, heff_box_word(v_k_241), v_t_245));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_d_2410 = v_field_248;
          V t_0 = v_ts_240;
          int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2410, v_acc_242});
          v_ts_240 = t_0;
          v_k_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        } else {
          heff_drop(v_field_248);
          V t_0 = v_ts_240;
          int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
          V t_2 = v_acc_242;
          v_ts_240 = t_0;
          v_k_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        }
      }
    } else {
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    }
  } else {
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
}
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efixDecls(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_xs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_xs_243;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = (g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str2, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str3, 3, "con");
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(V v_ys_240, V v_pv_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_PCon: {
    V v_args_244 = heff_field(v_x2_242, 1);
    V v_t_246 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam0, 1, 1, (V[]){heff_dup(v_pv_241)}), v_args_244));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_246, v_ys_240));
  }
  case TAG_PAtom: {
    V v_t_247 = heff_field(v_x2_242, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str0))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 1)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str1))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str2))) {
          V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_247, 1))}));
          V v_t_2412 = (g_list_2eany(v_t_2411, v_pv_241));
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_t_2412);
            V v_x_2413 = heff_dup(heff_rfield(v_t_247, 1));
            V v_t_2414 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
            return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_t_2414});
          } else {
            heff_drop(v_t_2412);
            return v_ys_240;
          }
        } else {
          return v_ys_240;
        }
      } else {
        V v_x_2415 = heff_dup(heff_rfield(v_t_247, 1));
        V v_t_2416 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
        return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_t_2416});
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str3))) {
        V v_t_2418 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_247, 1))}));
        V v_t_2419 = (g_list_2eany(v_t_2418, v_pv_241));
        if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
          heff_drop(v_t_2419);
          V v_x_2420 = heff_dup(heff_rfield(v_t_247, 1));
          V v_t_2421 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
          return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2420, v_t_2421});
        } else {
          heff_drop(v_t_2419);
          return v_ys_240;
        }
      } else {
        return v_ys_240;
      }
    }
  }
  case TAG_PParen: {
    V v_q_2423 = heff_field(v_x2_242, 1);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2423;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2426 = heff_field(v_x2_242, 1);
    V v_t_2430 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam1, 1, 1, (V[]){heff_dup(v_pv_241)}), v_ps_2426));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2430, v_ys_240));
  }
  case TAG_POp: {
    V v_l_2431 = heff_field(v_x2_242, 0);
    V v_q_2433 = heff_field(v_x2_242, 2);
    V v_t_2434 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_l_2431));
    V v_t_2435 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_q_2433));
    V v_t_2436 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2434, v_t_2435));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2436, v_ys_240));
  }
  case TAG_PRec: {
    V v_fs_2438 = heff_field(v_x2_242, 1);
    V v_t_2442 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam2, 1, 1, (V[]){heff_dup(v_pv_241)}), v_fs_2438));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2442, v_ys_240));
  }
  case TAG_PField: {
    V v_q_2445 = heff_field(v_x2_242, 2);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2445;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2446 = heff_field(v_x2_242, 0);
    V v_q_2448 = heff_field(v_x2_242, 2);
    V v_x_2449 = heff_dup(heff_rfield(v_x_2446, 1));
    V v_cell_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2449, heff_hole()});
    V v_u_2451 = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(v_ys_240, v_pv_241, v_q_2448, heff_dup(v_cell_2450)));
    heff_drop(v_u_2451);
    return v_cell_2450;
  }
  case TAG_PSeg: {
    V v_q_2452 = heff_field(v_x2_242, 0);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2452;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam0(V self, V *args) {
  V v_q_245 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_245; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_245); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam1(V self, V *args) {
  V v_q_2429 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2429; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2429); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam2(V self, V *args) {
  V v_q_2441 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2441; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2441); r_; });
}