// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AsDefinition 21504
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Doc 16324
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_FloatValue 23118
#define TAG_IntValue 62477
#define TAG_Left 13886
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatRecord 42380
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_Sig 30557
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StrValue 22621
#define TAG_TypeWord 10401
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_arms 9498206
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binders 123633223
#define LBL_cmt 308164
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_i 323
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_little 844663329
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_open 9913105
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_toks 10061290
#define LBL_ty 10476
#define LBL_unit 10090059
static uint32_t shape_above__below__loosest__errors[] = {LBL_above, LBL_below, LBL_loosest, LBL_errors};
static uint32_t shape_assoc__ops__above__below__loosest__errors__span__line[] = {LBL_assoc, LBL_ops, LBL_above, LBL_below, LBL_loosest, LBL_errors, LBL_span, LBL_line};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_eqns__end[] = {LBL_eqns, LBL_end};
static uint32_t shape_fixities__diags[] = {LBL_fixities, LBL_diags};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_op__e[] = {LBL_op, LBL_e};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot__arms[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot, LBL_arms};
static uint32_t shape_ty__size__unit__little__signed[] = {LBL_ty, LBL_size, LBL_unit, LBL_little, LBL_signed};
V g_heff_2esyntax_2ecst_2efirstP(V);
V g_heff_2esyntax_2ecst_2efirstP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstP_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2elastP(V);
V g_heff_2esyntax_2ecst_2elastP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastP_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2esurface_2eabGo(V, V);
V g_heff_2esyntax_2esurface_2eabGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eabGo_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V, V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
HeffT3 g_heff_2esyntax_2esurface_2edecimalOfDigits_24cpr(V);
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2edropN(V, V);
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edropN_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixitiesOfText(V, V);
V g_heff_2esyntax_2esurface_2efixitiesOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixitiesOfText_clo;
V g_heff_2esyntax_2esurface_2efixityFrom(V, V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_clo;
HeffT2 g_heff_2esyntax_2esurface_2efixityFrom_24cpr(V, V, V);
double g_heff_2esyntax_2esurface_2efloatOfText_w(V);
V g_heff_2esyntax_2esurface_2efloatOfText(V);
V g_heff_2esyntax_2esurface_2efloatOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfText_clo;
V g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664(V, V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eisVarE(V);
V g_heff_2esyntax_2esurface_2eisVarE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisVarE_clo;
V g_heff_2esyntax_2esurface_2eknotOf(V, V);
V g_heff_2esyntax_2esurface_2eknotOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eknotOf_clo;
V g_heff_2esyntax_2esurface_2elastEnd(V, V);
V g_heff_2esyntax_2esurface_2elastEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elastEnd_clo;
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletL_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emutualBody(V, V, V);
V g_heff_2esyntax_2esurface_2emutualBody_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualBody_clo;
HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualOut_clo;
V g_heff_2esyntax_2esurface_2epatL(V, V, V);
V g_heff_2esyntax_2esurface_2epatL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatL_clo;
V g_heff_2esyntax_2esurface_2epatSegmentsL(V, V);
V g_heff_2esyntax_2esurface_2epatSegmentsL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentsL_clo;
V g_heff_2esyntax_2esurface_2epatTok(V);
V g_heff_2esyntax_2esurface_2epatTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatTok_clo;
HeffT2 g_heff_2esyntax_2esurface_2epchainOf_24cpr(V);
HeffT2 g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_clo;
V g_heff_2esyntax_2esurface_2erestOfDecl(V, V, V);
V g_heff_2esyntax_2esurface_2erestOfDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erestOfDecl_clo;
V g_heff_2esyntax_2esurface_2erightsOf(V);
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_clo;
V g_heff_2esyntax_2esurface_2esetKnot(V, V);
V g_heff_2esyntax_2esurface_2esetKnot_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetKnot_clo;
V g_heff_2esyntax_2esurface_2esetScope(V, V);
V g_heff_2esyntax_2esurface_2esetScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetScope_clo;
V g_heff_2esyntax_2esurface_2eshortcut(V, V, V, V);
V g_heff_2esyntax_2esurface_2eshortcut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eshortcut_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2esizeSaid(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esizeSaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esizeSaid_clo;
V g_heff_2esyntax_2esurface_2especGroup(V, V, V);
V g_heff_2esyntax_2esurface_2especGroup_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroup_clo;
V g_heff_2esyntax_2esurface_2especGroups(V, V, V);
V g_heff_2esyntax_2esurface_2especGroups_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroups_clo;
V g_heff_2esyntax_2esurface_2especGroupsOf(V, V, V);
V g_heff_2esyntax_2esurface_2especGroupsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroupsOf_clo;
V g_heff_2esyntax_2esurface_2especWord(V, V, V);
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especWord_clo;
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
V g_heff_2esyntax_2esurface_2etakeSyms(V);
V g_heff_2esyntax_2esurface_2etakeSyms_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_clo;
V g_heff_2esyntax_2esurface_2etuplePRev(V, V);
V g_heff_2esyntax_2esurface_2etuplePRev_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etuplePRev_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24rec0_get(void);
V g_list_2eany_24s565534491x447967237(V, V);
V g_list_2eany_24s565534491x447967237_entry(V self, V *a);
extern Clo g_list_2eany_24s565534491x447967237_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f158727028x1528233175(V, V, V);
V g_list_2efoldl_24f158727028x1528233175_entry(V self, V *a);
extern Clo g_list_2efoldl_24f158727028x1528233175_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1744384903x906515519(V);
V g_list_2emap_24f1744384903x906515519_entry(V self, V *a);
extern Clo g_list_2emap_24f1744384903x906515519_clo;
V g_list_2emap_24s1691485302x273983346(V, V);
V g_list_2emap_24s1691485302x273983346_entry(V self, V *a);
extern Clo g_list_2emap_24s1691485302x273983346_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
Clo g_heff_2esyntax_2esurface_2esetScope_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esetScope_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esetScope(V v_sc_240, V v_s_241) {
top: ;
  V v_known_242 = heff_take_field(v_s_241, 2);
  V v_binders_243 = heff_take_field(v_s_241, 3);
  V v_patVars_244 = heff_take_field(v_s_241, 4);
  V v_fix_245 = heff_take_field(v_s_241, 5);
  V v_lenient_246 = heff_take_field(v_s_241, 6);
  V v_at_247 = heff_take_field(v_s_241, 7);
  V v_knot_248 = heff_take_field(v_s_241, 8);
  V v_arms_249 = heff_take_field(v_s_241, 9);
  return ({ V rv_1 = v_sc_240; V rv_2 = v_known_242; V rv_3 = v_binders_243; V rv_4 = v_patVars_244; V rv_5 = v_fix_245; V rv_6 = v_lenient_246; V rv_7 = v_at_247; V rv_8 = v_knot_248; V rv_9 = v_arms_249; V rr_ = heff_rec_reuse_nf(v_s_241, 1ULL, 10, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot__arms, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2esyntax_2esurface_2esetScope_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esetScope(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efloatOfText_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2efloatOfText_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2efloatOfText_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2efloatOfText_str3, 0, "");
Clo g_heff_2esyntax_2esurface_2efloatOfText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efloatOfText_entry, 1, 0};

double g_heff_2esyntax_2esurface_2efloatOfText_w(V v_s_240) {
top: ;
  V v_x2_241 = ({ V a_0 = v_s_240; V b_1 = ((V)&g_heff_2esyntax_2esurface_2efloatOfText_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2efloatOfText_str1), v_s_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  V v_t_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2esyntax_2esurface_2efloatOfText_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurface_2efloatOfText_str3); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  HeffT3 v_t_245 = ({ V a_0 = v_t_244; HeffT3 r_ = (g_heff_2esyntax_2esurface_2edecimalOfDigits_24cpr(a_0)); heff_drop(v_t_244); r_; });
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_field_248 = v_t_245.f[2];
    V v_t_249 = v_field_246;
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      double v_x_2410 = (g_std_2emath_2efromDecimal_w(v_field_247, v_field_248));
      return ((-1.0) * v_x_2410);
    } else {
      heff_drop(v_t_249);
      return (g_std_2emath_2efromDecimal_w(v_field_247, v_field_248));
    }
  }
}
V g_heff_2esyntax_2esurface_2efloatOfText(V v_s_240) {
  return heff_box_f64((g_heff_2esyntax_2esurface_2efloatOfText_w(v_s_240)));
}
V g_heff_2esyntax_2esurface_2efloatOfText_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efloatOfText(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2eisVarE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eisVarE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eisVarE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_False);
    }
    case TAG_ENotationVar: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      return NTAG(TAG_False);
    }
    case TAG_EBinary: {
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      return NTAG(TAG_False);
    }
    case TAG_ESpec: {
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      return NTAG(TAG_False);
    }
    case TAG_EWhile: {
      return NTAG(TAG_False);
    }
    case TAG_EFor: {
      return NTAG(TAG_False);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_False);
    }
    case TAG_EBreak: {
      return NTAG(TAG_False);
    }
    case TAG_EContinue: {
      return NTAG(TAG_False);
    }
    case TAG_EReturn: {
      return NTAG(TAG_False);
    }
    case TAG_ENest: {
      return NTAG(TAG_False);
    }
    case TAG_ELazy: {
      return NTAG(TAG_False);
    }
    case TAG_ETuple: {
      return NTAG(TAG_False);
    }
    case TAG_ETry: {
      return NTAG(TAG_False);
    }
    case TAG_EWith: {
      return NTAG(TAG_False);
    }
    case TAG_EWithBound: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eisVarE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eisVarE(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eapplyOp_str0, 2, "&&");
HEFF_LIT(g_heff_2esyntax_2esurface_2eapplyOp_str1, 5, "False");
HEFF_LIT(g_heff_2esyntax_2esurface_2eapplyOp_str2, 2, "||");
HEFF_LIT(g_heff_2esyntax_2esurface_2eapplyOp_str3, 4, "True");
Clo g_heff_2esyntax_2esurface_2eapplyOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eapplyOp_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eapplyOp(V v_op_240, V v_l_241, V v_r_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_op_240, 1)), ((V)&g_heff_2esyntax_2esurface_2eapplyOp_str0))) {
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_op_240, 3)), heff_dup(heff_rfield(v_op_240, 4))});
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eapplyOp_str1)}), v_t_243});
    return (g_heff_2esyntax_2esurface_2eshortcut(v_op_240, v_l_241, v_r_242, v_t_244));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_op_240, 1)), ((V)&g_heff_2esyntax_2esurface_2eapplyOp_str2))) {
      V v_t_245 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_op_240, 3)), heff_dup(heff_rfield(v_op_240, 4))});
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eapplyOp_str3)}), v_t_245});
      return (g_heff_2esyntax_2esurface_2eshortcut(v_op_240, v_l_241, v_t_246, v_r_242));
    } else {
      V v_t_247 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_op_240, 1)});
      V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_240, 3), heff_get_n(v_op_240, 4, 9)});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_t_248}), heff_tag_n(TAG_Cons, 2, (V[]){v_l_241, v_t_249})));
    }
  }
}
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eapplyOp(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Sig: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Eqn: {
      V v_g_249 = heff_field(v_x21_242, 0);
      V v_e_2410 = heff_field(v_x21_242, 1);
      V v_esp_2411 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      if (heff_strEq_c_lent(v_f_240, v_g_249, 2)) {
        HeffT2 v_t_2412 = (g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(v_f_240, v_rest_243));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          V v_t_2422;
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            V v_rest_2415 = v_field_2414;
            V v_end_2416 = heff_take_field(v_rest_2415, 1);
            V v_eqns_2417 = heff_take_field(v_rest_2415, 0);
            V v_a_2418 = heff_get_n(v_esp_2411, 1, 2);
            V v_b_2419 = v_end_2416;
            V v_t_2420;
            if (heff_intLt_c_lent(v_a_2418, v_b_2419, 0)) {
              heff_drop(v_a_2418);
              v_t_2420 = v_b_2419;
            } else {
              heff_drop(v_b_2419);
              v_t_2420 = v_a_2418;
            }
            v_t_2422 = ({ V rv_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2410, v_eqns_2417}); V rv_1 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_rest_2415, 0ULL, 2, shape_eqns__end, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          } else {
            heff_drop(v_field_2414);
            V v_t_2421 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2410, NTAG(TAG_Nil)});
            v_t_2422 = heff_rec_n(2, shape_eqns__end, (V[]){v_t_2421, heff_get_n(v_esp_2411, 1, 2)});
          }
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2422}});
        }
      } else {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_e_2410);
        heff_drop_rec(v_esp_2411, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_Whole: {
      V v_d_2423 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      switch (heff_tag_of(v_d_2423)) {
      case TAG_At: {
        V v_x11_2424 = heff_field(v_d_2423, 0);
        heff_take_n(v_d_2423, 1ULL, 2);
        switch (heff_tag_of(v_x11_2424)) {
        case TAG_DeclEquations: {
          heff_take_n(v_x11_2424, 0ULL, 5);
          heff_drop(v_rest_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_DeclDefine: {
          heff_take_n(v_x11_2424, 0ULL, 5);
          heff_drop(v_rest_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_DeclTheory: {
          heff_take_n(v_x11_2424, 0ULL, 4);
          heff_drop(v_rest_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_x11_2424, 0ULL, 3);
          heff_drop(v_rest_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_DeclTest: {
          heff_take_n(v_x11_2424, 0ULL, 2);
          V t_0 = v_f_240;
          V t_1 = v_rest_243;
          v_f_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_x11_2424, 0ULL, 1);
          V t_0 = v_f_240;
          V t_1 = v_rest_243;
          v_f_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2424)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_d_2423)}});
      }
    }
    case TAG_Doc: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_rest_243;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2esyntax_2esurface_2esigNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esigNames_entry, 1, 0};

V g_heff_2esyntax_2esurface_2esigNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_std_2eordmap_2eempty_get());
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Sig: {
      V v_f_244 = heff_field(v_x11_241, 1);
      V v_t_248 = (g_heff_2esyntax_2esurface_2esigNames(v_rest_242));
      return (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_248, heff_dup(v_f_244), NTAG(TAG_MkUnit)));
    }
    case TAG_Eqn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Whole: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Doc: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esigNames(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2eletL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eletL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eletL(V v_r_240, V v_x2_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2eletL_24cpr(v_r_240, v_x2_241, v_z_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eletL(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroups_str0, 1, "-");
Clo g_heff_2esyntax_2esurface_2especGroups_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especGroups_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especGroups(V v_x1_240, V v_cur_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cur_241));
    V v_xs_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_acc_242});
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
  }
  case TAG_Cons: {
    V v_t_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 1)), ((V)&g_heff_2esyntax_2esurface_2especGroups_str0))) {
      heff_drop_rec(v_t_245, 9);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cur_241));
      V t_0 = v_rest_246;
      V t_1 = NTAG(TAG_Nil);
      V t_2 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
      v_x1_240 = t_0;
      v_cur_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      V t_0 = v_rest_246;
      V t_1 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_t_245, v_cur_241});
      V t_2 = v_acc_242;
      v_x1_240 = t_0;
      v_cur_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2especGroups_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especGroups(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str0, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str1, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str2, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str3, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str4, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str5, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str6, 4, "size");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str7, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str9, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str10, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str11, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str12, 4, "unit");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str13, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str15, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str16, 28, "a segment says its unit once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str17, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str18, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2especGroup_str19, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
V g_heff_2esyntax_2esurface_2especGroup_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroup_lam7(V self, V *args);
Clo g_heff_2esyntax_2esurface_2especGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especGroup_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especGroup(V v_sp_240, V v_s_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_s_241, 5);
    return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam0, 1, 1, (V[]){v_sp_240});
  }
  case TAG_Cons: {
    V v_t_245 = heff_field(v_x3_242, 0);
    V v_x32_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    heff_drop(v_sp_240);
    switch (heff_tag_of(v_x32_246)) {
    case TAG_Nil: {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str1))) {
        V v_t_247 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_t_245, 1)));
        V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_245, 3), heff_get_n(v_t_245, 4, 9)});
        return heff_tail(((V)&g_heff_2esyntax_2esurface_2esizeSaid_clo), 4, (V[]){v_t_248, heff_tag_n(TAG_SizeNumber, 1, (V[]){v_t_247}), heff_dup(heff_rfield(v_s_241, 1)), v_s_241});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str2))) {
          return heff_tail(((V)&g_heff_2esyntax_2esurface_2especWord_clo), 2, (V[]){v_t_245, v_s_241});
        } else {
          heff_drop_rec(v_s_241, 5);
          return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam1, 1, 1, (V[]){v_t_245});
        }
      }
    }
    case TAG_Cons: {
      V v_o_2412 = heff_field(v_x32_246, 0);
      V v_x322_2413 = heff_field(v_x32_246, 1);
      heff_take_n(v_x32_246, 3ULL, 2);
      switch (heff_tag_of(v_x322_2413)) {
      case TAG_Nil: {
        heff_drop_rec(v_s_241, 5);
        heff_drop_rec(v_o_2412, 9);
        return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam2, 1, 1, (V[]){v_t_245});
      }
      case TAG_Cons: {
        V v_n_2417 = heff_field(v_x322_2413, 0);
        V v_x3222_2418 = heff_field(v_x322_2413, 1);
        heff_take_n(v_x322_2413, 3ULL, 2);
        switch (heff_tag_of(v_x3222_2418)) {
        case TAG_Nil: {
          heff_drop_rec(v_s_241, 5);
          heff_drop_rec(v_o_2412, 9);
          heff_drop_rec(v_n_2417, 9);
          return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam3, 1, 1, (V[]){v_t_245});
        }
        case TAG_Cons: {
          V v_c_2422 = heff_field(v_x3222_2418, 0);
          V v_x32222_2423 = heff_field(v_x3222_2418, 1);
          heff_take_n(v_x3222_2418, 3ULL, 2);
          V v_text_2424 = heff_take_field(v_c_2422, 1);
          V v_end_2425 = heff_get_n(v_c_2422, 4, 9);
          switch (heff_tag_of(v_x32222_2423)) {
          case TAG_Nil: {
            if ((heff_strEq_c(heff_dup(heff_rfield(v_t_245, 1)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str6)) && (heff_strEq_c(heff_dup(heff_rfield(v_o_2412, 1)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str7)) && (heff_strEq_c_lent(v_text_2424, ((V)&g_heff_2esyntax_2esurface_2especGroup_str8), 2) && (heff_strEq_c(heff_dup(heff_rfield(v_n_2417, 0)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str9)) || heff_strEq_c(heff_dup(heff_rfield(v_n_2417, 0)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str10))))))) {
              heff_drop_rec(v_o_2412, 9);
              heff_drop(v_text_2424);
              V v_t_2428;
              if (heff_strEq_c(heff_dup(heff_rfield(v_n_2417, 0)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str11))) {
                V v_t_2426 = ({ V b_0 = heff_get_n(v_n_2417, 1, 9); V r_ = (g_heff_2esyntax_2esurface_2eintOfText(b_0)); heff_drop(b_0); r_; });
                v_t_2428 = heff_tag_n(TAG_SizeNumber, 1, (V[]){v_t_2426});
              } else {
                V v_t_2427 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_n_2417, 3), heff_take_field(v_n_2417, 4)});
                v_t_2428 = heff_tag_n(TAG_SizeName, 3, (V[]){heff_get_n(v_n_2417, 1, 9), v_t_2427, MK_INT(1LL)});
              }
              V v_t_2429 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_t_245, 3, 9), v_end_2425});
              return heff_tail(((V)&g_heff_2esyntax_2esurface_2esizeSaid_clo), 4, (V[]){v_t_2429, v_t_2428, heff_dup(heff_rfield(v_s_241, 1)), v_s_241});
            } else {
              if ((heff_strEq_c(heff_dup(heff_rfield(v_t_245, 1)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str12)) && (heff_strEq_c(heff_dup(heff_rfield(v_o_2412, 1)), ((V)&g_heff_2esyntax_2esurface_2especGroup_str13)) && heff_strEq_c_lent(v_text_2424, ((V)&g_heff_2esyntax_2esurface_2especGroup_str14), 2)))) {
                heff_drop_rec(v_o_2412, 9);
                heff_drop(v_text_2424);
                V v_sp_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_t_245, 3, 9), v_end_2425});
                V v_n_2431 = v_n_2417;
                V v_kind_2432 = heff_take_field(v_n_2431, 0);
                V v_text_2433 = heff_get_n(v_n_2431, 1, 9);
                V v_s_2434 = v_s_241;
                if ((heff_strEq_c_lent(v_kind_2432, ((V)&g_heff_2esyntax_2esurface_2especGroup_str15), 2) && ({ V v_t_2451 = (g_heff_2esyntax_2esurface_2eintOfText(v_text_2433)); int c_ = (heff_intLe_c_lent(MK_INT(1LL), v_t_2451, 1) && ({ V v_t_2452 = (g_heff_2esyntax_2esurface_2eintOfText(v_text_2433)); int c_ = heff_intLe_c_lent(v_t_2452, MK_INT(256LL), 2); heff_drop(v_t_2452); c_; })); heff_drop(v_t_2451); c_; }))) {
                  heff_drop(v_kind_2432);
                  V v_n_2435 = ({ V a_0 = v_text_2433; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_text_2433); r_; });
                  return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam4, 1, 3, (V[]){v_s_2434, v_n_2435, v_sp_2430});
                } else {
                  heff_drop(v_kind_2432);
                  heff_drop(v_text_2433);
                  heff_drop_rec(v_s_2434, 5);
                  return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam5, 1, 1, (V[]){v_sp_2430});
                }
              } else {
                heff_drop_rec(v_s_241, 5);
                heff_drop_rec(v_o_2412, 9);
                heff_drop_rec(v_n_2417, 9);
                heff_drop(v_text_2424);
                return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam6, 1, 2, (V[]){v_t_245, v_end_2425});
              }
            }
          }
          case TAG_Cons: {
            heff_take_n(v_x32222_2423, 0ULL, 2);
            heff_drop_rec(v_s_241, 5);
            heff_drop_rec(v_o_2412, 9);
            heff_drop_rec(v_n_2417, 9);
            heff_drop(v_text_2424);
            heff_drop(v_end_2425);
            return heff_clo_n(g_heff_2esyntax_2esurface_2especGroup_lam7, 1, 1, (V[]){v_t_245});
          }
          default: return heff_nomatch(v_x32222_2423);
          }
        }
        default: return heff_nomatch(v_x3222_2418);
        }
      }
      default: return heff_nomatch(v_x322_2413);
      }
    }
    default: return heff_nomatch(v_x32_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2especGroup_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especGroup(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2especGroup_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str0), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_244}), v_st_243});
}
V g_heff_2esyntax_2esurface_2especGroup_lam1(V self, V *args) {
  V v_st_249 = args[0];
  V v_t_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_245, 3), heff_get_n(v_t_245, 4, 9)});
  V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str3), v_t_2410, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2411}), v_st_249});
}
V g_heff_2esyntax_2esurface_2especGroup_lam2(V self, V *args) {
  V v_st_2414 = args[0];
  V v_t_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_245, 3), heff_get_n(v_t_245, 4, 9)});
  V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str4), v_t_2415, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2416}), v_st_2414});
}
V g_heff_2esyntax_2esurface_2especGroup_lam3(V self, V *args) {
  V v_st_2419 = args[0];
  V v_t_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_245, 3), heff_get_n(v_t_245, 4, 9)});
  V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str5), v_t_2420, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2421}), v_st_2419});
}
V g_heff_2esyntax_2esurface_2especGroup_lam4(V self, V *args) {
  V v_p_2436 = args[0];
  V v_s_2434 = heff_env(self)[0];
  V v_n_2435 = heff_env(self)[1];
  V v_sp_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2437 = heff_take_field(v_s_2434, 2);
  switch (heff_tag_of(v_t_2437)) {
  case TAG_Nothing: {
    heff_drop_rec(v_sp_2430, 2);
    V v_t_2438 = ({ V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_n_2435}); V rr_ = heff_rec_reuse_nf(v_s_2434, 27ULL, 5, shape_ty__size__unit__little__signed, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2438}), v_p_2436});
  }
  case TAG_Just: {
    V v_ru_24t_2437_24Just = heff_take_reuse_n(v_t_2437, 0ULL, 1);
    heff_drop_rec(v_s_2434, 5);
    heff_drop(v_n_2435);
    V v_t_2440 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str16), v_sp_2430, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2437_24Just, TAG_Left, 1, (V[]){v_t_2440}), v_p_2436});
  }
  default: return heff_nomatch(v_t_2437);
  }
}
V g_heff_2esyntax_2esurface_2especGroup_lam5(V self, V *args) {
  V v_st_2441 = args[0];
  V v_sp_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str17), v_sp_2430, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2442}), v_st_2441});
}
V g_heff_2esyntax_2esurface_2especGroup_lam6(V self, V *args) {
  V v_st_2443 = args[0];
  V v_t_245 = heff_env(self)[0];
  V v_end_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2444 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_t_245, 3, 9), v_end_2425});
  V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str18), v_t_2444, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2445}), v_st_2443});
}
V g_heff_2esyntax_2esurface_2especGroup_lam7(V self, V *args) {
  V v_st_2448 = args[0];
  V v_t_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_245, 3), heff_get_n(v_t_245, 4, 9)});
  V v_t_2450 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especGroup_str19), v_t_2449, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2450}), v_st_2448});
}
V g_heff_2esyntax_2esurface_2especGroupsOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2especGroupsOf_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2especGroupsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especGroupsOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especGroupsOf(V v_sp_240, V v_s_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2especGroupsOf_lam0, 1, 1, (V[]){v_s_241});
  }
  case TAG_Cons: {
    V v_g_244 = heff_field(v_x3_242, 0);
    V v_gs_245 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_246 = heff_tr(g_heff_2esyntax_2esurface_2especGroup(heff_dup(v_sp_240), v_s_241, v_g_244));
    return heff_clo_n(g_heff_2esyntax_2esurface_2especGroupsOf_lam1, 1, 3, (V[]){v_m_246, v_sp_240, v_gs_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2especGroupsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especGroupsOf(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2especGroupsOf_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_s_241}), v_st_243});
}
V g_heff_2esyntax_2esurface_2especGroupsOf_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_gs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop(v_sp_240);
      heff_drop(v_gs_245);
      return heff_tag_re_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_249_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_248_24MkPair, 2);
      V v_t_2413 = (g_heff_2esyntax_2esurface_2especGroupsOf(v_sp_240, v_x_2412, v_gs_245));
      V f_ = v_t_2413;
      args[0] = v_st_2410;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str0, 53, "a string's segment is its bytes, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str1, 53, "a string's segment is its bytes, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str2, 53, "a string's segment is its bytes, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str3, 53, "a string's segment is its bytes, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str4, 48, "a number's segment is an integer: `1`, `258::16`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str5, 48, "a number's segment is an integer: `1`, `258::16`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str6, 48, "a number's segment is an integer: `1`, `258::16`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str7, 27, " is no Unicode scalar value");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str8, 42, "a float's segment is a float: `1.5::float`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str9, 42, "a float's segment is a float: `1.5::float`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str10, 42, "a float's segment is a float: `1.5::float`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str11, 42, "a float's segment is a float: `1.5::float`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str12, 46, "a rune's segment is a code point: `'\303\251'::utf8`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str13, 46, "a rune's segment is a code point: `'\303\251'::utf8`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str14, 46, "a rune's segment is a code point: `'\303\251'::utf8`");
HEFF_LIT(g_heff_2esyntax_2esurface_2evalueKind_24cpr_str15, 46, "a rune's segment is a code point: `'\303\251'::utf8`");

HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V v_sp_240, V v_v_241, V v_ty_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_StrValue: {
    switch (heff_tag_of(v_ty_242)) {
    case TAG_SegmentInteger: {
      V v_t_244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str0), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_244}), v_p_243}});
    }
    case TAG_SegmentBinary: {
      heff_drop(v_sp_240);
      V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return ((HeffT2){{v_t_245, v_p_243}});
    }
    case TAG_SegmentBits: {
      V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str1), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_246}), v_p_243}});
    }
    case TAG_SegmentFloat: {
      V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str2), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_247}), v_p_243}});
    }
    case TAG_SegmentUtf: {
      V v_ru_24ty_242_24SegmentUtf = heff_take_reuse_n(v_ty_242, 0ULL, 1);
      V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str3), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_Left, 1, (V[]){v_t_249}), v_p_243}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ty_242)}});
    }
  }
  case TAG_IntValue: {
    V v_c_2410 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24IntValue = heff_take_reuse_n(v_v_241, 1ULL, 1);
    switch (heff_tag_of(v_ty_242)) {
    case TAG_SegmentInteger: {
      heff_drop(v_sp_240);
      heff_drop(v_c_2410);
      V v_t_2411 = heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return ((HeffT2){{v_t_2411, v_p_243}});
    }
    case TAG_SegmentBinary: {
      heff_drop(v_c_2410);
      V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str4), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Left, 1, (V[]){v_t_2412}), v_p_243}});
    }
    case TAG_SegmentBits: {
      heff_drop(v_c_2410);
      V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str5), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Left, 1, (V[]){v_t_2413}), v_p_243}});
    }
    case TAG_SegmentFloat: {
      heff_drop(v_c_2410);
      V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str6), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Left, 1, (V[]){v_t_2414}), v_p_243}});
    }
    case TAG_SegmentUtf: {
      heff_take_n(v_ty_242, 0ULL, 1);
      if ((heff_intLe_c_lent(MK_INT(0LL), v_c_2410, 1) && (heff_intLe_c_lent(v_c_2410, MK_INT(1114111LL), 2) && ((((int64_t)55296ULL) <= heff_peek_word(v_c_2410)) ? !(heff_peek_word(v_c_2410) <= ((int64_t)57343ULL)) : 1)))) {
        heff_drop(v_sp_240);
        heff_drop(v_c_2410);
        V v_t_2416 = heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        return ((HeffT2){{v_t_2416, v_p_243}});
      } else {
        V v_t_2417 = heff_strAppend(heff_intShow(v_c_2410), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str7));
        V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2417, v_sp_240, NTAG(TAG_Nothing)});
        V v_f_2419 = heff_tag_at_n(v_ru_24v_241_24IntValue, TAG_Left, 1, (V[]){v_t_2418});
        return ((HeffT2){{v_f_2419, v_p_243}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_ty_242)}});
    }
  }
  case TAG_FloatValue: {
    switch (heff_tag_of(v_ty_242)) {
    case TAG_SegmentInteger: {
      V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str8), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2420}), v_p_243}});
    }
    case TAG_SegmentBinary: {
      V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str9), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2421}), v_p_243}});
    }
    case TAG_SegmentBits: {
      V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str10), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2422}), v_p_243}});
    }
    case TAG_SegmentFloat: {
      heff_drop(v_sp_240);
      V v_t_2423 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return ((HeffT2){{v_t_2423, v_p_243}});
    }
    case TAG_SegmentUtf: {
      V v_ru_24ty_242_24SegmentUtf = heff_take_reuse_n(v_ty_242, 0ULL, 1);
      V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str11), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_Left, 1, (V[]){v_t_2425}), v_p_243}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ty_242)}});
    }
  }
  case TAG_RuneValue: {
    switch (heff_tag_of(v_ty_242)) {
    case TAG_SegmentInteger: {
      V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str12), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2426}), v_p_243}});
    }
    case TAG_SegmentBinary: {
      V v_t_2427 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str13), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2427}), v_p_243}});
    }
    case TAG_SegmentBits: {
      V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str14), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2428}), v_p_243}});
    }
    case TAG_SegmentFloat: {
      V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2evalueKind_24cpr_str15), v_sp_240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2429}), v_p_243}});
    }
    case TAG_SegmentUtf: {
      V v_ru_24ty_242_24SegmentUtf = heff_take_reuse_n(v_ty_242, 0ULL, 1);
      heff_drop(v_sp_240);
      V v_t_2431 = heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return ((HeffT2){{v_t_2431, v_p_243}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ty_242)}});
    }
  }
  case TAG_OtherValue: {
    heff_drop(v_sp_240);
    heff_drop(v_ty_242);
    V v_t_2432 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return ((HeffT2){{v_t_2432, v_p_243}});
  }
  default: return ((HeffT2){{heff_nomatch(v_v_241)}});
  }
}
Clo g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(V v_st_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_st_240, 0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    return v_st_240;
  }
  case TAG_Cons: {
    heff_take_n(v_t_241, 0ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_st_240, 0));
    V v_t_2413;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nil: {
      v_t_2413 = v_st_240;
      break;
    }
    case TAG_Cons: {
      V v_o_245 = heff_field(v_t_244, 0);
      V v_os_246 = heff_field(v_t_244, 1);
      heff_take_n(v_t_244, 3ULL, 2);
      V v_t_247 = heff_dup(heff_rfield(v_st_240, 1));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nil: {
        heff_drop(v_o_245);
        heff_drop(v_os_246);
        v_t_2413 = v_st_240;
        break;
      }
      case TAG_Cons: {
        V v_r_248 = heff_field(v_t_247, 0);
        V v_it2_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        switch (heff_tag_of(v_it2_249)) {
        case TAG_Nil: {
          heff_drop(v_o_245);
          heff_drop(v_os_246);
          heff_drop(v_r_248);
          v_t_2413 = v_st_240;
          break;
        }
        case TAG_Cons: {
          V v_l_2410 = heff_field(v_it2_249, 0);
          V v_rest_2411 = heff_field(v_it2_249, 1);
          heff_take_n(v_it2_249, 3ULL, 2);
          V v_t_2412 = (g_heff_2esyntax_2esurface_2eapplyOp(v_o_245, v_l_2410, v_r_248));
          v_t_2413 = ({ V rv_0 = v_os_246; V rv_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_rest_2411}); V rr_ = heff_rec_reuse_nf(v_st_240, 0ULL, 2, shape_ops__out, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          break;
        }
        default: heff_nomatch(v_it2_249);
        }
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2413;
    v_st_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epatL_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatL_str1, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatL_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatL_str3, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatL_str4, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatL_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatL_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatL_str7, 15, "unexpected `::`");
V g_heff_2esyntax_2esurface_2epatL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2epatL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epatL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2epatL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2epatL_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2epatL(V v_r_240, V v_x2_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_c_243 = heff_field(v_x2_241, 0);
    V v_args_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24PCon = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_text_245 = heff_take_field(v_c_243, 1);
    V v_start_246 = heff_take_field(v_c_243, 3);
    V v_end_247 = heff_get_n(v_c_243, 4, 9);
    V v_m_248 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 1, 3), v_args_244));
    V v_x1_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_249)) {
    case TAG_MkPair: {
      V v_x11_2410 = heff_field(v_x1_249, 0);
      V v_st_2411 = heff_field(v_x1_249, 1);
      V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
      switch (heff_tag_of(v_x11_2410)) {
      case TAG_Left: {
        V v_e_2412 = heff_field(v_x11_2410, 0);
        V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
        heff_drop(v_text_245);
        heff_drop(v_start_246);
        heff_drop(v_end_247);
        heff_drop_cell(v_ru_24x1_249_24MkPair, 2);
        return heff_tag_at_n(v_ru_24x2_241_24PCon, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2410_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2412}), v_st_2411});
      }
      case TAG_Right: {
        V v_x_2413 = heff_field(v_x11_2410, 0);
        V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
        V v_t_2414 = v_text_245;
        V v_tsp_2415 = heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247});
        V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24PCon, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_2414)}), heff_dup(v_tsp_2415)});
        V v_x1_2417 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2416, v_x_2413));
        V v_t_2420;
        switch (heff_tag_of(v_x1_2417)) {
        case TAG_At: {
          V v_s_2419 = heff_field(v_x1_2417, 1);
          heff_take_n(v_x1_2417, 2ULL, 2);
          v_t_2420 = v_s_2419;
          break;
        }
        default: heff_nomatch(v_x1_2417);
        }
        V v_t_2421 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_2415, 0)); V rr_ = heff_rec_reuse_nf(v_t_2420, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_x_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_2414, v_tsp_2415, v_x_2413}), v_t_2421});
        return heff_tag_re_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){v_x_2422}), v_st_2411});
      }
      default: return heff_nomatch(v_x11_2410);
      }
    }
    default: return heff_nomatch(v_x1_249);
    }
  }
  case TAG_PAtom: {
    V v_t_2423 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PAtom = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_2423, 0)), ((V)&g_heff_2esyntax_2esurface_2epatL_str0))) {
      V v_t_2424 = (g_list_2eany_24s565534491x447967237(heff_dup(v_t_2423), heff_rfield(v_z_242, 4)));
      V v_t_2431;
      if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
        heff_drop(v_t_2424);
        V v_t_2425 = heff_tag_at_n(v_ru_24x2_241_24PAtom, TAG_PatVar, 1, (V[]){heff_dup(heff_rfield(v_t_2423, 1))});
        V v_t_2426 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2423, 3), heff_get_n(v_t_2423, 4, 9)});
        v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_t_2426});
      } else {
        heff_drop_cell(v_ru_24x2_241_24PAtom, 1);
        heff_drop(v_t_2424);
        V v_t_2427 = heff_take_field(v_t_2423, 1);
        V v_tsp_2428 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2423, 3), heff_get_n(v_t_2423, 4, 9)});
        V v_t_2429 = heff_tag_n(TAG_PatTag, 3, (V[]){v_t_2427, heff_dup(v_tsp_2428), NTAG(TAG_Nil)});
        V v_t_2430 = ({ V rr_ = heff_rec_reuse_na(v_tsp_2428, 3ULL, 2, shape_start__end, 15u, 0u); rr_; });
        v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){v_t_2429, v_t_2430});
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2431}), v_z_242});
    } else {
      V v_x_2432 = (g_heff_2esyntax_2esurface_2epatTok(v_t_2423));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24PAtom, TAG_Right, 1, (V[]){v_x_2432}), v_z_242});
    }
  }
  case TAG_PParen: {
    V v_p_2434 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_p_2434, v_z_242});
  }
  case TAG_PList: {
    V v_o_2436 = heff_field(v_x2_241, 0);
    V v_ps_2437 = heff_field(v_x2_241, 1);
    V v_c_2439 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 11ULL, 4);
    V v_text_2440 = heff_take_field(v_o_2436, 1);
    V v_start_2441 = heff_get_n(v_o_2436, 3, 9);
    if (heff_strEq_c_lent(v_text_2440, ((V)&g_heff_2esyntax_2esurface_2epatL_str1), 2)) {
      heff_drop(v_text_2440);
      V v_m_2442 = (g_heff_2esyntax_2esurface_2epatSegmentsL(v_r_240, v_ps_2437));
      V v_x1_2443 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2443)) {
      case TAG_MkPair: {
        V v_x11_2444 = heff_field(v_x1_2443, 0);
        V v_st_2445 = heff_field(v_x1_2443, 1);
        V v_ru_24x1_2443_24MkPair = heff_take_reuse_n(v_x1_2443, 3ULL, 2);
        switch (heff_tag_of(v_x11_2444)) {
        case TAG_Left: {
          V v_e_2446 = heff_field(v_x11_2444, 0);
          V v_ru_24x11_2444_24Left = heff_take_reuse_n(v_x11_2444, 1ULL, 1);
          heff_drop_rec(v_c_2439, 9);
          heff_drop(v_start_2441);
          return heff_tag_re_n(v_ru_24x1_2443_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2444_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2446}), v_st_2445});
        }
        case TAG_Right: {
          V v_x_2447 = heff_field(v_x11_2444, 0);
          V v_ru_24x11_2444_24Right = heff_take_reuse_n(v_x11_2444, 1ULL, 1);
          V v_t_2448 = heff_rec_n(2, shape_start__end, (V[]){v_start_2441, heff_get_n(v_c_2439, 4, 9)});
          V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatBinary, 1, (V[]){v_x_2447}), v_t_2448});
          return heff_tag_re_n(v_ru_24x1_2443_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2444_24Right, TAG_Right, 1, (V[]){v_t_2449}), v_st_2445});
        }
        default: return heff_nomatch(v_x11_2444);
        }
      }
      default: return heff_nomatch(v_x1_2443);
      }
    } else {
      if (heff_strEq_c(v_text_2440, ((V)&g_heff_2esyntax_2esurface_2epatL_str2))) {
        V v_m_2450 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 1, 3), v_ps_2437));
        V v_x1_2451 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2451)) {
        case TAG_MkPair: {
          V v_x11_2452 = heff_field(v_x1_2451, 0);
          V v_st_2453 = heff_field(v_x1_2451, 1);
          V v_ru_24x1_2451_24MkPair = heff_take_reuse_n(v_x1_2451, 3ULL, 2);
          switch (heff_tag_of(v_x11_2452)) {
          case TAG_Left: {
            V v_e_2454 = heff_field(v_x11_2452, 0);
            V v_ru_24x11_2452_24Left = heff_take_reuse_n(v_x11_2452, 1ULL, 1);
            heff_drop_rec(v_c_2439, 9);
            heff_drop(v_start_2441);
            return heff_tag_re_n(v_ru_24x1_2451_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2452_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2454}), v_st_2453});
          }
          case TAG_Right: {
            V v_x_2455 = heff_field(v_x11_2452, 0);
            V v_ru_24x11_2452_24Right = heff_take_reuse_n(v_x11_2452, 1ULL, 1);
            V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2455));
            V v_t_2457 = heff_rec_n(2, shape_start__end, (V[]){v_start_2441, heff_get_n(v_c_2439, 4, 9)});
            V v_x_2458 = (g_heff_2esyntax_2esurface_2etuplePRev(v_t_2457, v_t_2456));
            return heff_tag_re_n(v_ru_24x1_2451_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2452_24Right, TAG_Right, 1, (V[]){v_x_2458}), v_st_2453});
          }
          default: return heff_nomatch(v_x11_2452);
          }
        }
        default: return heff_nomatch(v_x1_2451);
        }
      } else {
        V v_m_2459 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 1, 3), v_ps_2437));
        V v_x1_2460 = heff_tr(heff_call(v_m_2459, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2460)) {
        case TAG_MkPair: {
          V v_x11_2461 = heff_field(v_x1_2460, 0);
          V v_st_2462 = heff_field(v_x1_2460, 1);
          V v_ru_24x1_2460_24MkPair = heff_take_reuse_n(v_x1_2460, 3ULL, 2);
          switch (heff_tag_of(v_x11_2461)) {
          case TAG_Left: {
            V v_e_2463 = heff_field(v_x11_2461, 0);
            V v_ru_24x11_2461_24Left = heff_take_reuse_n(v_x11_2461, 1ULL, 1);
            heff_drop_rec(v_c_2439, 9);
            heff_drop(v_start_2441);
            return heff_tag_re_n(v_ru_24x1_2460_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2461_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2463}), v_st_2462});
          }
          case TAG_Right: {
            V v_x_2464 = heff_field(v_x11_2461, 0);
            V v_ru_24x11_2461_24Right = heff_take_reuse_n(v_x11_2461, 1ULL, 1);
            V v_sp_2465 = heff_rec_n(2, shape_start__end, (V[]){v_start_2441, heff_get_n(v_c_2439, 4, 9)});
            V v_t_2466 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2epatL_str3), heff_dup(v_sp_2465), NTAG(TAG_Nil)});
            V v_t_2467 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_2465, 0)), heff_dup(heff_rfield(v_sp_2465, 1))});
            V v_x_2468 = (g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664(((V)&g_heff_2esyntax_2esurface_2epatL_str4), v_sp_2465, heff_tag_n(TAG_At, 2, (V[]){v_t_2466, v_t_2467}), v_x_2464));
            return heff_tag_re_n(v_ru_24x1_2460_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2461_24Right, TAG_Right, 1, (V[]){v_x_2468}), v_st_2462});
          }
          default: return heff_nomatch(v_x11_2461);
          }
        }
        default: return heff_nomatch(v_x1_2460);
        }
      }
    }
  }
  case TAG_POp: {
    V v_l_2469 = heff_field(v_x2_241, 0);
    V v_op_2470 = heff_field(v_x2_241, 1);
    V v_q_2471 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    HeffT2 v_t_2472 = (g_heff_2esyntax_2esurface_2epchainOf_24cpr(v_q_2471));
    {
      V v_field_2473 = v_t_2472.f[0];
      V v_field_2474 = v_t_2472.f[1];
      V v_rh_2475 = v_field_2473;
      V v_rest_2476 = v_field_2474;
      V v_m_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_l_2469}));
      V v_x1_2478 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2478)) {
      case TAG_MkPair: {
        V v_x11_2479 = heff_field(v_x1_2478, 0);
        V v_st_2480 = heff_field(v_x1_2478, 1);
        V v_ru_24x1_2478_24MkPair = heff_take_reuse_n(v_x1_2478, 3ULL, 2);
        switch (heff_tag_of(v_x11_2479)) {
        case TAG_Left: {
          V v_e_2481 = heff_field(v_x11_2479, 0);
          V v_ru_24x11_2479_24Left = heff_take_reuse_n(v_x11_2479, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop(v_op_2470);
          heff_drop(v_rh_2475);
          heff_drop(v_rest_2476);
          return heff_tag_re_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2479_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2481}), v_st_2480});
        }
        case TAG_Right: {
          V v_x_2482 = heff_field(v_x11_2479, 0);
          V v_ru_24x11_2479_24Right = heff_take_reuse_n(v_x11_2479, 1ULL, 1);
          V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){v_op_2470, v_rh_2475}), v_rest_2476});
          V v_t_2495 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2epatL_lam0, 1, 1, (V[]){v_r_240}), v_t_2483));
          V v_x1_2496 = heff_tr(heff_call(v_t_2495, 1, (V[]){v_st_2480}));
          switch (heff_tag_of(v_x1_2496)) {
          case TAG_MkPair: {
            V v_x11_2497 = heff_field(v_x1_2496, 0);
            V v_st_2498 = heff_field(v_x1_2496, 1);
            V v_ru_24x1_2496_24MkPair = heff_take_reuse_n(v_x1_2496, 3ULL, 2);
            switch (heff_tag_of(v_x11_2497)) {
            case TAG_Left: {
              V v_e_2499 = heff_field(v_x11_2497, 0);
              V v_ru_24x11_2497_24Left = heff_take_reuse_n(v_x11_2497, 1ULL, 1);
              heff_drop(v_x_2482);
              heff_drop_cell(v_ru_24x11_2479_24Right, 1);
              return heff_tag_re_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2497_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2499}), v_st_2498});
            }
            case TAG_Right: {
              V v_x_24100 = heff_field(v_x11_2497, 0);
              V v_ru_24x11_2497_24Right = heff_take_reuse_n(v_x11_2497, 1ULL, 1);
              V v_e0_24101 = v_x_2482;
              V v_rest_24102 = v_x_24100;
              V v_st_24103 = v_st_2498;
              V v_t_24104 = heff_dup(heff_rfield(v_st_24103, 5));
              V v_t_24105 = heff_dup(heff_rfield(v_st_24103, 6));
              V v_t_24106 = (g_heff_2esyntax_2esurface_2echeckFixOf(heff_dup(v_t_24104), v_t_24105, heff_dup(v_rest_24102)));
              V v_x1_24107 = heff_tr(heff_call(v_t_24106, 1, (V[]){v_st_24103}));
              switch (heff_tag_of(v_x1_24107)) {
              case TAG_MkPair: {
                V v_x11_24108 = heff_field(v_x1_24107, 0);
                V v_st_24109 = heff_field(v_x1_24107, 1);
                V v_ru_24x1_24107_24MkPair = heff_take_reuse_n(v_x1_24107, 3ULL, 2);
                switch (heff_tag_of(v_x11_24108)) {
                case TAG_Left: {
                  V v_e_24110 = heff_field(v_x11_24108, 0);
                  heff_take_n(v_x11_24108, 1ULL, 1);
                  heff_drop_cell(v_ru_24x11_2479_24Right, 1);
                  heff_drop(v_e0_24101);
                  heff_drop(v_rest_24102);
                  heff_drop(v_t_24104);
                  heff_drop(v_t_24105);
                  heff_drop_cell(v_ru_24x1_24107_24MkPair, 2);
                  return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2497_24Right, TAG_Left, 1, (V[]){v_e_24110}), v_st_24109});
                }
                case TAG_Right: {
                  heff_take_n(v_x11_24108, 0ULL, 1);
                  V v_t_24112 = heff_tag_at_n(v_ru_24x1_24107_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_e0_24101), NTAG(TAG_Nil)});
                  V v_t_24113 = heff_rec_n(2, shape_ops__out, (V[]){NTAG(TAG_Nil), v_t_24112});
                  HeffT2 v_t_24114 = ({ V a_0 = v_t_24104; V a_1 = v_t_24105; V a_2 = v_t_24113; V a_3 = v_rest_24102; V a_4 = v_st_24109; HeffT2 r_ = (g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_24105); heff_drop(v_rest_24102); r_; });
                  {
                    V v_field_24115 = v_t_24114.f[0];
                    V v_field_24116 = v_t_24114.f[1];
                    V v_x11_24117 = v_field_24115;
                    V v_st_24118 = v_field_24116;
                    switch (heff_tag_of(v_x11_24117)) {
                    case TAG_Left: {
                      V v_e_24119 = heff_field(v_x11_24117, 0);
                      heff_take_n(v_x11_24117, 1ULL, 1);
                      heff_drop_cell(v_ru_24x11_2479_24Right, 1);
                      heff_drop(v_e0_24101);
                      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2497_24Right, TAG_Left, 1, (V[]){v_e_24119}), v_st_24118});
                    }
                    case TAG_Right: {
                      V v_x_24120 = heff_field(v_x11_24117, 0);
                      heff_take_n(v_x11_24117, 1ULL, 1);
                      heff_drop_cell(v_ru_24x11_2497_24Right, 1);
                      V v_st_24121 = (g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(v_x_24120));
                      V v_t_24122 = heff_get_n(v_st_24121, 1, 2);
                      V v_t_24125;
                      switch (heff_tag_of(v_t_24122)) {
                      case TAG_Nil: {
                        v_t_24125 = v_e0_24101;
                        break;
                      }
                      case TAG_Cons: {
                        V v_x_24123 = heff_field(v_t_24122, 0);
                        heff_take_n(v_t_24122, 1ULL, 2);
                        heff_drop(v_e0_24101);
                        v_t_24125 = v_x_24123;
                        break;
                      }
                      default: heff_nomatch(v_t_24122);
                      }
                      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2479_24Right, TAG_Right, 1, (V[]){v_t_24125}), v_st_24118});
                    }
                    default: return heff_nomatch(v_x11_24117);
                    }
                  }
                }
                default: return heff_nomatch(v_x11_24108);
                }
              }
              default: return heff_nomatch(v_x1_24107);
              }
            }
            default: return heff_nomatch(v_x11_2497);
            }
          }
          default: return heff_nomatch(v_x1_2496);
          }
        }
        default: return heff_nomatch(v_x11_2479);
        }
      }
      default: return heff_nomatch(v_x1_2478);
      }
    }
  }
  case TAG_PRec: {
    V v_o_24126 = heff_field(v_x2_241, 0);
    V v_fs_24127 = heff_field(v_x2_241, 1);
    V v_c_24129 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 11ULL, 4);
    V v_m_24152 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2epatL_lam2, 1, 1, (V[]){v_r_240}), v_fs_24127));
    V v_x1_24153 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24153)) {
    case TAG_MkPair: {
      V v_x11_24154 = heff_field(v_x1_24153, 0);
      V v_st_24155 = heff_field(v_x1_24153, 1);
      V v_ru_24x1_24153_24MkPair = heff_take_reuse_n(v_x1_24153, 3ULL, 2);
      switch (heff_tag_of(v_x11_24154)) {
      case TAG_Left: {
        V v_e_24156 = heff_field(v_x11_24154, 0);
        V v_ru_24x11_24154_24Left = heff_take_reuse_n(v_x11_24154, 1ULL, 1);
        heff_drop_rec(v_o_24126, 9);
        heff_drop_rec(v_c_24129, 9);
        return heff_tag_re_n(v_ru_24x1_24153_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24154_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24156}), v_st_24155});
      }
      case TAG_Right: {
        V v_x_24157 = heff_field(v_x11_24154, 0);
        V v_ru_24x11_24154_24Right = heff_take_reuse_n(v_x11_24154, 1ULL, 1);
        V v_t_24158 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24126, 3, 9), heff_get_n(v_c_24129, 4, 9)});
        V v_t_24159 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatRecord, 1, (V[]){v_x_24157}), v_t_24158});
        return heff_tag_re_n(v_ru_24x1_24153_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24154_24Right, TAG_Right, 1, (V[]){v_t_24159}), v_st_24155});
      }
      default: return heff_nomatch(v_x11_24154);
      }
    }
    default: return heff_nomatch(v_x1_24153);
    }
  }
  case TAG_PField: {
    V v_p_24162 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 4ULL, 3);
    return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_p_24162, v_z_242});
  }
  case TAG_PAs: {
    V v_x_24163 = heff_field(v_x2_241, 0);
    V v_p_24165 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PAs = heff_take_reuse_n(v_x2_241, 5ULL, 3);
    V v_text_24166 = heff_take_field(v_x_24163, 1);
    V v_start_24167 = heff_take_field(v_x_24163, 3);
    V v_end_24168 = heff_get_n(v_x_24163, 4, 9);
    V v_m_24169 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_p_24165)}));
    V v_x1_24170 = heff_tr(heff_call(v_m_24169, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24170)) {
    case TAG_MkPair: {
      V v_x11_24171 = heff_field(v_x1_24170, 0);
      V v_st_24172 = heff_field(v_x1_24170, 1);
      V v_ru_24x1_24170_24MkPair = heff_take_reuse_n(v_x1_24170, 3ULL, 2);
      switch (heff_tag_of(v_x11_24171)) {
      case TAG_Left: {
        V v_e_24173 = heff_field(v_x11_24171, 0);
        V v_ru_24x11_24171_24Left = heff_take_reuse_n(v_x11_24171, 1ULL, 1);
        heff_drop(v_p_24165);
        heff_drop_cell(v_ru_24x2_241_24PAs, 3);
        heff_drop(v_text_24166);
        heff_drop(v_start_24167);
        heff_drop(v_end_24168);
        return heff_tag_re_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24171_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24173}), v_st_24172});
      }
      case TAG_Right: {
        V v_x_24174 = heff_field(v_x11_24171, 0);
        V v_ru_24x11_24171_24Right = heff_take_reuse_n(v_x11_24171, 1ULL, 1);
        V v_b_24175 = (g_heff_2esyntax_2ecst_2elastP(v_p_24165));
        V v_t_24176 = heff_tag_at_n(v_ru_24x2_241_24PAs, TAG_PatAs, 3, (V[]){v_text_24166, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_24167), v_end_24168}), v_x_24174});
        V v_t_24177 = heff_rec_n(2, shape_start__end, (V[]){v_start_24167, heff_get_n(v_b_24175, 4, 9)});
        V v_x_24178 = heff_tag_n(TAG_At, 2, (V[]){v_t_24176, v_t_24177});
        return heff_tag_re_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24171_24Right, TAG_Right, 1, (V[]){v_x_24178}), v_st_24172});
      }
      default: return heff_nomatch(v_x11_24171);
      }
    }
    default: return heff_nomatch(v_x1_24170);
    }
  }
  case TAG_PSeg: {
    V v_cc_24180 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    heff_drop_rec(v_r_240, 3);
    V v_start_24182 = heff_take_field(v_cc_24180, 3);
    V v_end_24183 = heff_get_n(v_cc_24180, 4, 9);
    V v_t_24184 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatL_str7), heff_rec_n(2, shape_start__end, (V[]){v_start_24182, v_end_24183}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24184}), v_z_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2epatL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epatL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2epatL_lam1(V self, V *args) {
  V v_st_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  V v_op_2485 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2489 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_st_2488}));
  switch (heff_tag_of(v_x1_2489)) {
  case TAG_MkPair: {
    V v_x11_2490 = heff_field(v_x1_2489, 0);
    V v_st_2491 = heff_field(v_x1_2489, 1);
    V v_ru_24x1_2489_24MkPair = heff_take_reuse_n(v_x1_2489, 3ULL, 2);
    switch (heff_tag_of(v_x11_2490)) {
    case TAG_Left: {
      V v_e_2492 = heff_field(v_x11_2490, 0);
      V v_ru_24x11_2490_24Left = heff_take_reuse_n(v_x11_2490, 1ULL, 1);
      heff_drop(v_op_2485);
      return heff_tag_re_n(v_ru_24x1_2489_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2490_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2492}), v_st_2491});
    }
    case TAG_Right: {
      V v_x_2493 = heff_field(v_x11_2490, 0);
      V v_ru_24x11_2490_24Right = heff_take_reuse_n(v_x11_2490, 1ULL, 1);
      V v_t_2494 = heff_tag_at_n(v_ru_24x11_2490_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_2485, v_x_2493})});
      return heff_tag_re_n(v_ru_24x1_2489_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2494, v_st_2491});
    }
    default: return heff_nomatch(v_x11_2490);
    }
  }
  default: return heff_nomatch(v_x1_2489);
  }
}
V g_heff_2esyntax_2esurface_2epatL_lam0(V self, V *args) {
  V v_m_2484 = args[0];
  V v_r_240 = heff_env(self)[0];
  switch (heff_tag_of(v_m_2484)) {
  case TAG_MkPair: {
    V v_op_2485 = heff_field(v_m_2484, 0);
    V v_p_2486 = heff_field(v_m_2484, 1);
    heff_take_n(v_m_2484, 3ULL, 2);
    heff_clo_take(self, 1);
    V v_m_2487 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_p_2486}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epatL_lam1, 1, 2, (V[]){v_m_2487, v_op_2485});
  }
  default: return heff_nomatch(v_m_2484);
  }
}
V g_heff_2esyntax_2esurface_2epatL_lam3(V self, V *args) {
  V v_st_24137 = args[0];
  V v_m_24136 = heff_env(self)[0];
  V v_x_24133 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24138 = heff_tr(heff_call(v_m_24136, 1, (V[]){v_st_24137}));
  switch (heff_tag_of(v_x1_24138)) {
  case TAG_MkPair: {
    V v_x11_24139 = heff_field(v_x1_24138, 0);
    V v_st_24140 = heff_field(v_x1_24138, 1);
    V v_ru_24x1_24138_24MkPair = heff_take_reuse_n(v_x1_24138, 3ULL, 2);
    switch (heff_tag_of(v_x11_24139)) {
    case TAG_Left: {
      V v_e_24141 = heff_field(v_x11_24139, 0);
      V v_ru_24x11_24139_24Left = heff_take_reuse_n(v_x11_24139, 1ULL, 1);
      heff_drop_rec(v_x_24133, 9);
      return heff_tag_re_n(v_ru_24x1_24138_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24139_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24141}), v_st_24140});
    }
    case TAG_Right: {
      V v_x_24142 = heff_field(v_x11_24139, 0);
      V v_ru_24x11_24139_24Right = heff_take_reuse_n(v_x11_24139, 1ULL, 1);
      V v_t_24143 = heff_tag_n(TAG_MkFieldPat, 2, (V[]){heff_get_n(v_x_24133, 1, 9), v_x_24142});
      return heff_tag_re_n(v_ru_24x1_24138_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24139_24Right, TAG_Right, 1, (V[]){v_t_24143}), v_st_24140});
    }
    default: return heff_nomatch(v_x11_24139);
    }
  }
  default: return heff_nomatch(v_x1_24138);
  }
}
V g_heff_2esyntax_2esurface_2epatL_lam4(V self, V *args) {
  V v_st_24150 = args[0];
  V v_msg_24149 = heff_env(self)[0];
  V v_start_24145 = heff_env(self)[1];
  V v_end_24146 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24151 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24149, heff_rec_n(2, shape_start__end, (V[]){v_start_24145, v_end_24146}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24151}), v_st_24150});
}
V g_heff_2esyntax_2esurface_2epatL_lam2(V self, V *args) {
  V v_f_24130 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_r_24131 = v_r_240;
  V v_x2_24132 = v_f_24130;
  switch (heff_tag_of(v_x2_24132)) {
  case TAG_PField: {
    V v_x_24133 = heff_field(v_x2_24132, 0);
    V v_p_24135 = heff_field(v_x2_24132, 2);
    heff_take_n(v_x2_24132, 5ULL, 3);
    V v_m_24136 = heff_tr(heff_call(heff_get_n(v_r_24131, 1, 3), 1, (V[]){v_p_24135}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epatL_lam3, 1, 2, (V[]){v_m_24136, v_x_24133});
  }
  default: {
    heff_drop_rec(v_r_24131, 3);
    V v_t_24144 = (g_heff_2esyntax_2ecst_2efirstP(v_x2_24132));
    V v_start_24145 = heff_take_field(v_t_24144, 3);
    V v_end_24146 = heff_get_n(v_t_24144, 4, 9);
    V v_t_24147 = ({ V a_0 = v_x2_24132; V r_ = (g_heff_2esyntax_2ecst_2efirstP(a_0)); heff_drop(v_x2_24132); r_; });
    V v_t_24148 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2epatL_str5), heff_get_n(v_t_24147, 1, 9));
    V v_msg_24149 = heff_strAppend(v_t_24148, ((V)&g_heff_2esyntax_2esurface_2epatL_str6));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epatL_lam4, 1, 3, (V[]){v_msg_24149, v_start_24145, v_end_24146});
  }
  }
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(heff_dup(v_x_241), v_t_243));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(heff_dup(heff_rfield(v_x_241, 1)), v_t_243));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2emutualItems_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24cpr(V v_r_240, V v_k_241, V v_ds_242, V v_st_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2esurface_2eknotOf(v_k_241, v_ds_242));
  V v_st_245 = (g_heff_2esyntax_2esurface_2esetKnot(v_t_244, v_st_243));
  V v_t_246 = heff_dup(heff_rfield(v_st_245, 1));
  V v_t_247 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 2, 3), v_ds_242));
  V v_x1_248 = heff_tr(heff_call(v_t_247, 1, (V[]){v_st_245}));
  V v_x11_2414;
  V v_st_2415;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    heff_take_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop(v_t_246);
      v_x11_2414 = heff_tag_re_n(v_ru_24x11_249_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2411});
      v_st_2415 = v_st_2410;
      break;
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_st_2413 = (g_heff_2esyntax_2esurface_2esetScope(v_t_246, v_st_2410));
      v_x11_2414 = heff_tag_re_n(v_ru_24x11_249_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_2412});
      v_st_2415 = v_st_2413;
      break;
    }
    default: heff_nomatch(v_x11_249);
    }
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  switch (heff_tag_of(v_x11_2414)) {
  case TAG_Left: {
    V v_e_2416 = heff_field(v_x11_2414, 0);
    V v_ru_24x11_2414_24Left = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
    return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2414_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2416}), v_st_2415}});
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x11_2414, 0);
    V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
    V v_st_2418 = (g_heff_2esyntax_2esurface_2esetKnot(heff_dup(g_std_2eordmap_2eempty_get()), v_st_2415));
    V v_t_2419 = heff_dup(heff_rfield(v_st_2418, 7));
    V v_items_2420 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2417));
    V v_items_2421 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2420, NTAG(TAG_Nil)));
    V v_d_2425 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2emutualItems_24cpr_lam0, 2, 1, (V[]){v_t_2419}); V a_1 = heff_dup(g_heff_2esyntax_2esurface_2ewhereL_24rec0_get()); V a_2 = v_items_2421; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2421); r_; });
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2425, 3, 4)));
    V v_items_2427 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2417));
    V v_items_2428 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2427, NTAG(TAG_Nil)));
    V v_t_2429 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2428));
    V v_t_2430 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2428));
    V v_t_2431 = (g_list_2emap_24s2130193383x1335133353(heff_dup(g_std_2eordmap_2eempty_get()), v_t_2429, v_t_2430, v_items_2428));
    V v_t_2432 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2431));
    V v_t_2433 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2426, v_t_2432));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_Nil: {
      V v_items_2434 = ({ V a_0 = v_x_2417; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2417); r_; });
      V v_x_2435 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2434, NTAG(TAG_Nil)));
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){v_x_2435}), v_st_2418}});
    }
    case TAG_Cons: {
      V v_d_2436 = heff_field(v_t_2433, 0);
      heff_take_n(v_t_2433, 1ULL, 2);
      heff_drop(v_x_2417);
      heff_drop_cell(v_ru_24x11_2414_24Right, 1);
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2436}), v_st_2418}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2433)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x11_2414)}});
  }
}
V g_heff_2esyntax_2esurface_2emutualItems_24cpr_lam0(V self, V *args) {
  V v_d_2422 = args[0];
  V v_it_2423 = args[1];
  V v_t_2419 = heff_env(self)[0];
  V v_t_2424 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2422, 2)), v_it_2423));
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_2419; V a_1 = v_d_2422; V a_2 = v_t_2424; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
}
Clo g_heff_2esyntax_2esurface_2emutualOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emutualOut_entry, 5, 0};

V g_heff_2esyntax_2esurface_2emutualOut(V v_ksp_240, V v_bsp_241, V v_m_242, V v_k_243, V v_defs_244) {
top: ;
  V v_t_245 = (g_list_2emap_24f1744384903x906515519(heff_dup(v_defs_244)));
  V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_m_242)}), heff_dup(v_ksp_240)});
  V v_t_247 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2emutualBody_clo), 2, (V[]){v_t_246, heff_dup(v_k_243)}));
  V v_t_248 = (g_heff_2esyntax_2esurface_2erightsOf(heff_dup(v_defs_244)));
  V v_t_249 = (g_list_2emap(v_t_247, v_t_248));
  V v_defs_2410 = (g_heff_2esyntax_2esurface_2erightsOf(heff_dup(v_defs_244)));
  V v_t_2411 = (g_list_2emap_24s1691485302x273983346(heff_dup(v_k_243), v_defs_2410));
  V v_t_2412 = (g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119(heff_dup(v_k_243), v_defs_244));
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_m_242)}), heff_dup(v_ksp_240)});
  V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EStruct, 1, (V[]){v_t_2411}), heff_dup(v_bsp_241)});
  V v_t_2415 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_dup(v_k_243), heff_dup(v_bsp_241), NTAG(TAG_Nil), v_t_2414});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, heff_dup(v_bsp_241)}), NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_DeclEquations, 5, (V[]){v_k_243, heff_dup(v_bsp_241), NTAG(TAG_AsDefinition), v_t_2413, v_t_2416});
  V v_t_2418 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2417, heff_dup(v_bsp_241)})});
  V v_t_2419 = (g_heff_2esyntax_2esurface_2eappendS(v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2412})));
  V v_t_2420 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ESig, 1, (V[]){v_t_245}), heff_dup(v_bsp_241)});
  V v_t_2422 = heff_tag_n(TAG_DeclDefine, 5, (V[]){v_m_242, heff_dup(v_ksp_240), NTAG(TAG_Nil), heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_ksp_240}), v_t_2421});
  V v_t_2423 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_bsp_241})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2419});
}
V g_heff_2esyntax_2esurface_2emutualOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emutualOut(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str1, 5, "above");
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str2, 68, "`above` names the operators it is above (`below` alone is below all)");
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str3, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str4, 5, "below");
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str5, 48, "expected `above` or `below` and operators, not `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eabGo_str6, 1, "`");
Clo g_heff_2esyntax_2esurface_2eabGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eabGo_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eabGo(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_w_242 = heff_field(v_x2_241, 0);
    V v_tail_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_w_242, 0)), ((V)&g_heff_2esyntax_2esurface_2eabGo_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_w_242, 1)), ((V)&g_heff_2esyntax_2esurface_2eabGo_str1)))) {
      V v_acc_244 = v_acc_240;
      V v_w_245 = v_w_242;
      V v_start_246 = heff_take_field(v_w_245, 2);
      V v_end_247 = heff_get_n(v_w_245, 3, 7);
      V v_ops_248 = (g_heff_2esyntax_2esurface_2etakeSyms(heff_dup(v_tail_243)));
      V v_t_2414;
      switch (heff_tag_of(v_ops_248)) {
      case TAG_Nil: {
        V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eabGo_str2), heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), NTAG(TAG_Nothing)});
        V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_dup(heff_rfield(v_acc_244, 3))});
        v_t_2414 = ({ V rv_3 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_acc_244, 7ULL, 4, shape_above__below__loosest__errors, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
        break;
      }
      case TAG_Cons: {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_start_246);
        heff_drop(v_end_247);
        V v_t_2413 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_acc_244, 0), v_ops_248));
        v_t_2414 = ({ V rv_0 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_acc_244, 14ULL, 4, shape_above__below__loosest__errors, 252u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        break;
      }
      default: heff_nomatch(v_ops_248);
      }
      V v_t_2415 = (g_list_2efoldl_24f158727028x1528233175(MK_INT(1LL), MK_INT(0LL), v_tail_243));
      V v_t_2416 = (g_heff_2esyntax_2esurface_2edropN(v_t_2415, v_tail_243));
      V t_0 = v_t_2414;
      V t_1 = v_t_2416;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      if ((heff_strEq_c(heff_dup(heff_rfield(v_w_242, 0)), ((V)&g_heff_2esyntax_2esurface_2eabGo_str3)) && heff_strEq_c(heff_dup(heff_rfield(v_w_242, 1)), ((V)&g_heff_2esyntax_2esurface_2eabGo_str4)))) {
        heff_drop_rec(v_w_242, 7);
        V v_ops_2417 = (g_heff_2esyntax_2esurface_2etakeSyms(heff_dup(v_tail_243)));
        V v_t_2421;
        switch (heff_tag_of(v_ops_2417)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          v_t_2421 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_acc_240, 11ULL, 4, shape_above__below__loosest__errors, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          break;
        }
        case TAG_Cons: {
          V v_t_2420 = (g_heff_2esyntax_2esurface_2eappendS_24tok2(v_ru_24x2_241_24Cons, heff_take_field(v_acc_240, 1), v_ops_2417));
          v_t_2421 = ({ V rv_1 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_acc_240, 13ULL, 4, shape_above__below__loosest__errors, 243u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          break;
        }
        default: heff_nomatch(v_ops_2417);
        }
        V v_t_2422 = (g_list_2efoldl_24f158727028x1528233175(MK_INT(1LL), MK_INT(0LL), v_tail_243));
        V v_t_2423 = (g_heff_2esyntax_2esurface_2edropN(v_t_2422, v_tail_243));
        V t_0 = v_t_2421;
        V t_1 = v_t_2423;
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_tail_243);
        V v_span_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_w_242, 2), heff_take_field(v_w_242, 3)});
        V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eabGo_str5), heff_get_n(v_w_242, 1, 7));
        V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_2425, ((V)&g_heff_2esyntax_2esurface_2eabGo_str6)), v_span_2424, NTAG(TAG_Nothing)});
        V v_t_2427 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_dup(heff_rfield(v_acc_240, 3))});
        return ({ V rv_3 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_acc_240, 7ULL, 4, shape_above__below__loosest__errors, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eabGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eabGo(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2elastEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elastEnd_entry, 2, 0};

V g_heff_2esyntax_2esurface_2elastEnd(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_get_n(v_t_240, 3, 7);
  }
  case TAG_Cons: {
    V v_u_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop_rec(v_t_240, 7);
      return heff_dup(heff_rfield(v_u_242, 3));
    }
    case TAG_Cons: {
      V t_0 = v_t_240;
      V t_1 = v_x22_243;
      v_t_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2elastEnd_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2elastEnd(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDecls_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDecls_str1, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDecls_str2, 6, "infixr");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDecls_str3, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDecls_str4, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDecls_str5, 6, "infixr");
Clo g_heff_2esyntax_2esurface_2efixDecls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixDecls_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixDecls(V v_ts_240, V v_box_24k_241, V v_acc_242) {
  int64_t v_k_241 = heff_unbox_word(v_box_24k_241);
top: ;
  if (((((int64_t)0ULL) <= v_k_241) && (v_k_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
    V v_t_243 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_k_241), 2);
    if (((heff_dup(heff_rfield(v_t_243, 6)) == NTAG(TAG_True)) && (heff_intEq_c(heff_dup(heff_rfield(v_t_243, 5)), MK_INT(0LL)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2efixDecls_str0)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 1)), ((V)&g_heff_2esyntax_2esurface_2efixDecls_str1)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 1)), ((V)&g_heff_2esyntax_2esurface_2efixDecls_str2)) || heff_strEq_c(heff_dup(heff_rfield(v_t_243, 1)), ((V)&g_heff_2esyntax_2esurface_2efixDecls_str3)))))))) {
      V v_ts_244 = heff_dup(v_ts_240);
      int64_t v_k_245 = v_k_241;
      V v_t_246 = v_t_243;
      V v_rest_247 = ({ V a_0 = v_ts_244; V a_1 = heff_box_word((v_k_245 + ((int64_t)1ULL))); V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2erestOfDecl(a_0, a_1, a_2)); heff_drop(v_ts_244); r_; });
      V v_t_248 = v_t_246;
      V v_rest_249 = heff_dup(v_rest_247);
      V v_ops_2410 = (g_heff_2esyntax_2esurface_2etakeSyms(heff_dup(v_rest_247)));
      V v_t_2411 = (g_list_2efoldl_24f158727028x1528233175(MK_INT(1LL), MK_INT(0LL), v_rest_247));
      V v_t_2412 = (g_heff_2esyntax_2esurface_2edropN(v_t_2411, v_rest_247));
      V v_t_2413 = heff_rec_n(4, shape_above__below__loosest__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_Nil)});
      V v_r_2414 = (g_heff_2esyntax_2esurface_2eabGo(v_t_2413, v_t_2412));
      V v_errors_2415 = heff_take_field(v_r_2414, 3);
      V v_above_2416 = heff_take_field(v_r_2414, 0);
      V v_below_2417 = heff_take_field(v_r_2414, 1);
      V v_loosest_2418 = heff_get_n(v_r_2414, 2, 4);
      V v_s_2419 = heff_dup(heff_rfield(v_t_248, 1));
      V v_t_2420;
      if (heff_strEq_c_lent(v_s_2419, ((V)&g_heff_2esyntax_2esurface_2efixDecls_str4), 2)) {
        heff_drop(v_s_2419);
        v_t_2420 = NTAG(TAG_AssocLeft);
      } else {
        if (heff_strEq_c(v_s_2419, ((V)&g_heff_2esyntax_2esurface_2efixDecls_str5))) {
          v_t_2420 = NTAG(TAG_AssocRight);
        } else {
          v_t_2420 = NTAG(TAG_AssocNone);
        }
      }
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_errors_2415));
      V v_a_2422 = heff_dup(heff_rfield(v_t_248, 2));
      V v_b_2423 = ({ V a_0 = heff_dup(v_t_248); V a_1 = v_rest_249; V r_ = (g_heff_2esyntax_2esurface_2elastEnd(a_0, a_1)); heff_drop(v_rest_249); r_; });
      V v_d_2424 = heff_rec_n(8, shape_assoc__ops__above__below__loosest__errors__span__line, (V[]){v_t_2420, v_ops_2410, v_above_2416, v_below_2417, v_loosest_2418, v_t_2421, heff_rec_n(2, shape_start__end, (V[]){v_a_2422, v_b_2423}), heff_get_n(v_t_248, 4, 7)});
      V t_0 = v_ts_240;
      int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2424, v_acc_242});
      v_ts_240 = t_0;
      v_k_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_t_243, 7);
      V t_0 = v_ts_240;
      int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
      V t_2 = v_acc_242;
      v_ts_240 = t_0;
      v_k_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
  } else {
    heff_drop(v_ts_240);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
}
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixDecls(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2efixityFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixityFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixityFrom(V v_place_240, V v_imported_241, V v_decls_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2efixityFrom_24cpr(v_place_240, v_imported_241, v_decls_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_rec_n(2, shape_fixities__diags, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2efixityFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixityFrom(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efixitiesOfText_str0, 0, "");
Clo g_heff_2esyntax_2esurface_2efixitiesOfText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixitiesOfText_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efixitiesOfText(V v_imported_240, V v_src_241) {
top: ;
  V v_t_242 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_243 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_241, v_t_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  {
    V v_field_244 = v_t_243.f[0];
    heff_drop(v_t_243.f[1]);
    heff_drop(v_t_243.f[2]);
    V v_ts_247 = heff_arrayFromList(v_field_244);
    V v_t_248 = (g_heff_2esyntax_2esurface_2efixDecls(v_ts_247, MK_INT(0LL), NTAG(TAG_Nil)));
    HeffT2 v_t_249 = (g_heff_2esyntax_2esurface_2efixityFrom_24cpr(((V)&g_heff_2esyntax_2esurface_2efixitiesOfText_str0), v_imported_240, v_t_248));
    {
      V v_field_2410 = v_t_249.f[0];
      heff_drop(v_t_249.f[1]);
      return v_field_2410;
    }
  }
}
V g_heff_2esyntax_2esurface_2efixitiesOfText_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixitiesOfText(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_24cpr(V v_kw_240, V v_x_241, V v_ty_242, V v_st_243) {
top: ;
  V v_text_244 = heff_take_field(v_x_241, 1);
  V v_start_245 = heff_take_field(v_x_241, 3);
  V v_end_246 = heff_get_n(v_x_241, 4, 9);
  V v_x1_247 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_ty_242), v_st_243));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      heff_drop_rec(v_kw_240, 9);
      heff_drop(v_ty_242);
      heff_drop(v_text_244);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x11_248_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2410}), v_st_249}});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = (g_heff_2esyntax_2ecst_2elastE(v_ty_242));
      V v_e_2413 = heff_get_n(v_t_2412, 4, 9);
      V v_t_2414 = heff_tag_n(TAG_DeclPrimitive, 3, (V[]){v_text_244, heff_rec_n(2, shape_start__end, (V[]){v_start_245, v_end_246}), v_x_2411});
      V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_240, 3, 9), v_e_2413});
      V v_t_2416 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_At, 2, (V[]){v_t_2414, v_t_2415})});
      V v_x_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){v_x_2417}), v_st_249}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_247)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str2, 3, "con");
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(V v_ys_240, V v_pv_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_PCon: {
    V v_args_244 = heff_field(v_x2_242, 1);
    V v_t_246 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam0, 1, 1, (V[]){heff_dup(v_pv_241)}), v_args_244));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_246, v_ys_240));
  }
  case TAG_PAtom: {
    V v_t_247 = heff_field(v_x2_242, 0);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str0)) && !heff_strEq_c(heff_dup(heff_rfield(v_t_247, 1)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str1)))) {
      V v_x_248 = heff_dup(heff_rfield(v_t_247, 1));
      V v_t_249 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_t_249});
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str2))) {
        V v_t_2410 = (g_list_2eany_24s565534491x447967237(heff_dup(v_t_247), v_pv_241));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_t_2410);
          V v_x_2411 = heff_dup(heff_rfield(v_t_247, 1));
          V v_t_2412 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
          return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_t_2412});
        } else {
          heff_drop(v_t_2410);
          return v_ys_240;
        }
      } else {
        return v_ys_240;
      }
    }
  }
  case TAG_PParen: {
    V v_q_2414 = heff_field(v_x2_242, 1);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2414;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2417 = heff_field(v_x2_242, 1);
    V v_t_2421 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam1, 1, 1, (V[]){heff_dup(v_pv_241)}), v_ps_2417));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2421, v_ys_240));
  }
  case TAG_POp: {
    V v_l_2422 = heff_field(v_x2_242, 0);
    V v_q_2424 = heff_field(v_x2_242, 2);
    V v_t_2425 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_l_2422));
    V v_t_2426 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_q_2424));
    V v_t_2427 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2425, v_t_2426));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2427, v_ys_240));
  }
  case TAG_PRec: {
    V v_fs_2429 = heff_field(v_x2_242, 1);
    V v_t_2433 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam2, 1, 1, (V[]){heff_dup(v_pv_241)}), v_fs_2429));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2433, v_ys_240));
  }
  case TAG_PField: {
    V v_q_2436 = heff_field(v_x2_242, 2);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2436;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2437 = heff_field(v_x2_242, 0);
    V v_q_2439 = heff_field(v_x2_242, 2);
    V v_x_2440 = heff_dup(heff_rfield(v_x_2437, 1));
    V v_cell_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2440, heff_hole()});
    V v_u_2442 = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(v_ys_240, v_pv_241, v_q_2439, v_cell_2441));
    heff_drop(v_u_2442);
    return v_cell_2441;
  }
  case TAG_PSeg: {
    V v_q_2443 = heff_field(v_x2_242, 0);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2443;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam0(V self, V *args) {
  V v_q_245 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_245; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_245); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam1(V self, V *args) {
  V v_q_2420 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2420; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2420); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam2(V self, V *args) {
  V v_q_2432 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2432; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2432); r_; });
}
Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebind_24tok1_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ebind_24tok1(V v_tok_240, V v_m_241, V v_f_242, V v_st_243) {
top: ;
  V v_x1_244 = heff_tr(heff_call(v_m_241, 1, (V[]){v_st_243}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    V v_ru_24x1_244_24MkPair = heff_take_reuse_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      heff_drop(v_f_242);
      return heff_tag_re_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_tok_240, TAG_Left, 1, (V[]){v_e_247}), v_st_246});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop_cell(v_ru_24x1_244_24MkPair, 2);
      return heff_tail(v_f_242, 2, (V[]){v_x_248, v_st_246});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebind_24tok1(a[0], a[1], a[2], a[3]);
}