// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclEquations 25755
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_EUSet 22856
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkEquation 38417
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Sig 30557
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_code 9554612
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_fix 310927
#define LBL_kind 9787483
#define LBL_lenient 294367673
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V, V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2eassembleDiagOne(V, V, V, V);
V g_heff_2esyntax_2esurface_2eassembleDiagOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleDiagOne_clo;
V g_heff_2esyntax_2esurface_2eassembleOne(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleOne_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2eeqnsUnder(V, V);
V g_heff_2esyntax_2esurface_2eeqnsUnder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnsUnder_clo;
V g_heff_2esyntax_2esurface_2efixDeclAt(V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclAt_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2eletBodyL(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletBodyL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletBodyL_clo;
V g_heff_2esyntax_2esurface_2eletHeadL(V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletHeadL_clo;
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
Clo g_heff_2esyntax_2esurface_2eassembleOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eassembleOne_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eassembleOne(V v_broken_240, V v_rest_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Sig: {
    V v_declared_243 = heff_field(v_x3_242, 0);
    V v_f_244 = heff_field(v_x3_242, 1);
    V v_fsp_245 = heff_field(v_x3_242, 2);
    V v_ty_246 = heff_field(v_x3_242, 3);
    V v_sp_247 = heff_field(v_x3_242, 4);
    V v_ru_24x3_242_24Sig = heff_take_reuse_n(v_x3_242, 31ULL, 5);
    V v_x3_248 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_f_244), v_broken_240));
    V v_t_2410;
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nothing: {
      v_t_2410 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_248, 0ULL, 1);
      v_t_2410 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_248);
    }
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_rest_241);
      heff_drop(v_t_2410);
      V v_t_2411 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_AbandonWord)});
      V v_t_2412 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_dup(v_f_244), heff_dup(v_fsp_245), NTAG(TAG_Nil), heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_247)})});
      V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_fsp_245, 0)), heff_dup(heff_rfield(v_sp_247, 1))});
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_t_2413}), NTAG(TAG_Nil)});
      V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Sig, TAG_DeclEquations, 5, (V[]){v_f_244, v_fsp_245, v_declared_243, v_ty_246, v_t_2414}), v_sp_247});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
    } else {
      heff_drop(v_t_2410);
      V v_x6_2416 = (g_heff_2esyntax_2esurface_2eeqnsUnder(heff_dup(v_f_244), v_rest_241));
      switch (heff_tag_of(v_x6_2416)) {
      case TAG_Nothing: {
        heff_drop(v_declared_243);
        heff_drop(v_f_244);
        heff_drop_rec(v_fsp_245, 2);
        heff_drop(v_ty_246);
        heff_drop_rec(v_sp_247, 2);
        heff_drop_cell(v_ru_24x3_242_24Sig, 5);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_es_2417 = heff_field(v_x6_2416, 0);
        V v_ru_24x6_2416_24Just = heff_take_reuse_n(v_x6_2416, 1ULL, 1);
        V v_a_2418 = heff_take_field(v_sp_247, 1);
        V v_b_2419 = heff_take_field(v_es_2417, 1);
        V v_b_2421;
        if (heff_intLt_c(heff_dup(v_a_2418), heff_dup(v_b_2419))) {
          heff_drop(v_a_2418);
          v_b_2421 = v_b_2419;
        } else {
          heff_drop(v_b_2419);
          v_b_2421 = v_a_2418;
        }
        V v_t_2422 = heff_tag_at_n(v_ru_24x3_242_24Sig, TAG_DeclEquations, 5, (V[]){v_f_244, v_fsp_245, v_declared_243, v_ty_246, heff_get_n(v_es_2417, 0, 2)});
        V v_t_2423 = ({ V rv_1 = v_b_2421; V rr_ = heff_rec_reuse_nf(v_sp_247, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x6_2416_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_t_2423})});
      }
      default: return heff_nomatch(v_x6_2416);
      }
    }
  }
  case TAG_Eqn: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Whole: {
    V v_d_2427 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Whole = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    heff_drop(v_rest_241);
    return heff_tag_at_n(v_ru_24x3_242_24Whole, TAG_Just, 1, (V[]){v_d_2427});
  }
  case TAG_Doc: {
    V v_d_2428 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Doc = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    heff_drop(v_rest_241);
    return heff_tag_at_n(v_ru_24x3_242_24Doc, TAG_Just, 1, (V[]){v_d_2428});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2eassembleOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eassembleOne(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2esigNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esigNames_entry, 1, 0};

V g_heff_2esyntax_2esurface_2esigNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_map_2eempty_get());
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Sig: {
      V v_f_244 = heff_field(v_x11_241, 1);
      V v_t_248 = (g_heff_2esyntax_2esurface_2esigNames(v_rest_242));
      return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_f_244), NTAG(TAG_MkUnit), v_t_248));
    }
    case TAG_Eqn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Whole: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Doc: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esigNames(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eassembleDiagOne_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eassembleDiagOne_str1, 30, "` has a type but no definition");
HEFF_LIT(g_heff_2esyntax_2esurface_2eassembleDiagOne_str2, 17, "` needs a type: `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eassembleDiagOne_str3, 7, " : ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eassembleDiagOne_str4, 1, "`");
Clo g_heff_2esyntax_2esurface_2eassembleDiagOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eassembleDiagOne_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eassembleDiagOne(V v_broken_240, V v_sigs_241, V v_eqns_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Sig: {
    V v_f_245 = heff_field(v_x4_243, 1);
    V v_sp_248 = heff_field(v_x4_243, 4);
    V v_x3_249 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_f_245), v_eqns_242));
    V v_x1_2411;
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      v_x1_2411 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_249, 0ULL, 1);
      v_x1_2411 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_249);
    }
    if ((heff_dup(v_x1_2411) == NTAG(TAG_True))) {
      heff_drop(v_x1_2411);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_x1_2411);
      V v_x3_2412 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_f_245), v_broken_240));
      V v_x1_2414;
      switch (heff_tag_of(v_x3_2412)) {
      case TAG_Nothing: {
        v_x1_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_2412, 0ULL, 1);
        v_x1_2414 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_2412);
      }
      if ((heff_dup(v_x1_2414) == NTAG(TAG_True))) {
        heff_drop(v_x1_2414);
        return NTAG(TAG_Nothing);
      } else {
        heff_drop(v_x1_2414);
        V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_str0), heff_strAppend(heff_dup(v_f_245), ((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_str1)));
        V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2415, heff_dup(v_sp_248), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
      }
    }
  }
  case TAG_Eqn: {
    V v_f_2417 = heff_field(v_x4_243, 0);
    V v_sp_2419 = heff_field(v_x4_243, 2);
    V v_x3_2420 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_f_2417), v_sigs_241));
    V v_x1_2422;
    switch (heff_tag_of(v_x3_2420)) {
    case TAG_Nothing: {
      v_x1_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2420, 0ULL, 1);
      v_x1_2422 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2420);
    }
    if ((heff_dup(v_x1_2422) == NTAG(TAG_True))) {
      heff_drop(v_x1_2422);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_x1_2422);
      V v_x3_2423 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_f_2417), v_broken_240));
      V v_x1_2425;
      switch (heff_tag_of(v_x3_2423)) {
      case TAG_Nothing: {
        v_x1_2425 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_2423, 0ULL, 1);
        v_x1_2425 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_2423);
      }
      if ((heff_dup(v_x1_2425) == NTAG(TAG_True))) {
        heff_drop(v_x1_2425);
        return NTAG(TAG_Nothing);
      } else {
        heff_drop(v_x1_2425);
        V v_t_2426 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_str2), heff_strAppend(heff_dup(v_f_2417), ((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_str3)));
        V v_t_2427 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_str4), heff_strAppend(heff_dup(v_f_2417), v_t_2426));
        V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2427, heff_dup(v_sp_2419), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2428});
      }
    }
  }
  case TAG_Whole: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Doc: {
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2esurface_2eassembleDiagOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2esyntax_2esurface_2eassembleDiagOne(a0, a1, a2, a3); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str3, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str7, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str19, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str21, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str41, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str43, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str45, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str46, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str47, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str48, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str49, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str51, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str52, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str53, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str54, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str55, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str56, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_str57, 12, "unexpected `");
Clo g_heff_2esyntax_2esurface_2eletL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eletL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eletL(V v_r_240, V v_e_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    heff_drop(v_r_240);
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_245 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_246 = heff_strAppend(heff_get_n(v_t_245, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str0));
    V v_msg_247 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str1), v_t_246);
    V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_244, 3), heff_get_n(v_t_244, 4, 9)});
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_247, v_t_248, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_z_242});
  }
  case TAG_EParen: {
    heff_drop(v_r_240);
    V v_t_2413 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2414 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2415 = heff_strAppend(heff_get_n(v_t_2414, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str2));
    V v_msg_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str3), v_t_2415);
    V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2413, 3), heff_get_n(v_t_2413, 4, 9)});
    V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2416, v_t_2417, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2418}), v_z_242});
  }
  case TAG_Named: {
    heff_drop(v_r_240);
    V v_t_2424 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2425 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2426 = heff_strAppend(heff_get_n(v_t_2425, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str4));
    V v_msg_2427 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str5), v_t_2426);
    V v_t_2428 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2424, 3), heff_get_n(v_t_2424, 4, 9)});
    V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2427, v_t_2428, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2429}), v_z_242});
  }
  case TAG_Tup: {
    heff_drop(v_r_240);
    V v_t_2434 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2435 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2436 = heff_strAppend(heff_get_n(v_t_2435, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str6));
    V v_msg_2437 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str7), v_t_2436);
    V v_t_2438 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2434, 3), heff_get_n(v_t_2434, 4, 9)});
    V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2437, v_t_2438, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2439}), v_z_242});
  }
  case TAG_Braces: {
    heff_drop(v_r_240);
    V v_t_2444 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2445 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2446 = heff_strAppend(heff_get_n(v_t_2445, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str8));
    V v_msg_2447 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str9), v_t_2446);
    V v_t_2448 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2444, 3), heff_get_n(v_t_2444, 4, 9)});
    V v_t_2449 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2447, v_t_2448, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2449}), v_z_242});
  }
  case TAG_Update: {
    heff_drop(v_r_240);
    V v_t_2456 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2457 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_2458 = heff_strAppend(heff_get_n(v_t_2457, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str10));
    V v_msg_2459 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str11), v_t_2458);
    V v_t_2460 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2456, 3), heff_get_n(v_t_2456, 4, 9)});
    V v_t_2461 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2459, v_t_2460, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2461}), v_z_242});
  }
  case TAG_EUSet: {
    heff_drop(v_r_240);
    V v_t_2465 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2466 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2467 = heff_strAppend(heff_get_n(v_t_2466, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str12));
    V v_msg_2468 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str13), v_t_2467);
    V v_t_2469 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2465, 3), heff_get_n(v_t_2465, 4, 9)});
    V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2468, v_t_2469, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2470}), v_z_242});
  }
  case TAG_InstB: {
    heff_drop(v_r_240);
    V v_t_2476 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2477 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2478 = heff_strAppend(heff_get_n(v_t_2477, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str14));
    V v_msg_2479 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str15), v_t_2478);
    V v_t_2480 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2476, 3), heff_get_n(v_t_2476, 4, 9)});
    V v_t_2481 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2479, v_t_2480, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2481}), v_z_242});
  }
  case TAG_EFSet: {
    heff_drop(v_r_240);
    V v_t_2485 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2486 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2487 = heff_strAppend(heff_get_n(v_t_2486, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str16));
    V v_msg_2488 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str17), v_t_2487);
    V v_t_2489 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2485, 3), heff_get_n(v_t_2485, 4, 9)});
    V v_t_2490 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2488, v_t_2489, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2490}), v_z_242});
  }
  case TAG_EFDefault: {
    heff_drop(v_r_240);
    V v_t_2494 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2495 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2496 = heff_strAppend(heff_get_n(v_t_2495, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str18));
    V v_msg_2497 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str19), v_t_2496);
    V v_t_2498 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2494, 3), heff_get_n(v_t_2494, 4, 9)});
    V v_t_2499 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2497, v_t_2498, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2499}), v_z_242});
  }
  case TAG_Sum: {
    heff_drop(v_r_240);
    V v_t_24105 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24106 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24107 = heff_strAppend(heff_get_n(v_t_24106, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str20));
    V v_msg_24108 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str21), v_t_24107);
    V v_t_24109 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24105, 3), heff_get_n(v_t_24105, 4, 9)});
    V v_t_24110 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24108, v_t_24109, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24110}), v_z_242});
  }
  case TAG_ECon: {
    heff_drop(v_r_240);
    V v_t_24113 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24114 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24115 = heff_strAppend(heff_get_n(v_t_24114, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str22));
    V v_msg_24116 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str23), v_t_24115);
    V v_t_24117 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24113, 3), heff_get_n(v_t_24113, 4, 9)});
    V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24116, v_t_24117, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24118}), v_z_242});
  }
  case TAG_EField: {
    heff_drop(v_r_240);
    V v_t_24121 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24122 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24123 = heff_strAppend(heff_get_n(v_t_24122, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str24));
    V v_msg_24124 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str25), v_t_24123);
    V v_t_24125 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24121, 3), heff_get_n(v_t_24121, 4, 9)});
    V v_t_24126 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24124, v_t_24125, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24126}), v_z_242});
  }
  case TAG_ENeg: {
    heff_drop(v_r_240);
    V v_t_24129 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24130 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24131 = heff_strAppend(heff_get_n(v_t_24130, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str26));
    V v_msg_24132 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str27), v_t_24131);
    V v_t_24133 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24129, 3), heff_get_n(v_t_24129, 4, 9)});
    V v_t_24134 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24132, v_t_24133, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24134}), v_z_242});
  }
  case TAG_App: {
    heff_drop(v_r_240);
    V v_t_24137 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24138 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24139 = heff_strAppend(heff_get_n(v_t_24138, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str28));
    V v_msg_24140 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str29), v_t_24139);
    V v_t_24141 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24137, 3), heff_get_n(v_t_24137, 4, 9)});
    V v_t_24142 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24140, v_t_24141, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24142}), v_z_242});
  }
  case TAG_Op: {
    heff_drop(v_r_240);
    V v_t_24146 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24147 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24148 = heff_strAppend(heff_get_n(v_t_24147, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str30));
    V v_msg_24149 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str31), v_t_24148);
    V v_t_24150 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24146, 3), heff_get_n(v_t_24146, 4, 9)});
    V v_t_24151 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24149, v_t_24150, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24151}), v_z_242});
  }
  case TAG_Ops: {
    heff_drop(v_r_240);
    V v_t_24154 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24155 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24156 = heff_strAppend(heff_get_n(v_t_24155, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str32));
    V v_msg_24157 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str33), v_t_24156);
    V v_t_24158 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24154, 3), heff_get_n(v_t_24154, 4, 9)});
    V v_t_24159 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24157, v_t_24158, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24159}), v_z_242});
  }
  case TAG_OpRhs: {
    heff_drop(v_r_240);
    V v_t_24162 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24163 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24164 = heff_strAppend(heff_get_n(v_t_24163, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str34));
    V v_msg_24165 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str35), v_t_24164);
    V v_t_24166 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24162, 3), heff_get_n(v_t_24162, 4, 9)});
    V v_t_24167 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24165, v_t_24166, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24167}), v_z_242});
  }
  case TAG_Ann: {
    heff_drop(v_r_240);
    V v_t_24171 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24172 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24173 = heff_strAppend(heff_get_n(v_t_24172, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str36));
    V v_msg_24174 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str37), v_t_24173);
    V v_t_24175 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24171, 3), heff_get_n(v_t_24171, 4, 9)});
    V v_t_24176 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24174, v_t_24175, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24176}), v_z_242});
  }
  case TAG_BVar: {
    heff_drop(v_r_240);
    V v_t_24178 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24179 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_24180 = heff_strAppend(heff_get_n(v_t_24179, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str38));
    V v_msg_24181 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str39), v_t_24180);
    V v_t_24182 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24178, 3), heff_get_n(v_t_24178, 4, 9)});
    V v_t_24183 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24181, v_t_24182, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24183}), v_z_242});
  }
  case TAG_BImp: {
    heff_drop(v_r_240);
    V v_t_24187 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24188 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24189 = heff_strAppend(heff_get_n(v_t_24188, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str40));
    V v_msg_24190 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str41), v_t_24189);
    V v_t_24191 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24187, 3), heff_get_n(v_t_24187, 4, 9)});
    V v_t_24192 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24190, v_t_24191, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24192}), v_z_242});
  }
  case TAG_BAnn: {
    heff_drop(v_r_240);
    V v_t_24198 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24199 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24200 = heff_strAppend(heff_get_n(v_t_24199, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str42));
    V v_msg_24201 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str43), v_t_24200);
    V v_t_24202 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24198, 3), heff_get_n(v_t_24198, 4, 9)});
    V v_t_24203 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24201, v_t_24202, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24203}), v_z_242});
  }
  case TAG_Lam: {
    heff_drop(v_r_240);
    V v_t_24208 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24209 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24210 = heff_strAppend(heff_get_n(v_t_24209, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str44));
    V v_msg_24211 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str45), v_t_24210);
    V v_t_24212 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24208, 3), heff_get_n(v_t_24208, 4, 9)});
    V v_t_24213 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24211, v_t_24212, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24213}), v_z_242});
  }
  case TAG_Case: {
    heff_drop(v_r_240);
    V v_t_24218 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24219 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24220 = heff_strAppend(heff_get_n(v_t_24219, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str46));
    V v_msg_24221 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str47), v_t_24220);
    V v_t_24222 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24218, 3), heff_get_n(v_t_24218, 4, 9)});
    V v_t_24223 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24221, v_t_24222, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24223}), v_z_242});
  }
  case TAG_EAlt: {
    heff_drop(v_r_240);
    V v_t_24227 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24228 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24229 = heff_strAppend(heff_get_n(v_t_24228, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str48));
    V v_msg_24230 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str49), v_t_24229);
    V v_t_24231 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24227, 3), heff_get_n(v_t_24227, 4, 9)});
    V v_t_24232 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24230, v_t_24231, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24232}), v_z_242});
  }
  case TAG_If: {
    heff_drop(v_r_240);
    V v_t_24239 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24240 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24241 = heff_strAppend(heff_get_n(v_t_24240, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str50));
    V v_msg_24242 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str51), v_t_24241);
    V v_t_24243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24239, 3), heff_get_n(v_t_24239, 4, 9)});
    V v_t_24244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24242, v_t_24243, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24244}), v_z_242});
  }
  case TAG_Do: {
    heff_drop(v_r_240);
    V v_t_24247 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24248 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24249 = heff_strAppend(heff_get_n(v_t_24248, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str52));
    V v_msg_24250 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str53), v_t_24249);
    V v_t_24251 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24247, 3), heff_get_n(v_t_24247, 4, 9)});
    V v_t_24252 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24250, v_t_24251, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24252}), v_z_242});
  }
  case TAG_ESBind: {
    heff_drop(v_r_240);
    V v_t_24256 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24257 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24258 = heff_strAppend(heff_get_n(v_t_24257, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str54));
    V v_msg_24259 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str55), v_t_24258);
    V v_t_24260 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24256, 3), heff_get_n(v_t_24256, 4, 9)});
    V v_t_24261 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24259, v_t_24260, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24261}), v_z_242});
  }
  case TAG_ELet: {
    V v_kw_24262 = heff_dup(heff_field(v_e_241, 0));
    V v_p_24263 = heff_dup(heff_field(v_e_241, 1));
    V v_ann0_24264 = heff_dup(heff_field(v_e_241, 2));
    V v_e5_24266 = heff_dup(heff_field(v_e_241, 4));
    V v_e6_24267 = heff_dup(heff_field(v_e_241, 5));
    switch (heff_tag_of(v_e6_24267)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      heff_drop(v_kw_24262);
      heff_drop(v_p_24263);
      heff_drop(v_ann0_24264);
      heff_drop(v_e5_24266);
      V v_t_24268 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24269 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
      V v_t_24270 = heff_strAppend(heff_get_n(v_t_24269, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_str56));
      V v_msg_24271 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_str57), v_t_24270);
      V v_t_24272 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24268, 3), heff_get_n(v_t_24268, 4, 9)});
      V v_t_24273 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24271, v_t_24272, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24273}), v_z_242});
    }
    case TAG_Just: {
      V v_e61_24274 = heff_field(v_e6_24267, 0);
      V v_ru_24e6_24267_24Just = heff_take_reuse_n(v_e6_24267, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      switch (heff_tag_of(v_e61_24274)) {
      case TAG_MkPair: {
        V v_body_24276 = heff_field(v_e61_24274, 1);
        V v_ru_24e61_24274_24MkPair = heff_take_reuse_n(v_e61_24274, 2ULL, 2);
        V v_m_24277 = (g_heff_2esyntax_2esurface_2eletHeadL(heff_dup(v_r_240), heff_dup(v_p_24263), v_ann0_24264, v_e5_24266));
        V v_x1_24278 = heff_tr(heff_call(v_m_24277, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24278)) {
        case TAG_MkPair: {
          V v_x11_24279 = heff_field(v_x1_24278, 0);
          V v_st_24280 = heff_field(v_x1_24278, 1);
          heff_take_n(v_x1_24278, 3ULL, 2);
          switch (heff_tag_of(v_x11_24279)) {
          case TAG_Left: {
            V v_e_24281 = heff_field(v_x11_24279, 0);
            heff_take_n(v_x11_24279, 1ULL, 1);
            heff_drop(v_r_240);
            heff_drop(v_kw_24262);
            heff_drop(v_p_24263);
            heff_drop(v_body_24276);
            return heff_tag_at_n(v_ru_24e61_24274_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e6_24267_24Just, TAG_Left, 1, (V[]){v_e_24281}), v_st_24280});
          }
          case TAG_Right: {
            V v_x_24282 = heff_field(v_x11_24279, 0);
            heff_take_n(v_x11_24279, 1ULL, 1);
            heff_drop_cell(v_ru_24e6_24267_24Just, 1);
            heff_drop_cell(v_ru_24e61_24274_24MkPair, 2);
            V v_t_24283 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_24263; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_24263); r_; });
            return (g_heff_2esyntax_2esurface_2eletBodyL(v_r_240, v_kw_24262, v_x_24282, v_t_24283, v_body_24276, v_st_24280));
          }
          default: return heff_nomatch(v_x11_24279);
          }
        }
        default: return heff_nomatch(v_x1_24278);
        }
      }
      default: return heff_nomatch(v_e61_24274);
      }
    }
    default: return heff_nomatch(v_e6_24267);
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eletL(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(V v_st_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_st_240, 0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    return v_st_240;
  }
  case TAG_Cons: {
    heff_take_n(v_t_241, 0ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_st_240, 0));
    V v_t_2413;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nil: {
      v_t_2413 = v_st_240;
      break;
    }
    case TAG_Cons: {
      V v_o_245 = heff_field(v_t_244, 0);
      V v_os_246 = heff_field(v_t_244, 1);
      heff_take_n(v_t_244, 3ULL, 2);
      V v_t_247 = heff_dup(heff_rfield(v_st_240, 1));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nil: {
        heff_drop(v_o_245);
        heff_drop(v_os_246);
        v_t_2413 = v_st_240;
        break;
      }
      case TAG_Cons: {
        V v_r_248 = heff_field(v_t_247, 0);
        V v_it2_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        switch (heff_tag_of(v_it2_249)) {
        case TAG_Nil: {
          heff_drop(v_o_245);
          heff_drop(v_os_246);
          heff_drop(v_r_248);
          v_t_2413 = v_st_240;
          break;
        }
        case TAG_Cons: {
          V v_l_2410 = heff_field(v_it2_249, 0);
          V v_rest_2411 = heff_field(v_it2_249, 1);
          heff_take_n(v_it2_249, 3ULL, 2);
          heff_drop_rec(v_st_240, 2);
          V v_t_2412 = (g_heff_2esyntax_2esurface_2eapplyOp(v_o_245, v_l_2410, v_r_248));
          v_t_2413 = heff_rec_n(2, shape_ops__out, (V[]){v_os_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_rest_2411})});
          break;
        }
        default: heff_nomatch(v_it2_249);
        }
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2413;
    v_st_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(a[0]);
}
Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(V v_e0_240, V v_rest_241, V v_st_242) {
top: ;
  V v_x_243 = heff_dup(heff_rfield(v_st_242, 5));
  V v_x_244 = heff_dup(heff_rfield(v_st_242, 6));
  V v_m_245 = (g_heff_2esyntax_2esurface_2echeckFixOf(heff_dup(v_x_243), v_x_244, heff_dup(v_rest_241)));
  V v_x1_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_242}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop(v_e0_240);
      heff_drop(v_rest_241);
      heff_drop(v_x_243);
      heff_drop(v_x_244);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 0ULL, 1);
      V v_t_2411 = heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_e0_240), NTAG(TAG_Nil)});
      V v_t_2412 = heff_rec_n(2, shape_ops__out, (V[]){NTAG(TAG_Nil), v_t_2411});
      V v_m_2413 = ({ V a_0 = v_x_243; V a_1 = v_x_244; V a_2 = v_t_2412; V a_3 = v_rest_241; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_248}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_e0_240);
          return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_st_2419 = (g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(v_x_2418));
          V v_t_2420 = heff_get_n(v_st_2419, 1, 2);
          V v_x_2423;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_Nil: {
            v_x_2423 = v_e0_240;
            break;
          }
          case TAG_Cons: {
            V v_x_2421 = heff_field(v_t_2420, 0);
            heff_take_n(v_t_2420, 1ULL, 2);
            heff_drop(v_e0_240);
            v_x_2423 = v_x_2421;
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Right, 1, (V[]){v_x_2423}), v_st_2416});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(heff_dup(v_x_241), v_t_243));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2efixDecls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixDecls_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixDecls(V v_ts_240, V v_k_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_k_241))) {
    if (heff_intLt_c(heff_dup(v_k_241), heff_arrayLength(heff_dup(v_ts_240)))) {
      V v_t_245 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_k_241));
      V v_t_246 = (g_heff_2esyntax_2esurface_2efixDeclAt(heff_dup(v_ts_240), heff_dup(v_k_241), v_t_245));
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        V t_0 = v_ts_240;
        V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
        V t_2 = v_acc_242;
        v_ts_240 = t_0;
        v_k_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
      case TAG_Just: {
        V v_d_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        V t_0 = v_ts_240;
        V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_247, v_acc_242});
        v_ts_240 = t_0;
        v_k_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    } else {
      heff_drop(v_ts_240);
      heff_drop(v_k_241);
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    }
  } else {
    heff_drop(v_ts_240);
    heff_drop(v_k_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
}
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixDecls(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_xs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_xs_243;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = (g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str2, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str3, 3, "con");
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(V v_ys_240, V v_pv_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_PCon: {
    V v_args_244 = heff_field(v_x2_242, 1);
    V v_t_246 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam0, 1, 1, (V[]){heff_dup(v_pv_241)}), v_args_244));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_246, v_ys_240));
  }
  case TAG_PAtom: {
    V v_t_247 = heff_field(v_x2_242, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str0))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 1)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str1))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str2))) {
          V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_247, 1))}));
          V v_t_2412 = (g_list_2eany(v_t_2411, v_pv_241));
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_t_2412);
            V v_x_2413 = heff_dup(heff_rfield(v_t_247, 1));
            V v_t_2414 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
            return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_t_2414});
          } else {
            heff_drop(v_t_2412);
            return v_ys_240;
          }
        } else {
          return v_ys_240;
        }
      } else {
        V v_x_2415 = heff_dup(heff_rfield(v_t_247, 1));
        V v_t_2416 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
        return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_t_2416});
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_str3))) {
        V v_t_2418 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_247, 1))}));
        V v_t_2419 = (g_list_2eany(v_t_2418, v_pv_241));
        if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
          heff_drop(v_t_2419);
          V v_x_2420 = heff_dup(heff_rfield(v_t_247, 1));
          V v_t_2421 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
          return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2420, v_t_2421});
        } else {
          heff_drop(v_t_2419);
          return v_ys_240;
        }
      } else {
        return v_ys_240;
      }
    }
  }
  case TAG_PParen: {
    V v_q_2423 = heff_field(v_x2_242, 1);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2423;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2426 = heff_field(v_x2_242, 1);
    V v_t_2430 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam1, 1, 1, (V[]){heff_dup(v_pv_241)}), v_ps_2426));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2430, v_ys_240));
  }
  case TAG_POp: {
    V v_l_2431 = heff_field(v_x2_242, 0);
    V v_q_2433 = heff_field(v_x2_242, 2);
    V v_t_2434 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_l_2431));
    V v_t_2435 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_q_2433));
    V v_t_2436 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2434, v_t_2435));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2436, v_ys_240));
  }
  case TAG_PRec: {
    V v_fs_2438 = heff_field(v_x2_242, 1);
    V v_t_2442 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam2, 1, 1, (V[]){heff_dup(v_pv_241)}), v_fs_2438));
    return (g_heff_2esyntax_2esurface_2eappendS(v_t_2442, v_ys_240));
  }
  case TAG_PField: {
    V v_q_2445 = heff_field(v_x2_242, 2);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2445;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2446 = heff_field(v_x2_242, 0);
    V v_q_2448 = heff_field(v_x2_242, 2);
    V v_x_2449 = heff_dup(heff_rfield(v_x_2446, 1));
    V v_cell_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2449, heff_hole()});
    V v_u_2451 = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(v_ys_240, v_pv_241, v_q_2448, heff_dup(v_cell_2450)));
    heff_drop(v_u_2451);
    return v_cell_2450;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam0(V self, V *args) {
  V v_q_245 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_245; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_245); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam1(V self, V *args) {
  V v_q_2429 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2429; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2429); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_lam2(V self, V *args) {
  V v_q_2441 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2441; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2441); r_; });
}