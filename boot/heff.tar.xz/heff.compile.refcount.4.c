// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CLet 49341
#define TAG_Given 9359
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_MkArm 55352
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define LBL_after 294093302
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_cells 295903083
#define LBL_flat 9641024
#define LBL_funs 9650075
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_owned 307523263
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sts 323756
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_takes 311482598
#define LBL_tokens 1078955205
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tokens, LBL_ret};
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_clo;
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_clo;
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_clo;
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_clo;
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_clo;
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_clo;
V g_heff_2ecompile_2erefcount_2ebuiltOf(V);
V g_heff_2ecompile_2erefcount_2ebuiltOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebuiltOf_clo;
V g_heff_2ecompile_2erefcount_2ecoerce(V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok2_clo;
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo;
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(V, V, V);
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_clo;
HeffT2 g_heff_2ecompile_2erefcount_2edeclRun_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
V g_heff_2ecompile_2erefcount_2efvOp(V);
V g_heff_2ecompile_2erefcount_2efvOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvOp_clo;
V g_heff_2ecompile_2erefcount_2efvRest(V, V);
V g_heff_2ecompile_2erefcount_2efvRest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvRest_clo;
V g_heff_2ecompile_2erefcount_2efvSts(V);
V g_heff_2ecompile_2erefcount_2efvSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_clo;
V g_heff_2ecompile_2erefcount_2efvSts_24tok1(V, V);
V g_heff_2ecompile_2erefcount_2efvSts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_24tok1_clo;
V g_heff_2ecompile_2erefcount_2efvTl(V);
V g_heff_2ecompile_2erefcount_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_clo;
V g_heff_2ecompile_2erefcount_2efvTl_24tok1(V, V);
V g_heff_2ecompile_2erefcount_2efvTl_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_24tok1_clo;
V g_heff_2ecompile_2erefcount_2efvVal(V);
V g_heff_2ecompile_2erefcount_2efvVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvVal_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2eintW(V, V);
V g_heff_2ecompile_2erefcount_2eintW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eintW_clo;
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(V, V);
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_clo;
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_clo;
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo;
V g_heff_2ecompile_2erefcount_2elentIn(V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentIn_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_clo;
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2eoperandsOf(V);
V g_heff_2ecompile_2erefcount_2eoperandsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsOf_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs(V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_clo;
V g_heff_2ecompile_2erefcount_2ereadsWith(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereadsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereadsWith_clo;
V g_heff_2ecompile_2erefcount_2ereuseArgs(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseV_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseV_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(V, V);
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etakeIn_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakesAt(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakesAt_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etokenOp_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2etokenSt_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etokenSts(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etokenSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etokenSts_clo;
V g_heff_2ecompile_2erefcount_2eunboxOf(V, V);
V g_heff_2ecompile_2erefcount_2eunboxOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxOf_clo;
V g_heff_2ecompile_2erefcount_2eunboxParam(V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithFrame(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
V g_list_2eany_24s1419545795x962553976(V, V, V);
V g_list_2eany_24s1419545795x962553976_entry(V self, V *a);
extern Clo g_list_2eany_24s1419545795x962553976_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24s698037429x265256386(V);
V g_list_2emap_24s698037429x265256386_entry(V self, V *a);
extern Clo g_list_2emap_24s698037429x265256386_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
Clo g_heff_2ecompile_2erefcount_2ewithPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithPath_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewithPath(V v_owned_240, V v_after_241, V v_ce_242) {
top: ;
  V v_funs_243 = heff_take_field(v_ce_242, 0);
  V v_bounce_244 = heff_take_field(v_ce_242, 1);
  V v_self_245 = heff_take_field(v_ce_242, 2);
  V v_lam_246 = heff_take_field(v_ce_242, 3);
  V v_borrowed_247 = heff_take_field(v_ce_242, 6);
  V v_bor_248 = heff_take_field(v_ce_242, 7);
  V v_known_249 = heff_take_field(v_ce_242, 8);
  V v_takes_2410 = heff_take_field(v_ce_242, 9);
  V v_reprs_2411 = heff_take_field(v_ce_242, 10);
  V v_sigs_2412 = heff_take_field(v_ce_242, 11);
  V v_flat_2413 = heff_take_field(v_ce_242, 12);
  V v_sure_2414 = heff_take_field(v_ce_242, 13);
  V v_sureRecs_2415 = heff_take_field(v_ce_242, 14);
  V v_tokens_2416 = heff_take_field(v_ce_242, 15);
  V v_ret_2417 = heff_get_n(v_ce_242, 16, 17);
  return heff_rec_n(17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, (V[]){v_funs_243, v_bounce_244, v_self_245, v_lam_246, v_owned_240, v_after_241, v_borrowed_247, v_bor_248, v_known_249, v_takes_2410, v_reprs_2411, v_sigs_2412, v_flat_2413, v_sure_2414, v_sureRecs_2415, v_tokens_2416, v_ret_2417});
}
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithPath(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efreeGo_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2efreeGo(V v_bs_240, V v_seen_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_bs_240, v_v_244));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_v_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_x_249 = v_field_248;
        heff_drop(v_x_249);
        V t_0 = v_bs_240;
        V t_1 = v_seen_241;
        V t_2 = v_vs_245;
        V t_3 = v_acc_243;
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      } else {
        heff_drop(v_field_248);
        HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_seen_241, v_v_244));
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop(v_v_244);
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            V v_x_2413 = v_field_2412;
            heff_drop(v_x_2413);
            V t_0 = v_bs_240;
            V t_1 = v_seen_241;
            V t_2 = v_vs_245;
            V t_3 = v_acc_243;
            v_bs_240 = t_0;
            v_seen_241 = t_1;
            v_x3_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          } else {
            heff_drop(v_field_2412);
            V v_t_2414 = (g_std_2emap_2einsert_24s93785294x875597928(v_seen_241, heff_dup(v_v_244), NTAG(TAG_MkUnit)));
            V t_0 = v_bs_240;
            V t_1 = v_t_2414;
            V t_2 = v_vs_245;
            V t_3 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_v_244, v_acc_243});
            v_bs_240 = t_0;
            v_seen_241 = t_1;
            v_x3_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2efreeGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erefcount_2efvVal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvVal_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2efvVal(V v_v_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_240}), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_bs_245 = v_field_243;
    V v_ms_246 = v_field_244;
    V v_bs_247 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_245));
    V v_ms_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_246));
    V v_t_249 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_247; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_bs_247); r_; });
    return ({ V a_0 = v_t_249; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_ms_248; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  }
}
V g_heff_2ecompile_2erefcount_2efvVal_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvVal(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2efvOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvOp_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2efvOp(V v_o_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_240}), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_bs_245 = v_field_243;
    V v_ms_246 = v_field_244;
    V v_bs_247 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_245));
    V v_ms_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_246));
    V v_t_249 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_247; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_bs_247); r_; });
    return ({ V a_0 = v_t_249; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_ms_248; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  }
}
V g_heff_2ecompile_2erefcount_2efvOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvOp(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2efvRest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvRest_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2efvRest(V v_ss_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return (g_heff_2ecompile_2erefcount_2efvSts(v_ss_240));
  }
  case TAG_Just: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_ITl, 1, (V[]){v_t_242}), NTAG(TAG_Nil)});
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_240}), v_t_243});
    HeffT2 v_t_245 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_244));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_bs_248 = v_field_246;
      V v_ms_249 = v_field_247;
      V v_bs_2410 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_248));
      V v_ms_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_249));
      V v_t_2412 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2410; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_bs_2410); r_; });
      return ({ V a_0 = v_t_2412; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_ms_2411; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2efvRest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvRest(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2elentIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentIn_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2elentIn(V v_ce_240, V v_bi_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_es_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2erefcount_2eelemI(heff_dup(v_i_242), v_bi_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_x1_2434;
      switch (heff_tag_of(v_e_244)) {
      case TAG_SVar: {
        V v_x_247 = heff_field(v_e_244, 0);
        V v_ru_24e_244_24SVar = heff_take_reuse_n(v_e_244, 1ULL, 1);
        HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_ce_240, 10), v_x_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            heff_drop(v_x_247);
            heff_drop_cell(v_ru_24e_244_24SVar, 1);
            V v_x_2411 = v_field_2410;
            heff_drop(v_x_2411);
            v_x1_2434 = NTAG(TAG_Nothing);
          } else {
            heff_drop(v_field_2410);
            v_x1_2434 = heff_tag_at_n(v_ru_24e_244_24SVar, TAG_Just, 1, (V[]){v_x_247});
          }
        }
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_e_244, 0ULL, 3);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_e_244, 0ULL, 4);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_244);
      }
      V v_xs_2435 = (g_heff_2ecompile_2erefcount_2elentIn(v_ce_240, v_bi_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_es_245));
      switch (heff_tag_of(v_x1_2434)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        return v_xs_2435;
      }
      case TAG_Just: {
        V v_x_2436 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_x_2436, v_xs_2435});
      }
      default: return heff_nomatch(v_x1_2434);
      }
    } else {
      heff_drop(v_e_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_ce_240;
      V t_1 = v_bi_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_es_245;
      v_ce_240 = t_0;
      v_bi_241 = t_1;
      v_i_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erefcount_2elentIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2elentIn(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2eunboxParam_str0, 4, "box$");
Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eunboxParam_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eunboxParam(V v_ce_240, V v_lent_241, V v_x_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_ce_240, 10), v_x_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_245;
      heff_drop(v_x_246);
      HeffT2 v_t_247 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2413;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_rp_2411;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2410 = v_field_249;
          v_rp_2411 = v_x_2410;
        } else {
          heff_drop(v_field_249);
          v_rp_2411 = NTAG(TAG_RepV);
        }
        V v_v_2412 = heff_tag_n(TAG_RLocal, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2eunboxParam_str0), heff_dup(v_x_242))});
        if ((heff_dup(v_lent_241) == NTAG(TAG_True))) {
          v_t_2413 = heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_2411, v_v_2412});
        } else {
          v_t_2413 = heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_2411, v_v_2412});
        }
      }
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_2413}), NTAG(TAG_Nil)});
    } else {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_x_242);
      heff_drop(v_field_245);
      return NTAG(TAG_Nil);
    }
  }
}
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eunboxParam(a[0], a1, a[2]); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2erefcount_2etakeIn_24cpr(V v_ts_240, V v_live_241, V v_e_242, V v_l_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SVar: {
    V v_x_245 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_t_246 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_245, v_live_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_list_2eany_24s1419545795x962553976(v_x_245, v_l_243, v_ts_240));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_RTakeField, 2, (V[]){v_x_245, v_i_244})}});
      } else {
        heff_drop(v_i_244);
        heff_drop(v_x_245);
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_i_244);
      heff_drop(v_x_245);
      heff_drop(v_t_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_SGlobal: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SInt: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFloat: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SStr: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SBytes: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFixed: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFloat32: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimFn: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_e_242, 0ULL, 4);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2eunboxOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eunboxOf_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eunboxOf(V v_rp_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_RLocal: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RDup: {
    V v_x_243 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24RDup = heff_take_reuse_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, heff_tag_at_n(v_ru_24v_241_24RDup, TAG_RLocal, 1, (V[]){v_x_243})});
  }
  case TAG_RClo: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGet: {
    V v_g_245 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24RGet = heff_take_reuse_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, heff_tag_at_n(v_ru_24v_241_24RGet, TAG_RGetRaw, 1, (V[]){v_g_245})});
  }
  case TAG_RGetRaw: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RInt: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFloat: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RStr: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RBytes: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFixed: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RF32: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RNTag: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RTag: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RTagIn: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RRec: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RRecIn: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RField: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RDupE: {
    V v_e_2435 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, v_e_2435});
  }
  case TAG_RFieldV: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGetN: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFieldU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGetNU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RWord: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RTakeField: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGetLabel: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrimFn: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrim: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RLam: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RCall: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RApply: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RBool: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RAbandon: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RBox: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RUnbox: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPeek: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrimU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrimAt: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFixU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RF32U: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RF64U: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erefcount_2eunboxOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eunboxOf(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2ereuseOp_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(V v_ru_240, V v_n_241, V v_o_242) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_v_243 = heff_field(v_o_242, 0);
    V v_ru_24o_242_24OSimple = heff_take_reuse_n(v_o_242, 1ULL, 1);
    HeffT2 v_t_244 = (g_heff_2ecompile_2erefcount_2ereuseV_24cpr(v_ru_240, v_n_241, v_v_243));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_b_247 = v_field_245;
      V v_v2_248 = v_field_246;
      return ((HeffT2){{v_b_247, heff_tag_at_n(v_ru_24o_242_24OSimple, TAG_OSimple, 1, (V[]){v_v2_248})}});
    }
  }
  case TAG_OCall: {
    V v_g_249 = heff_field(v_o_242, 0);
    V v_argv_2410 = heff_field(v_o_242, 1);
    V v_ru_24o_242_24OCall = heff_take_reuse_n(v_o_242, 3ULL, 2);
    V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseOp_24cpr_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_argv_2410; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_argv_2410); r_; });
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkPair: {
      V v_b_2413 = heff_field(v_t_2412, 0);
      V v_as2_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 3ULL, 2);
      return ((HeffT2){{v_b_2413, heff_tag_at_n(v_ru_24o_242_24OCall, TAG_OCall, 2, (V[]){v_g_249, v_as2_2414})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2412)}});
    }
  }
  case TAG_OApply: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), v_o_242}});
  }
  case TAG_OPrim: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), v_o_242}});
  }
  case TAG_OAbandon: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), v_o_242}});
  }
  case TAG_OBool: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), v_o_242}});
  }
  default: return ((HeffT2){{heff_nomatch(v_o_242)}});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseOp_24cpr_lam0(V self, V *args) {
  V v_v_2411 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2411));
}
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(V v_ru_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_SLet: {
      V v_x_245 = heff_field(v_x41_243, 0);
      V v_o_246 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 3ULL, 2);
      HeffT2 v_t_247 = (g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_o_246));
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_b_2410 = v_field_248;
        V v_o2_2411 = v_field_249;
        if ((heff_dup(v_b_2410) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_b_2410);
          V v_t_2412 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SLet, 2, (V[]){v_x_245, v_o2_2411}), v_rest_244});
          return ((HeffT2){{NTAG(TAG_True), v_t_2412}});
        } else {
          heff_drop(v_b_2410);
          HeffT2 v_t_2413 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
          {
            V v_field_2414 = v_t_2413.f[0];
            V v_field_2415 = v_t_2413.f[1];
            V v_b_2416 = v_field_2414;
            V v_ss_2417 = v_field_2415;
            V v_t_2418 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SLet, 2, (V[]){v_x_245, v_o2_2411}), v_ss_2417});
            return ((HeffT2){{v_b_2416, v_t_2418}});
          }
        }
      }
    }
    case TAG_SDecl: {
      HeffT2 v_t_2420 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
      {
        V v_field_2421 = v_t_2420.f[0];
        V v_field_2422 = v_t_2420.f[1];
        V v_b_2423 = v_field_2421;
        V v_ss_2424 = v_field_2422;
        return ((HeffT2){{v_b_2423, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_x41_243, v_ss_2424})}});
      }
    }
    case TAG_SSet: {
      V v_x_2425 = heff_field(v_x41_243, 0);
      V v_o_2426 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 3ULL, 2);
      HeffT2 v_t_2427 = (g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_o_2426));
      {
        V v_field_2428 = v_t_2427.f[0];
        V v_field_2429 = v_t_2427.f[1];
        V v_b_2430 = v_field_2428;
        V v_o2_2431 = v_field_2429;
        if ((heff_dup(v_b_2430) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_b_2430);
          V v_t_2432 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SSet, 2, (V[]){v_x_2425, v_o2_2431}), v_rest_244});
          return ((HeffT2){{NTAG(TAG_True), v_t_2432}});
        } else {
          heff_drop(v_b_2430);
          HeffT2 v_t_2433 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
          {
            V v_field_2434 = v_t_2433.f[0];
            V v_field_2435 = v_t_2433.f[1];
            V v_b_2436 = v_field_2434;
            V v_ss_2437 = v_field_2435;
            V v_t_2438 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SSet, 2, (V[]){v_x_2425, v_o2_2431}), v_ss_2437});
            return ((HeffT2){{v_b_2436, v_t_2438}});
          }
        }
      }
    }
    case TAG_SIf: {
      V v_c_2439 = heff_field(v_x41_243, 0);
      V v_ts_2440 = heff_field(v_x41_243, 1);
      V v_fs_2441 = heff_field(v_x41_243, 2);
      heff_take_n(v_x41_243, 7ULL, 3);
      HeffT2 v_t_2442 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_ts_2440));
      {
        V v_field_2443 = v_t_2442.f[0];
        V v_field_2444 = v_t_2442.f[1];
        V v_bt_2445 = v_field_2443;
        V v_ts2_2446 = v_field_2444;
        HeffT2 v_t_2447 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_fs_2441));
        {
          V v_field_2448 = v_t_2447.f[0];
          V v_field_2449 = v_t_2447.f[1];
          V v_bf_2450 = v_field_2448;
          V v_fs2_2451 = v_field_2449;
          if (((heff_dup(v_bt_2445) == NTAG(TAG_True)) || (heff_dup(v_bf_2450) == NTAG(TAG_True)))) {
            heff_drop(v_ru_240);
            heff_drop(v_n_241);
            heff_drop(v_bt_2445);
            heff_drop(v_bf_2450);
            V v_t_2452 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SIf, 3, (V[]){v_c_2439, v_ts2_2446, v_fs2_2451}), v_rest_244});
            return ((HeffT2){{NTAG(TAG_True), v_t_2452}});
          } else {
            heff_drop(v_bt_2445);
            heff_drop(v_bf_2450);
            HeffT2 v_t_2453 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
            {
              V v_field_2454 = v_t_2453.f[0];
              V v_field_2455 = v_t_2453.f[1];
              V v_b_2456 = v_field_2454;
              V v_ss_2457 = v_field_2455;
              V v_t_2458 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SIf, 3, (V[]){v_c_2439, v_ts2_2446, v_fs2_2451}), v_ss_2457});
              return ((HeffT2){{v_b_2456, v_t_2458}});
            }
          }
        }
      }
    }
    case TAG_SCase: {
      V v_v_2459 = heff_field(v_x41_243, 0);
      V v_arms_2460 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24SCase = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      V v_ps_2470 = (g_list_2emap_24tok2(v_ru_24x41_243_24SCase, heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr_lam0, 1, 2, (V[]){heff_dup(v_ru_240), heff_dup(v_n_241)}), v_arms_2460));
      V v_b_2471 = (g_list_2eany_24s910662703x1730636603(v_ps_2470));
      V v_as2_2472 = (g_list_2emap_24s1173914895x100384474(v_ps_2470));
      if ((heff_dup(v_b_2471) == NTAG(TAG_True))) {
        heff_drop(v_ru_240);
        heff_drop(v_n_241);
        heff_drop(v_b_2471);
        V v_t_2473 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SCase, 2, (V[]){v_v_2459, v_as2_2472}), v_rest_244});
        return ((HeffT2){{NTAG(TAG_True), v_t_2473}});
      } else {
        heff_drop(v_b_2471);
        HeffT2 v_t_2474 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
        {
          V v_field_2475 = v_t_2474.f[0];
          V v_field_2476 = v_t_2474.f[1];
          V v_b_2477 = v_field_2475;
          V v_ss_2478 = v_field_2476;
          V v_t_2479 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SCase, 2, (V[]){v_v_2459, v_as2_2472}), v_ss_2478});
          return ((HeffT2){{v_b_2477, v_t_2479}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr_lam0(V self, V *args) {
  V v_x4_2461 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x4_2461)) {
  case TAG_MkArm: {
    V v_t_2462 = heff_field(v_x4_2461, 0);
    V v_vs_2463 = heff_field(v_x4_2461, 1);
    V v_ss_2464 = heff_field(v_x4_2461, 2);
    V v_ru_24x4_2461_24MkArm = heff_take_reuse_n(v_x4_2461, 7ULL, 3);
    HeffT2 v_t_2465 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_ss_2464));
    {
      V v_field_2466 = v_t_2465.f[0];
      V v_field_2467 = v_t_2465.f[1];
      V v_b_2468 = v_field_2466;
      V v_x_2469 = v_field_2467;
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2468, heff_tag_at_n(v_ru_24x4_2461_24MkArm, TAG_MkArm, 3, (V[]){v_t_2462, v_vs_2463, v_x_2469})});
    }
  }
  default: return heff_nomatch(v_x4_2461);
  }
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2etokenOp_24cpr_str0, 4, "$tok");
HEFF_LIT(g_heff_2ecompile_2erefcount_2etokenOp_24cpr_str1, 4, "$tok");

HeffT2 g_heff_2ecompile_2erefcount_2etokenOp_24cpr(V v_tk_240, V v_ru_241, V v_n_242, V v_o_243) {
top: ;
  switch (heff_tag_of(v_o_243)) {
  case TAG_OSimple: {
    heff_drop_rec(v_tk_240, 2);
    heff_drop(v_ru_241);
    heff_drop(v_n_242);
    return ((HeffT2){{NTAG(TAG_False), v_o_243}});
  }
  case TAG_OCall: {
    V v_g_245 = heff_field(v_o_243, 0);
    V v_argv_246 = heff_field(v_o_243, 1);
    V v_ru_24o_243_24OCall = heff_take_reuse_n(v_o_243, 3ULL, 2);
    V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2etokenOp_24cpr_str0), heff_intShow(heff_dup(v_n_242)));
    HeffT2 v_t_248 = ({ V b_0 = heff_get_n(v_tk_240, 1, 2); V b_1 = heff_strAppend(heff_dup(v_g_245), v_t_247); HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_x_2411 = v_field_2410;
        heff_drop(v_x_2411);
        V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2etokenOp_24cpr_str1), heff_intShow(v_n_242));
        V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_ru_241}), v_argv_246});
        V v_f_2414 = heff_tag_at_n(v_ru_24o_243_24OCall, TAG_OCall, 2, (V[]){heff_strAppend(v_g_245, v_t_2412), v_t_2413});
        return ((HeffT2){{NTAG(TAG_True), v_f_2414}});
      } else {
        heff_drop(v_ru_241);
        heff_drop(v_n_242);
        heff_drop(v_field_2410);
        return ((HeffT2){{NTAG(TAG_False), heff_tag_at_n(v_ru_24o_243_24OCall, TAG_OCall, 2, (V[]){v_g_245, v_argv_246})}});
      }
    }
  }
  case TAG_OApply: {
    heff_drop_rec(v_tk_240, 2);
    heff_drop(v_ru_241);
    heff_drop(v_n_242);
    return ((HeffT2){{NTAG(TAG_False), v_o_243}});
  }
  case TAG_OPrim: {
    heff_drop_rec(v_tk_240, 2);
    heff_drop(v_ru_241);
    heff_drop(v_n_242);
    return ((HeffT2){{NTAG(TAG_False), v_o_243}});
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_tk_240, 2);
    heff_drop(v_ru_241);
    heff_drop(v_n_242);
    return ((HeffT2){{NTAG(TAG_False), v_o_243}});
  }
  case TAG_OBool: {
    heff_drop_rec(v_tk_240, 2);
    heff_drop(v_ru_241);
    heff_drop(v_n_242);
    return ((HeffT2){{NTAG(TAG_False), v_o_243}});
  }
  default: return ((HeffT2){{heff_nomatch(v_o_243)}});
  }
}
V g_heff_2ecompile_2erefcount_2etokenSt_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2etokenSt_24cpr(V v_k_240, V v_tk_241, V v_ru_242, V v_n_243, V v_st_244) {
top: ;
  switch (heff_tag_of(v_st_244)) {
  case TAG_SLet: {
    V v_x_245 = heff_field(v_st_244, 0);
    V v_o_246 = heff_field(v_st_244, 1);
    V v_ru_24st_244_24SLet = heff_take_reuse_n(v_st_244, 3ULL, 2);
    heff_drop_rec(v_k_240, 2);
    HeffT2 v_t_247 = (g_heff_2ecompile_2erefcount_2etokenOp_24cpr(v_tk_241, v_ru_242, v_n_243, v_o_246));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_b_2410 = v_field_248;
      V v_o2_2411 = v_field_249;
      return ((HeffT2){{v_b_2410, heff_tag_at_n(v_ru_24st_244_24SLet, TAG_SLet, 2, (V[]){v_x_245, v_o2_2411})}});
    }
  }
  case TAG_SDecl: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_tk_241);
    heff_drop(v_ru_242);
    heff_drop(v_n_243);
    return ((HeffT2){{NTAG(TAG_False), v_st_244}});
  }
  case TAG_SSet: {
    V v_x_2413 = heff_field(v_st_244, 0);
    V v_o_2414 = heff_field(v_st_244, 1);
    V v_ru_24st_244_24SSet = heff_take_reuse_n(v_st_244, 3ULL, 2);
    heff_drop_rec(v_k_240, 2);
    HeffT2 v_t_2415 = (g_heff_2ecompile_2erefcount_2etokenOp_24cpr(v_tk_241, v_ru_242, v_n_243, v_o_2414));
    {
      V v_field_2416 = v_t_2415.f[0];
      V v_field_2417 = v_t_2415.f[1];
      V v_b_2418 = v_field_2416;
      V v_o2_2419 = v_field_2417;
      return ((HeffT2){{v_b_2418, heff_tag_at_n(v_ru_24st_244_24SSet, TAG_SSet, 2, (V[]){v_x_2413, v_o2_2419})}});
    }
  }
  case TAG_SIf: {
    V v_c_2420 = heff_field(v_st_244, 0);
    V v_ts_2421 = heff_field(v_st_244, 1);
    V v_fs_2422 = heff_field(v_st_244, 2);
    V v_ru_24st_244_24SIf = heff_take_reuse_n(v_st_244, 7ULL, 3);
    heff_drop(v_tk_241);
    heff_drop(v_ru_242);
    heff_drop(v_n_243);
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_ts_2421}));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_MkPair: {
      V v_bt_2424 = heff_field(v_t_2423, 0);
      V v_ts2_2425 = heff_field(v_t_2423, 1);
      heff_take_n(v_t_2423, 3ULL, 2);
      V v_t_2426 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_fs_2422}));
      switch (heff_tag_of(v_t_2426)) {
      case TAG_MkPair: {
        V v_bf_2427 = heff_field(v_t_2426, 0);
        V v_fs2_2428 = heff_field(v_t_2426, 1);
        heff_take_n(v_t_2426, 3ULL, 2);
        V v_t_2429 = heff_bool(((heff_dup(v_bt_2424) == NTAG(TAG_True)) || (heff_dup(v_bf_2427) == NTAG(TAG_True))));
        heff_drop(v_bt_2424);
        heff_drop(v_bf_2427);
        return ((HeffT2){{v_t_2429, heff_tag_at_n(v_ru_24st_244_24SIf, TAG_SIf, 3, (V[]){v_c_2420, v_ts2_2425, v_fs2_2428})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2426)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2423)}});
    }
  }
  case TAG_SCase: {
    V v_v_2430 = heff_field(v_st_244, 0);
    V v_arms_2431 = heff_field(v_st_244, 1);
    V v_ru_24st_244_24SCase = heff_take_reuse_n(v_st_244, 3ULL, 2);
    heff_drop(v_tk_241);
    heff_drop(v_ru_242);
    heff_drop(v_n_243);
    V v_ps_2439 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2etokenSt_24cpr_lam0, 1, 1, (V[]){v_k_240}), v_arms_2431));
    V v_b_2440 = (g_list_2eany_24s910662703x1730636603(v_ps_2439));
    V v_as2_2441 = (g_list_2emap_24s1173914895x100384474(v_ps_2439));
    return ((HeffT2){{v_b_2440, heff_tag_at_n(v_ru_24st_244_24SCase, TAG_SCase, 2, (V[]){v_v_2430, v_as2_2441})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_st_244)}});
  }
}
V g_heff_2ecompile_2erefcount_2etokenSt_24cpr_lam0(V self, V *args) {
  V v_arm_2432 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_arm_2432)) {
  case TAG_MkArm: {
    V v_t_2433 = heff_field(v_arm_2432, 0);
    V v_vs_2434 = heff_field(v_arm_2432, 1);
    V v_ss_2435 = heff_field(v_arm_2432, 2);
    V v_ru_24arm_2432_24MkArm = heff_take_reuse_n(v_arm_2432, 7ULL, 3);
    V v_x3_2436 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_ss_2435}));
    switch (heff_tag_of(v_x3_2436)) {
    case TAG_MkPair: {
      V v_b_2437 = heff_field(v_x3_2436, 0);
      V v_x_2438 = heff_field(v_x3_2436, 1);
      V v_ru_24x3_2436_24MkPair = heff_take_reuse_n(v_x3_2436, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x3_2436_24MkPair, TAG_MkPair, 2, (V[]){v_b_2437, heff_tag_at_n(v_ru_24arm_2432_24MkArm, TAG_MkArm, 3, (V[]){v_t_2433, v_vs_2434, v_x_2438})});
    }
    default: return heff_nomatch(v_x3_2436);
    }
  }
  default: return heff_nomatch(v_arm_2432);
  }
}
Clo g_heff_2ecompile_2erefcount_2etokenSts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etokenSts_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2etokenSts(V v_k_240, V v_tk_241, V v_ru_242, V v_n_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_tk_241);
    heff_drop(v_ru_242);
    heff_drop(v_n_243);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_st_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    HeffT2 v_t_247 = (g_heff_2ecompile_2erefcount_2etokenSt_24cpr(heff_dup(v_k_240), v_tk_241, v_ru_242, v_n_243, v_st_245));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_x31_2410 = v_field_248;
      V v_st_2411 = v_field_249;
      if ((heff_dup(v_x31_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_k_240, 2);
        heff_drop(v_x31_2410);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_st_2411, v_rest_246})});
      } else {
        heff_drop(v_x31_2410);
        V v_x2_2412 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_rest_246}));
        switch (heff_tag_of(v_x2_2412)) {
        case TAG_MkPair: {
          V v_b_2413 = heff_field(v_x2_2412, 0);
          V v_ss_2414 = heff_field(v_x2_2412, 1);
          V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_b_2413, heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_st_2411, v_ss_2414})});
        }
        default: return heff_nomatch(v_x2_2412);
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2erefcount_2etokenSts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etokenSts(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2erefcount_2epeekArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epeekArgs_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2epeekArgs(V v_ce_240, V v_x_241, V v_argv_242, V v_rest_243) {
top: ;
  V v_borrowed_244 = heff_take_field(v_ce_240, 6);
  V v_reprs_245 = heff_get_n(v_ce_240, 10, 17);
  switch (heff_tag_of(v_argv_242)) {
  case TAG_Nil: {
    heff_drop(v_rest_243);
    heff_drop(v_borrowed_244);
    heff_drop(v_reprs_245);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_argv1_246 = heff_field(v_argv_242, 0);
    V v_argv2_247 = heff_field(v_argv_242, 1);
    V v_ru_24argv_242_24Cons = heff_take_reuse_n(v_argv_242, 3ULL, 2);
    switch (heff_tag_of(v_argv1_246)) {
    case TAG_SVar: {
      V v_a_248 = heff_field(v_argv1_246, 0);
      V v_ru_24argv1_246_24SVar = heff_take_reuse_n(v_argv1_246, 1ULL, 1);
      switch (heff_tag_of(v_argv2_247)) {
      case TAG_Nil: {
        heff_drop(v_rest_243);
        heff_drop(v_borrowed_244);
        heff_drop(v_reprs_245);
        heff_drop_cell(v_ru_24argv_242_24Cons, 2);
        heff_drop(v_a_248);
        heff_drop_cell(v_ru_24argv1_246_24SVar, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_i_249 = heff_field(v_argv2_247, 0);
        V v_argv22_2410 = heff_field(v_argv2_247, 1);
        heff_take_n(v_argv2_247, 3ULL, 2);
        switch (heff_tag_of(v_argv22_2410)) {
        case TAG_Nil: {
          V v_t_2411 = ({ V a_0 = v_a_248; V a_1 = v_borrowed_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_borrowed_244); r_; });
          if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
            heff_drop(v_t_2411);
            HeffT2 v_t_2412 = ({ V a_0 = v_reprs_245; V a_1 = v_x_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_reprs_245); r_; });
            {
              V v_field_2414 = v_t_2412.f[1];
              int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
              if ((v_tag_2413 == ((int64_t)0ULL))) {
                V v_x_2415 = v_field_2414;
                switch (heff_tag_of(v_x_2415)) {
                case TAG_RepV: {
                  V v_t_2416 = (g_heff_2ecompile_2erefcount_2eintW(v_x_241, v_rest_243));
                  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
                    heff_drop(v_t_2416);
                    return heff_tag_at_n(v_ru_24argv1_246_24SVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24argv_242_24Cons, TAG_MkPair, 2, (V[]){v_a_248, v_i_249})});
                  } else {
                    heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                    heff_drop(v_a_248);
                    heff_drop_cell(v_ru_24argv1_246_24SVar, 1);
                    heff_drop(v_i_249);
                    heff_drop(v_t_2416);
                    return NTAG(TAG_Nothing);
                  }
                }
                case TAG_RepFix: {
                  heff_take_n(v_x_2415, 0ULL, 1);
                  heff_drop(v_rest_243);
                  heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                  heff_drop(v_a_248);
                  heff_drop_cell(v_ru_24argv1_246_24SVar, 1);
                  heff_drop(v_i_249);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepF64: {
                  heff_drop(v_rest_243);
                  heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                  heff_drop(v_a_248);
                  heff_drop_cell(v_ru_24argv1_246_24SVar, 1);
                  heff_drop(v_i_249);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepInt: {
                  heff_drop(v_rest_243);
                  heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                  heff_drop(v_a_248);
                  heff_drop_cell(v_ru_24argv1_246_24SVar, 1);
                  heff_drop(v_i_249);
                  return NTAG(TAG_Nothing);
                }
                default: return heff_nomatch(v_x_2415);
                }
              } else {
                heff_drop(v_field_2414);
                V v_t_2418 = (g_heff_2ecompile_2erefcount_2eintW(v_x_241, v_rest_243));
                if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
                  heff_drop(v_t_2418);
                  return heff_tag_at_n(v_ru_24argv1_246_24SVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24argv_242_24Cons, TAG_MkPair, 2, (V[]){v_a_248, v_i_249})});
                } else {
                  heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                  heff_drop(v_a_248);
                  heff_drop_cell(v_ru_24argv1_246_24SVar, 1);
                  heff_drop(v_i_249);
                  heff_drop(v_t_2418);
                  return NTAG(TAG_Nothing);
                }
              }
            }
          } else {
            heff_drop(v_rest_243);
            heff_drop(v_reprs_245);
            heff_drop_cell(v_ru_24argv_242_24Cons, 2);
            heff_drop(v_a_248);
            heff_drop_cell(v_ru_24argv1_246_24SVar, 1);
            heff_drop(v_i_249);
            heff_drop(v_t_2411);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_argv22_2410, 0ULL, 2);
          heff_drop(v_rest_243);
          heff_drop(v_borrowed_244);
          heff_drop(v_reprs_245);
          heff_drop_cell(v_ru_24argv_242_24Cons, 2);
          heff_drop(v_a_248);
          heff_drop_cell(v_ru_24argv1_246_24SVar, 1);
          heff_drop(v_i_249);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_argv22_2410);
        }
      }
      default: return heff_nomatch(v_argv2_247);
      }
    }
    case TAG_SGlobal: {
      heff_take_n(v_argv1_246, 0ULL, 1);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SInt: {
      heff_take_n(v_argv1_246, 0ULL, 1);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      heff_take_na(v_argv1_246, 0ULL, 1);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      heff_take_n(v_argv1_246, 0ULL, 1);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      heff_take_n(v_argv1_246, 0ULL, 1);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      heff_take_n(v_argv1_246, 0ULL, 2);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      heff_take_na(v_argv1_246, 0ULL, 1);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_argv1_246, 0ULL, 1);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_argv1_246, 0ULL, 2);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_argv1_246, 0ULL, 3);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_argv1_246, 0ULL, 2);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_argv1_246, 0ULL, 4);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_argv1_246, 0ULL, 2);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_argv2_247);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_argv1_246);
    }
  }
  default: return heff_nomatch(v_argv_242);
  }
}
V g_heff_2ecompile_2erefcount_2epeekArgs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2epeekArgs(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2erefcount_2edeclRun_24cpr(V v_xs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_xs_240, v_x2_241}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_dup(heff_field(v_x2_241, 0));
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SLet: {
      heff_take_n(v_x21_242, 0ULL, 2);
      return ((HeffT2){{v_xs_240, v_x2_241}});
    }
    case TAG_SDecl: {
      V v_y_246 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Cons: {
        V v_rest_248 = heff_field(v_x2_241, 1);
        V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
        V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_246, NTAG(TAG_Nil)});
        V v_t_2410 = (g_prelude_2e_2b_2b(v_xs_240, v_t_249));
        V t_0 = v_t_2410;
        V t_1 = v_rest_248;
        v_xs_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
      }
    }
    case TAG_SSet: {
      heff_take_n(v_x21_242, 0ULL, 2);
      return ((HeffT2){{v_xs_240, v_x2_241}});
    }
    case TAG_SIf: {
      heff_take_n(v_x21_242, 0ULL, 3);
      return ((HeffT2){{v_xs_240, v_x2_241}});
    }
    case TAG_SCase: {
      heff_take_n(v_x21_242, 0ULL, 2);
      return ((HeffT2){{v_xs_240, v_x2_241}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(V v_ce_240, V v_xs_241, V v_t_242, V v_fv_243) {
top: ;
  V v_owned_244 = (g_prelude_2e_2b_2b(heff_dup(v_xs_241), v_fv_243));
  V v_wanted_245 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_242)));
  V v_xs_247 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam0, 1, 1, (V[]){v_wanted_245}), v_owned_244));
  V v_t_2413 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam1, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_247));
  V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
  V v_t_2415 = (g_heff_2ecompile_2erefcount_2ewithFrame(NTAG(TAG_Nothing), v_t_2414, v_ce_240));
  V v_t_2416 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(NTAG(TAG_Nil), v_t_2415));
  V v_ce_2417 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2413, NTAG(TAG_Nil), v_t_2416));
  return (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2417, v_t_242));
}
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_246); heff_drop(v_wanted_245); r_; });
}
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_248); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) ? ({ V v_x_2412 = heff_dup(v_field_2411); int c_ = 0; heff_drop(v_x_2412); c_; }) : 1));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_str0, 10, "arrayIndex");
Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V v_ce_240, V v_live_241, V v_want_242, V v_o_243) {
top: ;
  switch (heff_tag_of(v_o_243)) {
  case TAG_OSimple: {
    V v_v_244 = heff_field(v_o_243, 0);
    heff_take_n(v_o_243, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, v_want_242, v_v_244);
  }
  case TAG_OCall: {
    V v_g_245 = heff_field(v_o_243, 0);
    V v_argv_246 = heff_field(v_o_243, 1);
    V v_ru_24o_243_24OCall = heff_take_reuse_n(v_o_243, 3ULL, 2);
    HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 11), v_g_245));
    V v_t_2411;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_s_2410 = v_field_249;
        v_t_2411 = heff_get_n(v_s_2410, 1, 2);
      } else {
        heff_drop(v_field_249);
        v_t_2411 = NTAG(TAG_RepV);
      }
    }
    V v_t_2412 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24o_243_24OCall, TAG_OCall, 2, (V[]){v_g_245, v_argv_246})));
    return (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2411, v_want_242, v_t_2412));
  }
  case TAG_OApply: {
    V v_t_2415 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2415));
  }
  case TAG_OPrim: {
    V v_p_2416 = heff_field(v_o_243, 0);
    V v_argv_2417 = heff_field(v_o_243, 1);
    V v_ru_24o_243_24OPrim = heff_take_reuse_n(v_o_243, 3ULL, 2);
    if (heff_strEq_c_lent(v_p_2416, ((V)&g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_str0), 2)) {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        V v_t_2418 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2417));
        return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, heff_tag_at_n(v_ru_24o_243_24OPrim, TAG_RPrim, 2, (V[]){v_p_2416, v_t_2418})));
      }
      case TAG_RepFix: {
        heff_drop_cell(v_ru_24o_243_24OPrim, 2);
        V v_t_2420 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2417));
        return heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_2416, v_want_242, v_t_2420});
      }
      case TAG_RepF64: {
        heff_drop_cell(v_ru_24o_243_24OPrim, 2);
        V v_t_2421 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2417));
        return heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_2416, v_want_242, v_t_2421});
      }
      case TAG_RepInt: {
        heff_drop_cell(v_ru_24o_243_24OPrim, 2);
        V v_t_2422 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2417));
        return heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_2416, v_want_242, v_t_2422});
      }
      default: return heff_nomatch(v_want_242);
      }
    } else {
      V v_t_2423 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2417));
      return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, heff_tag_at_n(v_ru_24o_243_24OPrim, TAG_RPrim, 2, (V[]){v_p_2416, v_t_2423})));
    }
  }
  case TAG_OAbandon: {
    V v_t_2424 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2424));
  }
  case TAG_OBool: {
    V v_t_2426 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2426));
  }
  default: return heff_nomatch(v_o_243);
  }
}
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(V v_ce_240, V v_x_241, V v_o_242, V v_rest_243, V v_after_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    V v_fa_246 = (g_heff_2ecompile_2erefcount_2efvOp(heff_dup(v_o_242)));
    V v_known_247 = (g_heff_2ecompile_2erefcount_2ebuiltOf(heff_dup(v_o_242)));
    V v_t_2410;
    switch (heff_tag_of(v_after_244)) {
    case TAG_Nothing: {
      v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_rest_243)}), NTAG(TAG_Nil)});
      break;
    }
    case TAG_Just: {
      V v_t_248 = heff_dup(heff_field(v_after_244, 0));
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_248}), NTAG(TAG_Nil)});
      v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_rest_243)}), v_t_249});
      break;
    }
    default: heff_nomatch(v_after_244);
    }
    V v_t_2411 = (g_heff_2ecompile_2erefcount_2eoperandsOf(heff_dup(v_o_242)));
    V v_takes_2412 = (g_heff_2ecompile_2erefcount_2etakesAt(heff_dup(v_ce_240), NTAG(TAG_Nil), v_t_2410, v_t_2411));
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_rest_243), heff_dup(v_after_244)));
    V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2413, heff_dup(heff_rfield(v_ce_240, 5))));
    return ({ V a_0 = heff_dup(v_ce_240); V a_1 = heff_dup(v_x_241); V a_2 = v_fa_246; V a_3 = heff_clo_n(g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam0, 1, 3, (V[]){v_ce_240, v_x_241, v_o_242}); V a_4 = v_known_247; V a_5 = v_takes_2412; V a_6 = v_rest_243; V a_7 = v_after_244; V a_8 = v_t_2414; V r_ = (g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_known_247); r_; });
  }
  case TAG_Just: {
    V v_x71_2435 = heff_field(v_x7_245, 0);
    heff_drop(v_o_242);
    switch (heff_tag_of(v_x71_2435)) {
    case TAG_MkPair: {
      V v_a_2436 = heff_field(v_x71_2435, 0);
      V v_i_2437 = heff_field(v_x71_2435, 1);
      V v_t_2438 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_rest_243), heff_dup(v_after_244)));
      V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2438, heff_dup(heff_rfield(v_ce_240, 5))));
      return (g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(v_ce_240, v_x_241, heff_dup(v_a_2436), heff_dup(v_i_2437), v_rest_243, v_after_244, v_t_2439));
    }
    default: return heff_nomatch(v_x71_2435);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam1(V self, V *args) {
  V v_v_2430 = args[0];
  V v_ce2_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2431 = ({ V a_0 = v_v_2430; V b_1 = heff_get_n(v_ce2_2415, 5, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(v_v_2430); heff_drop(b_1); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2431) == NTAG(TAG_True)));
  heff_drop(v_x1_2431);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam0(V self, V *args) {
  V v_ce2_2415 = args[0];
  V v_ce_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_o_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2421;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    V v_t_2420;
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2418;
      v_t_2420 = v_x_2419;
    } else {
      heff_drop(v_field_2418);
      v_t_2420 = NTAG(TAG_RepV);
    }
    v_t_2421 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce2_2415), heff_dup(heff_rfield(v_ce2_2415, 5)), v_t_2420, heff_dup(v_o_242)));
  }
  V v_t_2434;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    heff_take_n(v_o_242, 0ULL, 1);
    heff_drop_rec(v_ce2_2415, 17);
    v_t_2434 = NTAG(TAG_Nil);
    break;
  }
  case TAG_OCall: {
    heff_take_n(v_o_242, 0ULL, 2);
    heff_drop_rec(v_ce2_2415, 17);
    v_t_2434 = NTAG(TAG_Nil);
    break;
  }
  case TAG_OApply: {
    heff_take_n(v_o_242, 0ULL, 2);
    heff_drop_rec(v_ce2_2415, 17);
    v_t_2434 = NTAG(TAG_Nil);
    break;
  }
  case TAG_OPrim: {
    heff_take_n(v_o_242, 0ULL, 2);
    heff_drop_rec(v_ce2_2415, 17);
    v_t_2434 = NTAG(TAG_Nil);
    break;
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_ce2_2415, 17);
    v_t_2434 = NTAG(TAG_Nil);
    break;
  }
  case TAG_OBool: {
    V v_ru_24o_242_24OBool = heff_take_reuse_n(v_o_242, 0ULL, 1);
    V v_xs_2432 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam1, 1, 1, (V[]){heff_dup(v_ce2_2415)}), heff_dup(heff_rfield(v_ce2_2415, 4))));
    V v_t_2433 = (g_heff_2ecompile_2erefcount_2edropsOf(v_ce2_2415, v_xs_2432));
    v_t_2434 = (g_list_2emap_24s1796125103x644876049_24tok1(v_ru_24o_242_24OBool, v_t_2433));
    break;
  }
  default: heff_nomatch(v_o_242);
  }
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_241, v_t_2421}), v_t_2434});
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(V v_ce_240, V v_taken_241, V v_lent_242, V v_t_243, V v_vs_244, V v_fb_245, V v_leaves_246, V v_p_247) {
top: ;
  V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
  V v_t_249 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_248, MK_INT(1LL))));
  V v_t_2410 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_vs_244), v_t_249));
  V v_ws_2415 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam0, 1, 1, (V[]){heff_dup(v_fb_245)}), v_t_2410));
  HeffT2 v_t_2416 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 13), v_t_243));
  V v_t_2420;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2418;
      v_t_2420 = v_x_2419;
    } else {
      heff_drop(v_field_2418);
      v_t_2420 = NTAG(TAG_Nil);
    }
  }
  V v_t_2421 = (g_std_2emap_2elookup_24s1930949324x2078207031(heff_rfield(v_ce_240, 12), v_t_243));
  V v_t_2422 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_t_2420; V a_2 = v_ws_2415; V a_3 = v_t_2421; V r_ = (g_heff_2ecompile_2erefcount_2ereadsWith(a_0, a_1, a_2, a_3)); heff_drop(v_t_2421); r_; });
  return (g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(v_ce_240, v_taken_241, v_lent_242, v_t_243, v_vs_244, v_fb_245, v_leaves_246, v_t_2422, v_p_247));
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(a[0], a1, a2, a[3], a[4], a[5], a[6], a[7]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam0(V self, V *args) {
  V v_p_2411 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414;
  switch (heff_tag_of(v_p_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_p_2411, 0);
    heff_take_n(v_p_2411, 1ULL, 2);
    v_t_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_p_2411);
  }
  return ({ V a_0 = v_t_2414; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_t_2414); heff_drop(v_fb_245); r_; });
}
Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_p_248 = heff_field(v_x7_245, 0);
    V v_ps_249 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_i_244);
      heff_drop(v_p_248);
      heff_drop(v_ps_249);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_2410 = heff_field(v_x8_246, 0);
      V v_es_2411 = heff_field(v_x8_246, 1);
      V v_ru_24x8_246_24Cons = heff_take_reuse_n(v_x8_246, 3ULL, 2);
      HeffT2 v_t_2412 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_ce_240, 10), v_p_248));
      V v_t_2426;
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_x_2415 = v_field_2414;
          heff_drop(v_x_2415);
          V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_2411)));
          V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2416); r_; });
          V v_t_2418 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x8_246_24Cons, v_t_2417, heff_dup(v_live_241)));
          V v_live_2419 = (g_prelude_2e_2b_2b(heff_dup(v_before_242), v_t_2418));
          HeffT2 v_t_2420 = ({ V a_0 = heff_rfield(v_ce_240, 10); V a_1 = v_p_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_p_248); r_; });
          V v_t_2425;
          {
            V v_field_2422 = v_t_2420.f[1];
            int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
            V v_t_2424;
            if ((v_tag_2421 == ((int64_t)0ULL))) {
              V v_x_2423 = v_field_2422;
              v_t_2424 = v_x_2423;
            } else {
              heff_drop(v_field_2422);
              v_t_2424 = NTAG(TAG_RepV);
            }
            v_t_2425 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2419, v_t_2424, heff_dup(v_e_2410)));
          }
          v_t_2426 = heff_tag_n(TAG_Given, 1, (V[]){v_t_2425});
        } else {
          heff_drop(v_p_248);
          heff_drop_cell(v_ru_24x8_246_24Cons, 2);
          heff_drop(v_field_2414);
          v_t_2426 = (g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), v_bi_243, heff_dup(v_i_244), heff_dup(v_e_2410), heff_dup(v_es_2411)));
        }
      }
      V v_cell_2427 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
      V v_u_2428 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2427));
      heff_drop(v_u_2428);
      V v_t_2429 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_2410; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_2410); r_; });
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_t_2429;
      V t_3 = v_bi_243;
      V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
      V t_5 = v_ps_249;
      V t_6 = v_es_2411;
      V t_7 = v_cell_2427;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_before_242 = t_2;
      v_bi_243 = t_3;
      v_i_244 = t_4;
      v_x7_245 = t_5;
      v_x8_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_b_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245;
    if ((heff_dup(v_b_244) == NTAG(TAG_True))) {
      heff_drop(v_b_244);
      v_t_245 = MK_INT(1LL);
    } else {
      heff_drop(v_b_244);
      v_t_245 = MK_INT(0LL);
    }
    V v_t_246 = (g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(v_f_240, v_xs_243));
    return heff_intAdd(v_t_245, heff_intMul(MK_INT(2LL), v_t_246));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam5(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2(V v_tok_240, V v_ce_241, V v_xs_242, V v_st_243, V v_rest_244, V v_after_245, V v_wb_246) {
top: ;
  V v_t_247 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_st_243), NTAG(TAG_Nil)});
  V v_t_248 = (g_heff_2ecompile_2erefcount_2efvSts(v_t_247));
  V v_wanted_249 = (g_prelude_2e_2b_2b(v_t_248, heff_dup(v_wb_246)));
  V v_xs_2412 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam0, 1, 1, (V[]){v_wanted_249}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_t_2413 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_2412));
  V v_t_2414 = (g_list_2emap_24s1796125103x644876049(v_t_2413));
  V v_t_2415 = (g_list_2emap_24s698037429x265256386(heff_dup(v_xs_242)));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_st_243), NTAG(TAG_Nil)});
  V v_t_2417 = (g_heff_2ecompile_2erefcount_2efvSts(v_t_2416));
  V v_wanted_2418 = (g_prelude_2e_2b_2b(v_t_2417, heff_dup(v_wb_246)));
  V v_t_2420 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam1, 1, 1, (V[]){v_wanted_2418}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_t_2421 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2420, heff_dup(v_wb_246), heff_dup(v_ce_241)));
  V v_t_2422 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2421));
  V v_t_2423 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(v_t_2422, v_st_243));
  V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2423));
  V v_xs_2427 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam2, 1, 1, (V[]){heff_dup(v_wb_246)}), heff_dup(v_xs_242)));
  V v_t_2428 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_2427));
  V v_t_2429 = (g_list_2emap_24s1796125103x644876049(v_t_2428));
  V v_t_2431 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam3, 1, 1, (V[]){heff_dup(v_wb_246)}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_xs_2433 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam4, 1, 1, (V[]){v_wb_246}), v_xs_242));
  V v_t_2439 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam5, 1, 1, (V[]){heff_dup(v_ce_241)}), v_xs_2433));
  V v_t_2440 = (g_prelude_2e_2b_2b(v_t_2431, v_t_2439));
  V v_t_2441 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), heff_dup(v_ce_241)));
  V v_ce_2442 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2440, heff_get_n(v_ce_241, 5, 17), v_t_2441));
  V v_t_2443 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2442, v_rest_244, v_after_245));
  V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2429, v_t_2443));
  V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2444));
  return (g_prelude_2e_2b_2b(v_t_2414, v_t_2445));
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam0(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = ({ V a_0 = v_v_2410; V a_1 = v_wanted_249; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2410); heff_drop(v_wanted_249); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam1(V self, V *args) {
  V v_v_2419 = args[0];
  V v_wanted_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2419; V a_1 = v_wanted_2418; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2419); heff_drop(v_wanted_2418); r_; });
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2426 = ({ V a_0 = v_x_2425; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2425); heff_drop(v_wb_246); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2426) == NTAG(TAG_True)));
  heff_drop(v_x1_2426);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam3(V self, V *args) {
  V v_v_2430 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2430; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2430); heff_drop(v_wb_246); r_; });
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2432; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2432); heff_drop(v_wb_246); r_; });
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_ce_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2435 = ({ V b_0 = heff_get_n(v_ce_241, 10, 17); V a_1 = v_x_2434; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2434); r_; });
  {
    V v_field_2437 = v_t_2435.f[1];
    int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2436 == ((int64_t)0ULL)) ? ({ V v_x_2438 = heff_dup(v_field_2437); int c_ = 0; heff_drop(v_x_2438); c_; }) : 1));
    heff_drop(v_field_2437);
    return v_ret_24bool;
  }
}