// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ATail 47533
#define TAG_ArrayIndex 31774
#define TAG_CLet 49341
#define TAG_Given 9359
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_KnownClo 18392
#define TAG_KnownRec 32578
#define TAG_KnownTag 34380
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_RCall 39004
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RGet 32719
#define TAG_RGetRaw 14078
#define TAG_RLocal 34280
#define TAG_RPeek 36757
#define TAG_RPrimAt 2075
#define TAG_RUnbox 59387
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Reuse 22912
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define LBL_after 294093302
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_cells 295903083
#define LBL_counted 1189688364
#define LBL_flat 9641024
#define LBL_flats 298871860
#define LBL_funs 9650075
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_names 305943394
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_plain 308106724
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sts 323756
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_takes 311482598
#define LBL_tokens 1078955205
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tokens, LBL_ret};
static uint32_t shape_plain__flats__names__counted__flat__sure[] = {LBL_plain, LBL_flats, LBL_names, LBL_counted, LBL_flat, LBL_sure};
V g_heff_2ecompile_2erefcount_2eanyW(V, V);
V g_heff_2ecompile_2erefcount_2eanyW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eanyW_clo;
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_clo;
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_clo;
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_clo;
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_clo;
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_clo;
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_clo;
V g_heff_2ecompile_2erefcount_2ecoerce(V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok1(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok1_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok2_clo;
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo;
V g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755_clo;
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(V, V, V);
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_clo;
V g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619_clo;
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_clo;
HeffT2 g_heff_2ecompile_2erefcount_2edeclRun_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
V g_heff_2ecompile_2erefcount_2efreeOf(V, V);
V g_heff_2ecompile_2erefcount_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeOf_clo;
V g_heff_2ecompile_2erefcount_2efvArm(V);
V g_heff_2ecompile_2erefcount_2efvArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvArm_clo;
V g_heff_2ecompile_2erefcount_2efvRest(V, V);
V g_heff_2ecompile_2erefcount_2efvRest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvRest_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(V, V);
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_clo;
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo;
V g_heff_2ecompile_2erefcount_2elentIn(V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentIn_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_clo;
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_clo;
V g_heff_2ecompile_2erefcount_2enotFlatAt(V, V, V);
V g_heff_2ecompile_2erefcount_2enotFlatAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2enotFlatAt_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs(V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_clo;
V g_heff_2ecompile_2erefcount_2ereuseArgs(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseV_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseV_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(V, V);
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
V g_heff_2ecompile_2erefcount_2etakesAt(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakesAt_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etokenOp_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2etokenSt_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxOf(V, V);
V g_heff_2ecompile_2erefcount_2eunboxOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxOf_clo;
V g_heff_2ecompile_2erefcount_2eunboxParam(V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
V g_list_2eany_24s332132496x946063656(V, V);
V g_list_2eany_24s332132496x946063656_entry(V self, V *a);
extern Clo g_list_2eany_24s332132496x946063656_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2efoldl_24s1050197499x1941129217(V, V);
V g_list_2efoldl_24s1050197499x1941129217_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1050197499x1941129217_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s479112018x1726839132(V);
V g_list_2ekeepIf_24s479112018x1726839132_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s479112018x1726839132_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s698037429x265256386(V);
V g_list_2emap_24s698037429x265256386_entry(V self, V *a);
extern Clo g_list_2emap_24s698037429x265256386_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2erefcount_2ewithPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithPath_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewithPath(V v_owned_240, V v_after_241, V v_ce_242) {
top: ;
  return ({ V rv_4 = v_owned_240; V rv_5 = v_after_241; V rr_ = heff_rec_reuse_nf(v_ce_242, 131023ULL, 17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, 4294963455u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithPath(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efreeGo_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2efreeGo(V v_bs_240, V v_seen_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_bs_240, v_v_244));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_v_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_x_249 = v_field_248;
        heff_drop(v_x_249);
        V t_0 = v_bs_240;
        V t_1 = v_seen_241;
        V t_2 = v_vs_245;
        V t_3 = v_acc_243;
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      } else {
        heff_drop(v_field_248);
        HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_241, v_v_244));
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop(v_v_244);
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            V v_x_2413 = v_field_2412;
            heff_drop(v_x_2413);
            V t_0 = v_bs_240;
            V t_1 = v_seen_241;
            V t_2 = v_vs_245;
            V t_3 = v_acc_243;
            v_bs_240 = t_0;
            v_seen_241 = t_1;
            v_x3_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          } else {
            heff_drop(v_field_2412);
            V v_t_2414 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_seen_241, heff_dup(v_v_244), NTAG(TAG_MkUnit)));
            V t_0 = v_bs_240;
            V t_1 = v_t_2414;
            V t_2 = v_vs_245;
            V t_3 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_v_244, v_acc_243});
            v_bs_240 = t_0;
            v_seen_241 = t_1;
            v_x3_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2efreeGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erefcount_2efvRest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvRest_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2efvRest(V v_ss_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_240}), NTAG(TAG_Nil)});
    HeffT2 v_t_243 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_242));
    {
      V v_field_244 = v_t_243.f[0];
      V v_field_245 = v_t_243.f[1];
      V v_bs_246 = v_field_244;
      V v_ms_247 = v_field_245;
      V v_ms_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_247));
      V v_t_249 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_246; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_246); r_; });
      return ({ V a_0 = v_t_249; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_248; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
    }
  }
  case TAG_Just: {
    V v_t_2410 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_ITl, 1, (V[]){v_t_2410}), NTAG(TAG_Nil)});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_240}), v_t_2411});
    HeffT2 v_t_2413 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2412));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_bs_2416 = v_field_2414;
      V v_ms_2417 = v_field_2415;
      V v_ms_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2417));
      V v_t_2419 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2416; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2416); r_; });
      return ({ V a_0 = v_t_2419; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2418; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2419); r_; });
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2efvRest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvRest(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2elentIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentIn_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2elentIn(V v_ce_240, V v_bi_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_es_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2erefcount_2eelemI(heff_dup(v_i_242), v_bi_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_x1_2434;
      switch (heff_tag_of(v_e_244)) {
      case TAG_SVar: {
        V v_x_247 = heff_field(v_e_244, 0);
        V v_ru_24e_244_24SVar = heff_take_reuse_n(v_e_244, 1ULL, 1);
        HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_ce_240, 10), v_x_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            heff_drop(v_x_247);
            heff_drop_cell(v_ru_24e_244_24SVar, 1);
            V v_x_2411 = v_field_2410;
            heff_drop(v_x_2411);
            v_x1_2434 = NTAG(TAG_Nothing);
          } else {
            heff_drop(v_field_2410);
            v_x1_2434 = heff_tag_at_n(v_ru_24e_244_24SVar, TAG_Just, 1, (V[]){v_x_247});
          }
        }
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_e_244, 0ULL, 3);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_e_244, 0ULL, 4);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2434 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_244);
      }
      V v_xs_2435 = (g_heff_2ecompile_2erefcount_2elentIn(v_ce_240, v_bi_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_es_245));
      switch (heff_tag_of(v_x1_2434)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        return v_xs_2435;
      }
      case TAG_Just: {
        V v_x_2436 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_x_2436, v_xs_2435});
      }
      default: return heff_nomatch(v_x1_2434);
      }
    } else {
      heff_drop(v_e_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_ce_240;
      V t_1 = v_bi_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_es_245;
      v_ce_240 = t_0;
      v_bi_241 = t_1;
      v_i_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erefcount_2elentIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2elentIn(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2eunboxParam_str0, 4, "box$");
Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eunboxParam_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eunboxParam(V v_ce_240, V v_lent_241, V v_x_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_ce_240, 10), v_x_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_245;
      heff_drop(v_x_246);
      HeffT2 v_t_247 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2413;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_rp_2411;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2410 = v_field_249;
          v_rp_2411 = v_x_2410;
        } else {
          heff_drop(v_field_249);
          v_rp_2411 = NTAG(TAG_RepV);
        }
        V v_v_2412 = heff_tag_n(TAG_RLocal, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2eunboxParam_str0), heff_dup(v_x_242))});
        if ((heff_dup(v_lent_241) == NTAG(TAG_True))) {
          v_t_2413 = heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_2411, v_v_2412});
        } else {
          v_t_2413 = heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_2411, v_v_2412});
        }
      }
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_2413}), NTAG(TAG_Nil)});
    } else {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_x_242);
      heff_drop(v_field_245);
      return NTAG(TAG_Nil);
    }
  }
}
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eunboxParam(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2eunboxOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eunboxOf_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eunboxOf(V v_rp_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_RDup: {
    V v_x_242 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24RDup = heff_take_reuse_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, heff_tag_at_n(v_ru_24v_241_24RDup, TAG_RLocal, 1, (V[]){v_x_242})});
  }
  case TAG_RGet: {
    V v_g_243 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24RGet = heff_take_reuse_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, heff_tag_at_n(v_ru_24v_241_24RGet, TAG_RGetRaw, 1, (V[]){v_g_243})});
  }
  case TAG_RDupE: {
    V v_e_244 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, v_e_244});
  }
  default: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  }
}
V g_heff_2ecompile_2erefcount_2eunboxOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eunboxOf(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2ereuseOp_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(V v_ru_240, V v_n_241, V v_o_242) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_v_243 = heff_field(v_o_242, 0);
    V v_ru_24o_242_24OSimple = heff_take_reuse_n(v_o_242, 1ULL, 1);
    HeffT2 v_t_244 = (g_heff_2ecompile_2erefcount_2ereuseV_24cpr(v_ru_240, v_n_241, v_v_243));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_b_247 = v_field_245;
      V v_v2_248 = v_field_246;
      return ((HeffT2){{v_b_247, heff_tag_at_n(v_ru_24o_242_24OSimple, TAG_OSimple, 1, (V[]){v_v2_248})}});
    }
  }
  case TAG_OCall: {
    V v_g_249 = heff_field(v_o_242, 0);
    V v_argv_2410 = heff_field(v_o_242, 1);
    V v_ru_24o_242_24OCall = heff_take_reuse_n(v_o_242, 3ULL, 2);
    V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseOp_24cpr_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_argv_2410; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_argv_2410); r_; });
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkPair: {
      V v_b_2413 = heff_field(v_t_2412, 0);
      V v_as2_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 3ULL, 2);
      return ((HeffT2){{v_b_2413, heff_tag_at_n(v_ru_24o_242_24OCall, TAG_OCall, 2, (V[]){v_g_249, v_as2_2414})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2412)}});
    }
  }
  case TAG_OApply: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), v_o_242}});
  }
  case TAG_OPrim: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), v_o_242}});
  }
  case TAG_OAbandon: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), v_o_242}});
  }
  case TAG_OBool: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), v_o_242}});
  }
  default: return ((HeffT2){{heff_nomatch(v_o_242)}});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseOp_24cpr_lam0(V self, V *args) {
  V v_v_2411 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2411));
}
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(V v_ru_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_SLet: {
      V v_x_245 = heff_field(v_x41_243, 0);
      V v_o_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24SLet = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      HeffT2 v_t_247 = (g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_o_246));
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_b_2410 = v_field_248;
        V v_o2_2411 = v_field_249;
        if ((heff_dup(v_b_2410) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_b_2410);
          V v_t_2412 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24SLet, TAG_SLet, 2, (V[]){v_x_245, v_o2_2411}), v_rest_244});
          return ((HeffT2){{NTAG(TAG_True), v_t_2412}});
        } else {
          heff_drop(v_b_2410);
          HeffT2 v_t_2413 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
          {
            V v_field_2414 = v_t_2413.f[0];
            V v_field_2415 = v_t_2413.f[1];
            V v_b_2416 = v_field_2414;
            V v_ss_2417 = v_field_2415;
            V v_t_2418 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24SLet, TAG_SLet, 2, (V[]){v_x_245, v_o2_2411}), v_ss_2417});
            return ((HeffT2){{v_b_2416, v_t_2418}});
          }
        }
      }
    }
    case TAG_SOnce: {
      HeffT2 v_t_2421 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
      {
        V v_field_2422 = v_t_2421.f[0];
        V v_field_2423 = v_t_2421.f[1];
        V v_b_2424 = v_field_2422;
        V v_ss_2425 = v_field_2423;
        return ((HeffT2){{v_b_2424, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_x41_243, v_ss_2425})}});
      }
    }
    case TAG_SDecl: {
      HeffT2 v_t_2427 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
      {
        V v_field_2428 = v_t_2427.f[0];
        V v_field_2429 = v_t_2427.f[1];
        V v_b_2430 = v_field_2428;
        V v_ss_2431 = v_field_2429;
        return ((HeffT2){{v_b_2430, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_x41_243, v_ss_2431})}});
      }
    }
    case TAG_SSet: {
      V v_x_2432 = heff_field(v_x41_243, 0);
      V v_o_2433 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24SSet = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      HeffT2 v_t_2434 = (g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_o_2433));
      {
        V v_field_2435 = v_t_2434.f[0];
        V v_field_2436 = v_t_2434.f[1];
        V v_b_2437 = v_field_2435;
        V v_o2_2438 = v_field_2436;
        if ((heff_dup(v_b_2437) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_b_2437);
          V v_t_2439 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24SSet, TAG_SSet, 2, (V[]){v_x_2432, v_o2_2438}), v_rest_244});
          return ((HeffT2){{NTAG(TAG_True), v_t_2439}});
        } else {
          heff_drop(v_b_2437);
          HeffT2 v_t_2440 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
          {
            V v_field_2441 = v_t_2440.f[0];
            V v_field_2442 = v_t_2440.f[1];
            V v_b_2443 = v_field_2441;
            V v_ss_2444 = v_field_2442;
            V v_t_2445 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24SSet, TAG_SSet, 2, (V[]){v_x_2432, v_o2_2438}), v_ss_2444});
            return ((HeffT2){{v_b_2443, v_t_2445}});
          }
        }
      }
    }
    case TAG_SIf: {
      V v_c_2446 = heff_field(v_x41_243, 0);
      V v_ts_2447 = heff_field(v_x41_243, 1);
      V v_fs_2448 = heff_field(v_x41_243, 2);
      V v_ru_24x41_243_24SIf = heff_take_reuse_n(v_x41_243, 7ULL, 3);
      HeffT2 v_t_2449 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_ts_2447));
      {
        V v_field_2450 = v_t_2449.f[0];
        V v_field_2451 = v_t_2449.f[1];
        V v_bt_2452 = v_field_2450;
        V v_ts2_2453 = v_field_2451;
        HeffT2 v_t_2454 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_fs_2448));
        {
          V v_field_2455 = v_t_2454.f[0];
          V v_field_2456 = v_t_2454.f[1];
          V v_bf_2457 = v_field_2455;
          V v_fs2_2458 = v_field_2456;
          if (((heff_dup(v_bt_2452) == NTAG(TAG_True)) || (heff_dup(v_bf_2457) == NTAG(TAG_True)))) {
            heff_drop(v_ru_240);
            heff_drop(v_n_241);
            heff_drop(v_bt_2452);
            heff_drop(v_bf_2457);
            V v_t_2459 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24SIf, TAG_SIf, 3, (V[]){v_c_2446, v_ts2_2453, v_fs2_2458}), v_rest_244});
            return ((HeffT2){{NTAG(TAG_True), v_t_2459}});
          } else {
            heff_drop(v_bt_2452);
            heff_drop(v_bf_2457);
            HeffT2 v_t_2460 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
            {
              V v_field_2461 = v_t_2460.f[0];
              V v_field_2462 = v_t_2460.f[1];
              V v_b_2463 = v_field_2461;
              V v_ss_2464 = v_field_2462;
              V v_t_2465 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24SIf, TAG_SIf, 3, (V[]){v_c_2446, v_ts2_2453, v_fs2_2458}), v_ss_2464});
              return ((HeffT2){{v_b_2463, v_t_2465}});
            }
          }
        }
      }
    }
    case TAG_SCase: {
      V v_v_2466 = heff_field(v_x41_243, 0);
      V v_arms_2467 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24SCase = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      V v_ps_2477 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr_lam0, 1, 2, (V[]){heff_dup(v_ru_240), heff_dup(v_n_241)}), v_arms_2467));
      V v_b_2478 = (g_list_2eany_24s910662703x1730636603(v_ps_2477));
      V v_as2_2479 = (g_list_2emap_24s1173914895x100384474(v_ps_2477));
      if ((heff_dup(v_b_2478) == NTAG(TAG_True))) {
        heff_drop(v_ru_240);
        heff_drop(v_n_241);
        heff_drop(v_b_2478);
        V v_t_2480 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24SCase, TAG_SCase, 2, (V[]){v_v_2466, v_as2_2479}), v_rest_244});
        return ((HeffT2){{NTAG(TAG_True), v_t_2480}});
      } else {
        heff_drop(v_b_2478);
        HeffT2 v_t_2481 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
        {
          V v_field_2482 = v_t_2481.f[0];
          V v_field_2483 = v_t_2481.f[1];
          V v_b_2484 = v_field_2482;
          V v_ss_2485 = v_field_2483;
          V v_t_2486 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24SCase, TAG_SCase, 2, (V[]){v_v_2466, v_as2_2479}), v_ss_2485});
          return ((HeffT2){{v_b_2484, v_t_2486}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr_lam0(V self, V *args) {
  V v_x4_2468 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x4_2468)) {
  case TAG_MkArm: {
    V v_t_2469 = heff_field(v_x4_2468, 0);
    V v_vs_2470 = heff_field(v_x4_2468, 1);
    V v_ss_2471 = heff_field(v_x4_2468, 2);
    V v_ru_24x4_2468_24MkArm = heff_take_reuse_n(v_x4_2468, 7ULL, 3);
    HeffT2 v_t_2472 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_ss_2471));
    {
      V v_field_2473 = v_t_2472.f[0];
      V v_field_2474 = v_t_2472.f[1];
      V v_b_2475 = v_field_2473;
      V v_x_2476 = v_field_2474;
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2475, heff_tag_at_n(v_ru_24x4_2468_24MkArm, TAG_MkArm, 3, (V[]){v_t_2469, v_vs_2470, v_x_2476})});
    }
  }
  default: return heff_nomatch(v_x4_2468);
  }
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2etokenOp_24cpr_str0, 4, "$tok");
HEFF_LIT(g_heff_2ecompile_2erefcount_2etokenOp_24cpr_str1, 4, "$tok");

HeffT2 g_heff_2ecompile_2erefcount_2etokenOp_24cpr(V v_tk_240, V v_ru_241, V v_n_242, V v_o_243) {
top: ;
  switch (heff_tag_of(v_o_243)) {
  case TAG_OSimple: {
    heff_drop_rec(v_tk_240, 2);
    heff_drop(v_ru_241);
    heff_drop(v_n_242);
    return ((HeffT2){{NTAG(TAG_False), v_o_243}});
  }
  case TAG_OCall: {
    V v_g_245 = heff_field(v_o_243, 0);
    V v_argv_246 = heff_field(v_o_243, 1);
    V v_ru_24o_243_24OCall = heff_take_reuse_n(v_o_243, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_strAppend(heff_dup(v_g_245), ((V)&g_heff_2ecompile_2erefcount_2etokenOp_24cpr_str0)), heff_intShow(heff_dup(v_n_242)));
    HeffT2 v_t_248 = ({ V b_0 = heff_get_n(v_tk_240, 1, 2); V a_1 = v_t_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_247); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_x_2411 = v_field_2410;
        heff_drop(v_x_2411);
        V v_t_2412 = heff_strAppend(heff_strAppend(v_g_245, ((V)&g_heff_2ecompile_2erefcount_2etokenOp_24cpr_str1)), heff_intShow(v_n_242));
        V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_ru_241}), v_argv_246});
        V v_f_2414 = heff_tag_at_n(v_ru_24o_243_24OCall, TAG_OCall, 2, (V[]){v_t_2412, v_t_2413});
        return ((HeffT2){{NTAG(TAG_True), v_f_2414}});
      } else {
        heff_drop(v_ru_241);
        heff_drop(v_n_242);
        heff_drop(v_field_2410);
        return ((HeffT2){{NTAG(TAG_False), heff_tag_at_n(v_ru_24o_243_24OCall, TAG_OCall, 2, (V[]){v_g_245, v_argv_246})}});
      }
    }
  }
  case TAG_OApply: {
    heff_drop_rec(v_tk_240, 2);
    heff_drop(v_ru_241);
    heff_drop(v_n_242);
    return ((HeffT2){{NTAG(TAG_False), v_o_243}});
  }
  case TAG_OPrim: {
    heff_drop_rec(v_tk_240, 2);
    heff_drop(v_ru_241);
    heff_drop(v_n_242);
    return ((HeffT2){{NTAG(TAG_False), v_o_243}});
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_tk_240, 2);
    heff_drop(v_ru_241);
    heff_drop(v_n_242);
    return ((HeffT2){{NTAG(TAG_False), v_o_243}});
  }
  case TAG_OBool: {
    heff_drop_rec(v_tk_240, 2);
    heff_drop(v_ru_241);
    heff_drop(v_n_242);
    return ((HeffT2){{NTAG(TAG_False), v_o_243}});
  }
  default: return ((HeffT2){{heff_nomatch(v_o_243)}});
  }
}
V g_heff_2ecompile_2erefcount_2etokenSt_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2etokenSt_24cpr(V v_k_240, V v_tk_241, V v_ru_242, V v_n_243, V v_st_244) {
top: ;
  switch (heff_tag_of(v_st_244)) {
  case TAG_SLet: {
    V v_x_245 = heff_field(v_st_244, 0);
    V v_o_246 = heff_field(v_st_244, 1);
    V v_ru_24st_244_24SLet = heff_take_reuse_n(v_st_244, 3ULL, 2);
    heff_drop_rec(v_k_240, 2);
    HeffT2 v_t_247 = (g_heff_2ecompile_2erefcount_2etokenOp_24cpr(v_tk_241, v_ru_242, v_n_243, v_o_246));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_b_2410 = v_field_248;
      V v_o2_2411 = v_field_249;
      return ((HeffT2){{v_b_2410, heff_tag_at_n(v_ru_24st_244_24SLet, TAG_SLet, 2, (V[]){v_x_245, v_o2_2411})}});
    }
  }
  case TAG_SOnce: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_tk_241);
    heff_drop(v_ru_242);
    heff_drop(v_n_243);
    return ((HeffT2){{NTAG(TAG_False), v_st_244}});
  }
  case TAG_SDecl: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_tk_241);
    heff_drop(v_ru_242);
    heff_drop(v_n_243);
    return ((HeffT2){{NTAG(TAG_False), v_st_244}});
  }
  case TAG_SSet: {
    V v_x_2415 = heff_field(v_st_244, 0);
    V v_o_2416 = heff_field(v_st_244, 1);
    V v_ru_24st_244_24SSet = heff_take_reuse_n(v_st_244, 3ULL, 2);
    heff_drop_rec(v_k_240, 2);
    HeffT2 v_t_2417 = (g_heff_2ecompile_2erefcount_2etokenOp_24cpr(v_tk_241, v_ru_242, v_n_243, v_o_2416));
    {
      V v_field_2418 = v_t_2417.f[0];
      V v_field_2419 = v_t_2417.f[1];
      V v_b_2420 = v_field_2418;
      V v_o2_2421 = v_field_2419;
      return ((HeffT2){{v_b_2420, heff_tag_at_n(v_ru_24st_244_24SSet, TAG_SSet, 2, (V[]){v_x_2415, v_o2_2421})}});
    }
  }
  case TAG_SIf: {
    V v_c_2422 = heff_field(v_st_244, 0);
    V v_ts_2423 = heff_field(v_st_244, 1);
    V v_fs_2424 = heff_field(v_st_244, 2);
    V v_ru_24st_244_24SIf = heff_take_reuse_n(v_st_244, 7ULL, 3);
    heff_drop(v_tk_241);
    heff_drop(v_ru_242);
    heff_drop(v_n_243);
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_ts_2423}));
    switch (heff_tag_of(v_t_2425)) {
    case TAG_MkPair: {
      V v_bt_2426 = heff_field(v_t_2425, 0);
      V v_ts2_2427 = heff_field(v_t_2425, 1);
      heff_take_n(v_t_2425, 3ULL, 2);
      V v_t_2428 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_fs_2424}));
      switch (heff_tag_of(v_t_2428)) {
      case TAG_MkPair: {
        V v_bf_2429 = heff_field(v_t_2428, 0);
        V v_fs2_2430 = heff_field(v_t_2428, 1);
        heff_take_n(v_t_2428, 3ULL, 2);
        V v_t_2431 = heff_bool(((heff_dup(v_bt_2426) == NTAG(TAG_True)) || (heff_dup(v_bf_2429) == NTAG(TAG_True))));
        heff_drop(v_bt_2426);
        heff_drop(v_bf_2429);
        return ((HeffT2){{v_t_2431, heff_tag_at_n(v_ru_24st_244_24SIf, TAG_SIf, 3, (V[]){v_c_2422, v_ts2_2427, v_fs2_2430})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2428)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2425)}});
    }
  }
  case TAG_SCase: {
    V v_v_2432 = heff_field(v_st_244, 0);
    V v_arms_2433 = heff_field(v_st_244, 1);
    V v_ru_24st_244_24SCase = heff_take_reuse_n(v_st_244, 3ULL, 2);
    heff_drop(v_tk_241);
    heff_drop(v_ru_242);
    heff_drop(v_n_243);
    V v_ps_2441 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2etokenSt_24cpr_lam0, 1, 1, (V[]){v_k_240}), v_arms_2433));
    V v_b_2442 = (g_list_2eany_24s910662703x1730636603(v_ps_2441));
    V v_as2_2443 = (g_list_2emap_24s1173914895x100384474(v_ps_2441));
    return ((HeffT2){{v_b_2442, heff_tag_at_n(v_ru_24st_244_24SCase, TAG_SCase, 2, (V[]){v_v_2432, v_as2_2443})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_st_244)}});
  }
}
V g_heff_2ecompile_2erefcount_2etokenSt_24cpr_lam0(V self, V *args) {
  V v_arm_2434 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_arm_2434)) {
  case TAG_MkArm: {
    V v_t_2435 = heff_field(v_arm_2434, 0);
    V v_vs_2436 = heff_field(v_arm_2434, 1);
    V v_ss_2437 = heff_field(v_arm_2434, 2);
    V v_ru_24arm_2434_24MkArm = heff_take_reuse_n(v_arm_2434, 7ULL, 3);
    V v_x3_2438 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_ss_2437}));
    switch (heff_tag_of(v_x3_2438)) {
    case TAG_MkPair: {
      V v_b_2439 = heff_field(v_x3_2438, 0);
      V v_x_2440 = heff_field(v_x3_2438, 1);
      V v_ru_24x3_2438_24MkPair = heff_take_reuse_n(v_x3_2438, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x3_2438_24MkPair, TAG_MkPair, 2, (V[]){v_b_2439, heff_tag_at_n(v_ru_24arm_2434_24MkArm, TAG_MkArm, 3, (V[]){v_t_2435, v_vs_2436, v_x_2440})});
    }
    default: return heff_nomatch(v_x3_2438);
    }
  }
  default: return heff_nomatch(v_arm_2434);
  }
}
Clo g_heff_2ecompile_2erefcount_2epeekArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epeekArgs_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2epeekArgs(V v_ce_240, V v_x_241, V v_argv_242, V v_rest_243) {
top: ;
  V v_borrowed_244 = heff_take_field(v_ce_240, 6);
  V v_reprs_245 = heff_take_field(v_ce_240, 10);
  V v_self_246 = heff_get_n(v_ce_240, 2, 17);
  switch (heff_tag_of(v_argv_242)) {
  case TAG_Nil: {
    heff_drop(v_x_241);
    heff_drop(v_rest_243);
    heff_drop(v_borrowed_244);
    heff_drop(v_reprs_245);
    heff_drop(v_self_246);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_argv1_247 = heff_field(v_argv_242, 0);
    V v_argv2_248 = heff_field(v_argv_242, 1);
    V v_ru_24argv_242_24Cons = heff_take_reuse_n(v_argv_242, 3ULL, 2);
    switch (heff_tag_of(v_argv1_247)) {
    case TAG_SVar: {
      V v_a_249 = heff_field(v_argv1_247, 0);
      V v_ru_24argv1_247_24SVar = heff_take_reuse_n(v_argv1_247, 1ULL, 1);
      switch (heff_tag_of(v_argv2_248)) {
      case TAG_Nil: {
        heff_drop(v_x_241);
        heff_drop(v_rest_243);
        heff_drop(v_borrowed_244);
        heff_drop(v_reprs_245);
        heff_drop(v_self_246);
        heff_drop_cell(v_ru_24argv_242_24Cons, 2);
        heff_drop(v_a_249);
        heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_i_2410 = heff_field(v_argv2_248, 0);
        V v_argv22_2411 = heff_field(v_argv2_248, 1);
        heff_take_n(v_argv2_248, 3ULL, 2);
        switch (heff_tag_of(v_argv22_2411)) {
        case TAG_Nil: {
          V v_t_2412 = ({ V a_0 = v_a_249; V a_1 = v_borrowed_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_borrowed_244); r_; });
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_t_2412);
            HeffT2 v_t_2413 = ({ V a_0 = v_reprs_245; V a_1 = v_x_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_reprs_245); r_; });
            {
              V v_field_2415 = v_t_2413.f[1];
              int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
              if ((v_tag_2414 == ((int64_t)0ULL))) {
                V v_x_2416 = v_field_2415;
                switch (heff_tag_of(v_x_2416)) {
                case TAG_RepV: {
                  V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erefcount_2enotFlatAt_clo), 2, (V[]){v_self_246, v_x_241}));
                  V v_t_2418 = (g_heff_2ecompile_2erefcount_2eanyW(v_t_2417, v_rest_243));
                  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
                    heff_drop(v_t_2418);
                    return heff_tag_at_n(v_ru_24argv1_247_24SVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24argv_242_24Cons, TAG_MkPair, 2, (V[]){v_a_249, v_i_2410})});
                  } else {
                    heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                    heff_drop(v_a_249);
                    heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
                    heff_drop(v_i_2410);
                    heff_drop(v_t_2418);
                    return NTAG(TAG_Nothing);
                  }
                }
                case TAG_RepFix: {
                  heff_take_n(v_x_2416, 0ULL, 1);
                  heff_drop(v_x_241);
                  heff_drop(v_rest_243);
                  heff_drop(v_self_246);
                  heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                  heff_drop(v_a_249);
                  heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
                  heff_drop(v_i_2410);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepF64: {
                  heff_drop(v_x_241);
                  heff_drop(v_rest_243);
                  heff_drop(v_self_246);
                  heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                  heff_drop(v_a_249);
                  heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
                  heff_drop(v_i_2410);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepInt: {
                  heff_drop(v_x_241);
                  heff_drop(v_rest_243);
                  heff_drop(v_self_246);
                  heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                  heff_drop(v_a_249);
                  heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
                  heff_drop(v_i_2410);
                  return NTAG(TAG_Nothing);
                }
                default: return heff_nomatch(v_x_2416);
                }
              } else {
                heff_drop(v_field_2415);
                V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erefcount_2enotFlatAt_clo), 2, (V[]){v_self_246, v_x_241}));
                V v_t_2421 = (g_heff_2ecompile_2erefcount_2eanyW(v_t_2420, v_rest_243));
                if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
                  heff_drop(v_t_2421);
                  return heff_tag_at_n(v_ru_24argv1_247_24SVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24argv_242_24Cons, TAG_MkPair, 2, (V[]){v_a_249, v_i_2410})});
                } else {
                  heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                  heff_drop(v_a_249);
                  heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
                  heff_drop(v_i_2410);
                  heff_drop(v_t_2421);
                  return NTAG(TAG_Nothing);
                }
              }
            }
          } else {
            heff_drop(v_x_241);
            heff_drop(v_rest_243);
            heff_drop(v_reprs_245);
            heff_drop(v_self_246);
            heff_drop_cell(v_ru_24argv_242_24Cons, 2);
            heff_drop(v_a_249);
            heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
            heff_drop(v_i_2410);
            heff_drop(v_t_2412);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_argv22_2411, 0ULL, 2);
          heff_drop(v_x_241);
          heff_drop(v_rest_243);
          heff_drop(v_borrowed_244);
          heff_drop(v_reprs_245);
          heff_drop(v_self_246);
          heff_drop_cell(v_ru_24argv_242_24Cons, 2);
          heff_drop(v_a_249);
          heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
          heff_drop(v_i_2410);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_argv22_2411);
        }
      }
      default: return heff_nomatch(v_argv2_248);
      }
    }
    case TAG_SGlobal: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SInt: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      heff_take_na(v_argv1_247, 0ULL, 1);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      heff_take_n(v_argv1_247, 0ULL, 2);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      heff_take_na(v_argv1_247, 0ULL, 1);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_argv1_247, 0ULL, 2);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_argv1_247, 0ULL, 3);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_argv1_247, 0ULL, 2);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_argv1_247, 0ULL, 4);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_argv1_247, 0ULL, 2);
      heff_drop(v_x_241);
      heff_drop(v_rest_243);
      heff_drop(v_borrowed_244);
      heff_drop(v_reprs_245);
      heff_drop(v_self_246);
      heff_drop(v_argv2_248);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_argv1_247);
    }
  }
  default: return heff_nomatch(v_argv_242);
  }
}
V g_heff_2ecompile_2erefcount_2epeekArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2epeekArgs(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ecompile_2erefcount_2edeclRun_24cpr(V v_xs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_xs_240, v_x2_241}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_dup(heff_field(v_x2_241, 0));
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SLet: {
      heff_take_n(v_x21_242, 0ULL, 2);
      return ((HeffT2){{v_xs_240, v_x2_241}});
    }
    case TAG_SOnce: {
      heff_take_n(v_x21_242, 0ULL, 2);
      return ((HeffT2){{v_xs_240, v_x2_241}});
    }
    case TAG_SDecl: {
      V v_y_248 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Cons: {
        V v_rest_2410 = heff_field(v_x2_241, 1);
        V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
        V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_248, NTAG(TAG_Nil)});
        V v_t_2412 = (g_prelude_2e_2b_2b(v_xs_240, v_t_2411));
        V t_0 = v_t_2412;
        V t_1 = v_rest_2410;
        v_xs_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
      }
    }
    case TAG_SSet: {
      heff_take_n(v_x21_242, 0ULL, 2);
      return ((HeffT2){{v_xs_240, v_x2_241}});
    }
    case TAG_SIf: {
      heff_take_n(v_x21_242, 0ULL, 3);
      return ((HeffT2){{v_xs_240, v_x2_241}});
    }
    case TAG_SCase: {
      heff_take_n(v_x21_242, 0ULL, 2);
      return ((HeffT2){{v_xs_240, v_x2_241}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V v_ce_240, V v_live_241, V v_want_242, V v_o_243) {
top: ;
  switch (heff_tag_of(v_o_243)) {
  case TAG_OSimple: {
    V v_v_244 = heff_field(v_o_243, 0);
    heff_take_n(v_o_243, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, v_want_242, v_v_244);
  }
  case TAG_OCall: {
    V v_g_245 = heff_field(v_o_243, 0);
    V v_argv_246 = heff_field(v_o_243, 1);
    V v_ru_24o_243_24OCall = heff_take_reuse_n(v_o_243, 3ULL, 2);
    HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 11), v_g_245));
    V v_t_2411;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_s_2410 = v_field_249;
        v_t_2411 = heff_get_n(v_s_2410, 1, 2);
      } else {
        heff_drop(v_field_249);
        v_t_2411 = NTAG(TAG_RepV);
      }
    }
    V v_lit_2412 = v_g_245;
    V v_lit_2413 = v_argv_246;
    V v_ce_2414 = v_ce_240;
    V v_live_2415 = v_live_241;
    HeffT2 v_t_2416 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_ce_2414, 1), v_lit_2412));
    V v_t_2420;
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      v_t_2420 = heff_bool(((v_tag_2417 == ((int64_t)0ULL)) && ({ V v_x_2419 = heff_dup(v_field_2418); int c_ = 1; heff_drop(v_x_2419); c_; })));
      heff_drop(v_field_2418);
    }
    HeffT2 v_t_2421 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_2414, 11), v_lit_2412));
    V v_t_2425;
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        V v_x_2424 = v_field_2423;
        v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2424, 1, 2)});
      } else {
        heff_drop(v_field_2423);
        v_t_2425 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2426 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_2414, 7), v_lit_2412));
    V v_t_2430;
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        V v_x_2429 = v_field_2428;
        v_t_2430 = v_x_2429;
      } else {
        heff_drop(v_field_2428);
        v_t_2430 = NTAG(TAG_Nil);
      }
    }
    HeffT2 v_t_2431 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_2414, 11), v_lit_2412));
    V v_t_2435;
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        V v_s_2434 = v_field_2433;
        v_t_2435 = heff_get_n(v_s_2434, 0, 2);
      } else {
        heff_drop(v_field_2433);
        v_t_2435 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_lit_2413)));
      }
    }
    V v_t_2436 = (g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(v_ce_2414, v_live_2415, NTAG(TAG_Nil), v_t_2430, MK_INT(0LL), v_t_2435, v_lit_2413));
    HEFF_LAST return g_heff_2ecompile_2erefcount_2ecoerce_24tok2(v_ru_24o_243_24OCall, v_t_2411, v_want_242, heff_tag_n(TAG_RCall, 4, (V[]){v_lit_2412, v_t_2420, v_t_2425, v_t_2436}));
  }
  case TAG_OApply: {
    V v_t_2439 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2439));
  }
  case TAG_OPrim: {
    V v_p_2440 = heff_field(v_o_243, 0);
    V v_argv_2441 = heff_field(v_o_243, 1);
    V v_ru_24o_243_24OPrim = heff_take_reuse_n(v_o_243, 3ULL, 2);
    switch (heff_tag_of(v_p_2440)) {
    case TAG_ArrayIndex: {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        V v_t_2442 = (g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755(v_p_2440, v_argv_2441, v_ce_240, v_live_241));
        HEFF_LAST return g_heff_2ecompile_2erefcount_2ecoerce_24tok2(v_ru_24o_243_24OPrim, NTAG(TAG_RepV), v_want_242, v_t_2442);
      }
      case TAG_RepFix: {
        heff_drop_cell(v_ru_24o_243_24OPrim, 2);
        V v_t_2444 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2441));
        return heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_2440, v_want_242, v_t_2444});
      }
      case TAG_RepF64: {
        heff_drop_cell(v_ru_24o_243_24OPrim, 2);
        V v_t_2445 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2441));
        return heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_2440, v_want_242, v_t_2445});
      }
      case TAG_RepInt: {
        heff_drop_cell(v_ru_24o_243_24OPrim, 2);
        V v_t_2446 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2441));
        return heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_2440, v_want_242, v_t_2446});
      }
      default: return heff_nomatch(v_want_242);
      }
    }
    default: {
      V v_t_2447 = (g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755(v_p_2440, v_argv_2441, v_ce_240, v_live_241));
      HEFF_LAST return g_heff_2ecompile_2erefcount_2ecoerce_24tok2(v_ru_24o_243_24OPrim, NTAG(TAG_RepV), v_want_242, v_t_2447);
    }
    }
  }
  case TAG_OAbandon: {
    V v_t_2448 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2448));
  }
  case TAG_OBool: {
    V v_t_2450 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2450));
  }
  default: return heff_nomatch(v_o_243);
  }
}
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(V v_ce_240, V v_x_241, V v_o_242, V v_rest_243, V v_after_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){heff_dup(v_o_242)}), NTAG(TAG_Nil)});
    HeffT2 v_t_247 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_246));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_bs_2410 = v_field_248;
      V v_ms_2411 = v_field_249;
      V v_ms_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2411));
      V v_t_2413 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2410; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2410); r_; });
      V v_fa_2414 = ({ V a_0 = v_t_2413; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2412; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2413); r_; });
      V v_x1_2415 = heff_dup(v_o_242);
      V v_known_2483;
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_OSimple: {
        V v_x11_2416 = heff_field(v_x1_2415, 0);
        V v_ru_24x1_2415_24OSimple = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
        switch (heff_tag_of(v_x11_2416)) {
        case TAG_SVar: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
          v_known_2483 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SGlobal: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
          v_known_2483 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SInt: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
          v_known_2483 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SFloat: {
          heff_take_na(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
          v_known_2483 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SStr: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
          v_known_2483 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SBytes: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
          v_known_2483 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SFixed: {
          heff_take_n(v_x11_2416, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
          v_known_2483 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SFloat32: {
          heff_take_na(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
          v_known_2483 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SPrimFn: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
          v_known_2483 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SLam: {
          V v_xs_2427 = heff_field(v_x11_2416, 0);
          V v_x112_2428 = heff_field(v_x11_2416, 1);
          heff_take_n(v_x11_2416, 3ULL, 2);
          switch (heff_tag_of(v_x112_2428)) {
          case TAG_MkBlock: {
            V v_t_2429 = heff_field(v_x112_2428, 0);
            V v_ru_24x112_2428_24MkBlock = heff_take_reuse_n(v_x112_2428, 1ULL, 1);
            V v_xs_2430 = (g_heff_2ecompile_2erefcount_2efreeOf(v_xs_2427, v_t_2429));
            V v_t_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2430; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
            v_known_2483 = heff_tag_at_n(v_ru_24x1_2415_24OSimple, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x112_2428_24MkBlock, TAG_KnownClo, 1, (V[]){v_t_2431})});
            break;
          }
          default: heff_nomatch(v_x112_2428);
          }
          break;
        }
        case TAG_STag: {
          V v_argv_2433 = heff_field(v_x11_2416, 1);
          heff_take_n(v_x11_2416, 2ULL, 3);
          V v_t_2435 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_argv_2433; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_argv_2433); r_; });
          v_known_2483 = heff_tag_at_n(v_ru_24x1_2415_24OSimple, TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownTag, 1, (V[]){v_t_2435})});
          break;
        }
        case TAG_SRec: {
          V v_fs_2436 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 2);
          V v_t_2438 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fs_2436; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_fs_2436); r_; });
          v_known_2483 = heff_tag_at_n(v_ru_24x1_2415_24OSimple, TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownRec, 1, (V[]){v_t_2438})});
          break;
        }
        case TAG_SProj: {
          heff_take_n(v_x11_2416, 0ULL, 4);
          heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
          v_known_2483 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SPrim: {
          V v_x111_2443 = heff_field(v_x11_2416, 0);
          V v_argv_2444 = heff_field(v_x11_2416, 1);
          heff_take_n(v_x11_2416, 3ULL, 2);
          switch (heff_tag_of(v_x111_2443)) {
          case TAG_Reuse: {
            V v_x1_2445 = v_argv_2444;
            switch (heff_tag_of(v_x1_2445)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
              v_known_2483 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Cons: {
              V v_x12_2447 = heff_field(v_x1_2445, 1);
              heff_take_n(v_x1_2445, 2ULL, 2);
              switch (heff_tag_of(v_x12_2447)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                v_known_2483 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Cons: {
                V v_x121_2448 = heff_field(v_x12_2447, 0);
                V v_x122_2449 = heff_field(v_x12_2447, 1);
                heff_take_n(v_x12_2447, 3ULL, 2);
                switch (heff_tag_of(v_x121_2448)) {
                case TAG_SVar: {
                  heff_take_n(v_x121_2448, 0ULL, 1);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_SGlobal: {
                  heff_take_n(v_x121_2448, 0ULL, 1);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_SInt: {
                  heff_take_n(v_x121_2448, 0ULL, 1);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_SFloat: {
                  heff_take_na(v_x121_2448, 0ULL, 1);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_SStr: {
                  heff_take_n(v_x121_2448, 0ULL, 1);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_SBytes: {
                  heff_take_n(v_x121_2448, 0ULL, 1);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_SFixed: {
                  heff_take_n(v_x121_2448, 0ULL, 2);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_SFloat32: {
                  heff_take_na(v_x121_2448, 0ULL, 1);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_SPrimFn: {
                  heff_take_n(v_x121_2448, 0ULL, 1);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_SLam: {
                  heff_take_n(v_x121_2448, 0ULL, 2);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_STag: {
                  V v_argv_2463 = heff_field(v_x121_2448, 1);
                  heff_take_n(v_x121_2448, 2ULL, 3);
                  switch (heff_tag_of(v_x122_2449)) {
                  case TAG_Nil: {
                    V v_t_2465 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_argv_2463; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_argv_2463); r_; });
                    v_known_2483 = heff_tag_at_n(v_ru_24x1_2415_24OSimple, TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownTag, 1, (V[]){v_t_2465})});
                    break;
                  }
                  case TAG_Cons: {
                    heff_take_n(v_x122_2449, 0ULL, 2);
                    heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                    heff_drop(v_argv_2463);
                    v_known_2483 = NTAG(TAG_Nothing);
                    break;
                  }
                  default: heff_nomatch(v_x122_2449);
                  }
                  break;
                }
                case TAG_SRec: {
                  heff_take_n(v_x121_2448, 0ULL, 2);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_SProj: {
                  heff_take_n(v_x121_2448, 0ULL, 4);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_SPrim: {
                  heff_take_n(v_x121_2448, 0ULL, 2);
                  heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
                  heff_drop(v_x122_2449);
                  v_known_2483 = NTAG(TAG_Nothing);
                  break;
                }
                default: heff_nomatch(v_x121_2448);
                }
                break;
              }
              default: heff_nomatch(v_x12_2447);
              }
              break;
            }
            default: heff_nomatch(v_x1_2445);
            }
            break;
          }
          default: {
            heff_drop_cell(v_ru_24x1_2415_24OSimple, 1);
            heff_drop(v_x111_2443);
            heff_drop(v_argv_2444);
            v_known_2483 = NTAG(TAG_Nothing);
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_x11_2416);
        }
        break;
      }
      case TAG_OCall: {
        heff_take_n(v_x1_2415, 0ULL, 2);
        v_known_2483 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_OApply: {
        heff_take_n(v_x1_2415, 0ULL, 2);
        v_known_2483 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_OPrim: {
        heff_take_n(v_x1_2415, 0ULL, 2);
        v_known_2483 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_OAbandon: {
        v_known_2483 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_OBool: {
        heff_take_n(v_x1_2415, 0ULL, 1);
        v_known_2483 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x1_2415);
      }
      V v_t_2486;
      switch (heff_tag_of(v_after_244)) {
      case TAG_Nothing: {
        v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_rest_243)}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_Just: {
        V v_t_2484 = heff_dup(heff_field(v_after_244, 0));
        V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_2484}), NTAG(TAG_Nil)});
        v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_rest_243)}), v_t_2485});
        break;
      }
      default: heff_nomatch(v_after_244);
      }
      V v_x1_2487 = heff_dup(v_o_242);
      V v_t_24119;
      switch (heff_tag_of(v_x1_2487)) {
      case TAG_OSimple: {
        V v_x11_2488 = heff_field(v_x1_2487, 0);
        heff_take_n(v_x1_2487, 1ULL, 1);
        switch (heff_tag_of(v_x11_2488)) {
        case TAG_SVar: {
          heff_take_n(v_x11_2488, 0ULL, 1);
          v_t_24119 = NTAG(TAG_Nil);
          break;
        }
        case TAG_SGlobal: {
          heff_take_n(v_x11_2488, 0ULL, 1);
          v_t_24119 = NTAG(TAG_Nil);
          break;
        }
        case TAG_SInt: {
          heff_take_n(v_x11_2488, 0ULL, 1);
          v_t_24119 = NTAG(TAG_Nil);
          break;
        }
        case TAG_SFloat: {
          heff_take_na(v_x11_2488, 0ULL, 1);
          v_t_24119 = NTAG(TAG_Nil);
          break;
        }
        case TAG_SStr: {
          heff_take_n(v_x11_2488, 0ULL, 1);
          v_t_24119 = NTAG(TAG_Nil);
          break;
        }
        case TAG_SBytes: {
          heff_take_n(v_x11_2488, 0ULL, 1);
          v_t_24119 = NTAG(TAG_Nil);
          break;
        }
        case TAG_SFixed: {
          heff_take_n(v_x11_2488, 0ULL, 2);
          v_t_24119 = NTAG(TAG_Nil);
          break;
        }
        case TAG_SFloat32: {
          heff_take_na(v_x11_2488, 0ULL, 1);
          v_t_24119 = NTAG(TAG_Nil);
          break;
        }
        case TAG_SPrimFn: {
          heff_take_n(v_x11_2488, 0ULL, 1);
          v_t_24119 = NTAG(TAG_Nil);
          break;
        }
        case TAG_SLam: {
          heff_take_n(v_x11_2488, 0ULL, 2);
          v_t_24119 = NTAG(TAG_Nil);
          break;
        }
        case TAG_STag: {
          V v_argv_24102 = heff_field(v_x11_2488, 1);
          heff_take_n(v_x11_2488, 2ULL, 3);
          v_t_24119 = v_argv_24102;
          break;
        }
        case TAG_SRec: {
          V v_fs_24104 = heff_field(v_x11_2488, 0);
          V v_ru_24x11_2488_24SRec = heff_take_reuse_n(v_x11_2488, 1ULL, 2);
          v_t_24119 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x11_2488_24SRec, v_fs_24104));
          break;
        }
        case TAG_SProj: {
          V v_e_24106 = heff_field(v_x11_2488, 0);
          V v_l_24107 = heff_field(v_x11_2488, 1);
          V v_sh_24108 = heff_field(v_x11_2488, 2);
          V v_t_24109 = heff_field(v_x11_2488, 3);
          V v_ru_24x11_2488_24SProj = heff_take_reuse_n(v_x11_2488, 15ULL, 4);
          v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x11_2488_24SProj, TAG_SProj, 4, (V[]){v_e_24106, v_l_24107, v_sh_24108, v_t_24109}), NTAG(TAG_Nil)});
          break;
        }
        case TAG_SPrim: {
          V v_argv_24111 = heff_field(v_x11_2488, 1);
          heff_take_n(v_x11_2488, 2ULL, 2);
          v_t_24119 = v_argv_24111;
          break;
        }
        default: heff_nomatch(v_x11_2488);
        }
        break;
      }
      case TAG_OCall: {
        V v_argv_24113 = heff_field(v_x1_2487, 1);
        heff_take_n(v_x1_2487, 2ULL, 2);
        v_t_24119 = v_argv_24113;
        break;
      }
      case TAG_OApply: {
        V v_f_24114 = heff_field(v_x1_2487, 0);
        V v_argv_24115 = heff_field(v_x1_2487, 1);
        V v_ru_24x1_2487_24OApply = heff_take_reuse_n(v_x1_2487, 3ULL, 2);
        v_t_24119 = heff_tag_at_n(v_ru_24x1_2487_24OApply, TAG_Cons, 2, (V[]){v_f_24114, v_argv_24115});
        break;
      }
      case TAG_OPrim: {
        V v_argv_24117 = heff_field(v_x1_2487, 1);
        heff_take_n(v_x1_2487, 2ULL, 2);
        v_t_24119 = v_argv_24117;
        break;
      }
      case TAG_OAbandon: {
        v_t_24119 = NTAG(TAG_Nil);
        break;
      }
      case TAG_OBool: {
        heff_take_n(v_x1_2487, 0ULL, 1);
        v_t_24119 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_x1_2487);
      }
      V v_takes_24120 = (g_heff_2ecompile_2erefcount_2etakesAt(heff_dup(v_ce_240), NTAG(TAG_Nil), v_t_2486, v_t_24119));
      V v_t_24121 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_rest_243), heff_dup(v_after_244)));
      V v_t_24122 = (g_prelude_2e_2b_2b(v_t_24121, heff_dup(heff_rfield(v_ce_240, 5))));
      return ({ V a_0 = heff_dup(v_ce_240); V a_1 = heff_dup(v_x_241); V a_2 = v_fa_2414; V a_3 = heff_clo_n(g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam0, 1, 3, (V[]){v_ce_240, v_x_241, v_o_242}); V a_4 = v_known_2483; V a_5 = v_takes_24120; V a_6 = v_rest_243; V a_7 = v_after_244; V a_8 = v_t_24122; V r_ = (g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_known_2483); r_; });
    }
  }
  case TAG_Just: {
    V v_x71_24144 = heff_field(v_x7_245, 0);
    heff_drop(v_o_242);
    switch (heff_tag_of(v_x71_24144)) {
    case TAG_MkPair: {
      V v_a_24145 = heff_field(v_x71_24144, 0);
      V v_i_24146 = heff_field(v_x71_24144, 1);
      V v_t_24147 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_rest_243), heff_dup(v_after_244)));
      V v_t_24148 = (g_prelude_2e_2b_2b(v_t_24147, heff_dup(heff_rfield(v_ce_240, 5))));
      return (g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(v_ce_240, v_x_241, heff_dup(v_a_24145), heff_dup(v_i_24146), v_rest_243, v_after_244, v_t_24148));
    }
    default: return heff_nomatch(v_x71_24144);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam1(V self, V *args) {
  V v_v_24139 = args[0];
  V v_ce2_24123 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24140 = ({ V a_0 = v_v_24139; V b_1 = heff_get_n(v_ce2_24123, 5, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(v_v_24139); heff_drop(b_1); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24140) == NTAG(TAG_True)));
  heff_drop(v_x1_24140);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam0(V self, V *args) {
  V v_ce2_24123 = args[0];
  V v_ce_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_o_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_live_24124 = heff_dup(heff_rfield(v_ce2_24123, 5));
  HeffT2 v_t_24125 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_24130;
  {
    V v_field_24127 = v_t_24125.f[1];
    int64_t v_tag_24126 = ((int64_t)v_t_24125.f[0]);
    V v_t_24129;
    if ((v_tag_24126 == ((int64_t)0ULL))) {
      V v_x_24128 = v_field_24127;
      v_t_24129 = v_x_24128;
    } else {
      heff_drop(v_field_24127);
      v_t_24129 = NTAG(TAG_RepV);
    }
    v_t_24130 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce2_24123), v_live_24124, v_t_24129, heff_dup(v_o_242)));
  }
  V v_t_24143;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    heff_take_n(v_o_242, 0ULL, 1);
    heff_drop_rec(v_ce2_24123, 17);
    v_t_24143 = NTAG(TAG_Nil);
    break;
  }
  case TAG_OCall: {
    heff_take_n(v_o_242, 0ULL, 2);
    heff_drop_rec(v_ce2_24123, 17);
    v_t_24143 = NTAG(TAG_Nil);
    break;
  }
  case TAG_OApply: {
    heff_take_n(v_o_242, 0ULL, 2);
    heff_drop_rec(v_ce2_24123, 17);
    v_t_24143 = NTAG(TAG_Nil);
    break;
  }
  case TAG_OPrim: {
    heff_take_n(v_o_242, 0ULL, 2);
    heff_drop_rec(v_ce2_24123, 17);
    v_t_24143 = NTAG(TAG_Nil);
    break;
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_ce2_24123, 17);
    v_t_24143 = NTAG(TAG_Nil);
    break;
  }
  case TAG_OBool: {
    V v_ru_24o_242_24OBool = heff_take_reuse_n(v_o_242, 0ULL, 1);
    V v_xs_24141 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam1, 1, 1, (V[]){heff_dup(v_ce2_24123)}), heff_dup(heff_rfield(v_ce2_24123, 4))));
    V v_t_24142 = (g_heff_2ecompile_2erefcount_2edropsOf(v_ce2_24123, v_xs_24141));
    v_t_24143 = (g_list_2emap_24s1796125103x644876049_24tok1(v_ru_24o_242_24OBool, v_t_24142));
    break;
  }
  default: heff_nomatch(v_o_242);
  }
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_241, v_t_24130}), v_t_24143});
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(V v_ce_240, V v_taken_241, V v_lent_242, V v_t_243, V v_vs_244, V v_fb_245, V v_leaves_246, V v_p_247) {
top: ;
  V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
  V v_t_249 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_248, MK_INT(1LL))));
  V v_t_2410 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_vs_244), v_t_249));
  V v_ws_2415 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam0, 1, 1, (V[]){heff_dup(v_fb_245)}), v_t_2410));
  V v_ce_2416 = heff_dup(v_ce_240);
  HeffT2 v_t_2417 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 13), v_t_243));
  V v_su_2421;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2419;
      v_su_2421 = v_x_2420;
    } else {
      heff_drop(v_field_2419);
      v_su_2421 = NTAG(TAG_Nil);
    }
  }
  V v_ws_2422 = v_ws_2415;
  HeffT2 v_t_2423 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 12), v_t_243));
  V v_t_2457;
  {
    V v_field_2425 = v_t_2423.f[1];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    if ((v_tag_2424 == ((int64_t)0ULL))) {
      V v_ps_2426 = v_field_2425;
      V v_ce_2427 = v_ce_2416;
      V v_ps_2428 = v_ps_2426;
      V v_ws_2429 = heff_dup(v_ws_2422);
      V v_t_2434 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam1, 1, 1, (V[]){v_ps_2428}), v_ws_2429));
      V v_fs_2450 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam2, 1, 1, (V[]){v_ce_2427}), v_t_2434));
      V v_t_2453 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam3, 1, 1, (V[]){heff_dup(v_fs_2450)}), v_ws_2422));
      V v_t_2454 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2450)));
      V v_t_2455 = (g_list_2ekeepIf_24s479112018x1726839132(heff_dup(v_fs_2450)));
      V v_t_2456 = (g_list_2emap_24s1937570095x2110149801(v_t_2455));
      v_t_2457 = heff_rec_n(6, shape_plain__flats__names__counted__flat__sure, (V[]){v_t_2453, v_fs_2450, v_t_2454, v_t_2456, NTAG(TAG_True), v_su_2421});
    } else {
      heff_drop(v_ce_2416);
      heff_drop(v_su_2421);
      heff_drop(v_field_2425);
      v_t_2457 = heff_rec_n(6, shape_plain__flats__names__counted__flat__sure, (V[]){v_ws_2422, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_Nil)});
    }
  }
  return (g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(v_ce_240, v_taken_241, v_lent_242, v_t_243, v_vs_244, v_fb_245, v_leaves_246, v_t_2457, v_p_247));
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam0(V self, V *args) {
  V v_p_2411 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414;
  switch (heff_tag_of(v_p_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_p_2411, 0);
    heff_take_n(v_p_2411, 1ULL, 2);
    v_t_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_p_2411);
  }
  return ({ V a_0 = v_t_2414; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_t_2414); heff_drop(v_fb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam1(V self, V *args) {
  V v_p_2430 = args[0];
  V v_ps_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  switch (heff_tag_of(v_p_2430)) {
  case TAG_MkPair: {
    V v_y_2432 = heff_field(v_p_2430, 1);
    heff_take_n(v_p_2430, 2ULL, 2);
    v_t_2433 = v_y_2432;
    break;
  }
  default: heff_nomatch(v_p_2430);
  }
  return ({ V a_0 = v_t_2433; V a_1 = v_ps_2428; V r_ = (g_heff_2ecompile_2erefcount_2eelemI(a_0, a_1)); heff_drop(v_ps_2428); r_; });
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam2(V self, V *args) {
  V v_p_2435 = args[0];
  V v_ce_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438;
  switch (heff_tag_of(v_p_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_dup(heff_field(v_p_2435, 0));
    v_t_2438 = v_x_2436;
    break;
  }
  default: heff_nomatch(v_p_2435);
  }
  V v_t_2441;
  switch (heff_tag_of(v_p_2435)) {
  case TAG_MkPair: {
    V v_y_2440 = heff_dup(heff_field(v_p_2435, 1));
    v_t_2441 = v_y_2440;
    break;
  }
  default: heff_nomatch(v_p_2435);
  }
  V v_t_2444;
  switch (heff_tag_of(v_p_2435)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_p_2435, 0);
    heff_take_n(v_p_2435, 1ULL, 2);
    v_t_2444 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_p_2435);
  }
  HeffT2 v_t_2445 = ({ V b_0 = heff_get_n(v_ce_2427, 10, 17); V a_1 = v_t_2444; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2444); r_; });
  V v_t_2449;
  {
    V v_field_2447 = v_t_2445.f[1];
    int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
    if ((v_tag_2446 == ((int64_t)0ULL))) {
      V v_x_2448 = v_field_2447;
      v_t_2449 = v_x_2448;
    } else {
      heff_drop(v_field_2447);
      v_t_2449 = NTAG(TAG_RepV);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2441, v_t_2449})});
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam3(V self, V *args) {
  V v_p_2451 = args[0];
  V v_fs_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2452 = ({ V a_0 = v_p_2451; V a_1 = v_fs_2450; V r_ = (g_list_2eany_24s332132496x946063656(a_0, a_1)); heff_drop(v_p_2451); heff_drop(v_fs_2450); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2452) == NTAG(TAG_True)));
  heff_drop(v_x1_2452);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_bi_243);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_p_248 = heff_field(v_x7_245, 0);
    V v_ps_249 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_bi_243);
      heff_drop(v_i_244);
      heff_drop(v_p_248);
      heff_drop(v_ps_249);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_2410 = heff_field(v_x8_246, 0);
      V v_es_2411 = heff_field(v_x8_246, 1);
      V v_ru_24x8_246_24Cons = heff_take_reuse_n(v_x8_246, 3ULL, 2);
      HeffT2 v_t_2412 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_ce_240, 10), v_p_248));
      V v_t_2426;
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_x_2415 = v_field_2414;
          heff_drop(v_x_2415);
          V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_2411)));
          V v_t_2417 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_2416));
          V v_t_2418 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x8_246_24Cons, v_t_2417, heff_dup(v_live_241)));
          V v_live_2419 = (g_prelude_2e_2b_2b(heff_dup(v_before_242), v_t_2418));
          HeffT2 v_t_2420 = ({ V a_0 = heff_rfield(v_ce_240, 10); V a_1 = v_p_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_p_248); r_; });
          V v_t_2425;
          {
            V v_field_2422 = v_t_2420.f[1];
            int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
            V v_t_2424;
            if ((v_tag_2421 == ((int64_t)0ULL))) {
              V v_x_2423 = v_field_2422;
              v_t_2424 = v_x_2423;
            } else {
              heff_drop(v_field_2422);
              v_t_2424 = NTAG(TAG_RepV);
            }
            v_t_2425 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2419, v_t_2424, heff_dup(v_e_2410)));
          }
          v_t_2426 = heff_tag_n(TAG_Given, 1, (V[]){v_t_2425});
        } else {
          heff_drop(v_p_248);
          heff_drop_cell(v_ru_24x8_246_24Cons, 2);
          heff_drop(v_field_2414);
          v_t_2426 = (g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), heff_dup(v_bi_243), heff_dup(v_i_244), heff_dup(v_e_2410), heff_dup(v_es_2411)));
        }
      }
      V v_cell_2427 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
      V v_u_2428 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2427));
      heff_drop(v_u_2428);
      V v_t_2429 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_2410; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_2410); r_; });
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_t_2429;
      V t_3 = v_bi_243;
      V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
      V t_5 = v_ps_249;
      V t_6 = v_es_2411;
      V t_7 = v_cell_2427;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_before_242 = t_2;
      v_bi_243 = t_3;
      v_i_244 = t_4;
      v_x7_245 = t_5;
      v_x8_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447(V v_lit_240, V v_ce_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2erefcount_2efvArm(heff_tag_n(TAG_ATail, 1, (V[]){heff_dup(v_lit_240)})));
  V v_wanted_243 = (g_prelude_2e_2b_2b(v_t_242, heff_dup(heff_rfield(v_ce_241, 5))));
  V v_xs_246 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_lam0, 1, 1, (V[]){v_wanted_243}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_t_247 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_246));
  V v_t_248 = (g_list_2emap_24s1796125103x644876049(v_t_247));
  V v_owned_249 = heff_dup(heff_rfield(v_ce_241, 4));
  V v_t_2410 = (g_heff_2ecompile_2erefcount_2efvArm(heff_tag_n(TAG_ATail, 1, (V[]){heff_dup(v_lit_240)})));
  V v_wanted_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_dup(heff_rfield(v_ce_241, 5))));
  V v_t_2413 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_lam1, 1, 1, (V[]){v_wanted_2411}), v_owned_249));
  V v_ce_2414 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2413, heff_dup(heff_rfield(v_ce_241, 5)), v_ce_241));
  V v_t_2415 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2414, v_lit_240));
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_248, v_t_2415);
}
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_lam0(V self, V *args) {
  V v_v_244 = args[0];
  V v_wanted_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = ({ V a_0 = v_v_244; V a_1 = v_wanted_243; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_244); heff_drop(v_wanted_243); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_245) == NTAG(TAG_True)));
  heff_drop(v_x1_245);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_lam1(V self, V *args) {
  V v_v_2412 = args[0];
  V v_wanted_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2412; V a_1 = v_wanted_2411; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2412); heff_drop(v_wanted_2411); r_; });
}
Clo g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619(V v_lit_240, V v_lit_241, V v_ce_242, V v_c_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){heff_dup(v_c_243)}), NTAG(TAG_Nil)});
  HeffT2 v_t_245 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_244));
  V v_t_2412;
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_bs_248 = v_field_246;
    V v_ms_249 = v_field_247;
    V v_ms_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_249));
    V v_t_2411 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_248; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_248); r_; });
    v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2410; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); r_; });
  }
  V v_t_2413 = (g_heff_2ecompile_2erefcount_2efvArm(heff_tag_n(TAG_ATail, 1, (V[]){heff_dup(v_lit_241)})));
  V v_t_2414 = (g_heff_2ecompile_2erefcount_2efvArm(heff_tag_n(TAG_ATail, 1, (V[]){heff_dup(v_lit_240)})));
  V v_t_2415 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_242, 5)), v_t_2413, v_t_2414));
  V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2415));
  return (g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213(v_lit_241, v_lit_240, v_ce_242, v_c_243, v_t_2416));
}
V g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_b_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245;
    if ((heff_dup(v_b_244) == NTAG(TAG_True))) {
      heff_drop(v_b_244);
      v_t_245 = MK_INT(1LL);
    } else {
      heff_drop(v_b_244);
      v_t_245 = MK_INT(0LL);
    }
    V v_t_246 = (g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(v_f_240, v_xs_243));
    return heff_intAdd(v_t_245, heff_intMul(MK_INT(2LL), v_t_246));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam5(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2(V v_tok_240, V v_ce_241, V v_xs_242, V v_st_243, V v_rest_244, V v_after_245, V v_wb_246) {
top: ;
  V v_t_247 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_st_243), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_t_247}), NTAG(TAG_Nil)});
  HeffT2 v_t_249 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_248));
  V v_t_2416;
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_bs_2412 = v_field_2410;
    V v_ms_2413 = v_field_2411;
    V v_ms_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2413));
    V v_t_2415 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2412; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2412); r_; });
    v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2414; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2415); r_; });
  }
  V v_wanted_2417 = (g_prelude_2e_2b_2b(v_t_2416, heff_dup(v_wb_246)));
  V v_xs_2420 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam0, 1, 1, (V[]){v_wanted_2417}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_t_2421 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_2420));
  V v_t_2422 = (g_list_2emap_24s1796125103x644876049(v_t_2421));
  V v_t_2423 = (g_list_2emap_24s698037429x265256386(heff_dup(v_xs_242)));
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_st_243), NTAG(TAG_Nil)});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_t_2424}), NTAG(TAG_Nil)});
  HeffT2 v_t_2426 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2425));
  V v_t_2433;
  {
    V v_field_2427 = v_t_2426.f[0];
    V v_field_2428 = v_t_2426.f[1];
    V v_bs_2429 = v_field_2427;
    V v_ms_2430 = v_field_2428;
    V v_ms_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2430));
    V v_t_2432 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2429; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2429); r_; });
    v_t_2433 = ({ V a_0 = v_t_2432; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2431; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2432); r_; });
  }
  V v_wanted_2434 = (g_prelude_2e_2b_2b(v_t_2433, heff_dup(v_wb_246)));
  V v_t_2436 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam1, 1, 1, (V[]){v_wanted_2434}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_t_2437 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2436, heff_dup(v_wb_246), heff_dup(v_ce_241)));
  V v_t_2438 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2437));
  V v_t_2439 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(v_t_2438, v_st_243));
  V v_t_2440 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2439));
  V v_xs_2443 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam2, 1, 1, (V[]){heff_dup(v_wb_246)}), heff_dup(v_xs_242)));
  V v_t_2444 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_2443));
  V v_t_2445 = (g_list_2emap_24s1796125103x644876049(v_t_2444));
  V v_t_2447 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam3, 1, 1, (V[]){heff_dup(v_wb_246)}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_xs_2449 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam4, 1, 1, (V[]){v_wb_246}), v_xs_242));
  V v_t_2455 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam5, 1, 1, (V[]){heff_dup(v_ce_241)}), v_xs_2449));
  V v_t_2456 = (g_prelude_2e_2b_2b(v_t_2447, v_t_2455));
  V v_t_2457 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), heff_dup(v_ce_241)));
  V v_ce_2458 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2456, heff_get_n(v_ce_241, 5, 17), v_t_2457));
  V v_t_2459 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2458, v_rest_244, v_after_245));
  V v_t_2460 = (g_prelude_2e_2b_2b(v_t_2445, v_t_2459));
  V v_t_2461 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2460));
  return (g_prelude_2e_2b_2b(v_t_2422, v_t_2461));
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam0(V self, V *args) {
  V v_v_2418 = args[0];
  V v_wanted_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = ({ V a_0 = v_v_2418; V a_1 = v_wanted_2417; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2418); heff_drop(v_wanted_2417); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2419) == NTAG(TAG_True)));
  heff_drop(v_x1_2419);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam1(V self, V *args) {
  V v_v_2435 = args[0];
  V v_wanted_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2435; V a_1 = v_wanted_2434; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2435); heff_drop(v_wanted_2434); r_; });
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam2(V self, V *args) {
  V v_x_2441 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2442 = ({ V a_0 = v_x_2441; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2441); heff_drop(v_wb_246); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2442) == NTAG(TAG_True)));
  heff_drop(v_x1_2442);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam3(V self, V *args) {
  V v_v_2446 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2446; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2446); heff_drop(v_wb_246); r_; });
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam4(V self, V *args) {
  V v_x_2448 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2448; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2448); heff_drop(v_wb_246); r_; });
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_ce_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2451 = ({ V b_0 = heff_get_n(v_ce_241, 10, 17); V a_1 = v_x_2450; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2450); r_; });
  {
    V v_field_2453 = v_t_2451.f[1];
    int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2452 == ((int64_t)0ULL)) ? ({ V v_x_2454 = heff_dup(v_field_2453); int c_ = 0; heff_drop(v_x_2454); c_; }) : 1));
    heff_drop(v_field_2453);
    return v_ret_24bool;
  }
}