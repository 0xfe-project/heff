// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_MkWith 3751
#define TAG_NotRun 12703
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Sleep 25229
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_TryWait 64330
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_backend 2032133329
#define LBL_bind 9519364
#define LBL_build 295453320
#define LBL_builds 569118448
#define LBL_command 1182252425
#define LBL_dev 308879
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_fmap 9641981
#define LBL_group 299987609
#define LBL_hmap 9701563
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_malg 9839318
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_path 9928940
#define LBL_ret 322331
#define LBL_stamp 311115741
#define LBL_timeout 1065429926
#define LBL_wanted 1152016858
static uint32_t shape_builds__wanted[] = {LBL_builds, LBL_wanted};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_dev__apps__stamp[] = {LBL_dev, LBL_apps, LBL_stamp};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_name__ended[] = {LBL_name, LBL_ended};
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(void);
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s2022167152x294629972_24rec0_get(void);
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114(V, V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1(V, V, V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0(V, V, V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_clo;
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372(V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_clo;
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165(V, V, V);
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_clo;
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1(V, V, V, V);
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_clo;
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087(V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_clo;
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884(V, V, V, V, V);
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850(V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_clo;
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_clo;
V g_list_2eany_24s1255781029x1672221493(V, V);
V g_list_2eany_24s1255781029x1672221493_entry(V self, V *a);
extern Clo g_list_2eany_24s1255781029x1672221493_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s2104774589x596860835(V);
V g_list_2emap_24s2104774589x596860835_entry(V self, V *a);
extern Clo g_list_2emap_24s2104774589x596860835_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_resource_2eheldBy_24s1065400090x105490439(V, V, V, V, V, V);
V g_resource_2eheldBy_24s1065400090x105490439_entry(V self, V *a);
extern Clo g_resource_2eheldBy_24s1065400090x105490439_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_str0, 3, "app");
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_entry, 3, 0};

V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114(V v_st_240, V v_z_241, V v_z_242) {
top: ;
  V v_path_243 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_str0)));
  V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_243; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_246 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_lam0_clo)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  HEFF_LAST return g_co_2eop_24s1896221640x2141527803(v_t_2411, heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_lam1, 1, 4, (V[]){v_z_241, v_st_240, v_z_242, v_path_243}));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_lam2(V self, V *args) {
  V v_n_2417 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2417));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_243, v_t_2418));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_path_243 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_x_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    heff_clo_take(self, 4);
    heff_drop(v_path_243);
    return (g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0(v_z_241, v_st_240, v_z_242, heff_tag_re_n(v_ru_24x_2412_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2413})));
  }
  case TAG_Right: {
    V v_y_2414 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Right = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    switch (heff_tag_of(v_y_2414)) {
    case TAG_Left: {
      V v_err_2415 = heff_field(v_y_2414, 0);
      V v_ru_24y_2414_24Left = heff_take_reuse_n(v_y_2414, 1ULL, 1);
      heff_clo_take(self, 4);
      heff_drop(v_path_243);
      heff_drop_cell(v_ru_24x_2412_24Right, 1);
      return (g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0(v_z_241, v_st_240, v_z_242, heff_tag_re_n(v_ru_24y_2414_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2415})));
    }
    case TAG_Right: {
      V v_x_2416 = heff_field(v_y_2414, 0);
      heff_take_n(v_y_2414, 1ULL, 1);
      heff_clo_take(self, 4);
      V v_x_2419 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_lam2, 1, 1, (V[]){v_path_243}), v_x_2416));
      V v_x_2420 = (g_list_2emap_24s219049803x1458391381(v_x_2419));
      return (g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0(v_z_241, v_st_240, v_z_242, heff_tag_at_n(v_ru_24x_2412_24Right, TAG_Right, 1, (V[]){v_x_2420})));
    }
    default: return heff_nomatch(v_y_2414);
    }
  }
  default: return heff_nomatch(v_x_2412);
  }
}
HEFF_LIT(g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_str0, 52, "heff dev: not built; built again at the next change\012");
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_entry, 3, 0};

V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165(V v_r_240, V v_p_241, V v_p_242) {
top: ;
  V v_out_243 = heff_take_field(v_r_240, 1);
  V v_err_244 = heff_get_n(v_r_240, 2, 3);
  V v_t_245 = heff_tag_n(TAG_Write, 2, (V[]){v_out_243, NTAG(TAG_MkUnit)});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  HEFF_LAST return g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_lam0, 1, 3, (V[]){v_err_244, v_p_241, v_p_242}));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_str0), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_p_241, v_p_242));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_err_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_drop(v_x_2411);
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_err_244, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_lam1, 1, 2, (V[]){v_p_241, v_p_242})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_str0, 8, "building");
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_str1, 5, "build");
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam1, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam3, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_entry, 3, 0};

V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087(V v_st_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam0, 1, 3, (V[]){v_hd_241, v_st_240, v_k_242})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam1(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam3(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_drop(v_x_2419);
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam8(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_drop(v_x_2421);
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam9(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_drop(v_x_2422);
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam10(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_drop(v_x_2424);
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_drop(v_x_2415);
  V v_t_2416 = heff_dup(heff_rfield(v_x_2412, 0));
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Exited: {
    V v_n_2417 = heff_field(v_t_2416, 0);
    V v_ru_24t_2416_24Exited = heff_take_reuse_n(v_t_2416, 1ULL, 1);
    if (heff_intEq_c(v_n_2417, MK_INT(0LL))) {
      heff_clo_take(self, 4);
      heff_drop_rec(v_x_2412, 3);
      return (g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1(v_ru_24t_2416_24Exited, v_st_240, v_hd_241, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam6, 1, 1, (V[]){v_k_242})));
    } else {
      heff_clo_take(self, 4);
      heff_drop(v_st_240);
      return (g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1(v_ru_24t_2416_24Exited, v_x_2412, v_hd_241, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam7, 1, 1, (V[]){v_k_242})));
    }
  }
  case TAG_Signalled: {
    V v_ru_24t_2416_24Signalled = heff_take_reuse_n(v_t_2416, 0ULL, 1);
    heff_clo_take(self, 4);
    heff_drop(v_st_240);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1(v_ru_24t_2416_24Signalled, v_x_2412, v_hd_241, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam8, 1, 1, (V[]){v_k_242})));
  }
  case TAG_TimedOut: {
    heff_clo_take(self, 4);
    heff_drop(v_st_240);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165(v_x_2412, v_hd_241, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam9, 1, 1, (V[]){v_k_242})));
  }
  case TAG_NotRun: {
    V v_ru_24t_2416_24NotRun = heff_take_reuse_n(v_t_2416, 0ULL, 1);
    heff_clo_take(self, 4);
    heff_drop(v_st_240);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1(v_ru_24t_2416_24NotRun, v_x_2412, v_hd_241, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam10, 1, 1, (V[]){v_k_242})));
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_End, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam5, 1, 4, (V[]){v_x_2412, v_st_240, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_str1), NTAG(TAG_Nil)});
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_247), v_x_243, v_t_248, ((V)&g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam3_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s535099379x685970669(v_t_2411, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam4, 1, 4, (V[]){v_x_247, v_hd_241, v_st_240, v_k_242})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_245})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s535099379x685970669(v_t_246, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_lam2, 1, 4, (V[]){v_x_243, v_hd_241, v_st_240, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str0, 7, "status ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str1, 7, "signal ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str2, 9, "timed out");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str5, 9, "not run: ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str6, 10, "heff dev: ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str7, 8, " ended (");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str8, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str9, 1, "\012");
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_entry, 4, 0};

V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258(V v_acc_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){v_acc_240});
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return heff_tail(heff_dup(heff_rfield(v_r_244, 1)), 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam0, 1, 5, (V[]){v_r_244, v_acc_240, v_rest_245, v_p_242, v_p_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam2(V self, V *args) {
  V v_x_2437 = args[0];
  V v_g_2435 = heff_env(self)[0];
  V v_hd_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438 = heff_tr(heff_call(v_g_2435, 1, (V[]){v_x_2437}));
  V f_ = heff_get_n(v_hd_2434, 0, 3);
  args[0] = v_t_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam1(V self, V *args) {
  V v_g_2435 = args[0];
  V v_m_2436 = args[1];
  V v_hd_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2434, 1));
  args[0] = v_m_2436;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam2, 1, 2, (V[]){v_g_2435, v_hd_2434});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam3(V self, V *args) {
  V v_c_2439 = args[0];
  V v_hd_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_2434);
  heff_room[1] = heff_get_n(v_hd_2434, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam4(V self, V *args) {
  V v_a_2442 = args[0];
  V v_lit_2410 = heff_env(self)[0];
  V v_lit_2411 = heff_env(self)[1];
  V v_lit_2412 = heff_env(self)[2];
  V v_lit_2413 = heff_env(self)[3];
  heff_drop(v_a_2442);
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258(v_lit_2410, v_lit_2411, v_lit_2412, v_lit_2413));
}
V g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_r_244 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_clo_take(self, 5);
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_244, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_acc_240, v_t_247));
    return (g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258(v_t_248, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_Just: {
    V v_ran_249 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    heff_clo_take(self, 5);
    V v_lit_2410 = v_acc_240;
    V v_lit_2411 = v_rest_245;
    V v_lit_2412 = heff_dup(v_p_242);
    V v_lit_2413 = v_p_243;
    V v_t_2414 = heff_get_n(v_ran_249, 0, 3);
    V v_t_2423;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Exited: {
      V v_n_2415 = heff_field(v_t_2414, 0);
      heff_take_n(v_t_2414, 1ULL, 1);
      v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str0), heff_intShow(v_n_2415));
      break;
    }
    case TAG_Signalled: {
      V v_n_2416 = heff_field(v_t_2414, 0);
      heff_take_n(v_t_2414, 1ULL, 1);
      v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str1), heff_intShow(v_n_2416));
      break;
    }
    case TAG_TimedOut: {
      v_t_2423 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str2);
      break;
    }
    case TAG_NotRun: {
      V v_err_2417 = heff_field(v_t_2414, 0);
      heff_take_n(v_t_2414, 1ULL, 1);
      V v_path_2418 = heff_take_field(v_err_2417, 3);
      V v_name_2419 = heff_take_field(v_err_2417, 1);
      V v_message_2420 = heff_get_n(v_err_2417, 2, 4);
      V v_t_2421 = heff_strAppend(heff_strAppend(v_path_2418, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str3)), v_name_2419);
      V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str4)), v_message_2420);
      v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str5), v_t_2422);
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str6), heff_get_n(v_r_244, 0, 2));
    V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str7)), v_t_2423);
    V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str8)), ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_str9));
    V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2426, NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    V v_p_2433 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2432});
    V v_hd_2434 = v_p_242;
    V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam1, 2, 1, (V[]){heff_dup(v_hd_2434)})}), heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam3, 1, 1, (V[]){heff_dup(v_hd_2434)}), v_p_2433}));
    V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_2434, 2), 1, (V[]){v_t_2440}));
    V f_ = heff_get_n(v_hd_2434, 1, 3);
    heff_room[0] = v_t_2441;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258_lam4, 1, 4, (V[]){v_lit_2410, v_lit_2411, v_lit_2412, v_lit_2413});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_str1, 1, "\012");
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_entry, 5, 0};

V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884(V v_clock_240, V v_st_241, V v_d_242, V v_stamp_243, V v_running_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_Sleep, 2, (V[]){heff_box_word((((int64_t)250999999ULL) / ((int64_t)1000000ULL))), NTAG(TAG_MkUnit)});
  V v_t_246 = heff_tr(heff_call(heff_dup(v_clock_240), 1, (V[]){v_t_245}));
  return heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam0, 2, 6, (V[]){v_t_246, v_running_244, v_st_241, heff_dup(v_stamp_243), v_clock_240, v_d_242});
}
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_clock_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_x_2410 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_clo_take(self, 7);
    V v_t_2417 = ({ V a_0 = v_clock_240; V a_1 = v_st_241; V a_2 = v_d_242; V a_3 = v_x_2414; V a_4 = v_x_2410; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2414); r_; });
    V f_ = v_t_2417;
    heff_room[0] = v_hd_247;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_argv_2418 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    heff_clo_take(self, 7);
    heff_drop(v_clock_240);
    heff_drop(v_st_241);
    heff_drop(v_x_2410);
    heff_drop(v_hd_247);
    V v_t_2419 = heff_intAdd(heff_take_field(v_d_242, 0), MK_INT(1LL));
    V v_t_2420 = ({ V rv_0 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_d_242, 2ULL, 2, shape_builds__wanted, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_248;
    args[0] = heff_rec_n(3, shape_dev__apps__stamp, (V[]){v_t_2420, v_argv_2418, v_x_2414});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_stamp_243 = heff_env(self)[0];
  V v_clock_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_x_2410 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_x_2414;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nil: {
    v_x_2414 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x_2411, 0);
    V v_xs_2413 = heff_field(v_x_2411, 1);
    heff_take_n(v_x_2411, 3ULL, 2);
    v_x_2414 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_str1); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  if (heff_strEq_c_lent(v_x_2414, v_stamp_243, 0)) {
    heff_drop(v_x_2414);
    heff_clo_take(self, 7);
    V v_t_2415 = ({ V a_0 = v_clock_240; V a_1 = v_st_241; V a_2 = v_d_242; V a_3 = v_stamp_243; V a_4 = v_x_2410; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_stamp_243); r_; });
    V f_ = v_t_2415;
    heff_room[0] = v_hd_247;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_clo_take(self, 7);
    heff_drop(v_stamp_243);
    return (g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087(heff_dup(v_st_241), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam4, 1, 7, (V[]){v_clock_240, v_st_241, v_d_242, v_x_2414, v_x_2410, v_hd_247, v_k_248})));
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_stamp_243 = heff_env(self)[2];
  V v_clock_240 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = heff_dup(v_st_241); V a_1 = NTAG(TAG_Nil); V b_2 = heff_dup(g_heff_2ebuild_2ewatch_2eproject_get()); V a_3 = heff_dup(v_hd_247); V a_4 = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam3, 1, 7, (V[]){v_stamp_243, v_clock_240, v_st_241, v_d_242, v_x_2410, v_hd_247, v_k_248}); V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_running_244 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_stamp_243 = heff_env(self)[3];
  V v_clock_240 = heff_env(self)[4];
  V v_d_242 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_drop(v_x_249);
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1706893835x1779577258(NTAG(TAG_Nil), v_running_244, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam2, 1, 6, (V[]){v_st_241, v_hd_247, v_stamp_243, v_clock_240, v_d_242, v_k_248})));
}
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_t_246 = heff_env(self)[0];
  V v_running_244 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_stamp_243 = heff_env(self)[3];
  V v_clock_240 = heff_env(self)[4];
  V v_d_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_co_2eop_24s535099379x685970669(v_t_246, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_lam1, 1, 7, (V[]){v_running_244, v_hd_247, v_st_241, v_stamp_243, v_clock_240, v_d_242, v_k_248})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str2, 4, ".exe");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str5, 21, "heff dev: cannot run ");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str6, 1, "\012");
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam1, 1, 0};
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam6(V self, V *args); static Clo g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam6, 1, 0};
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam14(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam19(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam18(V self, V *args);
Clo g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_entry, 8, 0};

V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347(V v_clock_240, V v_ex_241, V v_cu_242, V v_st_243, V v_d_244, V v_stamp_245, V v_running_246, V v_x5_247) {
top: ;
  switch (heff_tag_of(v_x5_247)) {
  case TAG_Nil: {
    heff_drop(v_ex_241);
    heff_drop(v_cu_242);
    return (g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884(v_clock_240, v_st_243, v_d_244, v_stamp_245, v_running_246));
  }
  case TAG_Cons: {
    V v_a_248 = heff_field(v_x5_247, 0);
    V v_rest_249 = heff_field(v_x5_247, 1);
    V v_ru_24x5_247_24Cons = heff_take_reuse_n(v_x5_247, 3ULL, 2);
    V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str0)));
    V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str1)));
    V v_t_2412 = (g_std_2epath_2ejoin(v_t_2410, v_t_2411));
    V v_a_2413 = ({ V a_0 = v_st_243; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V v_n_2414 = heff_dup(heff_rfield(v_a_248, 0));
    V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_a_2413));
    V v_t_2416;
    switch (heff_tag_of(v_st_243)) {
    case TAG_Posix: {
      v_t_2416 = v_n_2414;
      break;
    }
    case TAG_Windows: {
      v_t_2416 = heff_strAppend(v_n_2414, ((V)&g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str2));
      break;
    }
    default: heff_nomatch(v_st_243);
    }
    V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_t_2416));
    V v_t_2418 = (g_std_2epath_2ejoin(v_t_2415, v_t_2417));
    V v_program_2419 = ({ V a_0 = v_st_243; V a_1 = v_t_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_cu_2420 = heff_dup(v_cu_242);
    V v_ex_2421 = heff_dup(v_ex_241);
    V v_c_2422 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_program_2419, NTAG(TAG_Nil), heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_body_2447 = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam0, 1, 9, (V[]){v_a_248, heff_dup(v_running_246), heff_dup(v_clock_240), heff_dup(v_ex_241), heff_dup(v_cu_242), heff_dup(v_st_243), heff_dup(v_d_244), heff_dup(v_stamp_245), heff_dup(v_rest_249)});
    V v_t_2448 = (g_std_2eprocess_2edirFor(heff_rfield(v_c_2422, 2)));
    V v_t_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_c_2422, 1019ULL, 10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, 1048527u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_a_2451 = heff_tag_at_n(v_ru_24x5_247_24Cons, TAG_Start, 2, (V[]){v_t_2449, ((V)&g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam6_clo)});
    V v_c_2474 = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam7, 2, 4, (V[]){v_ex_2421, v_cu_2420, v_body_2447, v_a_2451});
    V v_t_2499 = heff_tr(heff_call(heff_dup(v_ex_241), 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam12, 2, 1, (V[]){v_c_2474}), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam14, 3, 8, (V[]){v_clock_240, v_ex_241, v_cu_242, v_st_243, v_d_244, heff_dup(v_stamp_245), v_running_246, v_rest_249})})}));
    return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam18, 2, 1, (V[]){v_t_2499});
  }
  default: return heff_nomatch(v_x5_247);
  }
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam1(V self, V *args) {
  V v_r_2426 = args[0];
  return v_r_2426;
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_2445 = args[1];
  V v_k_2446 = args[2];
  V v_x_2440 = heff_env(self)[0];
  heff_drop(v_x_2444);
  heff_drop(v_hd_2445);
  heff_clo_take(self, 1);
  V f_ = v_k_2446;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_2442 = args[1];
  V v_k_2443 = args[2];
  V v_x_2440 = heff_env(self)[0];
  heff_drop(v_x_2441);
  heff_drop(v_hd_2442);
  heff_clo_take(self, 1);
  V f_ = v_k_2443;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam5, 3, 1, (V[]){v_x_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam3(V self, V *args) {
  V v_x_2440 = args[0];
  V v_k_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2439;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam4, 3, 1, (V[]){v_x_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam2(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_c_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2437;
  args[0] = v_hd_2438;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam3, 1, 1, (V[]){v_k_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam0(V self, V *args) {
  V v_p_2423 = args[0];
  V v_a_248 = heff_env(self)[0];
  V v_running_246 = heff_env(self)[1];
  V v_clock_240 = heff_env(self)[2];
  V v_ex_241 = heff_env(self)[3];
  V v_cu_242 = heff_env(self)[4];
  V v_st_243 = heff_env(self)[5];
  V v_d_244 = heff_env(self)[6];
  V v_stamp_245 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  V v_t_2425;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkWith: {
    V v_x_2424 = heff_field(v_p_2423, 0);
    heff_take_n(v_p_2423, 1ULL, 1);
    v_t_2425 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_TryWait, 2, (V[]){v_t_2425, ((V)&g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam1_clo)})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){v_t_2432}));
  heff_clo_take(self, 9);
  V v_t_2434 = heff_rec_n(2, shape_name__ended, (V[]){heff_get_n(v_a_248, 0, 2), v_t_2433});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
  V v_t_2436 = (g_prelude_2e_2b_2b(v_running_246, v_t_2435));
  V v_c_2437 = ({ V a_0 = v_clock_240; V a_1 = v_ex_241; V a_2 = v_cu_242; V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = v_t_2436; V a_7 = v_rest_249; V r_ = (g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_stamp_245); r_; });
  return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam2, 2, 1, (V[]){v_c_2437});
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam6(V self, V *args) {
  V v_s_2450 = args[0];
  return v_s_2450;
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam9(V self, V *args) {
  V v_x_2468 = args[0];
  V v_g_2466 = heff_env(self)[0];
  V v_hd_2465 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2469 = heff_tr(heff_call(v_g_2466, 1, (V[]){v_x_2468}));
  V f_ = heff_get_n(v_hd_2465, 0, 3);
  args[0] = v_t_2469;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam8(V self, V *args) {
  V v_g_2466 = args[0];
  V v_m_2467 = args[1];
  V v_hd_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2465, 1));
  args[0] = v_m_2467;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam9, 1, 2, (V[]){v_g_2466, v_hd_2465});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam10(V self, V *args) {
  V v_c_2470 = args[0];
  V v_hd_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2470;
  heff_room[0] = heff_dup(v_hd_2465);
  heff_room[1] = heff_get_n(v_hd_2465, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam11(V self, V *args) {
  V v_a_2473 = args[0];
  V v_lit_2454 = heff_env(self)[0];
  V v_lit_2455 = heff_env(self)[1];
  V v_lit_2456 = heff_env(self)[2];
  V v_lit_2457 = heff_env(self)[3];
  V v_lit_2458 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_resource_2eheldBy_24s1065400090x105490439(v_lit_2454, v_lit_2455, v_lit_2456, v_a_2473, v_lit_2457, v_lit_2458));
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam7(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  V v_ex_2421 = heff_env(self)[0];
  V v_cu_2420 = heff_env(self)[1];
  V v_body_2447 = heff_env(self)[2];
  V v_a_2451 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_lit_2454 = v_ex_2421;
  V v_lit_2455 = v_cu_2420;
  V v_lit_2456 = v_body_2447;
  V v_lit_2457 = heff_dup(v_hd_2452);
  V v_lit_2458 = v_k_2453;
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2451})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  V v_p_2464 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2463});
  V v_hd_2465 = v_hd_2452;
  V v_t_2471 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam8, 2, 1, (V[]){heff_dup(v_hd_2465)})}), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam10, 1, 1, (V[]){heff_dup(v_hd_2465)}), v_p_2464}));
  V v_t_2472 = heff_tr(heff_call(heff_take_field(v_hd_2465, 2), 1, (V[]){v_t_2471}));
  V f_ = heff_get_n(v_hd_2465, 1, 3);
  args[0] = v_t_2472;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam11, 1, 5, (V[]){v_lit_2454, v_lit_2455, v_lit_2456, v_lit_2457, v_lit_2458});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam13(V self, V *args) {
  V v_x_2477 = args[0];
  V v_hd_2475 = heff_env(self)[0];
  V v_k_2476 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2477;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2475;
  heff_room[2] = v_k_2476;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam12(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k_2476 = args[1];
  V v_c_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2474;
  args[0] = heff_dup(v_hd_2475);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam13, 1, 2, (V[]){v_hd_2475, v_k_2476});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam17(V self, V *args) {
  V v_x_2496 = args[0];
  V v_hd_2497 = args[1];
  V v_k_2498 = args[2];
  V v_x_2495 = heff_env(self)[0];
  heff_drop(v_x_2496);
  heff_drop(v_hd_2497);
  heff_clo_take(self, 1);
  V f_ = v_k_2498;
  args[0] = v_x_2495;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam16(V self, V *args) {
  V v_x_2495 = args[0];
  V v_k_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2480;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam17, 3, 1, (V[]){v_x_2495});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam15(V self, V *args) {
  V v_x_2493 = args[0];
  V v_clock_240 = heff_env(self)[0];
  V v_ex_241 = heff_env(self)[1];
  V v_cu_242 = heff_env(self)[2];
  V v_st_243 = heff_env(self)[3];
  V v_d_244 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_running_246 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  V v_hd_2479 = heff_env(self)[8];
  V v_k_2480 = heff_env(self)[9];
  heff_drop(v_x_2493);
  heff_clo_take(self, 10);
  V v_t_2494 = ({ V a_0 = v_clock_240; V a_1 = v_ex_241; V a_2 = v_cu_242; V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = v_running_246; V a_7 = v_rest_249; V r_ = (g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_stamp_245); r_; });
  V f_ = v_t_2494;
  heff_room[0] = v_hd_2479;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam16, 1, 1, (V[]){v_k_2480});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam14(V self, V *args) {
  V v_err_2478 = args[0];
  V v_hd_2479 = args[1];
  V v_k_2480 = args[2];
  V v_clock_240 = heff_env(self)[0];
  V v_ex_241 = heff_env(self)[1];
  V v_cu_242 = heff_env(self)[2];
  V v_st_243 = heff_env(self)[3];
  V v_d_244 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_running_246 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  V v_path_2481 = heff_take_field(v_err_2478, 3);
  V v_name_2482 = heff_take_field(v_err_2478, 1);
  V v_message_2483 = heff_get_n(v_err_2478, 2, 4);
  V v_t_2484 = heff_strAppend(heff_strAppend(v_path_2481, ((V)&g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str3)), v_name_2482);
  V v_t_2485 = heff_strAppend(heff_strAppend(v_t_2484, ((V)&g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str4)), v_message_2483);
  V v_t_2486 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str5), v_t_2485), ((V)&g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_str6));
  V v_t_2487 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2486, NTAG(TAG_MkUnit)});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
  heff_clo_take(self, 8);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2492}), heff_dup(v_hd_2479), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam15, 1, 10, (V[]){v_clock_240, v_ex_241, v_cu_242, v_st_243, v_d_244, v_stamp_245, v_running_246, v_rest_249, v_hd_2479, v_k_2480})));
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam19(V self, V *args) {
  V v_x_24102 = args[0];
  V v_hd_24100 = heff_env(self)[0];
  V v_k_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_24102;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_24100;
  heff_room[2] = v_k_24101;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam18(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k_24101 = args[1];
  V v_t_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_co_2eop_24s535099379x685970669(v_t_2499, heff_dup(v_hd_24100), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347_lam19, 1, 2, (V[]){v_hd_24100, v_k_24101})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str1, 14, "nothing to run");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str4, 17, "heff dev: built (");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str5, 11, "); running ");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str7, 1, "c");
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_entry, 9, 0};

V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407(V v_clock_240, V v_ex_241, V v_cu_242, V v_st_243, V v_d_244, V v_stamp_245, V v_apps_246, V v_z_247, V v_z_248) {
top: ;
  V v_d_249 = heff_dup(v_d_244);
  V v_wanted_2410 = heff_take_field(v_d_249, 1);
  V v_builds_2411 = heff_get_n(v_d_249, 0, 2);
  V v_apps_2412 = heff_dup(v_apps_246);
  V v_wanted_2413 = v_wanted_2410;
  V v_argv_2418 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_lam0, 1, 1, (V[]){v_wanted_2413}), v_apps_2412));
  V v_t_2424;
  switch (heff_tag_of(v_argv_2418)) {
  case TAG_Nil: {
    v_t_2424 = ((V)&g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str1);
    break;
  }
  case TAG_Cons: {
    V v_x2_2421 = (g_list_2emap_24s2104774589x596860835(v_argv_2418));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str3); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    break;
  }
  default: heff_nomatch(v_argv_2418);
  }
  V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str4), heff_intShow(v_builds_2411));
  V v_str_2426 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str5)), v_t_2424);
  V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2426, ((V)&g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str6)), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_c_2433 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
  return heff_tail(v_c_2433, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_lam1, 1, 9, (V[]){v_d_244, v_apps_246, v_clock_240, v_ex_241, v_cu_242, v_st_243, heff_dup(v_stamp_245), v_z_247, heff_dup(v_z_248)})});
}
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a8 = a[8]; V r = g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7], a8); heff_drop(a5); heff_drop(a8); return r;
}
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_lam0(V self, V *args) {
  V v_a_2414 = args[0];
  V v_wanted_2413 = heff_env(self)[0];
  V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_a_2414, 1)), 0, 6);
  if (heff_strEq_c(v_t_2415, ((V)&g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str0))) {
    heff_clo_take(self, 1);
    switch (heff_tag_of(v_wanted_2413)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_2414, 2);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return ({ V a_0 = v_a_2414; V a_1 = v_wanted_2413; V r_ = (g_list_2eany_24s1255781029x1672221493(a_0, a_1)); heff_drop_tag(v_wanted_2413, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2413);
    }
  } else {
    heff_drop_rec(v_a_2414, 2);
    heff_drop(self);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_lam2(V self, V *args) {
  V v_a_2436 = args[0];
  V v_wanted_2435 = heff_env(self)[0];
  V v_t_2437 = heff_get_n(heff_dup(heff_rfield(v_a_2436, 1)), 0, 6);
  if (heff_strEq_c(v_t_2437, ((V)&g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_str7))) {
    heff_clo_take(self, 1);
    switch (heff_tag_of(v_wanted_2435)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_2436, 2);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return ({ V a_0 = v_a_2436; V a_1 = v_wanted_2435; V r_ = (g_list_2eany_24s1255781029x1672221493(a_0, a_1)); heff_drop_tag(v_wanted_2435, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2435);
    }
  } else {
    heff_drop_rec(v_a_2436, 2);
    heff_drop(self);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_lam3(V self, V *args) {
  V v_x_2442 = args[0];
  V v_clock_240 = heff_env(self)[0];
  V v_ex_241 = heff_env(self)[1];
  V v_cu_242 = heff_env(self)[2];
  V v_st_243 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_z_248 = heff_env(self)[5];
  V v_dev_2443 = heff_take_field(v_x_2442, 0);
  V v_stamp_2444 = heff_take_field(v_x_2442, 2);
  V v_apps_2445 = heff_get_n(v_x_2442, 1, 3);
  heff_clo_take(self, 6);
  return ({ V a_0 = v_clock_240; V a_1 = v_ex_241; V a_2 = v_cu_242; V a_3 = v_st_243; V a_4 = v_dev_2443; V a_5 = v_stamp_2444; V a_6 = v_apps_2445; V a_7 = v_z_247; V a_8 = v_z_248; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_stamp_2444); heff_drop(v_z_248); r_; });
}
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_lam1(V self, V *args) {
  V v_x_2434 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_apps_246 = heff_env(self)[1];
  V v_clock_240 = heff_env(self)[2];
  V v_ex_241 = heff_env(self)[3];
  V v_cu_242 = heff_env(self)[4];
  V v_st_243 = heff_env(self)[5];
  V v_stamp_245 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  V v_z_248 = heff_env(self)[8];
  heff_drop(v_x_2434);
  V v_wanted_2435 = heff_dup(heff_rfield(v_d_244, 1));
  heff_clo_take(self, 9);
  V v_t_2440 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_lam2, 1, 1, (V[]){v_wanted_2435}), v_apps_246));
  V v_t_2441 = ({ V a_0 = heff_dup(v_clock_240); V a_1 = heff_dup(v_ex_241); V a_2 = heff_dup(v_cu_242); V a_3 = heff_dup(v_st_243); V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = NTAG(TAG_Nil); V a_7 = v_t_2440; V r_ = (g_heff_2ebuild_2edev_2eheld_24s280472741x1933715347(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_stamp_245); r_; });
  V f_ = v_t_2441;
  heff_room[0] = heff_dup(v_z_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_lam3, 1, 6, (V[]){v_clock_240, v_ex_241, v_cu_242, v_st_243, v_z_247, v_z_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_str0, 10, "package.hf");
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_lam0, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_entry, 4, 0};

V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372(V v_clock_240, V v_ex_241, V v_cu_242, V v_wanted_243) {
top: ;
  V v_path_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_str0)));
  V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_244; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_244); r_; });
  V v_a_247 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_245, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_lam1, 2, 5, (V[]){v_a_247, v_clock_240, v_wanted_243, v_ex_241, v_cu_242});
}
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  V v_clock_240 = heff_env(self)[2];
  V v_wanted_243 = heff_env(self)[3];
  V v_ex_241 = heff_env(self)[4];
  V v_cu_242 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_x_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Left = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    heff_clo_take(self, 6);
    return (g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0(v_hd_248, v_k_249, v_clock_240, v_wanted_243, v_ex_241, v_cu_242, heff_tag_re_n(v_ru_24x_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2416})));
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Right = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    switch (heff_tag_of(v_y_2417)) {
    case TAG_Left: {
      V v_err_2418 = heff_field(v_y_2417, 0);
      V v_ru_24y_2417_24Left = heff_take_reuse_n(v_y_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2415_24Right, 1);
      heff_clo_take(self, 6);
      return (g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0(v_hd_248, v_k_249, v_clock_240, v_wanted_243, v_ex_241, v_cu_242, heff_tag_re_n(v_ru_24y_2417_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2418})));
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_y_2417, 0);
      heff_take_n(v_y_2417, 1ULL, 1);
      heff_clo_take(self, 6);
      return (g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0(v_hd_248, v_k_249, v_clock_240, v_wanted_243, v_ex_241, v_cu_242, heff_tag_at_n(v_ru_24x_2415_24Right, TAG_Right, 1, (V[]){v_x_2419})));
    }
    default: return heff_nomatch(v_y_2417);
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_a_247 = heff_env(self)[0];
  V v_clock_240 = heff_env(self)[1];
  V v_wanted_243 = heff_env(self)[2];
  V v_ex_241 = heff_env(self)[3];
  V v_cu_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_247})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2414, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_lam2, 1, 6, (V[]){v_hd_248, v_k_249, v_clock_240, v_wanted_243, v_ex_241, v_cu_242})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_str0, 3, "app");
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_entry, 4, 0};

V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1(V v_tok_240, V v_st_241, V v_z_242, V v_z_243) {
top: ;
  V v_path_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_str0)));
  V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_244; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_247 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_245, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_lam0_clo)});
  V v_t_248 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2412, heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_lam1, 1, 4, (V[]){v_z_242, v_st_241, v_z_243, v_path_244})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_lam2(V self, V *args) {
  V v_n_2418 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2418));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_244, v_t_2419));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_path_244 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_x_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    heff_clo_take(self, 4);
    heff_drop(v_path_244);
    return (g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0(v_z_242, v_st_241, v_z_243, heff_tag_re_n(v_ru_24x_2413_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2414})));
  }
  case TAG_Right: {
    V v_y_2415 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Right = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    switch (heff_tag_of(v_y_2415)) {
    case TAG_Left: {
      V v_err_2416 = heff_field(v_y_2415, 0);
      V v_ru_24y_2415_24Left = heff_take_reuse_n(v_y_2415, 1ULL, 1);
      heff_clo_take(self, 4);
      heff_drop(v_path_244);
      heff_drop_cell(v_ru_24x_2413_24Right, 1);
      return (g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0(v_z_242, v_st_241, v_z_243, heff_tag_re_n(v_ru_24y_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2416})));
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_y_2415, 0);
      heff_take_n(v_y_2415, 1ULL, 1);
      heff_clo_take(self, 4);
      V v_x_2420 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_24tok1_lam2, 1, 1, (V[]){v_path_244}), v_x_2417));
      V v_x_2421 = (g_list_2emap_24s219049803x1458391381(v_x_2420));
      return (g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0(v_z_242, v_st_241, v_z_243, heff_tag_at_n(v_ru_24x_2413_24Right, TAG_Right, 1, (V[]){v_x_2421})));
    }
    default: return heff_nomatch(v_y_2415);
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}
HEFF_LIT(g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_str0, 52, "heff dev: not built; built again at the next change\012");
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_entry, 4, 0};

V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1(V v_tok_240, V v_r_241, V v_p_242, V v_p_243) {
top: ;
  V v_out_244 = heff_take_field(v_r_241, 1);
  V v_err_245 = heff_get_n(v_r_241, 2, 3);
  V v_t_246 = heff_tag_n(TAG_Write, 2, (V[]){v_out_244, NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_lam0, 1, 3, (V[]){v_err_245, v_p_242, v_p_243})));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_drop(v_x_2419);
  V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_str0), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_p_242, v_p_243));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_err_245 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_drop(v_x_2412);
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_err_245, NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s878787599x979881165_24tok1_lam1, 1, 2, (V[]){v_p_242, v_p_243})));
}