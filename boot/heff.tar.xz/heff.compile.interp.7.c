// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_syntax 1059664654
V g_heff_2ecompile_2einterp_2ebits1(V);
V g_heff_2ecompile_2einterp_2ebits1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebits1_clo;
V g_heff_2ecompile_2einterp_2ebitsRead(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsRead_clo;
V g_heff_2ecompile_2einterp_2ebytes2(V);
V g_heff_2ecompile_2einterp_2ebytes2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytes2_clo;
V g_heff_2ecompile_2einterp_2ebytesTake2(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesTake2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesTake2_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo(V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_clo;
V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_get(void);
V g_heff_2ecompile_2einterp_2ef32V2(V);
V g_heff_2ecompile_2einterp_2ef32V2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ef32V2_clo;
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_get(void);
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_get(void);
V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_get(void);
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void);
V g_heff_2ecompile_2einterp_2efixThunk(V, V, V);
V g_heff_2ecompile_2einterp_2efixThunk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixThunk_clo;
V g_heff_2ecompile_2einterp_2efloat32V(V);
V g_heff_2ecompile_2einterp_2efloat32V_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat32V_clo;
V g_heff_2ecompile_2einterp_2eglobalEnvGo(V, V);
V g_heff_2ecompile_2einterp_2eglobalEnvGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eglobalEnvGo_clo;
V g_heff_2ecompile_2einterp_2eint2(V);
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eint2_clo;
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get(void);
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_clo;
V g_heff_2ecompile_2einterp_2eintTake2(V, V, V);
V g_heff_2ecompile_2einterp_2eintTake2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintTake2_clo;
V g_heff_2ecompile_2einterp_2elittleInGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2elittleInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleInGo_clo;
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2eruneTake2(V, V, V);
V g_heff_2ecompile_2einterp_2eruneTake2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneTake2_clo;
V g_heff_2ecompile_2einterp_2escalarV(V);
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escalarV_clo;
V g_heff_2ecompile_2einterp_2esetAt_24dps(V, V, V, V);
V g_heff_2ecompile_2einterp_2esetAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esetAt_24dps_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
V g_heff_2eutil_2erune_2ebitsTail(V, V, V, V);
V g_heff_2eutil_2erune_2ebitsTail_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ebitsTail_clo;
V g_heff_2eutil_2erune_2equoteBytesGo(V, V, V, V);
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteBytesGo_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_map_2einsert_24s1705770630x2073956475(V, V, V);
V g_map_2einsert_24s1705770630x2073956475_entry(V self, V *a);
extern Clo g_map_2einsert_24s1705770630x2073956475_clo;
V g_heff_2ecompile_2einterp_2eint2_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eint2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eint2(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eint2(a[0]);
}
V g_heff_2ecompile_2einterp_2eint2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Ok = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return ({ V a_0 = v_f_240; V a_1 = v_v_246; V a_2 = v_v_248; V r_ = (g_heff_2ecompile_2einterp_2eintTake2(a_0, a_1, a_2)); heff_drop(v_v_246); heff_drop(v_v_248); r_; });
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_249 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return heff_tag_at_n(v_ru_24x1_245_24Ok, TAG_Bug, 1, (V[]){v_what_249});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2410 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return heff_tag_at_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, (V[]){v_what_2410});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2einterp_2eint2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
Clo g_heff_2ecompile_2einterp_2eruneTake2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneTake2_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eruneTake2(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VFun: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
  }
  case TAG_VCons: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
  }
  case TAG_VTag: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
  }
  case TAG_VInt: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
  }
  case TAG_VFloat: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
  }
  case TAG_VFloat32: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
  }
  case TAG_VStr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
  }
  case TAG_VRune: {
    V v_a_2411 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_VFun: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VCons: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VTag: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VInt: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat32: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VStr: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VRune: {
      V v_b_2420 = heff_field(v_x3_242, 0);
      return heff_tail(v_f_240, 2, (V[]){heff_dup(v_a_2411), heff_dup(v_b_2420)});
    }
    case TAG_VArr: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBytes: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBits: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VErased: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_VArr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
  }
  case TAG_VBytes: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
  }
  case TAG_VBits: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
  }
  case TAG_VErased: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2eruneTake2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2einterp_2eruneTake2(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2einterp_2ebytes2_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ebytes2_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2ebytes2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebytes2_entry, 1, 0};

V g_heff_2ecompile_2einterp_2ebytes2(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ebytes2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2ebytes2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebytes2(a[0]);
}
V g_heff_2ecompile_2einterp_2ebytes2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Ok = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return ({ V a_0 = v_f_240; V a_1 = v_v_246; V a_2 = v_v_248; V r_ = (g_heff_2ecompile_2einterp_2ebytesTake2(a_0, a_1, a_2)); heff_drop(v_v_246); heff_drop(v_v_248); r_; });
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_249 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return heff_tag_at_n(v_ru_24x1_245_24Ok, TAG_Bug, 1, (V[]){v_what_249});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2410 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return heff_tag_at_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, (V[]){v_what_2410});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2einterp_2ebytes2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ebytes2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_str0, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_str1, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_str2, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_str3, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_str4, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_str5, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_str6, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_str7, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_str8, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_str9, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_str10, 36, "a primitive given what is not `Bits`");
V g_heff_2ecompile_2einterp_2ebits1_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2ebits1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebits1_entry, 1, 0};

V g_heff_2ecompile_2einterp_2ebits1(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ebits1_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2ebits1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebits1(a[0]);
}
V g_heff_2ecompile_2einterp_2ebits1_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_243 = heff_tr(heff_call(v_a_242, 1, (V[]){v_d_241}));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Ok: {
    V v_v_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Ok = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    switch (heff_tag_of(v_v_244)) {
    case TAG_VFun: {
      heff_take_n(v_v_244, 0ULL, 1);
      heff_drop(v_f_240);
      return heff_tag_at_n(v_ru_24x1_243_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_str0)});
    }
    case TAG_VCons: {
      heff_take_n(v_v_244, 0ULL, 1);
      heff_drop(v_f_240);
      return heff_tag_at_n(v_ru_24x1_243_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_str1)});
    }
    case TAG_VTag: {
      heff_take_n(v_v_244, 0ULL, 2);
      heff_drop(v_f_240);
      return heff_tag_at_n(v_ru_24x1_243_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_str2)});
    }
    case TAG_VInt: {
      heff_take_n(v_v_244, 0ULL, 1);
      heff_drop(v_f_240);
      return heff_tag_at_n(v_ru_24x1_243_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_str3)});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_244, 0ULL, 1);
      heff_drop(v_f_240);
      return heff_tag_at_n(v_ru_24x1_243_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_str4)});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_244, 0ULL, 1);
      heff_drop(v_f_240);
      return heff_tag_at_n(v_ru_24x1_243_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_str5)});
    }
    case TAG_VStr: {
      heff_take_n(v_v_244, 0ULL, 1);
      heff_drop(v_f_240);
      return heff_tag_at_n(v_ru_24x1_243_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_str6)});
    }
    case TAG_VRune: {
      heff_take_n(v_v_244, 0ULL, 1);
      heff_drop(v_f_240);
      return heff_tag_at_n(v_ru_24x1_243_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_str7)});
    }
    case TAG_VArr: {
      heff_take_n(v_v_244, 0ULL, 1);
      heff_drop(v_f_240);
      return heff_tag_at_n(v_ru_24x1_243_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_str8)});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_244, 0ULL, 1);
      heff_drop(v_f_240);
      return heff_tag_at_n(v_ru_24x1_243_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_str9)});
    }
    case TAG_VBits: {
      V v_n_2416 = heff_field(v_v_244, 0);
      V v_a_2417 = heff_field(v_v_244, 1);
      heff_take_n(v_v_244, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_243_24Ok, 1);
      V f_ = v_f_240;
      args[0] = v_n_2416;
      args[1] = v_a_2417;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_VErased: {
      heff_drop(v_f_240);
      return heff_tag_at_n(v_ru_24x1_243_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_str10)});
    }
    default: return heff_nomatch(v_v_244);
    }
  }
  case TAG_Abn: {
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2418 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Bug = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    heff_drop(v_f_240);
    return heff_tag_at_n(v_ru_24x1_243_24Bug, TAG_Bug, 1, (V[]){v_what_2418});
  }
  default: return heff_nomatch(v_x1_243);
  }
}
Clo g_heff_2ecompile_2einterp_2ebitsRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsRead_entry, 4, 0};

V g_heff_2ecompile_2einterp_2ebitsRead(V v_s_240, V v_i_241, V v_n_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_242), MK_INT(0LL))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return v_acc_243;
  } else {
    V v_t_245 = heff_strByteAt(heff_dup(v_s_240), heff_intDiv(heff_dup(v_i_241), MK_INT(8LL)));
    V v_t_246 = heff_intSub(MK_INT(7LL), heff_intMod(heff_dup(v_i_241), MK_INT(8LL)));
    V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(v_t_246));
    V v_t_248 = heff_intMod(heff_intDiv(v_t_245, v_t_247), MK_INT(2LL));
    V v_t_249 = heff_intAdd(heff_intMul(v_acc_243, MK_INT(2LL)), v_t_248);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = heff_intSub(v_n_242, MK_INT(1LL));
    V t_3 = v_t_249;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2einterp_2ebitsRead_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitsRead(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2einterp_2elittleInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2elittleInGo_entry, 5, 0};

V g_heff_2ecompile_2einterp_2elittleInGo(V v_w_240, V v_n_241, V v_k_242, V v_i_243, V v_acc_244) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_242), heff_dup(v_i_243))) {
    heff_drop(v_w_240);
    heff_drop(v_n_241);
    heff_drop(v_k_242);
    heff_drop(v_i_243);
    return v_acc_244;
  } else {
    V v_t_246 = heff_intMul(MK_INT(8LL), heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
    V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intSub(heff_dup(v_n_241), v_t_246)));
    V v_t_248 = heff_intMod(heff_intDiv(heff_dup(v_w_240), v_t_247), MK_INT(256LL));
    V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intMul(MK_INT(8LL), heff_dup(v_i_243))));
    V v_t_2410 = heff_intAdd(v_acc_244, heff_intMul(v_t_248, v_t_249));
    V t_0 = v_w_240;
    V t_1 = v_n_241;
    V t_2 = v_k_242;
    V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
    V t_4 = v_t_2410;
    v_w_240 = t_0;
    v_n_241 = t_1;
    v_k_242 = t_2;
    v_i_243 = t_3;
    v_acc_244 = t_4;
    goto top;
  }
}
V g_heff_2ecompile_2einterp_2elittleInGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2elittleInGo(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2einterp_2esetAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2esetAt_24dps_entry, 4, 0};

V g_heff_2ecompile_2einterp_2esetAt_24dps(V v_x1_240, V v_i_241, V v_x_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_x_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_y_244 = heff_field(v_x1_240, 0);
    V v_ys_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      heff_drop(v_y_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_ys_245}));
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_245;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      V t_2 = v_x_242;
      V t_3 = v_cell_247;
      v_x1_240 = t_0;
      v_i_241 = t_1;
      v_x_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2esetAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2esetAt_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_val, &g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_st, g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) - heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam1, 2, 1, (V[]){v_a_241})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str0, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str1, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str2, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str3, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str4, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str5, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str6, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str7, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str8, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str9, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str10, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str11, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str12, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str13, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str14, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str15, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str16, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str17, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str18, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str19, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str20, 20, "no primitive float32");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str21, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str22, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str23, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str24, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str25, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str26, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str27, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str28, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str29, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str30, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str31, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str32, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str33, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str34, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str35, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str36, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str37, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str38, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str39, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str40, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str41, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str42, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str43, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str44, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str45, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str46, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str47, 20, "no primitive float32");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str48, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str49, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str50, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str51, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str52, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str53, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str54, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str55, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str56, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str57, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str58, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str59, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str60, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str61, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str62, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str63, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str64, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str65, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str66, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str67, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str68, 20, "no primitive float32");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str69, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str70, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str71, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str72, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str73, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str74, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str75, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str76, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str77, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str78, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str79, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str80, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str81, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str82, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str83, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str84, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str85, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str86, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str87, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str88, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str89, 20, "no primitive float32");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str90, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str91, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str92, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str93, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str94, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str95, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str96, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str97, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str98, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str99, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str100, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str101, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str102, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str103, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str104, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str105, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str106, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str107, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str108, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str109, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str110, 20, "no primitive float32");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str111, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str112, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str113, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str114, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str115, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str116, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str117, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str118, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str119, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str120, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str121, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str122, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str123, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str124, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str125, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str126, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str127, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str128, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str129, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str130, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str131, 20, "no primitive float32");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str132, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str133, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str134, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str135, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str136, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str137, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str138, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str139, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str140, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str141, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str142, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str143, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str144, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str145, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str146, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str147, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str148, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str149, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str150, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str151, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str152, 20, "no primitive float32");
V g_heff_2ecompile_2einterp_2efloat32V_lam0(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam1(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam1, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam2(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam2, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam3(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam3, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam4(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam5(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam6(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam7(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam8(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam9(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam9, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam10(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam10, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam11(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam12(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam12, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam13(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam13, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam14(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam14, 2, 0};
Clo g_heff_2ecompile_2einterp_2efloat32V_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_entry, 1, 0};

V g_heff_2ecompile_2einterp_2efloat32V(V v_op_240) {
top: ;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    return heff_dup(g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_get());
  }
  case TAG_OpSub: {
    return heff_dup(g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_get());
  }
  case TAG_OpMul: {
    return heff_dup(g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_get());
  }
  case TAG_OpDiv: {
    return heff_dup(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get());
  }
  case TAG_OpRem: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam0, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpEq: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ef32V2(((V)&g_heff_2ecompile_2einterp_2efloat32V_lam1_clo));
  }
  case TAG_OpLt: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ef32V2(((V)&g_heff_2ecompile_2einterp_2efloat32V_lam2_clo));
  }
  case TAG_OpLe: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ef32V2(((V)&g_heff_2ecompile_2einterp_2efloat32V_lam3_clo));
  }
  case TAG_OpAnd: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam4, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpOr: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam5, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpXor: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam6, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpShl: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam7, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpShr: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam8, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpShow: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat32V_lam9_clo)});
  }
  case TAG_OpFromInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat32V_lam10_clo)});
  }
  case TAG_OpToInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam11, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpSqrt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat32V_lam12_clo)});
  }
  case TAG_OpFromFloat: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat32V_lam13_clo)});
  }
  case TAG_OpToFloat: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat32V_lam14_clo)});
  }
  case TAG_OpFloor: {
    return heff_dup(g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_get());
  }
  default: return heff_nomatch(v_op_240);
  }
}
V g_heff_2ecompile_2einterp_2efloat32V_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2efloat32V(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2efloat32V_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  heff_drop(v_a_242);
  V v_t_243;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str0);
    break;
  }
  case TAG_OpSub: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str1);
    break;
  }
  case TAG_OpMul: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str2);
    break;
  }
  case TAG_OpDiv: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str3);
    break;
  }
  case TAG_OpRem: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str4);
    break;
  }
  case TAG_OpEq: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str5);
    break;
  }
  case TAG_OpLt: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str6);
    break;
  }
  case TAG_OpLe: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str7);
    break;
  }
  case TAG_OpAnd: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str8);
    break;
  }
  case TAG_OpOr: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str9);
    break;
  }
  case TAG_OpXor: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str10);
    break;
  }
  case TAG_OpShl: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str11);
    break;
  }
  case TAG_OpShr: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str12);
    break;
  }
  case TAG_OpShow: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str13);
    break;
  }
  case TAG_OpFromInt: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str14);
    break;
  }
  case TAG_OpToInt: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str15);
    break;
  }
  case TAG_OpSqrt: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str16);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str17);
    break;
  }
  case TAG_OpToFloat: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str18);
    break;
  }
  case TAG_OpFloor: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str19);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str20), v_t_243)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam1(V self, V *args) {
  V v_box_24a_244 = args[0];
  V v_box_24b_245 = args[1];
  float v_a_244 = heff_unbox_f32(v_box_24a_244);
  float v_b_245 = heff_unbox_f32(v_box_24b_245);
  V v_t_247;
  if ((v_a_244 == v_b_245)) {
    v_t_247 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str21);
  } else {
    v_t_247 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str22);
  }
  V v_t_248 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_248});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam2(V self, V *args) {
  V v_box_24a_249 = args[0];
  V v_box_24b_2410 = args[1];
  float v_a_249 = heff_unbox_f32(v_box_24a_249);
  float v_b_2410 = heff_unbox_f32(v_box_24b_2410);
  V v_t_2412;
  if ((v_a_249 < v_b_2410)) {
    v_t_2412 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str23);
  } else {
    v_t_2412 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str24);
  }
  V v_t_2413 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2413});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam3(V self, V *args) {
  V v_box_24a_2414 = args[0];
  V v_box_24b_2415 = args[1];
  float v_a_2414 = heff_unbox_f32(v_box_24a_2414);
  float v_b_2415 = heff_unbox_f32(v_box_24b_2415);
  V v_t_2417;
  if ((v_a_2414 <= v_b_2415)) {
    v_t_2417 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str25);
  } else {
    v_t_2417 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str26);
  }
  V v_t_2418 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2418});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam4(V self, V *args) {
  V v_d_2419 = args[0];
  V v_a_2420 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2419);
  heff_drop(v_a_2420);
  V v_t_2421;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str27);
    break;
  }
  case TAG_OpSub: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str28);
    break;
  }
  case TAG_OpMul: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str29);
    break;
  }
  case TAG_OpDiv: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str30);
    break;
  }
  case TAG_OpRem: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str31);
    break;
  }
  case TAG_OpEq: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str32);
    break;
  }
  case TAG_OpLt: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str33);
    break;
  }
  case TAG_OpLe: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str34);
    break;
  }
  case TAG_OpAnd: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str35);
    break;
  }
  case TAG_OpOr: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str36);
    break;
  }
  case TAG_OpXor: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str37);
    break;
  }
  case TAG_OpShl: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str38);
    break;
  }
  case TAG_OpShr: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str39);
    break;
  }
  case TAG_OpShow: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str40);
    break;
  }
  case TAG_OpFromInt: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str41);
    break;
  }
  case TAG_OpToInt: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str42);
    break;
  }
  case TAG_OpSqrt: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str43);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str44);
    break;
  }
  case TAG_OpToFloat: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str45);
    break;
  }
  case TAG_OpFloor: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str46);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str47), v_t_2421)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam5(V self, V *args) {
  V v_d_2422 = args[0];
  V v_a_2423 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2422);
  heff_drop(v_a_2423);
  V v_t_2424;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str48);
    break;
  }
  case TAG_OpSub: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str49);
    break;
  }
  case TAG_OpMul: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str50);
    break;
  }
  case TAG_OpDiv: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str51);
    break;
  }
  case TAG_OpRem: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str52);
    break;
  }
  case TAG_OpEq: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str53);
    break;
  }
  case TAG_OpLt: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str54);
    break;
  }
  case TAG_OpLe: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str55);
    break;
  }
  case TAG_OpAnd: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str56);
    break;
  }
  case TAG_OpOr: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str57);
    break;
  }
  case TAG_OpXor: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str58);
    break;
  }
  case TAG_OpShl: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str59);
    break;
  }
  case TAG_OpShr: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str60);
    break;
  }
  case TAG_OpShow: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str61);
    break;
  }
  case TAG_OpFromInt: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str62);
    break;
  }
  case TAG_OpToInt: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str63);
    break;
  }
  case TAG_OpSqrt: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str64);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str65);
    break;
  }
  case TAG_OpToFloat: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str66);
    break;
  }
  case TAG_OpFloor: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str67);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str68), v_t_2424)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam6(V self, V *args) {
  V v_d_2425 = args[0];
  V v_a_2426 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2425);
  heff_drop(v_a_2426);
  V v_t_2427;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str69);
    break;
  }
  case TAG_OpSub: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str70);
    break;
  }
  case TAG_OpMul: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str71);
    break;
  }
  case TAG_OpDiv: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str72);
    break;
  }
  case TAG_OpRem: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str73);
    break;
  }
  case TAG_OpEq: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str74);
    break;
  }
  case TAG_OpLt: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str75);
    break;
  }
  case TAG_OpLe: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str76);
    break;
  }
  case TAG_OpAnd: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str77);
    break;
  }
  case TAG_OpOr: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str78);
    break;
  }
  case TAG_OpXor: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str79);
    break;
  }
  case TAG_OpShl: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str80);
    break;
  }
  case TAG_OpShr: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str81);
    break;
  }
  case TAG_OpShow: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str82);
    break;
  }
  case TAG_OpFromInt: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str83);
    break;
  }
  case TAG_OpToInt: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str84);
    break;
  }
  case TAG_OpSqrt: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str85);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str86);
    break;
  }
  case TAG_OpToFloat: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str87);
    break;
  }
  case TAG_OpFloor: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str88);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str89), v_t_2427)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam7(V self, V *args) {
  V v_d_2428 = args[0];
  V v_a_2429 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2428);
  heff_drop(v_a_2429);
  V v_t_2430;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str90);
    break;
  }
  case TAG_OpSub: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str91);
    break;
  }
  case TAG_OpMul: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str92);
    break;
  }
  case TAG_OpDiv: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str93);
    break;
  }
  case TAG_OpRem: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str94);
    break;
  }
  case TAG_OpEq: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str95);
    break;
  }
  case TAG_OpLt: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str96);
    break;
  }
  case TAG_OpLe: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str97);
    break;
  }
  case TAG_OpAnd: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str98);
    break;
  }
  case TAG_OpOr: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str99);
    break;
  }
  case TAG_OpXor: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str100);
    break;
  }
  case TAG_OpShl: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str101);
    break;
  }
  case TAG_OpShr: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str102);
    break;
  }
  case TAG_OpShow: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str103);
    break;
  }
  case TAG_OpFromInt: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str104);
    break;
  }
  case TAG_OpToInt: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str105);
    break;
  }
  case TAG_OpSqrt: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str106);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str107);
    break;
  }
  case TAG_OpToFloat: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str108);
    break;
  }
  case TAG_OpFloor: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str109);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str110), v_t_2430)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam8(V self, V *args) {
  V v_d_2431 = args[0];
  V v_a_2432 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2431);
  heff_drop(v_a_2432);
  V v_t_2433;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str111);
    break;
  }
  case TAG_OpSub: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str112);
    break;
  }
  case TAG_OpMul: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str113);
    break;
  }
  case TAG_OpDiv: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str114);
    break;
  }
  case TAG_OpRem: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str115);
    break;
  }
  case TAG_OpEq: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str116);
    break;
  }
  case TAG_OpLt: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str117);
    break;
  }
  case TAG_OpLe: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str118);
    break;
  }
  case TAG_OpAnd: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str119);
    break;
  }
  case TAG_OpOr: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str120);
    break;
  }
  case TAG_OpXor: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str121);
    break;
  }
  case TAG_OpShl: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str122);
    break;
  }
  case TAG_OpShr: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str123);
    break;
  }
  case TAG_OpShow: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str124);
    break;
  }
  case TAG_OpFromInt: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str125);
    break;
  }
  case TAG_OpToInt: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str126);
    break;
  }
  case TAG_OpSqrt: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str127);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str128);
    break;
  }
  case TAG_OpToFloat: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str129);
    break;
  }
  case TAG_OpFloor: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str130);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str131), v_t_2433)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam9(V self, V *args) {
  V v_d_2434 = args[0];
  V v_a_2435 = args[1];
  V v_x1_2436 = heff_tr(heff_call(v_a_2435, 1, (V[]){v_d_2434}));
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_Ok: {
    V v_v_2437 = heff_field(v_x1_2436, 0);
    V v_ru_24x1_2436_24Ok = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
    switch (heff_tag_of(v_v_2437)) {
    case TAG_VFun: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2437, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat32: {
      V v_a_2444 = heff_field(v_v_2437, 0);
      V v_ru_24v_2437_24VFloat32 = heff_take_reuse_n(v_v_2437, 1ULL, 1);
      V v_t_2445 = heff_tag_at_n(v_ru_24v_2437_24VFloat32, TAG_VStr, 1, (V[]){heff_float32Show(v_a_2444)});
      return heff_tag_at_n(v_ru_24x1_2436_24Ok, TAG_Ok, 1, (V[]){v_t_2445});
    }
    case TAG_VStr: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2437, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    default: return heff_nomatch(v_v_2437);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2452 = heff_field(v_x1_2436, 0);
    V v_ru_24x1_2436_24Bug = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2436_24Bug, TAG_Bug, 1, (V[]){v_what_2452});
  }
  default: return heff_nomatch(v_x1_2436);
  }
}
V g_heff_2ecompile_2einterp_2efloat32V_lam10(V self, V *args) {
  V v_d_2453 = args[0];
  V v_a_2454 = args[1];
  V v_x1_2455 = heff_tr(heff_call(v_a_2454, 1, (V[]){v_d_2453}));
  switch (heff_tag_of(v_x1_2455)) {
  case TAG_Ok: {
    V v_v_2456 = heff_field(v_x1_2455, 0);
    V v_ru_24x1_2455_24Ok = heff_take_reuse_n(v_x1_2455, 1ULL, 1);
    switch (heff_tag_of(v_v_2456)) {
    case TAG_VFun: {
      heff_take_n(v_v_2456, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2456, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2456, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2461 = heff_field(v_v_2456, 0);
      V v_ru_24v_2456_24VInt = heff_take_reuse_n(v_v_2456, 1ULL, 1);
      V v_t_2462 = heff_tag_at_n(v_ru_24v_2456_24VInt, TAG_VFloat32, 1, (V[]){heff_box_f32(heff_from_int_f32(v_a_2461))});
      return heff_tag_at_n(v_ru_24x1_2455_24Ok, TAG_Ok, 1, (V[]){v_t_2462});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2456, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2456, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2456, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2456, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2456, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2456, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2456, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2456);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2471 = heff_field(v_x1_2455, 0);
    V v_ru_24x1_2455_24Bug = heff_take_reuse_n(v_x1_2455, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2455_24Bug, TAG_Bug, 1, (V[]){v_what_2471});
  }
  default: return heff_nomatch(v_x1_2455);
  }
}
V g_heff_2ecompile_2einterp_2efloat32V_lam11(V self, V *args) {
  V v_d_2472 = args[0];
  V v_a_2473 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2472);
  heff_drop(v_a_2473);
  V v_t_2474;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str132);
    break;
  }
  case TAG_OpSub: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str133);
    break;
  }
  case TAG_OpMul: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str134);
    break;
  }
  case TAG_OpDiv: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str135);
    break;
  }
  case TAG_OpRem: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str136);
    break;
  }
  case TAG_OpEq: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str137);
    break;
  }
  case TAG_OpLt: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str138);
    break;
  }
  case TAG_OpLe: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str139);
    break;
  }
  case TAG_OpAnd: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str140);
    break;
  }
  case TAG_OpOr: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str141);
    break;
  }
  case TAG_OpXor: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str142);
    break;
  }
  case TAG_OpShl: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str143);
    break;
  }
  case TAG_OpShr: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str144);
    break;
  }
  case TAG_OpShow: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str145);
    break;
  }
  case TAG_OpFromInt: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str146);
    break;
  }
  case TAG_OpToInt: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str147);
    break;
  }
  case TAG_OpSqrt: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str148);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str149);
    break;
  }
  case TAG_OpToFloat: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str150);
    break;
  }
  case TAG_OpFloor: {
    v_t_2474 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str151);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str152), v_t_2474)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam12(V self, V *args) {
  V v_d_2475 = args[0];
  V v_a_2476 = args[1];
  V v_x1_2477 = heff_tr(heff_call(v_a_2476, 1, (V[]){v_d_2475}));
  switch (heff_tag_of(v_x1_2477)) {
  case TAG_Ok: {
    V v_v_2478 = heff_field(v_x1_2477, 0);
    V v_ru_24x1_2477_24Ok = heff_take_reuse_n(v_x1_2477, 1ULL, 1);
    switch (heff_tag_of(v_v_2478)) {
    case TAG_VFun: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2478, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat32: {
      V v_a_2485 = heff_field(v_v_2478, 0);
      V v_ru_24v_2478_24VFloat32 = heff_take_reuse_n(v_v_2478, 1ULL, 1);
      V v_t_2486 = heff_tag_at_n(v_ru_24v_2478_24VFloat32, TAG_VFloat32, 1, (V[]){heff_box_f32(sqrtf(heff_unbox_f32(v_a_2485)))});
      return heff_tag_at_n(v_ru_24x1_2477_24Ok, TAG_Ok, 1, (V[]){v_t_2486});
    }
    case TAG_VStr: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2478, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    default: return heff_nomatch(v_v_2478);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2493 = heff_field(v_x1_2477, 0);
    V v_ru_24x1_2477_24Bug = heff_take_reuse_n(v_x1_2477, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2477_24Bug, TAG_Bug, 1, (V[]){v_what_2493});
  }
  default: return heff_nomatch(v_x1_2477);
  }
}
V g_heff_2ecompile_2einterp_2efloat32V_lam13(V self, V *args) {
  V v_d_2494 = args[0];
  V v_a_2495 = args[1];
  V v_x1_2496 = heff_tr(heff_call(v_a_2495, 1, (V[]){v_d_2494}));
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_Ok: {
    V v_v_2497 = heff_field(v_x1_2496, 0);
    V v_ru_24x1_2496_24Ok = heff_take_reuse_n(v_x1_2496, 1ULL, 1);
    switch (heff_tag_of(v_v_2497)) {
    case TAG_VFun: {
      heff_take_n(v_v_2497, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2496_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2497, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2496_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2497, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2496_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_2497, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2496_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24103 = heff_tflat_f64(v_v_2497, 0);
      V v_ru_24v_2497_24VFloat = heff_take_reuse_na(v_v_2497, 0ULL, 1);
      V v_t_24104 = heff_tag_at_n(v_ru_24v_2497_24VFloat, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)v_a_24103))});
      return heff_tag_at_n(v_ru_24x1_2496_24Ok, TAG_Ok, 1, (V[]){v_t_24104});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2497, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2496_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2497, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2496_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2497, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2496_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2497, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2496_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2497, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2496_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2497, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2496_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2496_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_2497);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24112 = heff_field(v_x1_2496, 0);
    V v_ru_24x1_2496_24Bug = heff_take_reuse_n(v_x1_2496, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2496_24Bug, TAG_Bug, 1, (V[]){v_what_24112});
  }
  default: return heff_nomatch(v_x1_2496);
  }
}
V g_heff_2ecompile_2einterp_2efloat32V_lam14(V self, V *args) {
  V v_d_24113 = args[0];
  V v_a_24114 = args[1];
  V v_x1_24115 = heff_tr(heff_call(v_a_24114, 1, (V[]){v_d_24113}));
  switch (heff_tag_of(v_x1_24115)) {
  case TAG_Ok: {
    V v_v_24116 = heff_field(v_x1_24115, 0);
    V v_ru_24x1_24115_24Ok = heff_take_reuse_n(v_x1_24115, 1ULL, 1);
    switch (heff_tag_of(v_v_24116)) {
    case TAG_VFun: {
      heff_take_n(v_v_24116, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24115_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24116, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24115_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24116, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24115_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24116, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24115_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24116, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24115_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat32: {
      V v_a_24123 = heff_field(v_v_24116, 0);
      V v_ru_24v_24116_24VFloat32 = heff_take_reuse_n(v_v_24116, 1ULL, 1);
      V v_t_24124 = heff_tag_at_nf(v_ru_24v_24116_24VFloat32, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(((double)heff_unbox_f32(v_a_24123)))});
      return heff_tag_at_n(v_ru_24x1_24115_24Ok, TAG_Ok, 1, (V[]){v_t_24124});
    }
    case TAG_VStr: {
      heff_take_n(v_v_24116, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24115_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24116, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24115_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24116, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24115_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24116, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24115_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24116, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24115_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24115_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    default: return heff_nomatch(v_v_24116);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24131 = heff_field(v_x1_24115, 0);
    V v_ru_24x1_24115_24Bug = heff_take_reuse_n(v_x1_24115, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24115_24Bug, TAG_Bug, 1, (V[]){v_what_24131});
  }
  default: return heff_nomatch(v_x1_24115);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_st;
static V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_st)) return g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_val, &g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_st, g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VInt, 1, (V[]){heff_intMul(v_a_2412, v_b_2417)});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam1, 2, 1, (V[]){v_a_241})})});
}
Clo g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(V v_lit_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_247 = heff_bool((heff_intEq_c(heff_dup(v_a_241), MK_INT(0LL)) ? (heff_intEq_c(heff_dup(v_b_242), MK_INT(0LL)) || heff_intEq_c(heff_dup(v_b_242), MK_INT(-1LL))) : (heff_intEq_c(heff_dup(v_a_241), MK_INT(-1LL)) && (heff_intEq_c(heff_dup(v_b_242), MK_INT(0LL)) || heff_intEq_c(heff_dup(v_b_242), MK_INT(-1LL))))));
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_248 = heff_intAdd(heff_intMod(v_a_241, MK_INT(2LL)), heff_intMod(v_b_242, MK_INT(2LL)));
    return heff_intSub(MK_INT(0LL), heff_intMod(v_t_248, v_lit_240));
  } else {
    heff_drop(v_t_247);
    V v_t_249 = heff_intAdd(heff_intMod(heff_dup(v_a_241), MK_INT(2LL)), heff_intMod(heff_dup(v_b_242), MK_INT(2LL)));
    V v_t_2410 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(heff_dup(v_lit_240), heff_intDiv(v_a_241, MK_INT(2LL)), heff_intDiv(v_b_242, MK_INT(2LL))));
    return heff_intAdd(heff_intMod(v_t_249, v_lit_240), heff_intMul(MK_INT(2LL), v_t_2410));
  }
}
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str0, 4, "#fun");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str1, 6, "#value");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str2, 6, "#value");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str4, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str5, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str6, 1, "'");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str7, 1, "'");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str8, 6, "#value");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str11, 2, "b[");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str12, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str15, 2, "b[");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str16, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str17, 7, "#erased");
Clo g_heff_2ecompile_2einterp_2escalarV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2escalarV_entry, 1, 0};

V g_heff_2ecompile_2einterp_2escalarV(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    return ((V)&g_heff_2ecompile_2einterp_2escalarV_str0);
  }
  case TAG_VCons: {
    return ((V)&g_heff_2ecompile_2einterp_2escalarV_str1);
  }
  case TAG_VTag: {
    return ((V)&g_heff_2ecompile_2einterp_2escalarV_str2);
  }
  case TAG_VInt: {
    V v_i_245 = heff_field(v_x1_240, 0);
    return heff_intShow(heff_dup(v_i_245));
  }
  case TAG_VFloat: {
    V v_x_246 = heff_tget_v(v_x1_240, 0);
    return heff_floatShow(v_x_246);
  }
  case TAG_VFloat32: {
    V v_x_247 = heff_field(v_x1_240, 0);
    return heff_float32Show(heff_dup(v_x_247));
  }
  case TAG_VStr: {
    V v_s_248 = heff_field(v_x1_240, 0);
    V v_t_249 = (g_heff_2eutil_2erune_2equoteGo(heff_dup(v_s_248), MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2escalarV_str3)));
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2escalarV_str4), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2einterp_2escalarV_str5)));
  }
  case TAG_VRune: {
    V v_c_2410 = heff_field(v_x1_240, 0);
    V v_t_2411 = (g_heff_2eutil_2erune_2equoted(heff_dup(v_c_2410)));
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2escalarV_str6), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2einterp_2escalarV_str7)));
  }
  case TAG_VArr: {
    return ((V)&g_heff_2ecompile_2einterp_2escalarV_str8);
  }
  case TAG_VBytes: {
    V v_s_2413 = heff_field(v_x1_240, 0);
    V v_t_2414 = (g_heff_2eutil_2erune_2equoteBytesGo(heff_dup(v_s_2413), MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2escalarV_str9), ((V)&g_heff_2ecompile_2einterp_2escalarV_str10)));
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2escalarV_str11), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2einterp_2escalarV_str12)));
  }
  case TAG_VBits: {
    V v_n_2415 = heff_field(v_x1_240, 0);
    V v_s_2416 = heff_field(v_x1_240, 1);
    V v_t_2417 = heff_strSlice(heff_dup(v_s_2416), MK_INT(0LL), heff_intDiv(heff_dup(v_n_2415), MK_INT(8LL)));
    V v_t_2418 = (g_heff_2eutil_2erune_2equoteBytesGo(v_t_2417, MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2escalarV_str13), ((V)&g_heff_2ecompile_2einterp_2escalarV_str14)));
    V v_t_2419 = (g_heff_2eutil_2erune_2ebitsTail(v_t_2418, heff_dup(v_s_2416), heff_dup(v_n_2415), heff_intMod(heff_dup(v_n_2415), MK_INT(8LL))));
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2escalarV_str15), heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2einterp_2escalarV_str16)));
  }
  case TAG_VErased: {
    return ((V)&g_heff_2ecompile_2einterp_2escalarV_str17);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2escalarV(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eevalGlobalsGo_entry, 4, 0};

V g_heff_2ecompile_2einterp_2eevalGlobalsGo(V v_wanted_240, V v_ge_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_wanted_240);
    heff_drop(v_ge_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x31_244, 0);
      V v_entry_247 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      V v_r_248 = heff_tr(g_heff_2ecompile_2einterp_2efixThunk(heff_dup(v_ge_241), heff_get_n(v_entry_247, 0, 4), MK_INT(0LL)));
      V v_t_249 = (g_map_2einsert_24s1705770630x2073956475(heff_dup(v_r_248), heff_dup(v_x_246), v_ge_241));
      V v_t_2410 = heff_tr(heff_call(heff_dup(v_wanted_240), 1, (V[]){heff_dup(v_x_246)}));
      V v_t_2414;
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        V v_t_2413;
        switch (heff_tag_of(v_r_248)) {
        case TAG_Ok: {
          V v_v_2411 = heff_field(v_r_248, 0);
          V v_ru_24r_248_24Ok = heff_take_reuse_n(v_r_248, 1ULL, 1);
          v_t_2413 = heff_tag_at_n(v_ru_24r_248_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2411});
          break;
        }
        case TAG_Abn: {
          v_t_2413 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_2413 = NTAG(TAG_RDiverged);
          break;
        }
        case TAG_Bug: {
          V v_what_2412 = heff_field(v_r_248, 0);
          V v_ru_24r_248_24Bug = heff_take_reuse_n(v_r_248, 1ULL, 1);
          v_t_2413 = heff_tag_at_n(v_ru_24r_248_24Bug, TAG_RBug, 1, (V[]){v_what_2412});
          break;
        }
        default: heff_nomatch(v_r_248);
        }
        v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_t_2413}), v_acc_243});
      } else {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_x_246);
        heff_drop(v_r_248);
        heff_drop(v_t_2410);
        v_t_2414 = v_acc_243;
      }
      V t_0 = v_wanted_240;
      V t_1 = v_t_249;
      V t_2 = v_rest_245;
      V t_3 = v_t_2414;
      v_wanted_240 = t_0;
      v_ge_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eevalGlobalsGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2einterp_2eglobalEnvGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eglobalEnvGo_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eglobalEnvGo(V v_ge_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ge_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_entry_245 = heff_field(v_x21_242, 1);
      V v_r_246 = heff_tr(g_heff_2ecompile_2einterp_2efixThunk(heff_dup(v_ge_240), heff_dup(heff_rfield(v_entry_245, 0)), MK_INT(0LL)));
      V v_t_247 = (g_map_2einsert_24s1705770630x2073956475(v_r_246, heff_dup(v_x_244), v_ge_240));
      V t_0 = v_t_247;
      V t_1 = v_rest_243;
      v_ge_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2eglobalEnvGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2einterp_2eglobalEnvGo(a[0], a1); heff_drop(a1); return r;
}