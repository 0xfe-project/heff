// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_MkTF 48839
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_Text 56194
#define LBL_blank 295177582
#define LBL_fix 310927
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_lead 9813027
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_trail 311979552
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadLaid_clo;
V g_heff_2esyntax_2efmt_2elayout_2enamesDoc(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enamesDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enamesDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2enearGo(V, V);
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2esig(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2esig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esig_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etfDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etfDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_clo;
V g_list_2eany_24s2118781542x1794344985(V);
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a);
extern Clo g_list_2eany_24s2118781542x1794344985_clo;
V g_list_2eany_24s577543654x765608923(V);
V g_list_2eany_24s577543654x765608923_entry(V self, V *a);
extern Clo g_list_2eany_24s577543654x765608923_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24f1805635826x1386625471(V, V, V);
V g_list_2efoldl_24f1805635826x1386625471_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1805635826x1386625471_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s2139359291x1524787922(V);
V g_list_2emap_24s2139359291x1524787922_entry(V self, V *a);
extern Clo g_list_2emap_24s2139359291x1524787922_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str6, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2epP_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam3(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epP_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2epP(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_args_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_c_242)));
    V v_t_247 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam0, 1, 1, (V[]){v_env_240}), v_args_243));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_244, v_t_247);
  }
  case TAG_PAtom: {
    V v_t_248 = heff_field(v_x2_241, 0);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_t_248));
  }
  case TAG_PParen: {
    V v_o_249 = heff_field(v_x2_241, 0);
    V v_p_2410 = heff_field(v_x2_241, 1);
    V v_c_2411 = heff_field(v_x2_241, 2);
    V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_249)));
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_p_2410));
    V v_t_2414 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2411)));
    V v_t_2415 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2414));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2412, v_t_2415);
  }
  case TAG_PList: {
    V v_o_2416 = heff_field(v_x2_241, 0);
    V v_ps_2417 = heff_field(v_x2_241, 1);
    V v_commas_2418 = heff_field(v_x2_241, 2);
    V v_c_2419 = heff_field(v_x2_241, 3);
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2416)));
    V v_t_2422 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(heff_dup(v_env_240), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam1, 1, 1, (V[]){heff_dup(v_env_240)}), v_ps_2417, heff_dup(v_commas_2418), NTAG(TAG_True)));
    V v_t_2423 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2419)));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2423));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2420, v_t_2424);
  }
  case TAG_POp: {
    V v_l_2425 = heff_field(v_x2_241, 0);
    V v_op_2426 = heff_field(v_x2_241, 1);
    V v_r_2427 = heff_field(v_x2_241, 2);
    V v_a_2428 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_l_2425));
    V v_a_2429 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_op_2426)));
    V v_b_2430 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_r_2427));
    V v_t_2431 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str1)}), v_b_2430));
    V v_t_2432 = (g_std_2edoc_2e_3c_3e(v_a_2429, v_t_2431));
    V v_t_2433 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str2)}), v_t_2432));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2428, v_t_2433);
  }
  case TAG_PRec: {
    V v_o_2434 = heff_field(v_x2_241, 0);
    V v_fs_2435 = heff_field(v_x2_241, 1);
    V v_commas_2436 = heff_field(v_x2_241, 2);
    V v_c_2437 = heff_field(v_x2_241, 3);
    V v_a_2438 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2434)));
    V v_a_2440 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(heff_dup(v_env_240), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam2, 1, 1, (V[]){heff_dup(v_env_240)}), v_fs_2435, heff_dup(v_commas_2436), NTAG(TAG_True)));
    V v_b_2441 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2437)));
    V v_t_2442 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str3)}), v_b_2441));
    V v_t_2443 = (g_std_2edoc_2e_3c_3e(v_a_2440, v_t_2442));
    V v_t_2444 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str4)}), v_t_2443));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2438, v_t_2444);
  }
  case TAG_PField: {
    V v_x_2445 = heff_field(v_x2_241, 0);
    V v_eq_2446 = heff_field(v_x2_241, 1);
    V v_p_2447 = heff_field(v_x2_241, 2);
    V v_a_2448 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_2445)));
    V v_a_2449 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2446)));
    V v_b_2450 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_p_2447));
    V v_t_2451 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str5)}), v_b_2450));
    V v_t_2452 = (g_std_2edoc_2e_3c_3e(v_a_2449, v_t_2451));
    V v_t_2453 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str6)}), v_t_2452));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2448, v_t_2453);
  }
  case TAG_PAs: {
    V v_x_2454 = heff_field(v_x2_241, 0);
    V v_at_2455 = heff_field(v_x2_241, 1);
    V v_p_2456 = heff_field(v_x2_241, 2);
    V v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_2454)));
    V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_at_2455)));
    V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_p_2456));
    V v_t_2460 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2459));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2457, v_t_2460);
  }
  case TAG_PSeg: {
    V v_p_2461 = heff_field(v_x2_241, 0);
    V v_cc_2462 = heff_field(v_x2_241, 1);
    V v_spec_2463 = heff_field(v_x2_241, 2);
    V v_t_2464 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_p_2461));
    V v_t_2465 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_cc_2462)));
    V v_t_2467 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam3, 1, 1, (V[]){v_env_240}), v_spec_2463));
    V v_t_2468 = (g_std_2edoc_2e_3c_3e(v_t_2465, v_t_2467));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2464, v_t_2468);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2epP(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V a_0 = v_env_240; V a_1 = v_p_245; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_245); r_; });
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str0)}), v_t_246));
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam1(V self, V *args) {
  V v_p2_2421 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_env_240; V a_1 = v_p2_2421; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p2_2421); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam2(V self, V *args) {
  V v_p2_2439 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_env_240; V a_1 = v_p2_2439; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p2_2439); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam3(V self, V *args) {
  V v_t_2466 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2466));
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2enamesDoc_str0, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2enamesDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2enamesDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2enamesDoc_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2enamesDoc(V v_env_240, V v_x2_241, V v_commas_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_n_243 = heff_field(v_x2_241, 0);
    V v_ns_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_list_2efoldl_24f1805635826x1386625471(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_dup(v_env_240), v_n_243));
    V v_t_2411 = (g_list_2efoldl_24f1443542135x1147816397(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2enamesDoc_lam0, 2, 1, (V[]){v_env_240}), v_commas_242, v_ns_244));
    return (g_std_2edoc_2e_3c_3e(v_t_245, v_t_2411));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2enamesDoc_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2enamesDoc(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2enamesDoc_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_m_247 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_246));
  V v_b_249 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_env_240; V a_2 = v_m_247; V r_ = (g_list_2efoldl_24f1805635826x1386625471(a_0, a_1, a_2)); heff_drop(v_m_247); r_; });
  V v_t_2410 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2enamesDoc_str0)}), v_b_249));
  return (g_std_2edoc_2e_3c_3e(v_a_248, v_t_2410));
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etfDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etfDoc_str1, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2etfDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etfDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkTF: {
    V v_xs_242 = heff_field(v_x2_241, 0);
    V v_commas_243 = heff_field(v_x2_241, 1);
    V v_cc_244 = heff_field(v_x2_241, 2);
    V v_ty_245 = heff_field(v_x2_241, 3);
    V v_d_246 = heff_field(v_x2_241, 4);
    V v_t_247 = (g_list_2emap_24s2139359291x1524787922(heff_dup(v_xs_242)));
    V v_a_248 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_t_247; V a_2 = v_commas_243; V r_ = (g_heff_2esyntax_2efmt_2elayout_2enamesDoc(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
    V v_b_249 = (g_heff_2esyntax_2efmt_2elayout_2esig(heff_dup(v_env_240), heff_dup(v_cc_244), heff_dup(v_ty_245)));
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etfDoc_str0)}), v_b_249));
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_a_248, v_t_2410));
    V v_t_2418;
    switch (heff_tag_of(v_d_246)) {
    case TAG_Nothing: {
      heff_drop(v_env_240);
      v_t_2418 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_x21_2412 = heff_field(v_d_246, 0);
      switch (heff_tag_of(v_x21_2412)) {
      case TAG_MkPair: {
        V v_eq_2413 = heff_field(v_x21_2412, 0);
        V v_d_2414 = heff_field(v_x21_2412, 1);
        V v_t_2415 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2413)));
        V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, heff_dup(v_d_2414)}));
        V v_t_2417 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2416));
        v_t_2418 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etfDoc_str1)}), v_t_2417));
        break;
      }
      default: heff_nomatch(v_x21_2412);
      }
      break;
    }
    default: heff_nomatch(v_d_246);
    }
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2418);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2etfDoc(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eafterDef_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eafterDef_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_es_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_e_242)) {
    case TAG_DImport: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DFixity: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DSig: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DInstance: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DEqn: {
      V v_n_2415 = heff_dup(heff_field(v_e_242, 0));
      V v_x2_2420 = (g_list_2emap_24s759871588x920431471(v_n_2415));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eafterDef_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eafterDef_str1); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      if (heff_strEq_c_lent(v_t_2423, v_x_240, 1)) {
        heff_drop_tag(v_e_242, 5);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_es_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
      }
    }
    case TAG_DData: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DType: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DTheory: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DMutual: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DPrimitive: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DTest: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DWatch: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    default: return heff_nomatch(v_e_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eafterDef(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eskipped_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eskipped(V v_env_240, V v_above_241, V v_d_242) {
top: ;
  V v_t_2412;
  if ((heff_dup(v_above_241) == NTAG(TAG_True))) {
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_blank_244 = heff_take_field(v_t_243, 8);
    V v_ix_245 = heff_get_n(v_t_243, 7, 9);
    if (!(heff_dup(v_blank_244) == NTAG(TAG_True))) {
      heff_drop(v_blank_244);
      HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), v_ix_245));
      V v_t_2410;
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_x_249 = v_field_248;
          v_t_2410 = v_x_249;
        } else {
          heff_drop(v_field_248);
          v_t_2410 = NTAG(TAG_Nil);
        }
      }
      V v_x1_2411 = ({ V a_0 = v_t_2410; V r_ = (g_list_2eany_24s2118781542x1794344985(a_0)); heff_drop(v_t_2410); r_; });
      v_t_2412 = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
      heff_drop(v_x1_2411);
    } else {
      heff_drop(v_blank_244);
      heff_drop(v_ix_245);
      v_t_2412 = NTAG(TAG_False);
    }
  } else {
    v_t_2412 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_t_2412);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2412);
    V v_t_2413 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_blank_2414 = heff_take_field(v_t_2413, 8);
    V v_ix_2415 = heff_get_n(v_t_2413, 7, 9);
    if (!(heff_dup(v_blank_2414) == NTAG(TAG_True))) {
      heff_drop(v_blank_2414);
      HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = v_ix_2415; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2421;
      {
        V v_field_2418 = v_t_2416.f[1];
        int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
        V v_t_2420;
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          V v_x_2419 = v_field_2418;
          v_t_2420 = v_x_2419;
        } else {
          heff_drop(v_field_2418);
          v_t_2420 = NTAG(TAG_Nil);
        }
        v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2420));
      }
      V v_t_2422 = (g_heff_2esyntax_2efmt_2elayout_2enearGo(v_t_2421, NTAG(TAG_Nil)));
      return ({ V a_0 = v_t_2422; V r_ = (g_list_2eany_24s577543654x765608923(a_0)); heff_drop(v_t_2422); r_; });
    } else {
      heff_drop_rec(v_env_240, 7);
      heff_drop(v_blank_2414);
      heff_drop(v_ix_2415);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eskipped(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eleadLaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadLaid_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadLaid(V v_env_240, V v_ix_241, V v_n_242) {
top: ;
  if (heff_intEq_c_lent(v_n_242, MK_INT(0LL), 2)) {
    heff_drop(v_ix_241);
    heff_drop(v_n_242);
    return v_env_240;
  } else {
    HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(v_ix_241)));
    V v_t_247;
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_245;
        v_t_247 = v_x_246;
      } else {
        heff_drop(v_field_245);
        v_t_247 = NTAG(TAG_Nil);
      }
    }
    V v_t_248 = ({ V a_0 = v_n_242; V a_1 = v_t_247; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_t_249 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_env_240, 1), v_ix_241, v_t_248));
    return ({ V rv_1 = v_t_249; V rr_ = heff_rec_reuse_nf(v_env_240, 125ULL, 7, shape_src__lead__inline__trail__noLead__noTrail__fix, 16371u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eleadLaid(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_ls_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
    V v_t_246 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_245), MK_INT(-1LL)));
    V v_t_247 = heff_strSlice(heff_dup(v_l_242), v_t_244, heff_intAdd(v_t_246, MK_INT(1LL)));
    if (heff_strEq_c(v_t_247, heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get()))) {
      heff_drop(v_l_242);
      V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_str0), heff_hole()});
      V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_ls_243;
      V t_1 = v_cell_248;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      V v_t_2410 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
      V v_t_2412 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_2411), MK_INT(-1LL)));
      V v_t_2413 = heff_strSlice(heff_dup(v_l_242), v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2413, ((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_str1))) {
        heff_drop(v_l_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_ls_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      } else {
        V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_242, heff_hole()});
        V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
        heff_drop(v_u_2415);
        V t_0 = v_ls_243;
        V t_1 = v_cell_2414;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(a[0], a[1]);
}