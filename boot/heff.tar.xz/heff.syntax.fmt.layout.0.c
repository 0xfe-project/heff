// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetCond 24397
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_blank 295177582
#define LBL_end 310101
#define LBL_fix 310927
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_lead 9813027
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_pE 10300
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_trail 311979552
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_clo;
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo(V);
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eendsInDo_clo;
V g_heff_2esyntax_2efmt_2elayout_2einlineDoc(V);
V g_heff_2esyntax_2efmt_2elayout_2einlineDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2einlineDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadLaid_clo;
V g_heff_2esyntax_2efmt_2elayout_2enearGo(V, V);
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2esig(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2esig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esig_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etfDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etfDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_clo;
V g_list_2eany_24s2118781542x1794344985(V);
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a);
extern Clo g_list_2eany_24s2118781542x1794344985_clo;
V g_list_2eany_24s577543654x765608923(V);
V g_list_2eany_24s577543654x765608923_entry(V self, V *a);
extern Clo g_list_2eany_24s577543654x765608923_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24f1805635826x1386625471(V, V, V);
V g_list_2efoldl_24f1805635826x1386625471_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1805635826x1386625471_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2eflatten(V);
V g_std_2edoc_2eflatten_entry(V self, V *a);
extern Clo g_std_2edoc_2eflatten_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2einlineDoc_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2einlineDoc_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2einlineDoc_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2einlineDoc_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2einlineDoc_str4, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2einlineDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2einlineDoc_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2einlineDoc(V v_c_240) {
top: ;
  V v_x2_241 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2einlineDoc_str0); V a_1 = v_c_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2elayout_2einlineDoc_str1), v_c_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2esyntax_2efmt_2elayout_2einlineDoc_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_t_246;
  if (heff_strEq_c_lent(v_s_244, ((V)&g_heff_2esyntax_2efmt_2elayout_2einlineDoc_str3), 2)) {
    heff_drop(v_s_244);
    v_t_246 = NTAG(TAG_None);
  } else {
    v_t_246 = heff_tag_n(TAG_Text, 1, (V[]){v_s_244});
  }
  return (g_std_2edoc_2e_3c_3e(v_t_246, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2einlineDoc_str4)})));
}
V g_heff_2esyntax_2efmt_2elayout_2einlineDoc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2einlineDoc(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eendsInDo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eendsInDo_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eendsInDo(V v_args_240) {
top: ;
  V v_x1_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_240));
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_Atom: {
      heff_take_n(v_x_242, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_EParen: {
      heff_take_n(v_x_242, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_Named: {
      heff_take_n(v_x_242, 0ULL, 5);
      return NTAG(TAG_False);
    }
    case TAG_Tup: {
      heff_take_n(v_x_242, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_Seg: {
      heff_take_n(v_x_242, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_Braces: {
      heff_take_n(v_x_242, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_Update: {
      heff_take_n(v_x_242, 0ULL, 6);
      return NTAG(TAG_False);
    }
    case TAG_EUSet: {
      heff_take_n(v_x_242, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_InstB: {
      heff_take_n(v_x_242, 0ULL, 5);
      return NTAG(TAG_False);
    }
    case TAG_EFSet: {
      heff_take_n(v_x_242, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_EFDefault: {
      heff_take_n(v_x_242, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_Sum: {
      heff_take_n(v_x_242, 0ULL, 5);
      return NTAG(TAG_False);
    }
    case TAG_ECon: {
      heff_take_n(v_x_242, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_EField: {
      heff_take_n(v_x_242, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_ENeg: {
      heff_take_n(v_x_242, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_App: {
      heff_take_n(v_x_242, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_Op: {
      heff_take_n(v_x_242, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_Ops: {
      heff_take_n(v_x_242, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_OpRhs: {
      heff_take_n(v_x_242, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_Ann: {
      heff_take_n(v_x_242, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_BVar: {
      heff_take_n(v_x_242, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_BImp: {
      heff_take_n(v_x_242, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_BAnn: {
      heff_take_n(v_x_242, 0ULL, 5);
      return NTAG(TAG_False);
    }
    case TAG_Lam: {
      heff_take_n(v_x_242, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_Case: {
      heff_take_n(v_x_242, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_EAlt: {
      heff_take_n(v_x_242, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_If: {
      heff_take_n(v_x_242, 0ULL, 6);
      return NTAG(TAG_False);
    }
    case TAG_Do: {
      heff_take_n(v_x_242, 0ULL, 2);
      return NTAG(TAG_True);
    }
    case TAG_ESBind: {
      heff_take_n(v_x_242, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_take_n(v_x_242, 0ULL, 6);
      return NTAG(TAG_False);
    }
    case TAG_ELetMut: {
      heff_take_n(v_x_242, 0ULL, 6);
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      heff_take_n(v_x_242, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_EWhile: {
      heff_take_n(v_x_242, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_EFor: {
      heff_take_n(v_x_242, 0ULL, 6);
      return NTAG(TAG_False);
    }
    case TAG_EJump: {
      heff_take_n(v_x_242, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_EReturn: {
      heff_take_n(v_x_242, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_ENest: {
      heff_take_n(v_x_242, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_IfThen: {
      heff_take_n(v_x_242, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_ELetCond: {
      heff_take_n(v_x_242, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_ETry: {
      heff_take_n(v_x_242, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_ECatch: {
      heff_take_n(v_x_242, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_EWith: {
      heff_take_n(v_x_242, 0ULL, 6);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(a[0]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2esameOp_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2esameOp(V v_op_240, V v_other_241) {
top: ;
  switch (heff_tag_of(v_other_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_op_240, 9);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_other1_242 = heff_field(v_other_241, 0);
    switch (heff_tag_of(v_other1_242)) {
    case TAG_Atom: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EParen: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Named: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Tup: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Seg: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Braces: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Update: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EUSet: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_InstB: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFSet: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFDefault: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Sum: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ECon: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EField: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ENeg: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_App: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Op: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Ops: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_OpRhs: {
      V v_op2_2462 = heff_field(v_other1_242, 0);
      return heff_strEq(heff_dup(heff_rfield(v_op2_2462, 1)), heff_get_n(v_op_240, 1, 9));
    }
    case TAG_Ann: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_BVar: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_BImp: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_BAnn: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Lam: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Case: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EAlt: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_If: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Do: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ESBind: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ELetMut: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EWhile: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFor: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EJump: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EReturn: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ENest: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_IfThen: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ELetCond: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ETry: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ECatch: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EWith: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_other1_242);
    }
  }
  default: return heff_nomatch(v_other_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2esameOp(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str6, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2epP_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam3(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epP_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2epP(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_args_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_c_242)));
    V v_t_247 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam0, 1, 1, (V[]){v_env_240}), v_args_243));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_244, v_t_247);
  }
  case TAG_PAtom: {
    V v_t_248 = heff_field(v_x2_241, 0);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_t_248));
  }
  case TAG_PParen: {
    V v_o_249 = heff_field(v_x2_241, 0);
    V v_p_2410 = heff_field(v_x2_241, 1);
    V v_c_2411 = heff_field(v_x2_241, 2);
    V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_249)));
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_p_2410));
    V v_t_2414 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2411)));
    V v_t_2415 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2414));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2412, v_t_2415);
  }
  case TAG_PList: {
    V v_o_2416 = heff_field(v_x2_241, 0);
    V v_ps_2417 = heff_field(v_x2_241, 1);
    V v_commas_2418 = heff_field(v_x2_241, 2);
    V v_c_2419 = heff_field(v_x2_241, 3);
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2416)));
    V v_t_2422 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(heff_dup(v_env_240), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam1, 1, 1, (V[]){heff_dup(v_env_240)}), v_ps_2417, heff_dup(v_commas_2418), NTAG(TAG_True)));
    V v_t_2423 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2419)));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2423));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2420, v_t_2424);
  }
  case TAG_POp: {
    V v_l_2425 = heff_field(v_x2_241, 0);
    V v_op_2426 = heff_field(v_x2_241, 1);
    V v_r_2427 = heff_field(v_x2_241, 2);
    V v_a_2428 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_l_2425));
    V v_a_2429 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_op_2426)));
    V v_b_2430 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_r_2427));
    V v_t_2431 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str1)}), v_b_2430));
    V v_t_2432 = (g_std_2edoc_2e_3c_3e(v_a_2429, v_t_2431));
    V v_t_2433 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str2)}), v_t_2432));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2428, v_t_2433);
  }
  case TAG_PRec: {
    V v_o_2434 = heff_field(v_x2_241, 0);
    V v_fs_2435 = heff_field(v_x2_241, 1);
    V v_commas_2436 = heff_field(v_x2_241, 2);
    V v_c_2437 = heff_field(v_x2_241, 3);
    V v_a_2438 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2434)));
    V v_a_2440 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(heff_dup(v_env_240), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam2, 1, 1, (V[]){heff_dup(v_env_240)}), v_fs_2435, heff_dup(v_commas_2436), NTAG(TAG_True)));
    V v_b_2441 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2437)));
    V v_t_2442 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str3)}), v_b_2441));
    V v_t_2443 = (g_std_2edoc_2e_3c_3e(v_a_2440, v_t_2442));
    V v_t_2444 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str4)}), v_t_2443));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2438, v_t_2444);
  }
  case TAG_PField: {
    V v_x_2445 = heff_field(v_x2_241, 0);
    V v_eq_2446 = heff_field(v_x2_241, 1);
    V v_p_2447 = heff_field(v_x2_241, 2);
    V v_a_2448 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_2445)));
    V v_a_2449 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2446)));
    V v_b_2450 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_p_2447));
    V v_t_2451 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str5)}), v_b_2450));
    V v_t_2452 = (g_std_2edoc_2e_3c_3e(v_a_2449, v_t_2451));
    V v_t_2453 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str6)}), v_t_2452));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2448, v_t_2453);
  }
  case TAG_PAs: {
    V v_x_2454 = heff_field(v_x2_241, 0);
    V v_at_2455 = heff_field(v_x2_241, 1);
    V v_p_2456 = heff_field(v_x2_241, 2);
    V v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_2454)));
    V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_at_2455)));
    V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_p_2456));
    V v_t_2460 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2459));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2457, v_t_2460);
  }
  case TAG_PSeg: {
    V v_p_2461 = heff_field(v_x2_241, 0);
    V v_cc_2462 = heff_field(v_x2_241, 1);
    V v_spec_2463 = heff_field(v_x2_241, 2);
    V v_t_2464 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_p_2461));
    V v_t_2465 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_cc_2462)));
    V v_t_2467 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam3, 1, 1, (V[]){v_env_240}), v_spec_2463));
    V v_t_2468 = (g_std_2edoc_2e_3c_3e(v_t_2465, v_t_2467));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2464, v_t_2468);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2epP(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V a_0 = v_env_240; V a_1 = v_p_245; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_245); r_; });
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str0)}), v_t_246));
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam1(V self, V *args) {
  V v_p2_2421 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_env_240; V a_1 = v_p2_2421; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p2_2421); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam2(V self, V *args) {
  V v_p2_2439 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_env_240; V a_1 = v_p2_2439; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p2_2439); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam3(V self, V *args) {
  V v_t_2466 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2466));
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2esig_str0, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2esig_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2esig_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2esig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2esig_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2esig(V v_env_240, V v_cc_241, V v_ty_242) {
top: ;
  V v_a_243 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_241));
  V v_b_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_242}));
  V v_t_245 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2esig_str0)}), v_b_244));
  V v_d_246 = (g_std_2edoc_2e_3c_3e(v_a_243, v_t_245));
  return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2esig_lam0, 1, 1, (V[]){v_d_246})});
}
V g_heff_2esyntax_2efmt_2elayout_2esig_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2esig(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2efmt_2elayout_2esig_lam1(V self, V *args) {
  V v_i_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_249 = heff_intSub(v_k_247, v_i_248);
  if (heff_intEq_c_lent(v_i_249, MK_INT(0LL), 2)) {
    heff_drop(v_i_249);
    return v_d_246;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_249, v_d_246});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2esig_lam0(V self, V *args) {
  V v_k_247 = args[0];
  V v_d_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2esig_lam1, 1, 2, (V[]){v_k_247, v_d_246})});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etfDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etfDoc_str1, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2etfDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etfDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkTF: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_cc_243 = heff_field(v_x2_241, 1);
    V v_ty_244 = heff_field(v_x2_241, 2);
    V v_d_245 = heff_field(v_x2_241, 3);
    V v_a_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_242)));
    V v_b_247 = (g_heff_2esyntax_2efmt_2elayout_2esig(heff_dup(v_env_240), heff_dup(v_cc_243), heff_dup(v_ty_244)));
    V v_t_248 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etfDoc_str0)}), v_b_247));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(v_a_246, v_t_248));
    V v_t_2416;
    switch (heff_tag_of(v_d_245)) {
    case TAG_Nothing: {
      heff_drop(v_env_240);
      v_t_2416 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_x21_2410 = heff_field(v_d_245, 0);
      switch (heff_tag_of(v_x21_2410)) {
      case TAG_MkPair: {
        V v_eq_2411 = heff_field(v_x21_2410, 0);
        V v_d_2412 = heff_field(v_x21_2410, 1);
        V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2411)));
        V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, heff_dup(v_d_2412)}));
        V v_t_2415 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2414));
        v_t_2416 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etfDoc_str1)}), v_t_2415));
        break;
      }
      default: heff_nomatch(v_x21_2410);
      }
      break;
    }
    default: heff_nomatch(v_d_245);
    }
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_249, v_t_2416);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2etfDoc(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str20, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2epD_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam4(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epD_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2epD(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_DImport: {
    V v_t_242 = heff_field(v_x2_241, 0);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_t_242));
  }
  case TAG_DFixity: {
    V v_kw_243 = heff_field(v_x2_241, 0);
    V v_ts_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_243)));
    V v_t_248 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam0, 1, 1, (V[]){v_env_240}), v_ts_244));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_245, v_t_248);
  }
  case TAG_DSig: {
    V v_n_249 = heff_field(v_x2_241, 0);
    V v_cc_2410 = heff_field(v_x2_241, 1);
    V v_ty_2411 = heff_field(v_x2_241, 2);
    V v_a_2412 = (g_list_2efoldl_24f1805635826x1386625471(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_dup(v_env_240), v_n_249));
    V v_b_2413 = (g_heff_2esyntax_2efmt_2elayout_2esig(v_env_240, heff_dup(v_cc_2410), heff_dup(v_ty_2411)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str1)}), v_b_2413));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2412, v_t_2414);
  }
  case TAG_DInstance: {
    V v_kw_2415 = heff_field(v_x2_241, 0);
    V v_n_2416 = heff_field(v_x2_241, 1);
    V v_cc_2417 = heff_field(v_x2_241, 2);
    V v_ty_2418 = heff_field(v_x2_241, 3);
    V v_a_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2415)));
    V v_a_2420 = (g_list_2efoldl_24f1805635826x1386625471(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_dup(v_env_240), v_n_2416));
    V v_b_2421 = (g_heff_2esyntax_2efmt_2elayout_2esig(v_env_240, heff_dup(v_cc_2417), heff_dup(v_ty_2418)));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str2)}), v_b_2421));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str3)}), v_t_2423));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2419, v_t_2424);
  }
  case TAG_DEqn: {
    V v_n_2425 = heff_field(v_x2_241, 0);
    V v_pats_2426 = heff_field(v_x2_241, 1);
    V v_eq_2427 = heff_field(v_x2_241, 2);
    V v_rhs_2428 = heff_field(v_x2_241, 3);
    V v_w_2429 = heff_field(v_x2_241, 4);
    V v_t_2430 = (g_list_2efoldl_24f1805635826x1386625471(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_dup(v_env_240), v_n_2425));
    V v_a_2433 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam1, 1, 1, (V[]){heff_dup(v_env_240)}), v_pats_2426));
    V v_b_2434 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2427)));
    V v_t_2435 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str5)}), v_b_2434));
    V v_t_2436 = (g_std_2edoc_2e_3c_3e(v_a_2433, v_t_2435));
    V v_rhsLast_2437 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_rhs_2428)));
    V v_t_2439;
    switch (heff_tag_of(v_w_2429)) {
    case TAG_Nothing: {
      heff_drop_rec(v_rhsLast_2437, 9);
      v_t_2439 = heff_dup(v_env_240);
      break;
    }
    case TAG_Just: {
      v_t_2439 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), heff_dup(heff_rfield(v_env_240, 3)), heff_dup(heff_rfield(v_env_240, 4)), heff_get_n(v_rhsLast_2437, 7, 9), heff_dup(heff_rfield(v_env_240, 6))});
      break;
    }
    default: heff_nomatch(v_w_2429);
    }
    V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_t_2439, heff_dup(v_rhs_2428)}));
    V v_t_2441 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_rhs_2428)));
    V v_t_2442 = (g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(v_env_240, v_t_2441, v_w_2429));
    V v_t_2443 = (g_std_2edoc_2e_3c_3e(v_t_2440, v_t_2442));
    V v_t_2444 = (g_std_2edoc_2e_3c_3e(v_t_2436, v_t_2443));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2430, v_t_2444);
  }
  case TAG_DData: {
    V v_kw_2445 = heff_field(v_x2_241, 0);
    V v_name_2446 = heff_field(v_x2_241, 1);
    V v_params_2447 = heff_field(v_x2_241, 2);
    V v_universe_2448 = heff_field(v_x2_241, 3);
    V v_alts_2449 = heff_field(v_x2_241, 4);
    V v_a_2450 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2445)));
    V v_b_2451 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2446)));
    V v_t_2452 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str6)}), v_b_2451));
    V v_t_2453 = (g_std_2edoc_2e_3c_3e(v_a_2450, v_t_2452));
    V v_t_2457 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam2, 1, 1, (V[]){heff_dup(v_env_240)}), v_params_2447));
    V v_t_2465;
    switch (heff_tag_of(v_universe_2448)) {
    case TAG_Nothing: {
      v_t_2465 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_x21_2458 = heff_field(v_universe_2448, 0);
      switch (heff_tag_of(v_x21_2458)) {
      case TAG_MkPair: {
        V v_cc_2459 = heff_field(v_x21_2458, 0);
        V v_u_2460 = heff_field(v_x21_2458, 1);
        V v_a_2461 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_cc_2459)));
        V v_b_2462 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), heff_dup(v_u_2460)}));
        V v_t_2463 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str8)}), v_b_2462));
        V v_t_2464 = (g_std_2edoc_2e_3c_3e(v_a_2461, v_t_2463));
        v_t_2465 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str9)}), v_t_2464));
        break;
      }
      default: heff_nomatch(v_x21_2458);
      }
      break;
    }
    default: heff_nomatch(v_universe_2448);
    }
    V v_t_2466 = (g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(v_env_240, heff_dup(v_alts_2449)));
    V v_t_2467 = (g_std_2edoc_2e_3c_3e(v_t_2465, v_t_2466));
    V v_t_2468 = (g_std_2edoc_2e_3c_3e(v_t_2457, v_t_2467));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2453, v_t_2468);
  }
  case TAG_DType: {
    V v_kw_2469 = heff_field(v_x2_241, 0);
    V v_name_2470 = heff_field(v_x2_241, 1);
    V v_params_2471 = heff_field(v_x2_241, 2);
    V v_eq_2472 = heff_field(v_x2_241, 3);
    V v_body_2473 = heff_field(v_x2_241, 4);
    V v_a_2474 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2469)));
    V v_b_2475 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2470)));
    V v_t_2476 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str10)}), v_b_2475));
    V v_t_2477 = (g_std_2edoc_2e_3c_3e(v_a_2474, v_t_2476));
    V v_a_2481 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam3, 1, 1, (V[]){heff_dup(v_env_240)}), v_params_2471));
    V v_b_2482 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2472)));
    V v_t_2483 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str12)}), v_b_2482));
    V v_t_2484 = (g_std_2edoc_2e_3c_3e(v_a_2481, v_t_2483));
    V v_t_2485 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, heff_dup(v_body_2473)}));
    V v_t_2486 = (g_std_2edoc_2e_3c_3e(v_t_2484, v_t_2485));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2477, v_t_2486);
  }
  case TAG_DTheory: {
    V v_kw_2487 = heff_field(v_x2_241, 0);
    V v_name_2488 = heff_field(v_x2_241, 1);
    V v_params_2489 = heff_field(v_x2_241, 2);
    V v_w_2490 = heff_field(v_x2_241, 3);
    V v_fields_2491 = heff_field(v_x2_241, 4);
    V v_a_2492 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2487)));
    V v_b_2493 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2488)));
    V v_t_2494 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str13)}), v_b_2493));
    V v_t_2495 = (g_std_2edoc_2e_3c_3e(v_a_2492, v_t_2494));
    V v_a_2499 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam4, 1, 1, (V[]){heff_dup(v_env_240)}), v_params_2489));
    V v_b_24100 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_w_2490)));
    V v_t_24101 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str15)}), v_b_24100));
    V v_t_24102 = (g_std_2edoc_2e_3c_3e(v_a_2499, v_t_24101));
    V v_t_24103 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(v_env_240, MK_INT(0LL), v_fields_2491));
    V v_t_24104 = (g_std_2edoc_2e_3c_3e(v_t_24102, v_t_24103));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2495, v_t_24104);
  }
  case TAG_DMutual: {
    V v_kw_24105 = heff_field(v_x2_241, 0);
    V v_ds_24106 = heff_field(v_x2_241, 1);
    V v_t_24107 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_24105)));
    V v_t_24108 = (g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(v_env_240, MK_INT(0LL), v_ds_24106));
    V v_t_24109 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_24108));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_24107, v_t_24109);
  }
  case TAG_DPrimitive: {
    V v_kw_24110 = heff_field(v_x2_241, 0);
    V v_x_24111 = heff_field(v_x2_241, 1);
    V v_cc_24112 = heff_field(v_x2_241, 2);
    V v_ty_24113 = heff_field(v_x2_241, 3);
    V v_a_24114 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_24110)));
    V v_a_24115 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_24111)));
    V v_b_24116 = (g_heff_2esyntax_2efmt_2elayout_2esig(v_env_240, heff_dup(v_cc_24112), heff_dup(v_ty_24113)));
    V v_t_24117 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str16)}), v_b_24116));
    V v_t_24118 = (g_std_2edoc_2e_3c_3e(v_a_24115, v_t_24117));
    V v_t_24119 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str17)}), v_t_24118));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_24114, v_t_24119);
  }
  case TAG_DTest: {
    V v_kw_24120 = heff_field(v_x2_241, 0);
    V v_x_24121 = heff_field(v_x2_241, 1);
    V v_a_24122 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_24120)));
    V v_b_24123 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_x_24121)));
    V v_t_24124 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str18)}), v_b_24123));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_24122, v_t_24124);
  }
  case TAG_DWatch: {
    V v_w_24125 = heff_field(v_x2_241, 0);
    V v_e_24126 = heff_field(v_x2_241, 1);
    V v_t_24127 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_w_24125)));
    V v_t_24128 = (g_heff_2esyntax_2ecst_2efirstE(v_e_24126));
    V v_b_24129 = heff_get_n(v_t_24128, 3, 9);
    V v_s_24130 = heff_strSlice(heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_w_24125, 4)), v_b_24129);
    V v_t_24131 = (g_prelude_2eskipSpaces(v_s_24130, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_24132 = (heff_unbox_word(heff_strLength_lent(v_s_24130, 0)) - ((int64_t)1ULL));
    V v_t_24133 = (g_prelude_2eskipSpaces(v_s_24130, heff_box_word(v_t_24132), MK_INT(-1LL)));
    V v_t_24134 = heff_strSlice(v_s_24130, v_t_24131, heff_intAdd(v_t_24133, MK_INT(1LL)));
    V v_t_24143;
    if (heff_strEq_c(v_t_24134, ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str19))) {
      V v_t_24136 = (g_heff_2esyntax_2ecst_2efirstE(v_e_24126));
      V v_a_24137 = heff_get_n(v_t_24136, 3, 9);
      V v_t_24138 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_e_24126)));
      V v_t_24139 = heff_strSlice(heff_get_n(v_env_240, 0, 7), v_a_24137, heff_get_n(v_t_24138, 4, 9));
      V v_t_24140 = ({ V a_0 = v_t_24139; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ecomment(a_0)); heff_drop(v_t_24139); r_; });
      v_t_24143 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str20)}), v_t_24140));
    } else {
      V v_t_24141 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_e_24126)));
      V v_t_24142 = heff_strSlice(heff_get_n(v_env_240, 0, 7), heff_dup(heff_rfield(v_w_24125, 4)), heff_get_n(v_t_24141, 4, 9));
      v_t_24143 = ({ V a_0 = v_t_24142; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ecomment(a_0)); heff_drop(v_t_24142); r_; });
    }
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_24127, v_t_24143);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2epD(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam0(V self, V *args) {
  V v_t_246 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_246));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str0)}), v_t_247));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam1(V self, V *args) {
  V v_p_2431 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432 = ({ V a_0 = v_env_240; V a_1 = v_p_2431; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_2431); r_; });
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str4)}), v_t_2432));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam2(V self, V *args) {
  V v_p_2454 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_p_2454}));
  V v_t_2456 = (g_std_2edoc_2eflatten(v_t_2455));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str7)}), v_t_2456));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam3(V self, V *args) {
  V v_p_2478 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2479 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_p_2478}));
  V v_t_2480 = (g_std_2edoc_2eflatten(v_t_2479));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str11)}), v_t_2480));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam4(V self, V *args) {
  V v_p_2496 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2497 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_p_2496}));
  V v_t_2498 = (g_std_2edoc_2eflatten(v_t_2497));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str14)}), v_t_2498));
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eafterDef_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eafterDef_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_es_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_e_242)) {
    case TAG_DImport: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DFixity: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DSig: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DInstance: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DEqn: {
      V v_n_2414 = heff_dup(heff_field(v_e_242, 0));
      V v_x2_2419 = (g_list_2emap_24s759871588x920431471(v_n_2414));
      V v_t_2422;
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Nil: {
        v_t_2422 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eafterDef_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        V v_xs_2421 = heff_field(v_x2_2419, 1);
        heff_take_n(v_x2_2419, 3ULL, 2);
        v_t_2422 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eafterDef_str1); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2419);
      }
      if (heff_strEq_c_lent(v_t_2422, v_x_240, 1)) {
        heff_drop_tag(v_e_242, 5);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_es_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
      }
    }
    case TAG_DData: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DType: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DTheory: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DMutual: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DPrimitive: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DTest: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    case TAG_DWatch: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    default: return heff_nomatch(v_e_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eafterDef(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eskipped_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eskipped(V v_env_240, V v_above_241, V v_d_242) {
top: ;
  V v_t_2412;
  if ((heff_dup(v_above_241) == NTAG(TAG_True))) {
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_t_244 = heff_take_field(v_t_243, 8);
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop_rec(v_t_243, 9);
      heff_drop(v_t_244);
      v_t_2412 = NTAG(TAG_False);
    } else {
      heff_drop(v_t_244);
      HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_get_n(v_t_243, 7, 9)));
      V v_t_2410;
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_x_249 = v_field_247;
          v_t_2410 = v_x_249;
        } else {
          heff_drop(v_field_247);
          v_t_2410 = NTAG(TAG_Nil);
        }
      }
      V v_x1_2411 = ({ V a_0 = v_t_2410; V r_ = (g_list_2eany_24s2118781542x1794344985(a_0)); heff_drop(v_t_2410); r_; });
      v_t_2412 = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
      heff_drop(v_x1_2411);
    }
  } else {
    v_t_2412 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_t_2412);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2412);
    V v_t_2413 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_t_2414 = heff_take_field(v_t_2413, 8);
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop_rec(v_env_240, 7);
      heff_drop_rec(v_t_2413, 9);
      heff_drop(v_t_2414);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_t_2414);
      HeffT2 v_t_2415 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = heff_get_n(v_t_2413, 7, 9); HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2421;
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        V v_t_2420;
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_x_2419 = v_field_2417;
          v_t_2420 = v_x_2419;
        } else {
          heff_drop(v_field_2417);
          v_t_2420 = NTAG(TAG_Nil);
        }
        v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2420));
      }
      V v_t_2422 = (g_heff_2esyntax_2efmt_2elayout_2enearGo(v_t_2421, NTAG(TAG_Nil)));
      return ({ V a_0 = v_t_2422; V r_ = (g_list_2eany_24s577543654x765608923(a_0)); heff_drop(v_t_2422); r_; });
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eskipped(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eleadLaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadLaid_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadLaid(V v_env_240, V v_ix_241, V v_n_242) {
top: ;
  if (heff_intEq_c_lent(v_n_242, MK_INT(0LL), 2)) {
    heff_drop(v_ix_241);
    heff_drop(v_n_242);
    return v_env_240;
  } else {
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(v_ix_241)));
    V v_t_249;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        v_t_249 = v_x_248;
      } else {
        heff_drop(v_field_246);
        v_t_249 = NTAG(TAG_Nil);
      }
    }
    V v_t_2410 = ({ V a_0 = v_n_242; V a_1 = v_t_249; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_env_240, 1), v_ix_241, v_t_2410));
    return ({ V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_env_240, 125ULL, 7, shape_src__lead__inline__trail__noLead__noTrail__fix, 16371u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eleadLaid(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_ls_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_prelude_2eskipSpaces(v_l_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_l_241, 0)) - ((int64_t)1ULL));
    V v_t_245 = (g_prelude_2eskipSpaces(v_l_241, heff_box_word(v_t_244), MK_INT(-1LL)));
    V v_t_246 = heff_strSlice(heff_dup(v_l_241), v_t_243, heff_intAdd(v_t_245, MK_INT(1LL)));
    if (heff_strEq_c(v_t_246, heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get()))) {
      heff_drop(v_l_241);
      V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str0), heff_hole()});
      V v_u_249 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(v_ls_242, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      V v_t_2410 = (g_prelude_2eskipSpaces(v_l_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_l_241, 0)) - ((int64_t)1ULL));
      V v_t_2412 = (g_prelude_2eskipSpaces(v_l_241, heff_box_word(v_t_2411), MK_INT(-1LL)));
      V v_t_2413 = heff_strSlice(heff_dup(v_l_241), v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2413, ((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str1))) {
        heff_drop(v_l_241);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_ls_242;
        v_x1_240 = t_0;
        goto top;
      } else {
        V v_cell_2415 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_241, heff_hole()});
        V v_u_2416 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(v_ls_242, heff_dup(v_cell_2415)));
        heff_drop(v_u_2416);
        return v_cell_2415;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2ekeptLines(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_ls_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
    V v_t_246 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_245), MK_INT(-1LL)));
    V v_t_247 = heff_strSlice(heff_dup(v_l_242), v_t_244, heff_intAdd(v_t_246, MK_INT(1LL)));
    if (heff_strEq_c(v_t_247, heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get()))) {
      heff_drop(v_l_242);
      V v_cell_249 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_str0), heff_hole()});
      V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_ls_243;
      V t_1 = v_cell_249;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      V v_t_2411 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
      V v_t_2413 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_2412), MK_INT(-1LL)));
      V v_t_2414 = heff_strSlice(heff_dup(v_l_242), v_t_2411, heff_intAdd(v_t_2413, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2414, ((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_str1))) {
        heff_drop(v_l_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_ls_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      } else {
        V v_cell_2416 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_242, heff_hole()});
        V v_u_2417 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2416));
        heff_drop(v_u_2417);
        V t_0 = v_ls_243;
        V t_1 = v_cell_2416;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(a[0], a[1]);
}