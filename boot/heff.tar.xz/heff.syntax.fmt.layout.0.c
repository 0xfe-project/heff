// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_EUSet 22856
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_blank 295177582
#define LBL_comments 142722952
#define LBL_end 310101
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_fix 310927
#define LBL_i 323
#define LBL_imports 10411951
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_lead 9813027
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_pE 10300
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_trail 311979552
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2eprogramGo(V, V);
V g_heff_2esyntax_2ecst_2eprogramGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eprogramGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2efmtLexed(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2efmtLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2efmtLexed_clo;
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed(V, V);
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2efmtParsed_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2enearGo(V, V);
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2esig(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2esig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esig_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etfDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etfDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_clo;
V g_heff_2esyntax_2efmt_2etokens_2eattach(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eattach_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eattach_clo;
V g_list_2eany_24s2118781542x1794344985(V);
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a);
extern Clo g_list_2eany_24s2118781542x1794344985_clo;
V g_list_2eany_24s577543654x765608923(V);
V g_list_2eany_24s577543654x765608923_entry(V self, V *a);
extern Clo g_list_2eany_24s577543654x765608923_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_prelude_2e_2b_2b_24f201610143x1454021782(V, V);
V g_prelude_2e_2b_2b_24f201610143x1454021782_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f201610143x1454021782_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2eflatten(V);
V g_std_2edoc_2eflatten_entry(V self, V *a);
extern Clo g_std_2edoc_2eflatten_clo;
Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2esameOp_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2esameOp(V v_op_240, V v_other_241) {
top: ;
  switch (heff_tag_of(v_other_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_op_240, 9);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_other1_242 = heff_field(v_other_241, 0);
    switch (heff_tag_of(v_other1_242)) {
    case TAG_Atom: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EParen: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Named: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Tup: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Seg: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Braces: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Update: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EUSet: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_InstB: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFSet: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFDefault: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Sum: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ECon: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EField: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ENeg: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_App: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Op: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Ops: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_OpRhs: {
      V v_op2_2462 = heff_field(v_other1_242, 0);
      return heff_strEq(heff_dup(heff_rfield(v_op2_2462, 1)), heff_get_n(v_op_240, 1, 9));
    }
    case TAG_Ann: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_BVar: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_BImp: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_BAnn: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Lam: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Case: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EAlt: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_If: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Do: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ESBind: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_other1_242);
    }
  }
  default: return heff_nomatch(v_other_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2esameOp(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str6, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2epP_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam3(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epP_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2epP(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_args_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_c_242)));
    V v_t_247 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam0, 1, 1, (V[]){v_env_240}), v_args_243));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_244, v_t_247);
  }
  case TAG_PAtom: {
    V v_t_248 = heff_field(v_x2_241, 0);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_t_248));
  }
  case TAG_PParen: {
    V v_o_249 = heff_field(v_x2_241, 0);
    V v_p_2410 = heff_field(v_x2_241, 1);
    V v_c_2411 = heff_field(v_x2_241, 2);
    V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_249)));
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_p_2410));
    V v_t_2414 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2411)));
    V v_t_2415 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2414));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2412, v_t_2415);
  }
  case TAG_PList: {
    V v_o_2416 = heff_field(v_x2_241, 0);
    V v_ps_2417 = heff_field(v_x2_241, 1);
    V v_commas_2418 = heff_field(v_x2_241, 2);
    V v_c_2419 = heff_field(v_x2_241, 3);
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2416)));
    V v_t_2422 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(heff_dup(v_env_240), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam1, 1, 1, (V[]){heff_dup(v_env_240)}), v_ps_2417, heff_dup(v_commas_2418), NTAG(TAG_True)));
    V v_t_2423 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2419)));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2423));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2420, v_t_2424);
  }
  case TAG_POp: {
    V v_l_2425 = heff_field(v_x2_241, 0);
    V v_op_2426 = heff_field(v_x2_241, 1);
    V v_r_2427 = heff_field(v_x2_241, 2);
    V v_a_2428 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_l_2425));
    V v_a_2429 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_op_2426)));
    V v_b_2430 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_r_2427));
    V v_t_2431 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str1)}), v_b_2430));
    V v_t_2432 = (g_std_2edoc_2e_3c_3e(v_a_2429, v_t_2431));
    V v_t_2433 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str2)}), v_t_2432));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2428, v_t_2433);
  }
  case TAG_PRec: {
    V v_o_2434 = heff_field(v_x2_241, 0);
    V v_fs_2435 = heff_field(v_x2_241, 1);
    V v_commas_2436 = heff_field(v_x2_241, 2);
    V v_c_2437 = heff_field(v_x2_241, 3);
    V v_a_2438 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2434)));
    V v_a_2440 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(heff_dup(v_env_240), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam2, 1, 1, (V[]){heff_dup(v_env_240)}), v_fs_2435, heff_dup(v_commas_2436), NTAG(TAG_True)));
    V v_b_2441 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2437)));
    V v_t_2442 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str3)}), v_b_2441));
    V v_t_2443 = (g_std_2edoc_2e_3c_3e(v_a_2440, v_t_2442));
    V v_t_2444 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str4)}), v_t_2443));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2438, v_t_2444);
  }
  case TAG_PField: {
    V v_x_2445 = heff_field(v_x2_241, 0);
    V v_eq_2446 = heff_field(v_x2_241, 1);
    V v_p_2447 = heff_field(v_x2_241, 2);
    V v_a_2448 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_2445)));
    V v_a_2449 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2446)));
    V v_b_2450 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_p_2447));
    V v_t_2451 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str5)}), v_b_2450));
    V v_t_2452 = (g_std_2edoc_2e_3c_3e(v_a_2449, v_t_2451));
    V v_t_2453 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str6)}), v_t_2452));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2448, v_t_2453);
  }
  case TAG_PAs: {
    V v_x_2454 = heff_field(v_x2_241, 0);
    V v_at_2455 = heff_field(v_x2_241, 1);
    V v_p_2456 = heff_field(v_x2_241, 2);
    V v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_2454)));
    V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_at_2455)));
    V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_p_2456));
    V v_t_2460 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2459));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2457, v_t_2460);
  }
  case TAG_PSeg: {
    V v_p_2461 = heff_field(v_x2_241, 0);
    V v_cc_2462 = heff_field(v_x2_241, 1);
    V v_spec_2463 = heff_field(v_x2_241, 2);
    V v_t_2464 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_p_2461));
    V v_t_2465 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_cc_2462)));
    V v_t_2467 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam3, 1, 1, (V[]){v_env_240}), v_spec_2463));
    V v_t_2468 = (g_std_2edoc_2e_3c_3e(v_t_2465, v_t_2467));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2464, v_t_2468);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2epP(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V a_0 = v_env_240; V a_1 = v_p_245; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_245); r_; });
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str0)}), v_t_246));
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam1(V self, V *args) {
  V v_p2_2421 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_env_240; V a_1 = v_p2_2421; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p2_2421); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam2(V self, V *args) {
  V v_p2_2439 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_env_240; V a_1 = v_p2_2439; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p2_2439); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam3(V self, V *args) {
  V v_t_2466 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2466));
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2esig_str0, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2esig_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2esig_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2esig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2esig_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2esig(V v_env_240, V v_cc_241, V v_ty_242) {
top: ;
  V v_a_243 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_241));
  V v_b_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_242}));
  V v_t_245 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2esig_str0)}), v_b_244));
  V v_d_246 = (g_std_2edoc_2e_3c_3e(v_a_243, v_t_245));
  return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2esig_lam0, 1, 1, (V[]){v_d_246})});
}
V g_heff_2esyntax_2efmt_2elayout_2esig_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2esig(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2efmt_2elayout_2esig_lam1(V self, V *args) {
  V v_i_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_249 = heff_intSub(v_k_247, v_i_248);
  if (heff_intEq_c(heff_dup(v_i_249), MK_INT(0LL))) {
    heff_drop(v_i_249);
    return v_d_246;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_249, v_d_246});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2esig_lam0(V self, V *args) {
  V v_k_247 = args[0];
  V v_d_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2esig_lam1, 1, 2, (V[]){v_k_247, v_d_246})});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etfDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etfDoc_str1, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2etfDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etfDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkTF: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_cc_243 = heff_field(v_x2_241, 1);
    V v_ty_244 = heff_field(v_x2_241, 2);
    V v_d_245 = heff_field(v_x2_241, 3);
    V v_a_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_242)));
    V v_b_247 = (g_heff_2esyntax_2efmt_2elayout_2esig(heff_dup(v_env_240), heff_dup(v_cc_243), heff_dup(v_ty_244)));
    V v_t_248 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etfDoc_str0)}), v_b_247));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(v_a_246, v_t_248));
    V v_t_2416;
    switch (heff_tag_of(v_d_245)) {
    case TAG_Nothing: {
      heff_drop(v_env_240);
      v_t_2416 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_x21_2410 = heff_field(v_d_245, 0);
      switch (heff_tag_of(v_x21_2410)) {
      case TAG_MkPair: {
        V v_eq_2411 = heff_field(v_x21_2410, 0);
        V v_d_2412 = heff_field(v_x21_2410, 1);
        V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2411)));
        V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, heff_dup(v_d_2412)}));
        V v_t_2415 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2414));
        v_t_2416 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etfDoc_str1)}), v_t_2415));
        break;
      }
      default: heff_nomatch(v_x21_2410);
      }
      break;
    }
    default: heff_nomatch(v_d_245);
    }
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_249, v_t_2416);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2etfDoc(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str20, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str24, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str26, 0, "");
V g_heff_2esyntax_2efmt_2elayout_2epD_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam4(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epD_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2epD(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_DImport: {
    V v_t_242 = heff_field(v_x2_241, 0);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_t_242));
  }
  case TAG_DFixity: {
    V v_kw_243 = heff_field(v_x2_241, 0);
    V v_ts_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_243)));
    V v_t_248 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam0, 1, 1, (V[]){v_env_240}), v_ts_244));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_245, v_t_248);
  }
  case TAG_DSig: {
    V v_n_249 = heff_field(v_x2_241, 0);
    V v_cc_2410 = heff_field(v_x2_241, 1);
    V v_ty_2411 = heff_field(v_x2_241, 2);
    V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2esyntax_2efmt_2elayout_2etok_clo), 1, (V[]){heff_dup(v_env_240)}));
    V v_a_2413 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), v_t_2412, v_n_249));
    V v_b_2414 = (g_heff_2esyntax_2efmt_2elayout_2esig(v_env_240, heff_dup(v_cc_2410), heff_dup(v_ty_2411)));
    V v_t_2415 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str1)}), v_b_2414));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2413, v_t_2415);
  }
  case TAG_DInstance: {
    V v_kw_2416 = heff_field(v_x2_241, 0);
    V v_n_2417 = heff_field(v_x2_241, 1);
    V v_cc_2418 = heff_field(v_x2_241, 2);
    V v_ty_2419 = heff_field(v_x2_241, 3);
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2416)));
    V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2esyntax_2efmt_2elayout_2etok_clo), 1, (V[]){heff_dup(v_env_240)}));
    V v_a_2422 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), v_t_2421, v_n_2417));
    V v_b_2423 = (g_heff_2esyntax_2efmt_2elayout_2esig(v_env_240, heff_dup(v_cc_2418), heff_dup(v_ty_2419)));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str2)}), v_b_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_a_2422, v_t_2424));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str3)}), v_t_2425));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2426);
  }
  case TAG_DEqn: {
    V v_n_2427 = heff_field(v_x2_241, 0);
    V v_pats_2428 = heff_field(v_x2_241, 1);
    V v_eq_2429 = heff_field(v_x2_241, 2);
    V v_rhs_2430 = heff_field(v_x2_241, 3);
    V v_w_2431 = heff_field(v_x2_241, 4);
    V v_t_2432 = heff_tr(heff_call(((V)&g_heff_2esyntax_2efmt_2elayout_2etok_clo), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_2433 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), v_t_2432, v_n_2427));
    V v_a_2436 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam1, 1, 1, (V[]){heff_dup(v_env_240)}), v_pats_2428));
    V v_b_2437 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2429)));
    V v_t_2438 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str5)}), v_b_2437));
    V v_t_2439 = (g_std_2edoc_2e_3c_3e(v_a_2436, v_t_2438));
    V v_rhsLast_2440 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_rhs_2430)));
    V v_t_2442;
    switch (heff_tag_of(v_w_2431)) {
    case TAG_Nothing: {
      heff_drop_rec(v_rhsLast_2440, 9);
      v_t_2442 = heff_dup(v_env_240);
      break;
    }
    case TAG_Just: {
      v_t_2442 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), heff_dup(heff_rfield(v_env_240, 3)), heff_dup(heff_rfield(v_env_240, 4)), heff_get_n(v_rhsLast_2440, 7, 9), heff_dup(heff_rfield(v_env_240, 6))});
      break;
    }
    default: heff_nomatch(v_w_2431);
    }
    V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_t_2442, heff_dup(v_rhs_2430)}));
    V v_t_2444 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_rhs_2430)));
    V v_t_2445 = (g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(v_env_240, v_t_2444, v_w_2431));
    V v_t_2446 = (g_std_2edoc_2e_3c_3e(v_t_2443, v_t_2445));
    V v_t_2447 = (g_std_2edoc_2e_3c_3e(v_t_2439, v_t_2446));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2433, v_t_2447);
  }
  case TAG_DData: {
    V v_kw_2448 = heff_field(v_x2_241, 0);
    V v_name_2449 = heff_field(v_x2_241, 1);
    V v_params_2450 = heff_field(v_x2_241, 2);
    V v_universe_2451 = heff_field(v_x2_241, 3);
    V v_alts_2452 = heff_field(v_x2_241, 4);
    V v_a_2453 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2448)));
    V v_b_2454 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2449)));
    V v_t_2455 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str6)}), v_b_2454));
    V v_t_2456 = (g_std_2edoc_2e_3c_3e(v_a_2453, v_t_2455));
    V v_t_2460 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam2, 1, 1, (V[]){heff_dup(v_env_240)}), v_params_2450));
    V v_t_2468;
    switch (heff_tag_of(v_universe_2451)) {
    case TAG_Nothing: {
      v_t_2468 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_x21_2461 = heff_field(v_universe_2451, 0);
      switch (heff_tag_of(v_x21_2461)) {
      case TAG_MkPair: {
        V v_cc_2462 = heff_field(v_x21_2461, 0);
        V v_u_2463 = heff_field(v_x21_2461, 1);
        V v_a_2464 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_cc_2462)));
        V v_b_2465 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), heff_dup(v_u_2463)}));
        V v_t_2466 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str8)}), v_b_2465));
        V v_t_2467 = (g_std_2edoc_2e_3c_3e(v_a_2464, v_t_2466));
        v_t_2468 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str9)}), v_t_2467));
        break;
      }
      default: heff_nomatch(v_x21_2461);
      }
      break;
    }
    default: heff_nomatch(v_universe_2451);
    }
    V v_t_2469 = (g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(v_env_240, heff_dup(v_alts_2452)));
    V v_t_2470 = (g_std_2edoc_2e_3c_3e(v_t_2468, v_t_2469));
    V v_t_2471 = (g_std_2edoc_2e_3c_3e(v_t_2460, v_t_2470));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2456, v_t_2471);
  }
  case TAG_DType: {
    V v_kw_2472 = heff_field(v_x2_241, 0);
    V v_name_2473 = heff_field(v_x2_241, 1);
    V v_params_2474 = heff_field(v_x2_241, 2);
    V v_eq_2475 = heff_field(v_x2_241, 3);
    V v_body_2476 = heff_field(v_x2_241, 4);
    V v_a_2477 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2472)));
    V v_b_2478 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2473)));
    V v_t_2479 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str10)}), v_b_2478));
    V v_t_2480 = (g_std_2edoc_2e_3c_3e(v_a_2477, v_t_2479));
    V v_a_2484 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam3, 1, 1, (V[]){heff_dup(v_env_240)}), v_params_2474));
    V v_b_2485 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2475)));
    V v_t_2486 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str12)}), v_b_2485));
    V v_t_2487 = (g_std_2edoc_2e_3c_3e(v_a_2484, v_t_2486));
    V v_t_2488 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, heff_dup(v_body_2476)}));
    V v_t_2489 = (g_std_2edoc_2e_3c_3e(v_t_2487, v_t_2488));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2480, v_t_2489);
  }
  case TAG_DTheory: {
    V v_kw_2490 = heff_field(v_x2_241, 0);
    V v_name_2491 = heff_field(v_x2_241, 1);
    V v_params_2492 = heff_field(v_x2_241, 2);
    V v_w_2493 = heff_field(v_x2_241, 3);
    V v_fields_2494 = heff_field(v_x2_241, 4);
    V v_a_2495 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2490)));
    V v_b_2496 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2491)));
    V v_t_2497 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str13)}), v_b_2496));
    V v_t_2498 = (g_std_2edoc_2e_3c_3e(v_a_2495, v_t_2497));
    V v_a_24102 = (g_list_2efoldl_24f1559904364x1248618624(heff_dup(g_std_2edoc_2eemptyDoc_get()), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam4, 1, 1, (V[]){heff_dup(v_env_240)}), v_params_2492));
    V v_b_24103 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_w_2493)));
    V v_t_24104 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str15)}), v_b_24103));
    V v_t_24105 = (g_std_2edoc_2e_3c_3e(v_a_24102, v_t_24104));
    V v_t_24106 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(v_env_240, MK_INT(0LL), v_fields_2494));
    V v_t_24107 = (g_std_2edoc_2e_3c_3e(v_t_24105, v_t_24106));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2498, v_t_24107);
  }
  case TAG_DPrimitive: {
    V v_kw_24108 = heff_field(v_x2_241, 0);
    V v_x_24109 = heff_field(v_x2_241, 1);
    V v_cc_24110 = heff_field(v_x2_241, 2);
    V v_ty_24111 = heff_field(v_x2_241, 3);
    V v_a_24112 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_24108)));
    V v_a_24113 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_24109)));
    V v_b_24114 = (g_heff_2esyntax_2efmt_2elayout_2esig(v_env_240, heff_dup(v_cc_24110), heff_dup(v_ty_24111)));
    V v_t_24115 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str16)}), v_b_24114));
    V v_t_24116 = (g_std_2edoc_2e_3c_3e(v_a_24113, v_t_24115));
    V v_t_24117 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str17)}), v_t_24116));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_24112, v_t_24117);
  }
  case TAG_DTest: {
    V v_kw_24118 = heff_field(v_x2_241, 0);
    V v_x_24119 = heff_field(v_x2_241, 1);
    V v_a_24120 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_24118)));
    V v_b_24121 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_x_24119)));
    V v_t_24122 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str18)}), v_b_24121));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_24120, v_t_24122);
  }
  case TAG_DWatch: {
    V v_w_24123 = heff_field(v_x2_241, 0);
    V v_e_24124 = heff_field(v_x2_241, 1);
    V v_t_24125 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_w_24123)));
    V v_t_24126 = (g_heff_2esyntax_2ecst_2efirstE(v_e_24124));
    V v_b_24127 = heff_get_n(v_t_24126, 3, 9);
    V v_s_24128 = heff_strSlice(heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_w_24123, 4)), v_b_24127);
    V v_t_24129 = (g_prelude_2eskipSpaces(heff_dup(v_s_24128), MK_INT(0LL), MK_INT(1LL)));
    V v_t_24130 = heff_intSub(heff_strLength(heff_dup(v_s_24128)), MK_INT(1LL));
    V v_t_24131 = (g_prelude_2eskipSpaces(heff_dup(v_s_24128), v_t_24130, MK_INT(-1LL)));
    V v_t_24132 = heff_strSlice(v_s_24128, v_t_24129, heff_intAdd(v_t_24131, MK_INT(1LL)));
    V v_t_24151;
    if (heff_strEq_c(v_t_24132, ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str19))) {
      V v_t_24134 = (g_heff_2esyntax_2ecst_2efirstE(v_e_24124));
      V v_a_24135 = heff_get_n(v_t_24134, 3, 9);
      V v_t_24136 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_e_24124)));
      V v_t_24137 = heff_strSlice(heff_get_n(v_env_240, 0, 7), v_a_24135, heff_get_n(v_t_24136, 4, 9));
      V v_x2_24138 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str20), v_t_24137, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_s_24141;
      switch (heff_tag_of(v_x2_24138)) {
      case TAG_Nil: {
        v_s_24141 = ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str21);
        break;
      }
      case TAG_Cons: {
        V v_x_24139 = heff_field(v_x2_24138, 0);
        V v_xs_24140 = heff_field(v_x2_24138, 1);
        heff_take_n(v_x2_24138, 3ULL, 2);
        v_s_24141 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_24139; V a_2 = v_xs_24140; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24140); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24138);
      }
      V v_t_24143;
      if (heff_strEq_c(heff_dup(v_s_24141), ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str22))) {
        heff_drop(v_s_24141);
        v_t_24143 = NTAG(TAG_None);
      } else {
        v_t_24143 = heff_tag_n(TAG_Text, 1, (V[]){v_s_24141});
      }
      v_t_24151 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str23)}), v_t_24143));
    } else {
      V v_t_24144 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_e_24124)));
      V v_t_24145 = heff_strSlice(heff_get_n(v_env_240, 0, 7), heff_dup(heff_rfield(v_w_24123, 4)), heff_get_n(v_t_24144, 4, 9));
      V v_x2_24146 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str24), v_t_24145, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_s_24149;
      switch (heff_tag_of(v_x2_24146)) {
      case TAG_Nil: {
        v_s_24149 = ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str25);
        break;
      }
      case TAG_Cons: {
        V v_x_24147 = heff_field(v_x2_24146, 0);
        V v_xs_24148 = heff_field(v_x2_24146, 1);
        heff_take_n(v_x2_24146, 3ULL, 2);
        v_s_24149 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_24147; V a_2 = v_xs_24148; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24148); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24146);
      }
      if (heff_strEq_c(heff_dup(v_s_24149), ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str26))) {
        heff_drop(v_s_24149);
        v_t_24151 = NTAG(TAG_None);
      } else {
        v_t_24151 = heff_tag_n(TAG_Text, 1, (V[]){v_s_24149});
      }
    }
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_24125, v_t_24151);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2epD(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam0(V self, V *args) {
  V v_t_246 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_246));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str0)}), v_t_247));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam1(V self, V *args) {
  V v_p_2434 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = ({ V a_0 = v_env_240; V a_1 = v_p_2434; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_2434); r_; });
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str4)}), v_t_2435));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam2(V self, V *args) {
  V v_p_2457 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_p_2457}));
  V v_t_2459 = (g_std_2edoc_2eflatten(v_t_2458));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str7)}), v_t_2459));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam3(V self, V *args) {
  V v_p_2481 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2482 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_p_2481}));
  V v_t_2483 = (g_std_2edoc_2eflatten(v_t_2482));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str11)}), v_t_2483));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam4(V self, V *args) {
  V v_p_2499 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24100 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_p_2499}));
  V v_t_24101 = (g_std_2edoc_2eflatten(v_t_24100));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str14)}), v_t_24101));
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eafterDef_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eafterDef_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_es_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2446;
    switch (heff_tag_of(v_e_242)) {
    case TAG_DImport: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      V v_n_2414 = heff_dup(heff_field(v_e_242, 0));
      V v_x2_2419 = (g_list_2emap_24s759871588x920431471(v_n_2414));
      V v_t_2422;
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Nil: {
        v_t_2422 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eafterDef_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        V v_xs_2421 = heff_field(v_x2_2419, 1);
        heff_take_n(v_x2_2419, 3ULL, 2);
        v_t_2422 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eafterDef_str1); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2419);
      }
      v_t_2446 = heff_strEq(v_t_2422, heff_dup(v_x_240));
      break;
    }
    case TAG_DData: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_242);
    }
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_e_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_2446);
      V t_0 = v_x_240;
      V t_1 = v_es_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_240);
      heff_drop(v_t_2446);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eafterDef(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eskipped_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eskipped(V v_env_240, V v_above_241, V v_d_242) {
top: ;
  if ((heff_dup(v_above_241) == NTAG(TAG_True))) {
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_t_244 = heff_take_field(v_t_243, 8);
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop_rec(v_t_243, 9);
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
      V v_t_246 = heff_take_field(v_t_245, 8);
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop_rec(v_env_240, 7);
        heff_drop_rec(v_t_245, 9);
        heff_drop(v_t_246);
        return NTAG(TAG_False);
      } else {
        heff_drop(v_t_246);
        V v_x2_247 = ({ V a_0 = heff_get_n(v_t_245, 7, 9); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_249;
        switch (heff_tag_of(v_x2_247)) {
        case TAG_Nothing: {
          v_t_249 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_248 = heff_field(v_x2_247, 0);
          heff_take_n(v_x2_247, 1ULL, 1);
          v_t_249 = v_x_248;
          break;
        }
        default: heff_nomatch(v_x2_247);
        }
        V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_249));
        V v_t_2411 = (g_heff_2esyntax_2efmt_2elayout_2enearGo(v_t_2410, NTAG(TAG_Nil)));
        return ({ V a_0 = v_t_2411; V r_ = (g_list_2eany_24s577543654x765608923(a_0)); heff_drop(v_t_2411); r_; });
      }
    } else {
      heff_drop(v_t_244);
      V v_x2_2412 = (g_map_2elookup_24s567992785x1569911877(heff_get_n(v_t_243, 7, 9), heff_rfield(v_env_240, 1)));
      V v_t_2414;
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nothing: {
        v_t_2414 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        heff_take_n(v_x2_2412, 1ULL, 1);
        v_t_2414 = v_x_2413;
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
      V v_x1_2415 = ({ V a_0 = v_t_2414; V r_ = (g_list_2eany_24s2118781542x1794344985(a_0)); heff_drop(v_t_2414); r_; });
      if ((heff_dup(v_x1_2415) == NTAG(TAG_True))) {
        heff_drop(v_x1_2415);
        V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
        V v_t_2417 = heff_take_field(v_t_2416, 8);
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop_rec(v_env_240, 7);
          heff_drop_rec(v_t_2416, 9);
          heff_drop(v_t_2417);
          return NTAG(TAG_False);
        } else {
          heff_drop(v_t_2417);
          V v_x2_2418 = ({ V a_0 = heff_get_n(v_t_2416, 7, 9); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
          V v_t_2420;
          switch (heff_tag_of(v_x2_2418)) {
          case TAG_Nothing: {
            v_t_2420 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Just: {
            V v_x_2419 = heff_field(v_x2_2418, 0);
            heff_take_n(v_x2_2418, 1ULL, 1);
            v_t_2420 = v_x_2419;
            break;
          }
          default: heff_nomatch(v_x2_2418);
          }
          V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2420));
          V v_t_2422 = (g_heff_2esyntax_2efmt_2elayout_2enearGo(v_t_2421, NTAG(TAG_Nil)));
          return ({ V a_0 = v_t_2422; V r_ = (g_list_2eany_24s577543654x765608923(a_0)); heff_drop(v_t_2422); r_; });
        }
      } else {
        heff_drop_rec(v_env_240, 7);
        heff_drop(v_x1_2415);
        return NTAG(TAG_True);
      }
    }
  } else {
    V v_t_2423 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_t_2424 = heff_take_field(v_t_2423, 8);
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop_rec(v_env_240, 7);
      heff_drop_rec(v_t_2423, 9);
      heff_drop(v_t_2424);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_t_2424);
      V v_x2_2425 = ({ V a_0 = heff_get_n(v_t_2423, 7, 9); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2427;
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_Nothing: {
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2426 = heff_field(v_x2_2425, 0);
        heff_take_n(v_x2_2425, 1ULL, 1);
        v_t_2427 = v_x_2426;
        break;
      }
      default: heff_nomatch(v_x2_2425);
      }
      V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2427));
      V v_t_2429 = (g_heff_2esyntax_2efmt_2elayout_2enearGo(v_t_2428, NTAG(TAG_Nil)));
      return ({ V a_0 = v_t_2429; V r_ = (g_list_2eany_24s577543654x765608923(a_0)); heff_drop(v_t_2429); r_; });
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eskipped(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_ls_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), MK_INT(0LL), MK_INT(1LL)));
    V v_t_244 = heff_intSub(heff_strLength(heff_dup(v_l_241)), MK_INT(1LL));
    V v_t_245 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), v_t_244, MK_INT(-1LL)));
    V v_t_246 = heff_strSlice(heff_dup(v_l_241), v_t_243, heff_intAdd(v_t_245, MK_INT(1LL)));
    if (heff_strEq_c(v_t_246, heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get()))) {
      heff_drop(v_l_241);
      V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str0), heff_hole()});
      V v_u_249 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(v_ls_242, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      V v_t_2410 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), MK_INT(0LL), MK_INT(1LL)));
      V v_t_2411 = heff_intSub(heff_strLength(heff_dup(v_l_241)), MK_INT(1LL));
      V v_t_2412 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), v_t_2411, MK_INT(-1LL)));
      V v_t_2413 = heff_strSlice(heff_dup(v_l_241), v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2413, ((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str1))) {
        heff_drop(v_l_241);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_ls_242;
        v_x1_240 = t_0;
        goto top;
      } else {
        V v_cell_2415 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_241, heff_hole()});
        V v_u_2416 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(v_ls_242, heff_dup(v_cell_2415)));
        heff_drop(v_u_2416);
        return v_cell_2415;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2ekeptLines(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_ls_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_prelude_2eskipSpaces(heff_dup(v_l_242), MK_INT(0LL), MK_INT(1LL)));
    V v_t_245 = heff_intSub(heff_strLength(heff_dup(v_l_242)), MK_INT(1LL));
    V v_t_246 = (g_prelude_2eskipSpaces(heff_dup(v_l_242), v_t_245, MK_INT(-1LL)));
    V v_t_247 = heff_strSlice(heff_dup(v_l_242), v_t_244, heff_intAdd(v_t_246, MK_INT(1LL)));
    if (heff_strEq_c(v_t_247, heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get()))) {
      heff_drop(v_l_242);
      V v_cell_249 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_str0), heff_hole()});
      V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_ls_243;
      V t_1 = v_cell_249;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      V v_t_2411 = (g_prelude_2eskipSpaces(heff_dup(v_l_242), MK_INT(0LL), MK_INT(1LL)));
      V v_t_2412 = heff_intSub(heff_strLength(heff_dup(v_l_242)), MK_INT(1LL));
      V v_t_2413 = (g_prelude_2eskipSpaces(heff_dup(v_l_242), v_t_2412, MK_INT(-1LL)));
      V v_t_2414 = heff_strSlice(heff_dup(v_l_242), v_t_2411, heff_intAdd(v_t_2413, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2414, ((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_str1))) {
        heff_drop(v_l_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_ls_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      } else {
        V v_cell_2416 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_242, heff_hole()});
        V v_u_2417 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2416));
        heff_drop(v_u_2417);
        V t_0 = v_ls_243;
        V t_1 = v_cell_2416;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2ekeptLines_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2efmtLexed_str0, 21, "the file does not lex");
Clo g_heff_2esyntax_2efmt_2elayout_2efmtLexed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2efmtLexed_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2efmtLexed(V v_f_240, V v_src_241, V v_hdr_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_247 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_f_240);
    heff_drop(v_src_241);
    heff_drop_rec(v_hdr_242, 2);
    heff_drop_rec(v_l_243, 3);
    heff_drop(v_t_247);
    return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2efmtLexed_str0)});
  } else {
    heff_drop(v_t_247);
    V v_t_248 = (g_prelude_2e_2b_2b_24f201610143x1454021782(heff_take_field(v_l_243, 0), heff_get_n(v_hdr_242, 0, 2)));
    V v_t_249 = (g_list_2esortBy_24s88152486x2058486153(v_t_248));
    V v_at_2410 = (g_heff_2esyntax_2efmt_2etokens_2eattach(v_src_241, v_t_249, heff_get_n(v_l_243, 2, 3)));
    V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_at_2410, 1)), 0, 7);
    V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_at_2410, 1)), 1, 7);
    V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_at_2410, 1)), 2, 7);
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_at_2410, 1)), 3, 7);
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_at_2410, 1)), 4, 7);
    V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_at_2410, 1)), 5, 7);
    V v_at_2417 = ({ V rv_1 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){v_t_2411, v_t_2412, v_t_2413, v_t_2414, v_t_2415, v_t_2416, v_f_240}); V rr_ = heff_rec_reuse_nf(v_at_2410, 1ULL, 2, shape_toks__env, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    V v_t_2419 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_at_2417, 0)), MK_INT(0LL), MK_INT(0LL), v_t_2418, MK_INT(0LL)});
    V v_t_2420 = (g_heff_2esyntax_2ecst_2eprogramGo(v_t_2419, NTAG(TAG_Nil)));
    return (g_heff_2esyntax_2efmt_2elayout_2efmtParsed(v_at_2417, v_t_2420));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2efmtLexed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2efmtLexed(a[0], a[1], a[2], a[3]);
}