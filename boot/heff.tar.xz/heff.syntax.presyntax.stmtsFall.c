// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWord 44207
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_list_2eany_24s2049730270x433866075(V);
V g_list_2eany_24s2049730270x433866075_entry(V self, V *a);
extern Clo g_list_2eany_24s2049730270x433866075_clo;
V g_list_2eany_24s806340782x1757450604(V);
V g_list_2eany_24s806340782x1757450604_entry(V self, V *a);
extern Clo g_list_2eany_24s806340782x1757450604_clo;
Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_True);
    }
    case TAG_ETag: {
      return NTAG(TAG_True);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EString: {
      return NTAG(TAG_True);
    }
    case TAG_EBinary: {
      return NTAG(TAG_True);
    }
    case TAG_ERune: {
      return NTAG(TAG_True);
    }
    case TAG_EWord: {
      return NTAG(TAG_True);
    }
    case TAG_EApp: {
      return NTAG(TAG_True);
    }
    case TAG_EProject: {
      return NTAG(TAG_True);
    }
    case TAG_ENamed: {
      return NTAG(TAG_True);
    }
    case TAG_EPi: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_True);
    }
    case TAG_EAnn: {
      return NTAG(TAG_True);
    }
    case TAG_ESpec: {
      return NTAG(TAG_True);
    }
    case TAG_ESig: {
      return NTAG(TAG_True);
    }
    case TAG_ESum: {
      return NTAG(TAG_True);
    }
    case TAG_EStruct: {
      return NTAG(TAG_True);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_True);
    }
    case TAG_EMatch: {
      V v_alts_2433 = heff_field(v_x11_241, 1);
      V v_x1_2434 = (g_list_2eany_24s806340782x1757450604(v_alts_2433));
      if ((heff_dup(v_x1_2434) == NTAG(TAG_True))) {
        heff_drop(v_x1_2434);
        HEFF_LAST return g_list_2eany_24s2049730270x433866075(heff_dup(v_alts_2433));
      } else {
        heff_drop(v_x1_2434);
        return NTAG(TAG_True);
      }
    }
    case TAG_ELetIn: {
      return NTAG(TAG_True);
    }
    case TAG_EDo: {
      return NTAG(TAG_True);
    }
    case TAG_ELocal: {
      return NTAG(TAG_True);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_True);
    }
    case TAG_EAssign: {
      return NTAG(TAG_True);
    }
    case TAG_EWhile: {
      return NTAG(TAG_True);
    }
    case TAG_EFor: {
      return NTAG(TAG_True);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_True);
    }
    case TAG_EBreak: {
      return NTAG(TAG_False);
    }
    case TAG_EContinue: {
      return NTAG(TAG_False);
    }
    case TAG_EReturn: {
      return NTAG(TAG_False);
    }
    case TAG_ENest: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(a0); heff_drop(a0); return r;
}